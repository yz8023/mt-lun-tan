# MTForum — MT 论坛第三方客户端

[bbs.binmt.cc](https://bbs.binmt.cc/) 的第三方 Android 客户端。原生 Java + Material Design，覆盖板块浏览、帖子阅读、回复/发帖、个人中心、**多账号登录与切换**、**多账号自动签到**、AI 自动回复。

当前版本：**v5.22（versionCode 57）**

---

## v5.22：Markdown 导入 · 用户留言板 · 本机只读 MCP

- 发帖、编辑与回复均可将常见 Markdown 转为 Discuz BBCode；提供转换预览、复制、插入光标或替换正文，旧 BBCode 实时预览保持原样。
- 新增用户空间留言板：分页浏览、发布、回复、编辑和删除（仅当论坛页面提供相应权限链接时显示操作）。
- 恢复默认关闭的只读 MCP：只绑定 `127.0.0.1:9797`，Bearer Token 鉴权，含论坛/帖子/用户/搜索/通知等只读工具；不含 Cloudflare 隧道、写入工具或认证材料输出。
- 通知角标按账号隔离，并可选择将同帖通知批量标记已读；搜索历史可逐项删除；快速跳转支持链接。
- 构建源码包不包含 keystore、签名属性或密码。Debug 构建无需签名；Release 签名通过本地私有配置或 CI Secrets 提供。

## v5.21：链接打开修复 · 下载前确认 · 解锁随机池

- 链接打开统一跟随“应用内/系统浏览器”设置；纯文本支持 http、https、www 与常见裸域名（含 .cn）。
- 应用内浏览器下载文件前会展示文件名/大小，并可复制直链、取消或确认下载。
- 默认自动解锁回复候选逐行显示，可查看、编辑和恢复；每次解锁按标题适用情况随机挑选。

## v5.20：主页提速 · 回复图片 · 过滤语义分离

- 他人主页不再串行抓取当前账号最多 50 页关注列表后才显示；从资料页本身解析关注状态。
- 回复图片修正 ImageSpan 加载完成后的实际 bounds，避免一直按小占位尺寸排版；补充 `data-zoomfile` 等原图属性。
- 「屏蔽灌水回复」采用整条精准匹配；「关键词匹配」是独立的包含匹配开关和自定义词条列表。
- 默认精准过滤继续识别自动解锁完整模板；作者黑名单保持独立。

## v5.19：回复关键词过滤 · 图片/表情 · 下载命名与链接路由

- 回复关键词包含匹配、自动解锁模板识别；回复图片解析 Discuz 原图属性和签名附件 aid。
- 首页单图使用完整卡片宽度，双图按容器宽度固定尺寸居中裁切；Discuz 表情保持行内显示。
- 附件下载前展示文件名并支持复制直链；回复链接遵循应用内/系统浏览器设置。

## v5.18：评论区图片原图显示

- 回复图片渲染前查找 `file`、`zoomfile`、懒加载原图属性和图片外层直接附件链接；带 Discuz 签名 aid 时可补全原图附件路由。
- 对附件下载链接追加 `nothumb=yes`，明确请求原图；较大 CDN 图片地址保持原样，不改写无法确认来源的小图地址。
- 回复图片按评论正文可用宽度等比显示，避免把可用的原图错误地降级为小缩略图。

## v5.17：回复黑名单精准/模糊匹配 · 屏蔽模板灌水回复

- 帖子详情页新增回复内容黑名单词条（每行一条）；支持**精准匹配**（全文相等）和**模糊匹配**（包含即命中），默认精准。
- 新增「屏蔽灌水回复」开关，默认开启；过滤纯填充/客套模板，以及「帖子标题 + 客套语」，尽量保留有实际信息的回复。
- 过滤只改变本地回复列表显示，不删除论坛内容，也不影响论坛原始回复数。

## v5.16：安装包瘦身（20.8 → 3.8 MB）· 移除 MCP · 侧边栏折叠 · 首页图片固定尺寸 · 高刷申请

- **移除 MCP 功能**（顶栏按钮、设置入口、前台服务、公网隧道一并删除）。该功能用户判定无效，
  且它是唯一需要内置 cloudflared 的地方。
- **安装包瘦身**：cloudflared 一个文件压缩后就 17 MB，占整个 APK 的 **82%**（实测 20.81 MB → 去掉后约 3.8 MB）。
  同时去掉已无用的 `extractNativeLibs` 与 `FOREGROUND_SERVICE_SPECIAL_USE` 权限。
- **侧边栏分区折叠**：账号 / AI 自动化 / 显示 / 其它四块可点击收起展开，状态记忆；默认只展开「显示」。
- **首页图片**：单帖最多 2 张（已是原要求），改为**固定尺寸居中裁切**（两图各 4:3，单图 150dp），
  列表不再被长截图撑高、每张卡片高度一致。
- **高刷新率**：新增「请求高刷新率」开关（默认开）。系统对未主动申请的第三方 App 常按 60Hz 合成 ——
  这解释了「为什么 FPS 锁 60」；FPS 浮层现在同时显示「屏 xHz」以便区分布局与系统限制。

## v4.7：修复 Android 隧道 DNS · 帖子原图识别

- （v5.16 已整体移除 MCP 与隧道功能）App 使用 Android 网络栈注册 Quick Tunnel，并预解析 Cloudflare 边缘 IP，绕过 cloudflared 误连 `[::1]:53` 的 DNS 问题。
- 修复 Comiis 的 `comiis_loadimages=1` 被当成图片 URL，导致正文请求 `/1` 并显示站点随机表情/占位图。
- 主楼、评论、列表和离线页面只接受真实图片候选，普通文件名含 face/icon 不再被误判成表情。

## v4.6：顶栏 MCP · 修复 cloudflared 参数

- MCP 改到首页右上角原 AI 助手图标位置，移除不符合整体主题的大卡片；图标跟随主题色和现有毛玻璃按钮样式。
- 修复 cloudflared 代码 1：严格使用官方 `cloudflared tunnel --url` 参数顺序，避免把全局参数放在子命令后触发 usage 退出。
- 点击图标启用/重试，连接后再次点击一键复制完整配置；长按进入详细设置。

## v4.5：首页一键 MCP · 修复隧道退出

- 首页顶部直接启用公网 MCP，并实时显示连接状态。
- 使用 cloudflared 官方 Quick Tunnel 启动方式，修复临时配置导致的退出代码 1。
- 一次复制包含公网地址与授权头的完整 JSON，直接整体交给支持 MCP 的 AI。

## v4.4：真正内置公网 MCP · 完整功能审计 · 导读与设置重排

- APK 内置经 SHA256 校验的官方 arm64 `cloudflared`，App 内一键生成免费公网 HTTPS MCP 地址，无需自行部署第三方隧道。
- MCP 以前台服务保活，支持自动重连、启动恢复、Token 撤销、Host/Origin 防护、只读白名单、脱敏与审计。
- 对照 `qcxs/mtbbs_app` 完成论坛功能审计；首页补齐新帖、最新回复、热门、精华四类导读。
- 设置重新按账号、外观、网络浏览、AI 工具、关于五类排版；保留浏览器、认证图片、登录键盘与回复编辑等修复。

详见 [CHANGELOG.md](CHANGELOG.md) 与 [功能审计](docs/MTBBS_FEATURE_AUDIT.md)。

## v3.8：自动解锁重复回复真因 · 日志可复制 · 侧边栏统一

重复回复的真因是 ThreadDetailActivity 里还有第二条独立解锁链路(maybeAutoUnlock →
unlockSingleThread)完全没有防重，已删除并补齐保护；日志卡片可选中复制；
侧边栏改为与底栏同款悬浮胶囊、共用同一档不透明度。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v3.7：图片消失真因 · 记录中心双模式

图片消失是漏了 Comiis 模板的 comiis_loadimages 懒加载属性；
记录中心支持简洁/详细双模式、卡片可复制可打开、运行日志按标签着色；
补齐主列表错峰进场与点赞弹性反馈。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v3.6：删除回复 · 图片消失 · 记录中心

删除改为「整张编辑表单原样回提」不再猜参数；修图片 URL 相对路径/占位图导致消失；
新增记录中心页面（浏览历史/自动解锁/加载耗时/运行日志，卡片式可点击）。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v3.5：紧急修复

修复对隐藏帖反复自动回复（三因叠加）与删除自己回复无效（参数错 + 从不校验响应）。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v3.4：角标误报 · 隐藏标注 · 图片全宽 · 主题透明度

角标基线按账号隔离（修「全部历史变新消息」）；隐藏标记落盘；长按改复制链接、
拉黑挪进帖子；原位图片全宽显示原图；主题三档不透明度可调。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v3.3：渐变字 · 附件下载 · 渲染耗时埋点

渐变字（8 种预设，两色平滑插值）；附件解析与下载（带金币消耗二次确认）；
新增渲染耗时埋点定位「感觉慢」的真凶。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v3.2：BBCode 编辑器 · 浏览历史

实时预览 + 21 个标签预设 + RGB 取色器 + 彩虹字；浏览历史；
修复隐藏帖标签不显示、主题色全局不生效；耗时日志加「本次请求 N 个」。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v3.1：图片点击修对 · 帖子秒开 · 回复框重做

触摸命中测试替代无效的 ClickableSpan；帖子页内存缓存（LRU 8 篇）实现秒开；
回复框修输入法遮挡/滑动带走/长内容，新增 BBCode 预览与 12 个常用标签预设（发帖页同样支持）。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v3.0：进帖慢的真正根因

实测日志显示真实网络只要 320ms、解析 5–80ms，慢出来的 2000ms 全是节流器罚站。
改为前台/后台两条车道：用户导航不排队，只压后台轮询。
另修图片原位显示（底部重复 + 点不开）、日志分三段。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.9：七项反馈修复

独立 PerfLog 加载耗时日志（帖子+用户页）、修复解锁开关改过头、隐藏帖「回复」不跳浏览器、
AI 总结补上列表卡那个、隐藏帖列表打标、签到明细不被空值覆盖、正文图片位置可配。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.8：七项反馈修复

签到时间/奖励显示、自动签到状态可见、进帖变快（去掉缓存破坏参数）、代码块自动换行、
隐藏内容就地展开、AI 总结按钮可关、修复解锁开关失效、修复签到按钮特殊符号与状态不同步。
详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.7 新增：合并分支修复 · 崩溃与慢加载修复 · 应用主题

- 合并分支作者的 8 项功能修复（只看楼主、帖子编辑、评论发图、评论打赏/举报/删除、
  长按标题举报、点赞人全称、AI 总结、回复可复制）
- 再砍两处请求大头：首页每页 20 发的收藏预取、社区页每次 12 发的版块头部
- 修 v2.6 的进帖慢（节流改令牌桶）与退出帖子崩溃（Glide 销毁守卫）
- 设置页新增**应用主题**：深色模式 + 6 种主题色

详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.6 新增：请求节流（风控根因）· BBCode 复制 · 切号刷新 · 底栏自动隐藏

- **找到「被禁止访问」根因**：角标轮询 5 秒一轮 × 每轮 6 个并发 = **72 次请求/分钟**。
  已改为 60 秒，并加全局 `RequestThrottle`（220ms 最小间隔 + 60s/45 次窗口 + 403 自动退避）
- **复制正文改为 BBCode**（`HtmlToBBCode`，Jsoup 递归而非正则），点击=BBCode / 长按=纯文本
- **切号修复**：清请求去重缓存（旧账号页面会被复用）+ 账号代数驱动各页自动重载
- **楼层异常符号**：`TextClean` 清洗零宽与控制字符
- **底栏滚动自动隐藏**，侧边栏可开关

详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.5 新增：正文/评论复制 · 修复复制代码带行号

- **正文是按钮、评论区是长按** —— 主楼「复制正文」按钮；长按回复弹出复制菜单（整条 / 只复制代码 / 含楼层署名）
- **修复 v2.4 的行号污染**：`normalizeCodeBlocks` 把行号拼进了文本，复制出来每行顶个数字。
  现在行号由 `CodeBlockView` 画成独立装订线，显示与复制解耦
- **抽取改用 Jsoup**，覆盖论坛移动版原生结构 `div.comiis_blockcode > div > ol > li`
- 主楼代码块也渲染成可折叠 + 可复制的卡片

详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.4 新增：代码块折叠复制 · 快捷回复 · 底栏刷新 · 搜索风控修复

- **代码块**从正文摘出来独立成可折叠卡片，带语言标签 / 行数 / 一键复制；引用块同样可折叠复制
- **快捷回复**短语条，轻点填入、长按直发，内容可自定义（一行一条）
- **底栏再点当前 Tab** 即刷新该页
- **搜索风控修复**：原本一次性并发抓完所有结果页，改为按需分页 + 900ms 间隔 + 403 识别
- **不透明度**：对话框由 50% 提到 97%，长文可读

详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.3 新增：底栏重做 · 图标全矢量 · 动效体系

- **底栏**参考 [kd64i/dyparse](https://github.com/kd64i/dyparse)：64dp 悬浮胶囊、
  按 `WindowInsets.navigationBars` 避让系统导航栏、指示器弹簧滑动、按压缩放反馈
- **图标全矢量**：12 个新 `VectorDrawable` 替换所有当图标用的 emoji
- **动效体系**移植 [feitangyuan/motion-web](https://github.com/feitangyuan/motion-web)：
  统一的时长刻度 / 缓动字典 / 弹簧预设（`ui/anim/Motion.java` + `res/interpolator/`）
- **排版**：消息页卡片化 + 副标题 + 分类语义色

详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.2 新增：侧边栏重排 · 账号平铺快切 · 掉线自动重登

- **侧边栏按场景重新分组**：账号 → 签到 → AI 自动化 → 其他
- **账号平铺**：侧边栏直接列出所有账号，点一下即切换，每行显示今日签到状态 / 时间 / 金币 / 排名
- **掉线自动重登**：浏览时被 403 打掉会话，自动用加密保存的密码静默重登（`SessionGuard`）
- **密码只写不读**：已存密码只显示 `••••••••`，可覆盖可清除，永不回显
- 修复：登录后侧边栏仍显示「未登录」、消息页底部被导航栏遮挡、私信气泡是直角方块、
  长消息与列表文字被硬截断

详见 [CHANGELOG.md](CHANGELOG.md)。

## v2.1 新增：多账号登录 · 切换 · 批量签到

本次把 [Forinxy/mt](https://github.com/Forinxy/mt)（MT 论坛签到助手）的多账号签到思路移植了过来，并接到本客户端原有的 Cookie 会话体系上。

### 能做什么

| 功能 | 说明 |
| --- | --- |
| 多账号登录入库 | 账号密码 / Cookie 两种方式登录后自动存为账号快照 |
| 密码托管 | 勾选「记住密码」后，密码经 **Android KeyStore AES-GCM-256** 加密存本机 |
| 掉线自动重登 | Cookie 过期时用托管密码静默重新登录，拿到新 Cookie 后继续签到并回存 |
| 一键全部签到 | 给所有「已启用」账号逐个签到，**不影响前台正在使用的账号** |
| 单账号签到 | 账号列表里针对某个账号单独补签 |
| 账号切换 | Cookie 快照整体回灌，秒切；切换后自动重置当日签到判定 |
| 签到记录 | 每个账号独立记录 状态 / 排名 / 奖励 / 日期 |
| 每日定时签到 | WorkManager 周期任务，可设定时刻（默认 08:30），App 不开也能跑 |
| 结果通知 | 后台签到完成推送可展开的汇总通知 |
| 风控保护 | 账号之间可设间隔（默认 5 秒），避免论坛 ESA 按 IP 限流 403 |

### 入口在哪

- 侧边栏 → **切换账号**（短按快速切换 / 长按进管理页）
- 侧边栏 → 切换账号弹窗 → **⚙ 账号与签到管理**
- 设置 → **账号与签到**

### 关键设计

**1. 批量签到不会顶掉前台登录态**

全局 `HttpClient` 只有一份 cookieStore，拿它给别的账号登录会直接把当前账号挤下线。
所以新增了 `MtSignApi`，每次调用都新建一个带独立内存 CookieJar 的 `OkHttpClient`，
完全不碰前台会话 —— 这是「后台给 N 个账号签到，前台账号照常用」的前提。

**2. Discuz 的 auth 必须和 saltkey 配套**

`xxx_auth` 是用签发它时的 `xxx_saltkey` 加密的。只存/只发 auth，服务端会重新随机生成
saltkey 导致解密失败、判定为游客。因此账号快照始终整串 Cookie 存取，
并对「只粘贴了一个 `xxx_auth`」的情况直接给出明确报错。

**3. 登录态判定以 `formhash` 为准**

实测游客访问 `k_misign-sign.html` 时页面里 **有** `k_misign`、`spacecp` 字样
（侧边栏推广链接），**没有** `formhash`。所以这两个字样不能当登录标记，
判定只认 `formhash`。这条规则连同抓下来的真实游客页面一起进了单元测试做回归。

### 代码位置

```
app/src/main/java/com/solosu/mtforum/
├── session/
│   ├── AccountManager.java        多账号存储：快照/密码/签到记录/切换
│   ├── MtSignApi.java             独立会话签到引擎（Cookie 直签 + 密码登录）
│   ├── SignParser.java            纯 Java 解析规则（可单测，无 android 依赖）
│   ├── MultiSignInManager.java    批量签到调度 + 自动重登 + 限流间隔
│   ├── SignInSettings.java        签到相关设置集中管理
│   ├── SignInScheduler.java       WorkManager 每日排程
│   ├── SignInWorker.java          后台签到任务
│   ├── SignInNotifier.java        结果通知
│   ├── SessionGuard.java          403/掉线时用已存密码静默重登
├── ui/anim/Motion.java            动效令牌：时长/缓动/弹簧/按压/错峰
├── ui/widget/CodeBlockView.java   可折叠 + 一键复制的代码块
├── ui/Refreshable.java            底栏再点当前 Tab 触发页面刷新
└── session/QuickReplyManager.java 快捷回复短语（可自定义）
│   └── AutoSignInManager.java     入口分流（多账号 / 单账号）
├── ui/account/
│   ├── AccountManagerActivity.java 账号与签到管理页
│   └── AccountAdapter.java
└── util/CryptoUtils.java          KeyStore AES-GCM 凭据加密
```

单元测试：`app/src/test/java/com/solosu/mtforum/session/SignParserTest.java`（17 项，覆盖登录态判定、字段提取、接口返回解析、登录错误分流、Cookie 合法性）。

---

## 构建

需要：JDK 17、Android SDK 36、Gradle 8.13+

```bash
# 调试包
gradle :app:assembleDebug

# 发布包（需 keystore）
gradle :app:assembleRelease

# 跑单元测试
gradle :app:testDebugUnitTest
```

产物在 `app/build/outputs/apk/`。

> aapt2 走 Android SDK 自带即可。项目 `gradle.properties` 已剔除本机 `aapt2FromMavenOverride` 绝对路径，别加回来。
>
> 内存吃紧的机器（<4G）可保持 `gradle.properties` 里的 `org.gradle.jvmargs=-Xmx1400m` 与 `org.gradle.workers.max=1`，否则 dex 合并阶段容易 OOM。

### 发布包签名

`app/keystore.jks` 为打包示例（密码 `mtforum123`、别名 `mtforum`、有效期 10000 天）。**分享出去前请重新生成自己的 keystore，别用这个**：

```bash
keytool -genkeypair -v -keystore your.jks -alias your_alias -keyalg RSA -keysize 2048 -validity 10000
```

然后修改 `app/build.gradle` 里的 `signingConfigs.release` 三个字段。

## 目录结构

```
.
├── build.gradle                 # 根配置
├── settings.gradle
├── gradle.properties
├── gradle/
│   ├── libs.versions.toml       # 依赖版本
│   └── wrapper/
├── app/
│   ├── build.gradle             # app 配置(含 signingConfigs)
│   ├── proguard-rules.pro
│   ├── keystore.jks             # 示例签名,请自换
│   └── src/
│       ├── main/                # 源代码 + 资源
│       └── test/                # JVM 单元测试
├── CHANGELOG.md
└── README.md
```

## 依赖

OkHttp（网络）、Jsoup（HTML 解析）、Glide（图片）、Material Components（UI）、ViewPager2、DrawerLayout、WebKit、**WorkManager（定时签到）**、JUnit（测试）。

## 注意

- 论坛站点 `bbs.binmt.cc` 挂了阿里云 ESA，频率过高会被 IP 级 403 拦截。批量签到默认每个账号间隔 5 秒，账号多时别把间隔调成 0。
- `HttpClient` 里的 USER_AGENT 是写死的（三星 S918B/Chrome 120），论坛风控严格时可按需调整。
- 托管的密码只存在本机 KeyStore 加密区，不上传任何服务器；卸载应用即失效。换机 / 清除应用数据后需要重新输入。
- 登录若触发验证码，需要在 App 内手动登录一次拿到 Cookie，之后才能走免登录直签。
- Android 13+ 需要授予通知权限才能收到签到结果通知。
