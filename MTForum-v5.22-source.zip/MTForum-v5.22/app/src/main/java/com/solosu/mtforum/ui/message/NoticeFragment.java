package com.solosu.mtforum.ui.message;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.solosu.mtforum.R;
import com.solosu.mtforum.databinding.FragmentNoticeBinding;
import com.solosu.mtforum.ui.widget.FrostedGlassDrawable;
import com.solosu.mtforum.network.ForumParser;
import com.solosu.mtforum.network.HttpClient;
import com.solosu.mtforum.network.NoticeBadgeManager;
import com.solosu.mtforum.session.UserSessionManager;
import com.solosu.mtforum.ui.space.FriendListActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/**
 * 消息页(ViewPager 页)。
 * “消息”是底部导航页;“我的消息”是本页面中的私信分类,二者不能混淆。
 * 所有分类通过 HttpClient 请求网页端数据接口/HTML,再由原生布局渲染,绝不使用 WebView 套壳。
 */
public class NoticeFragment extends Fragment implements com.solosu.mtforum.ui.Refreshable {
    private static final int REQUEST_CODE_DETAIL = 1001;

    private FragmentNoticeBinding binding;
    /** build68: 六类角标 onResume 拉取节流，频繁返回不再重复全量拉 6 类（防 ESA 403） */
    private static final long BADGE_RESUME_THROTTLE_MS = 60000;
    private long lastBadgeLoadAt = 0L;
    private TextView badgeMessages, badgeFans, badgePosts, badgeInteractive, badgeSystem, badgeApp;
    private TextView tvClearAll;
    private HttpClient httpClient;
    private Handler mainHandler;
    private ExecutorService executor;
    private int badgeLoadGeneration;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentNoticeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        httpClient = HttpClient.getInstance();
        mainHandler = new Handler(Looper.getMainLooper());
        executor = Executors.newFixedThreadPool(4);

        initViews();
        setupClickListeners();
        // build62: 六个分类错峰淡入上移（standard-list 70ms/项）
        com.solosu.mtforum.ui.anim.Motion.staggerChildren(binding.noticeList);
        // 每次进入消息页都以服务器当前数据为准,不能使用本地 all_read 状态跳过请求。
        loadAllBadgeCounts();
    }

    @Override
    public void onResume() {
        super.onResume();
        // 从详情页返回或重新回到本页时,按节流周期同步全部六类服务器数据。
        long now = System.currentTimeMillis();
        if (now - lastBadgeLoadAt < BADGE_RESUME_THROTTLE_MS) return;
        lastBadgeLoadAt = now;
        if (executor != null && !executor.isShutdown()) {
            loadAllBadgeCounts();
        }
    }

    private void initViews() {
        badgeMessages = binding.badgeMessages;
        badgeFans = binding.badgeFans;
        badgePosts = binding.badgePosts;
        badgeInteractive = binding.badgeInteractive;
        badgeSystem = binding.badgeSystem;
        badgeApp = binding.badgeApp;
        tvClearAll = binding.tvClearAll;

        // build62: 图标已改为矢量图 + 分色圆底，不再叠毛玻璃（会盖掉 backgroundTint）
        // 六个入口统一加按压反馈，手感与底栏一致
        com.solosu.mtforum.ui.anim.Motion.pressFeedback(binding.llMyMessages);
        com.solosu.mtforum.ui.anim.Motion.pressFeedback(binding.llMyFans);
        com.solosu.mtforum.ui.anim.Motion.pressFeedback(binding.llMyPosts);
        com.solosu.mtforum.ui.anim.Motion.pressFeedback(binding.llInteractive);
        com.solosu.mtforum.ui.anim.Motion.pressFeedback(binding.llSystem);
        com.solosu.mtforum.ui.anim.Motion.pressFeedback(binding.llApp);
    }

    private void setupClickListeners() {
        binding.llMyMessages.setOnClickListener(v -> openNativeDetail("pm", "我的消息"));
        // 进入分类即视为查看当前内容,随后新增内容仍会重新产生角标。
        binding.llMyFans.setOnClickListener(v -> {
            NoticeBadgeManager.markViewed(requireContext(), "follower");
            Intent intent = new Intent(requireContext(), FriendListActivity.class);
            intent.putExtra("mode", "followers");
            startActivity(intent);
        });
        binding.llMyPosts.setOnClickListener(v -> openNativeDetail("mypost", "我的帖子"));
        binding.llInteractive.setOnClickListener(v -> openNativeDetail("interactive", "坛友互动"));
        binding.llSystem.setOnClickListener(v -> openNativeDetail("system", "系统提醒"));
        binding.llApp.setOnClickListener(v -> openNativeDetail("app", "应用提醒"));
        // 全部已读:按压缩放反馈 + 点击淡入动效,与主界面导航栏选中动效一致
        // build62: 统一走 Motion 令牌（按下 0.92 缩放，抬手 snappy 弹簧回弹）
        com.solosu.mtforum.ui.anim.Motion.pressFeedback(tvClearAll, 0.92f);
        tvClearAll.setOnClickListener(v -> clearAllBadges());
    }

    /** 进入分类时立即标记当前快照为已查看;详情页只负责展示内容。 */
    private void openNativeDetail(String view, String title) {
        NoticeBadgeManager.markViewed(requireContext(), view);
        String url;
        if ("pm".equals(view)) {
            url = HttpClient.BASE_URL + "home.php?mod=space&do=pm&mobile=2";
        } else if ("follower".equals(view)) {
            url = HttpClient.BASE_URL + "home.php?mod=follow&do=follower&uid=" + getUid() + "&mobile=2";
        } else {
            url = HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=" + view;
        }
        Intent intent = new Intent(requireContext(), NoticeDetailActivity.class);
        intent.putExtra("url", url);
        intent.putExtra(NoticeDetailActivity.EXTRA_VIEW_TYPE, view);
        intent.putExtra(NoticeDetailActivity.EXTRA_TITLE, title);
        requireActivity().startActivityForResult(intent, REQUEST_CODE_DETAIL);
    }

    private String getUid() {
        String uid = UserSessionManager.getInstance().getUid(requireContext());
        return TextUtils.isEmpty(uid) ? "0" : uid;
    }

    private void loadAllBadgeCounts() {
        if (executor == null || executor.isShutdown() || !isAdded()) return;
        lastBadgeLoadAt = System.currentTimeMillis();
        final int generation = ++badgeLoadGeneration;
        final android.content.Context app = requireContext().getApplicationContext();
        final String accountUid = NoticeBadgeManager.activeAccountUid(app);
        final int readEpoch = NoticeBadgeManager.getReadEpochForAccount(app, accountUid);
        String followerUid = TextUtils.isEmpty(accountUid) ? "0" : accountUid;
        loadCountBySnapshot(HttpClient.BASE_URL + "home.php?mod=space&do=pm&mobile=2", badgeMessages, "pm", app, accountUid, generation, readEpoch);
        loadCountBySnapshot(HttpClient.BASE_URL + "home.php?mod=follow&do=follower&uid=" + followerUid + "&mobile=2", badgeFans, "follower", app, accountUid, generation, readEpoch);
        loadCountBySnapshot(HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=mypost", badgePosts, "mypost", app, accountUid, generation, readEpoch);
        loadCountBySnapshot(HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=interactive", badgeInteractive, "interactive", app, accountUid, generation, readEpoch);
        loadCountBySnapshot(HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=system", badgeSystem, "system", app, accountUid, generation, readEpoch);
        loadCountBySnapshot(HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=app", badgeApp, "app", app, accountUid, generation, readEpoch);
    }

    /**
     * 通过当前列表内容和本地已查看快照计算角标，不依赖网页 unread class。
     */
    private void loadCountBySnapshot(String url, TextView badgeView, String viewType,
                                     android.content.Context app, String accountUid,
                                     int generation, int readEpoch) {
        if (badgeView == null || executor == null) return;
        try {
            executor.execute(() -> {
                try {
                    httpClient.syncFromCookieManager();
                    String html = ("pm".equals(viewType) || "follower".equals(viewType))
                            ? httpClient.get(url) : httpClient.getDesktop(url);
                    if (!isCurrentBadgeRequest(generation, accountUid, app)) return;
                    if (TextUtils.isEmpty(html) || ForumParser.isLoginPage(html)) {
                        mainHandler.post(() -> {
                            if (isCurrentBadgeRequest(generation, accountUid, app)) updateBadge(badgeView, 0);
                        });
                        return;
                    }
                    String snapshot = NoticeBadgeManager.buildSnapshot(viewType, html, httpClient);
                    NoticeBadgeManager.saveCurrentAndGetNewCountForAccount(
                            app, accountUid, viewType, snapshot, readEpoch);
                    mainHandler.post(() -> {
                        if (isCurrentBadgeRequest(generation, accountUid, app)) {
                            updateBadge(badgeView, NoticeBadgeManager.getNewCountForAccount(
                                    app, accountUid, viewType));
                        }
                    });
                } catch (Exception ignored) {
                    mainHandler.post(() -> {
                        if (isCurrentBadgeRequest(generation, accountUid, app)) updateBadge(badgeView, 0);
                    });
                }
            });
        } catch (RejectedExecutionException ignored) {
            // 视图销毁时，关闭中的执行器可能拒绝任务。
        }
    }

    private boolean isCurrentBadgeRequest(int generation, String accountUid,
                                          android.content.Context app) {
        return generation == badgeLoadGeneration && isAdded() && binding != null
                && TextUtils.equals(accountUid, NoticeBadgeManager.activeAccountUid(app));
    }

    private void updateBadge(TextView badgeView, int count) {
        if (badgeView == null) return;
        if (count > 0) {
            badgeView.setText(count > 99 ? "99+" : String.valueOf(count));
            badgeView.setVisibility(View.VISIBLE);
        } else badgeView.setVisibility(View.GONE);
    }

    private void hideAllBadges() {
        updateBadge(badgeMessages, 0); updateBadge(badgeFans, 0); updateBadge(badgePosts, 0);
        updateBadge(badgeInteractive, 0); updateBadge(badgeSystem, 0); updateBadge(badgeApp, 0);
    }

    private void clearAllBadges() {
        badgeLoadGeneration++;
        hideAllBadges();
        NoticeBadgeManager.markAllViewed(requireContext());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CODE_DETAIL || resultCode != getActivity().RESULT_OK || data == null) return;
        if (!data.getBooleanExtra(NoticeDetailActivity.RESULT_CLEARED, false)) return;
        String type = data.getStringExtra(NoticeDetailActivity.RESULT_VIEW_TYPE);
        if (!TextUtils.isEmpty(type)) NoticeBadgeManager.markViewed(requireContext(), type);
        if ("pm".equals(type)) updateBadge(badgeMessages, 0);
        else if ("follower".equals(type)) updateBadge(badgeFans, 0);
        else if ("mypost".equals(type)) updateBadge(badgePosts, 0);
        else if ("interactive".equals(type)) updateBadge(badgeInteractive, 0);
        else if ("system".equals(type)) updateBadge(badgeSystem, 0);
        else if ("app".equals(type)) updateBadge(badgeApp, 0);
    }

    @Override
    public void onDestroyView() {
        badgeLoadGeneration++;
        if (mainHandler != null) mainHandler.removeCallbacksAndMessages(null);
        if (executor != null) executor.shutdownNow();
        super.onDestroyView();
        executor = null;
        binding = null;
    }

    // ==================== build63: 底栏再点刷新 ====================
    @Override
    public void onTabReselected() {
        if (executor != null && !executor.isShutdown()) {
            loadAllBadgeCounts();
        }
    }

}
