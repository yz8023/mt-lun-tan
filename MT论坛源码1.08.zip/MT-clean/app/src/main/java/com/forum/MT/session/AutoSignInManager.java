package com.forum.MT.session;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 自动签到管理器。
 * 每次主界面进入前台时检查论坛当前签到状态；只有明确判断为未签到时才提交签到请求。
 */
public final class AutoSignInManager {
    private static final String PREF_NAME = "app_settings";
    private static final String KEY_AUTO_SIGN_IN = "auto_sign_in_enabled";
    private static final AtomicBoolean CHECKING = new AtomicBoolean(false);
    private static final AtomicBoolean APP_LAUNCH_CHECK = new AtomicBoolean(true);
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    private AutoSignInManager() {
    }

    public interface Callback {
        void onFinished(boolean success, boolean performed, String message);
    }

    public static boolean isEnabled(Context context) {
        if (context == null) return false;
        return context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_AUTO_SIGN_IN, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        if (context == null) return;
        context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_AUTO_SIGN_IN, enabled).apply();
    }

    /**
     * 检查当前网页签到状态并在需要时签到。每天只执行一次真正的网络检测。
     * 重复进入/重复回调期间只允许一个检查任务运行。
     */
    public static void checkAndSignIn(Context context, Callback callback) {
        if (context == null || !isEnabled(context)) return;
        Context appContext = context.getApplicationContext();

        // 优先依据本地持久化日期判断：若今日已签到，则不再发起网络检测。
        if (UserSessionManager.getInstance().isSignedInToday(appContext)) {
            if (callback != null) {
                MAIN_HANDLER.post(() -> callback.onFinished(true, false, "今日已签到"));
            }
            return;
        }

        // 本地日期不是今天 → 新的一天，重置 APP_LAUNCH_CHECK 允许再次检测。
        APP_LAUNCH_CHECK.set(true);

        HttpClient client = HttpClient.getInstance();
        if (!client.isLoggedIn() || !APP_LAUNCH_CHECK.compareAndSet(true, false)
                || !CHECKING.compareAndSet(false, true)) return;

        new Thread(() -> {
            boolean success = false;
            boolean performed = false;
            String message = "";
            try {
                String html = client.get(ForumParser.getForumlistMobileUrl());
                if (TextUtils.isEmpty(html) || ForumParser.isLoginPage(html)) {
                    message = "登录状态已失效";
                } else {
                    ForumParser.CommunityPageData data = ForumParser.parseCommunityPage(html);
                    String signText = data.getSignInText();

                    // 必须以当前网页状态为准；本地日期只用于无法解析网页时的兜底，不直接跳过网页检查。
                    if (isAlreadySigned(signText) || data.isAlreadySignedIn()) {
                        success = true;
                        message = "今日已签到";
                    } else if (data.isLoginRequired()) {
                        message = "请先登录";
                    } else if (!isNotSigned(signText)) {
                        message = "无法确认当前签到状态";
                    } else {
                        String formhash = data.getFormhash();
                        if (TextUtils.isEmpty(formhash)) formhash = ForumParser.parseFormhash(html);
                        if (TextUtils.isEmpty(formhash)) {
                            message = "无法获取签到凭证";
                        } else {
                            Map<String, String> params = new HashMap<>();
                            params.put("formhash", formhash);
                            String signUrl = HttpClient.BASE_URL
                                    + "plugin.php?id=k_misign:sign&operation=qiandao&format=text";
                            String result = client.post(signUrl, params);
                            message = cleanMessage(result);
                            success = isSignSuccess(message);
                            performed = true;
                            if (success) {
                                UserSessionManager.getInstance().saveSignInDate(appContext);
                            }
                        }
                    }
                }
            } catch (Exception e) {
                message = e.getMessage() == null ? "自动签到失败" : e.getMessage();
            } finally {
                CHECKING.set(false);
            }

            if (callback != null) {
                final boolean finalSuccess = success;
                final boolean finalPerformed = performed;
                final String finalMessage = message;
                MAIN_HANDLER.post(() -> callback.onFinished(finalSuccess, finalPerformed, finalMessage));
            }
        }).start();
    }

    private static boolean isAlreadySigned(String text) {
        if (TextUtils.isEmpty(text)) return false;
        return text.contains("今日已签") || text.contains("已签到") || text.contains("已签");
    }

    private static boolean isNotSigned(String text) {
        if (TextUtils.isEmpty(text)) return false;
        return text.contains("签到") && !isAlreadySigned(text);
    }

    private static boolean isSignSuccess(String text) {
        if (TextUtils.isEmpty(text)) return false;
        if (text.contains("失败") || text.contains("错误") || text.contains("请先登录")
                || text.contains("没有权限") || text.contains("非法操作")) return false;
        return text.contains("签到成功") || text.contains("今日已签")
                || text.contains("已签到") || text.contains("成功")
                || text.toLowerCase().contains("success")
                || text.toLowerCase().contains("succeed");
    }

    private static String cleanMessage(String raw) {
        if (TextUtils.isEmpty(raw)) return "";
        String text = raw.replaceAll("<!\\[CDATA\\[(.*?)\\]\\]>", "$1")
                .replaceAll("<[^>]+>", "")
                .trim();
        return text.isEmpty() ? raw.trim() : text;
    }
}