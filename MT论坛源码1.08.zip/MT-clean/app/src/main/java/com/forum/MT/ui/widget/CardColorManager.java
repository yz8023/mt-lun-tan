package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

/**
 * 内容卡片自定义颜色管理。
 *
 * 统一控制「帖子 / 消息 / 通知 / 置顶帖 / 好友」等所有内容卡片的背景颜色。
 * 颜色为 0 时表示使用默认白色。
 *
 * 与卡片边框（CardBorderManager）组合使用：
 *  - 自定义颜色时作为卡片填充色；
 *  - 边框仍由 CardBorderManager / RainbowBorderDrawable 控制。
 *
 * 偏好键：
 *   card_bg_color  (int, 0 表示使用默认白色)
 */
public final class CardColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_COLOR = "card_bg_color";

    /** 默认卡片背景色 */
    public static final int DEFAULT_CARD_COLOR = 0xFFFFF8E7;

    private static volatile int customColor = 0;

    private CardColorManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        customColor = prefs.getInt(KEY_COLOR, 0);
    }

    /** 获取当前自定义颜色，0 表示使用默认。 */
    public static int getCustomColor() {
        return customColor;
    }

    /** 设置自定义颜色，0 表示恢复默认。持久化并刷新已应用卡片。 */
    public static void setCustomColor(Context context, int color) {
        customColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_COLOR, color).apply();
        }
        CardBorderManager.refreshAll();
    }

    /** 当前卡片填充色。 */
    public static int resolveCardColor() {
        return customColor != 0 ? customColor : DEFAULT_CARD_COLOR;
    }

    /** 判断文字应使用深色还是白色（基于自定义色亮度）。 */
    public static boolean isDarkText() {
        if (customColor == 0) return true;
        double r = Color.red(customColor) / 255.0;
        double g = Color.green(customColor) / 255.0;
        double b = Color.blue(customColor) / 255.0;
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.5;
    }

    /**
     * 给指定 View 应用卡片背景（含圆角和边框）。
     * CardBorderManager 内部使用。
     */
    public static GradientDrawable createBackground(float cornerRadiusPx, int strokeColor, float strokeWidthPx) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(cornerRadiusPx);
        drawable.setColor(resolveCardColor());
        drawable.setStroke(Math.round(strokeWidthPx), strokeColor);
        return drawable;
    }
}