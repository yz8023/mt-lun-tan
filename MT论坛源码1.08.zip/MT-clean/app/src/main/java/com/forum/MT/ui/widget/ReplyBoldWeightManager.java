package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理评论内容加粗文字粗细程度的设置。
 * 与引用内容加粗（QuoteBoldWeightManager）相同的机制。
 */
public class ReplyBoldWeightManager {

    private static final String PREFS_NAME = "mt_forum_prefs";
    private static final String KEY_REPLY_BOLD_WEIGHT = "reply_bold_weight";
    private static final int DEFAULT_WEIGHT = 888;

    /**
     * 获取用户设置的评论加粗值
     * @param context 上下文
     * @return 字体粗细值 (100-1000)，默认 888
     */
    public static int getWeight(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_REPLY_BOLD_WEIGHT, DEFAULT_WEIGHT);
    }

    /**
     * 保存评论加粗值
     * @param context 上下文
     * @param weight 字体粗细值 (100-1000)
     */
    public static void setWeight(Context context, int weight) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_REPLY_BOLD_WEIGHT, weight).apply();
    }
}