package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理私信聊天页的配色：
 * 对方/自己的气泡底色、气泡文字色、气泡内链接色。
 * 颜色为 0 表示使用默认值（与 colors.xml 中的 chat_* 保持一致）。
 */
public class ChatColorManager {

    private static final String PREFS_NAME = "mt_forum_prefs";
    private static final String KEY_BUBBLE_IN  = "chat_bubble_in_color";
    private static final String KEY_BUBBLE_OUT = "chat_bubble_out_color";
    private static final String KEY_TEXT_IN    = "chat_text_in_color";
    private static final String KEY_TEXT_OUT   = "chat_text_out_color";
    private static final String KEY_LINK_IN    = "chat_link_in_color";
    private static final String KEY_LINK_OUT   = "chat_link_out_color";

    /** 默认对方气泡底色（白色） */
    public static final int DEFAULT_BUBBLE_IN  = 0xFFFFFFFF;
    /** 默认自己气泡底色（粉色，与全局主色一致） */
    public static final int DEFAULT_BUBBLE_OUT = 0xFFFF4081;
    /** 默认对方气泡文字色（深灰） */
    public static final int DEFAULT_TEXT_IN    = 0xFF212121;
    /** 默认自己气泡文字色（白色） */
    public static final int DEFAULT_TEXT_OUT   = 0xFFFFFFFF;
    /** 默认对方气泡链接色（深蓝） */
    public static final int DEFAULT_LINK_IN    = 0xFF1565C0;
    /** 默认自己气泡链接色（白色，粉底上需高对比） */
    public static final int DEFAULT_LINK_OUT   = 0xFFFFFFFF;

    private ChatColorManager() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private static int get(Context context, String key) {
        return prefs(context).getInt(key, 0);
    }

    private static void set(Context context, String key, int color) {
        prefs(context).edit().putInt(key, color).apply();
    }

    // ==================== 对方气泡底色 ====================

    public static int getBubbleInColor(Context context) {
        return get(context, KEY_BUBBLE_IN);
    }

    public static int resolveBubbleInColor(Context context) {
        int color = getBubbleInColor(context);
        return color != 0 ? color : DEFAULT_BUBBLE_IN;
    }

    public static void setBubbleInColor(Context context, int color) {
        set(context, KEY_BUBBLE_IN, color);
    }

    // ==================== 自己气泡底色 ====================

    public static int getBubbleOutColor(Context context) {
        return get(context, KEY_BUBBLE_OUT);
    }

    public static int resolveBubbleOutColor(Context context) {
        int color = getBubbleOutColor(context);
        return color != 0 ? color : DEFAULT_BUBBLE_OUT;
    }

    public static void setBubbleOutColor(Context context, int color) {
        set(context, KEY_BUBBLE_OUT, color);
    }

    // ==================== 对方气泡文字色 ====================

    public static int getTextInColor(Context context) {
        return get(context, KEY_TEXT_IN);
    }

    public static int resolveTextInColor(Context context) {
        int color = getTextInColor(context);
        return color != 0 ? color : DEFAULT_TEXT_IN;
    }

    public static void setTextInColor(Context context, int color) {
        set(context, KEY_TEXT_IN, color);
    }

    // ==================== 自己气泡文字色 ====================

    public static int getTextOutColor(Context context) {
        return get(context, KEY_TEXT_OUT);
    }

    public static int resolveTextOutColor(Context context) {
        int color = getTextOutColor(context);
        return color != 0 ? color : DEFAULT_TEXT_OUT;
    }

    public static void setTextOutColor(Context context, int color) {
        set(context, KEY_TEXT_OUT, color);
    }

    // ==================== 对方气泡链接色 ====================

    public static int getLinkInColor(Context context) {
        return get(context, KEY_LINK_IN);
    }

    public static int resolveLinkInColor(Context context) {
        int color = getLinkInColor(context);
        return color != 0 ? color : DEFAULT_LINK_IN;
    }

    public static void setLinkInColor(Context context, int color) {
        set(context, KEY_LINK_IN, color);
    }

    // ==================== 自己气泡链接色 ====================

    public static int getLinkOutColor(Context context) {
        return get(context, KEY_LINK_OUT);
    }

    public static int resolveLinkOutColor(Context context) {
        int color = getLinkOutColor(context);
        return color != 0 ? color : DEFAULT_LINK_OUT;
    }

    public static void setLinkOutColor(Context context, int color) {
        set(context, KEY_LINK_OUT, color);
    }
}
