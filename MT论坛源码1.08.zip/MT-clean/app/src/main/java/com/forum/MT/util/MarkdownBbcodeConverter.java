package com.forum.MT.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 将常用 Markdown 转成 Discuz BBCode。
 * 只处理 Markdown 语法，不改动已有的 BBCode 标签内容。
 */
public final class MarkdownBbcodeConverter {
    private static final Pattern IMAGE = Pattern.compile("!\\[([^]]*)]\\((\\S+?)(?:\\s+[\\\"'].*?[\\\"'])?\\)");
    private static final Pattern LINK = Pattern.compile("\\[([^]]+)]\\((\\S+?)(?:\\s+[\\\"'].*?[\\\"'])?\\)");
    private static final Pattern CODE = Pattern.compile("`([^`\\n]+)`");
    private static final Pattern BOLD_STAR = Pattern.compile("\\*\\*([^*\\n]+)\\*\\*");
    private static final Pattern BOLD_UNDERLINE = Pattern.compile("__([^_\\n]+)__");
    private static final Pattern STRIKE = Pattern.compile("~~([^~\\n]+)~~");
    private static final Pattern ITALIC_STAR = Pattern.compile("(?<!\\*)\\*([^*\\n]+)\\*(?!\\*)");
    private static final Pattern ITALIC_UNDERLINE = Pattern.compile("(?<!_)_([^_\\n]+)_(?!_)");

    private MarkdownBbcodeConverter() {}

    public static String convert(String source) {
        if (source == null || source.isEmpty()) return "";
        String normalized = source.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = normalized.split("\\n", -1);
        StringBuilder out = new StringBuilder(normalized.length() + 32);
        boolean fenced = false;
        StringBuilder fence = new StringBuilder();
        boolean inUnordered = false;
        boolean inOrdered = false;
        int orderedCounter = 1;

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
                if (!fenced) {
                    closeList(out, inUnordered, inOrdered);
                    inUnordered = false;
                    inOrdered = false;
                    fenced = true;
                    fence.setLength(0);
                } else {
                    out.append("[code]").append(fence).append("[/code]\n");
                    fenced = false;
                }
                continue;
            }
            if (fenced) {
                fence.append(line).append('\n');
                continue;
            }

            Matcher heading = Pattern.compile("^#{1,6}\\s+(.+?)\\s*#*\\s*$").matcher(trimmed);
            if (heading.matches()) {
                closeList(out, inUnordered, inOrdered);
                inUnordered = false;
                inOrdered = false;
                out.append("[size=5][b]").append(convertInline(heading.group(1))).append("[/b][/size]\n");
                continue;
            }
            if (trimmed.matches("^([-*_])(?:\\s*\\1){2,}\\s*$")) {
                closeList(out, inUnordered, inOrdered);
                inUnordered = false;
                inOrdered = false;
                out.append("─────────────────────────\n");
                continue;
            }

            Matcher unordered = Pattern.compile("^[-*+]\\s+(.+)$").matcher(trimmed);
            Matcher ordered = Pattern.compile("^\\d+[.)]\\s+(.+)$").matcher(trimmed);
            if (unordered.matches()) {
                if (inOrdered) { out.append("[/list]\n"); inOrdered = false; }
                if (!inUnordered) { out.append("[list]\n"); inUnordered = true; }
                out.append("[*]").append(convertInline(unordered.group(1))).append("\n");
                continue;
            }
            if (ordered.matches()) {
                if (inUnordered) { out.append("[/list]\n"); inUnordered = false; }
                if (!inOrdered) { inOrdered = true; orderedCounter = 1; }
                out.append(orderedCounter).append(". ").append(convertInline(ordered.group(1))).append("\n");
                orderedCounter++;
                continue;
            }
            if (inUnordered || inOrdered) {
                if (inUnordered) out.append("[/list]\n");
                inUnordered = false;
                inOrdered = false;
            }
            if (trimmed.startsWith(">")) {
                String quote = trimmed.replaceFirst("^>\\s?", "");
                out.append("[quote]").append(convertInline(quote)).append("[/quote]\n");
            } else if (trimmed.isEmpty()) {
                out.append('\n');
            } else {
                out.append(convertInline(line)).append('\n');
            }
        }
        if (fenced) out.append("[code]").append(fence).append("[/code]\n");
        if (inUnordered) out.append("[/list]\n");
        return out.toString().replaceAll("\\n{3,}", "\\n\\n").trim();
    }

    private static void closeList(StringBuilder out, boolean unordered, boolean ordered) {
        if (unordered) out.append("[/list]\n");
    }

    private static String convertInline(String value) {
        if (value == null || value.isEmpty()) return "";
        List<String> protectedTokens = new ArrayList<>();
        String text = protect(value, protectedTokens, "\\[[^\\]]+].*?\\[/[^]]+]");
        text = replace(text, IMAGE, "[img]$2[/img]");
        text = replace(text, LINK, "[url=$2]$1[/url]");
        text = replace(text, CODE, "[code]$1[/code]");
        text = replace(text, BOLD_STAR, "[b]$1[/b]");
        text = replace(text, BOLD_UNDERLINE, "[b]$1[/b]");
        text = replace(text, STRIKE, "[s]$1[/s]");
        text = replace(text, ITALIC_STAR, "[i]$1[/i]");
        text = replace(text, ITALIC_UNDERLINE, "[i]$1[/i]");
        for (int i = protectedTokens.size() - 1; i >= 0; i--) {
            text = text.replace("\u0001" + i + "\u0002", protectedTokens.get(i));
        }
        return text;
    }

    private static String protect(String value, List<String> tokens, String regex) {
        Matcher matcher = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(value);
        StringBuffer buffer = new StringBuffer();
        while (matcher.find()) {
            tokens.add(matcher.group());
            matcher.appendReplacement(buffer, Matcher.quoteReplacement("\u0001" + (tokens.size() - 1) + "\u0002"));
        }
        matcher.appendTail(buffer);
        return buffer.toString();
    }

    private static String replace(String value, Pattern pattern, String replacement) {
        return pattern.matcher(value).replaceAll(replacement);
    }
}
