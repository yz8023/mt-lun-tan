package com.forum.MT.ui.post;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.forum.MT.R;
import com.forum.MT.model.ForumCategory;

import java.util.ArrayList;
import java.util.List;

/**
 * 版块选择适配器：支持分组头 + 搜索过滤
 */
public class ForumPickerAdapter extends BaseAdapter {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_CHILD = 1;

    private final Context ctx;
    private final LayoutInflater inflater;

    /** 搜索前的完整列表 */
    private final List<Item> fullList = new ArrayList<>();
    /** 当前显示的列表（可能被搜索过滤） */
    private final List<Item> showList = new ArrayList<>();

    /** 原始数据 */
    private final List<ForumCategory> categories;

    public ForumPickerAdapter(Context ctx, List<ForumCategory> categories) {
        this.ctx = ctx;
        this.inflater = LayoutInflater.from(ctx);
        this.categories = categories;
        buildList("");
    }

    /** 扁平化分类+版块为一维列表 */
    private void buildList(String query) {
        fullList.clear();
        for (ForumCategory cat : categories) {
            if (cat.getForums() == null || cat.getForums().isEmpty()) continue;
            // 搜索时：如果该分类下有匹配的版块，则保留分类头
            boolean hasMatch = false;
            List<Item> children = new ArrayList<>();
            for (ForumCategory.Forum f : cat.getForums()) {
                if (TextUtils.isEmpty(query) || f.getName().toLowerCase().contains(query.toLowerCase())) {
                    children.add(new Item(TYPE_CHILD, f, cat.getName()));
                    hasMatch = true;
                }
            }
            if (hasMatch) {
                fullList.add(new Item(TYPE_HEADER, null, cat.getName()));
                fullList.addAll(children);
            }
        }
        filter(query);
    }

    /** 搜索过滤 */
    public void filter(String query) {
        showList.clear();
        if (TextUtils.isEmpty(query)) {
            showList.addAll(fullList);
        } else {
            String q = query.toLowerCase();
            for (Item item : fullList) {
                if (item.type == TYPE_HEADER) {
                    showList.add(item);
                } else if (item.forum.getName().toLowerCase().contains(q)) {
                    showList.add(item);
                }
            }
            // 清除没有子项的头
            List<Item> cleaned = new ArrayList<>();
            for (int i = 0; i < showList.size(); i++) {
                Item it = showList.get(i);
                if (it.type == TYPE_HEADER) {
                    boolean hasNext = false;
                    for (int j = i + 1; j < showList.size(); j++) {
                        if (showList.get(j).type == TYPE_CHILD) {
                            hasNext = true;
                            break;
                        }
                    }
                    if (hasNext) cleaned.add(it);
                } else {
                    cleaned.add(it);
                }
            }
            showList.clear();
            showList.addAll(cleaned);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() { return showList.size(); }

    @Override
    public Object getItem(int position) { return showList.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public int getViewTypeCount() { return 2; }

    @Override
    public int getItemViewType(int position) { return showList.get(position).type; }

    @Override
    public boolean isEnabled(int position) { return getItemViewType(position) == TYPE_CHILD; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Item item = showList.get(position);
        if (item.type == TYPE_HEADER) {
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.item_forum_group, parent, false);
            }
            ((TextView) convertView).setText(item.categoryName);
        } else {
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.item_forum_child, parent, false);
            }
            TextView tvName = convertView.findViewById(R.id.tv_forum_name);
            TextView tvToday = convertView.findViewById(R.id.tv_today_posts);
            tvName.setText(item.forum.getName());
            int today = item.forum.getTodayPosts();
            if (today > 0) {
                tvToday.setText(today + "");
                tvToday.setVisibility(View.VISIBLE);
            } else {
                tvToday.setVisibility(View.GONE);
            }
        }
        return convertView;
    }

    public ForumCategory.Forum getForumAt(int position) {
        Item item = showList.get(position);
        return item.type == TYPE_CHILD ? item.forum : null;
    }

    public boolean isEmpty() { return showList.isEmpty(); }

    private static class Item {
        final int type;
        final ForumCategory.Forum forum;
        final String categoryName;

        Item(int type, ForumCategory.Forum forum, String categoryName) {
            this.type = type;
            this.forum = forum;
            this.categoryName = categoryName;
        }
    }
}
