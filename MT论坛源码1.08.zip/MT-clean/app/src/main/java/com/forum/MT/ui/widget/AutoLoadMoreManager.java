package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 管理"自动加载更多回复"的设置
 * 开启后，滚动到回复列表底部时自动加载下一页
 */
public class AutoLoadMoreManager {
    private static final String PREF_NAME = "auto_load_more_pref";
    private static final String KEY_ENABLED = "enabled";

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
    }
}
