package com.forum.MT.ui.widget;

import android.app.Activity;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.HorizontalScrollView;
import android.widget.Scroller;

/**
 * 滑动切换评论区控制器。
 * <p>
 * 评论区通过 translationX 从右侧滑入覆盖正文页。
 * 正文页不移动，仅叠加半透明遮罩（scrim）增加层次感。
 */
public class SwipeCommentHelper {

    private final Activity activity;
    private final View mainContent;      // 正文页（SwipeRefreshLayout）
    private final View commentPanel;     // 评论区面板
    private final ViewGroup pageContainer;  // overlay 容器
    private final IsVisibleProvider isVisibleProvider;
    private final VisibilitySetter visibilitySetter;

    private int screenW = 0;

    // 半透明遮罩
    private View scrimView;

    // 手势状态
    private boolean isDragging = false;
    private float downX = 0, downY = 0;
    private float lastX = 0;
    private boolean horizontalDetected = false;
    private boolean touchInsideHorizontalScrollable = false;
    private VelocityTracker velocityTracker = null;

    private Scroller scroller;
    private Runnable flingRunnable = null;

    // 回调接口
    public interface IsVisibleProvider {
        boolean isVisible();
    }

    public interface VisibilitySetter {
        void setVisible(boolean visible);
    }

    public SwipeCommentHelper(Activity activity, View mainContent, View commentPanel,
                              ViewGroup pageContainer,
                              IsVisibleProvider provider, VisibilitySetter setter) {
        this.activity = activity;
        this.mainContent = mainContent;
        this.commentPanel = commentPanel;
        this.pageContainer = pageContainer;
        this.isVisibleProvider = provider;
        this.visibilitySetter = setter;
        this.scroller = new Scroller(activity, new DecelerateInterpolator(1.5f));
        init();
    }

    private void init() {
        screenW = activity.getResources().getDisplayMetrics().widthPixels;

        // 创建半透明遮罩，插在正文页和评论区之间
        scrimView = new View(activity);
        scrimView.setBackgroundColor(Color.BLACK);
        scrimView.setAlpha(0f);
        scrimView.setVisibility(View.INVISIBLE);
        scrimView.setClickable(false);
    }

    /**
     * 将遮罩 View 添加到 overlay 中正确位置（正文页之上，评论区之下）。
     * 在 setupSwipeCommentMode 添加完正文页后调用。
     */
    public void setupScrim() {
        // scrimView 在正文页(index 0)之后、评论区之前插入
        if (scrimView.getParent() == null) {
            pageContainer.addView(scrimView, 1,
                    new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    /**
     * 递归取消所有子 View 的长按
     */
    private void cancelLongPressInView(View view) {
        view.cancelLongPress();
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                cancelLongPressInView(group.getChildAt(i));
            }
        }
    }

    /**
     * 清除文字选择和复制菜单（ActionMode）
     */
    private void clearSelectionAndActionMode(Activity activity) {
        View decor = activity.getWindow().getDecorView();
        clearTextSelection(decor);
        activity.closeContextMenu();
        activity.closeOptionsMenu();
    }

    private void clearTextSelection(View view) {
        if (view instanceof android.widget.TextView) {
            android.widget.TextView tv = (android.widget.TextView) view;
            if (tv.hasSelection()) {
                android.text.method.MovementMethod mm = tv.getMovementMethod();
                boolean focusable = tv.isFocusable();
                boolean clickable = tv.isClickable();
                boolean longClickable = tv.isLongClickable();
                tv.clearFocus();
                tv.setTextIsSelectable(false);
                tv.setTextIsSelectable(true);
                tv.setMovementMethod(mm);
                tv.setFocusable(focusable);
                tv.setClickable(clickable);
                tv.setLongClickable(longClickable);
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                clearTextSelection(group.getChildAt(i));
            }
        }
    }

    /**
     * 递归检查触点是否落在某个 HorizontalScrollView（表格）内。
     * 如果是，说明用户想横向滑动表格，此时滑动切换手势不应拦截。
     */
    private boolean isTouchInsideHorizontalScrollable(float rawX, float rawY) {
        return isTouchInsideHorizontalScrollableInView(pageContainer, rawX, rawY);
    }

    private boolean isTouchInsideHorizontalScrollableInView(View view, float rawX, float rawY) {
        if (view == null) return false;
        if (view.getVisibility() != View.VISIBLE) return false;

        if (view instanceof HorizontalScrollView) {
            int[] loc = new int[2];
            view.getLocationOnScreen(loc);
            if (rawX >= loc[0] && rawX <= loc[0] + view.getWidth()
                    && rawY >= loc[1] && rawY <= loc[1] + view.getHeight()) {
                return true;
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                if (isTouchInsideHorizontalScrollableInView(group.getChildAt(i), rawX, rawY)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 在 Activity.dispatchTouchEvent 中调用。
     */
    public boolean handleDispatchTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();

        if (velocityTracker == null) {
            velocityTracker = VelocityTracker.obtain();
        }
        velocityTracker.addMovement(event);

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getRawX();
                downY = event.getRawY();
                lastX = downX;
                isDragging = false;
                horizontalDetected = false;
                // ★ 触摸点在表格（HorizontalScrollView）内时，不拦截手势
                touchInsideHorizontalScrollable = isTouchInsideHorizontalScrollable(downX, downY);
                if (!scroller.isFinished()) {
                    scroller.abortAnimation();
                }
                break;

            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downX;
                float dy = event.getRawY() - downY;

                if (!horizontalDetected) {
                    if (Math.abs(dx) > 24 && Math.abs(dx) > Math.abs(dy) * 1.2f
                            && !touchInsideHorizontalScrollable) {
                        horizontalDetected = true;
                        boolean canDrag = false;
                        if (!isVisibleProvider.isVisible() && dx < 0) {
                            canDrag = true; // 手指左移，打开评论
                        } else if (isVisibleProvider.isVisible() && dx > 0) {
                            canDrag = true; // 手指右移，回正文
                        }
                        if (canDrag) {
                            isDragging = true;
                            cancelLongPressInView(pageContainer);
                            clearSelectionAndActionMode(activity);
                            MotionEvent cancelEvent = MotionEvent.obtain(event);
                            cancelEvent.setAction(MotionEvent.ACTION_CANCEL);
                            pageContainer.dispatchTouchEvent(cancelEvent);
                            cancelEvent.recycle();
                        }
                    }
                }

                if (isDragging) {
                    float moveX = event.getRawX() - lastX;
                    lastX = event.getRawX();

                    float currentTrans = commentPanel.getTranslationX();
                    float newTrans = currentTrans + moveX;
                    if (newTrans < 0) newTrans = 0;
                    if (newTrans > screenW) newTrans = screenW;
                    commentPanel.setTranslationX(newTrans);

                    // 遮罩透明度：评论区越近，遮罩越深
                    float progress = 1f - (newTrans / screenW); // 0=正文, 1=评论
                    if (scrimView.getVisibility() != View.VISIBLE) {
                        scrimView.setVisibility(View.VISIBLE);
                    }
                    scrimView.setAlpha(progress * 0.5f);

                    return true;
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (isDragging) {
                    isDragging = false;
                    velocityTracker.computeCurrentVelocity(1000);
                    float velocityX = velocityTracker.getXVelocity();

                    float currentTrans = commentPanel.getTranslationX();
                    float progress = 1f - (currentTrans / screenW);

                    boolean shouldOpen;
                    if (!isVisibleProvider.isVisible()) {
                        shouldOpen = velocityX < -300 || progress > 0.5f;
                    } else {
                        shouldOpen = velocityX < -300 && progress > 0.3f;
                    }

                    if (shouldOpen && !isVisibleProvider.isVisible()) {
                        openCommentPage();
                    } else if (!shouldOpen && isVisibleProvider.isVisible()) {
                        closeCommentPage();
                    } else if (shouldOpen && isVisibleProvider.isVisible()) {
                        openCommentPage();
                    } else {
                        closeCommentPage();
                    }
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        velocityTracker = null;
                    }
                    return true;
                }
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    velocityTracker = null;
                }
                horizontalDetected = false;
                break;
        }
        return false;
    }

    /**
     * 打开评论区（带动画）
     */
    public void openCommentPage() {
        visibilitySetter.setVisible(true);
        commentPanel.setVisibility(View.VISIBLE);
        scrimView.setVisibility(View.VISIBLE);
        startScrollTo(0);
    }

    /**
     * 关闭评论区，回到正文（带动画）
     */
    public void closeCommentPage() {
        visibilitySetter.setVisible(false);
        startScrollTo(screenW);
    }

    private void startScrollTo(int targetX) {
        int startX = (int) commentPanel.getTranslationX();
        int dx = targetX - startX;
        if (dx == 0) return;
        scroller.startScroll(startX, 0, dx, 0, 300);
        if (flingRunnable != null) {
            pageContainer.removeCallbacks(flingRunnable);
        }
        flingRunnable = new Runnable() {
            @Override
            public void run() {
                if (scroller.computeScrollOffset()) {
                    float currX = scroller.getCurrX();
                    commentPanel.setTranslationX(currX);
                    // 遮罩透明度跟随
                    float progress = 1f - (currX / screenW);
                    scrimView.setAlpha(progress * 0.5f);
                    pageContainer.postOnAnimation(this);
                } else {
                    // 动画结束
                    if (commentPanel.getTranslationX() >= screenW - 1) {
                        commentPanel.setVisibility(View.INVISIBLE);
                        scrimView.setAlpha(0f);
                        scrimView.setVisibility(View.INVISIBLE);
                    }
                    flingRunnable = null;
                }
            }
        };
        pageContainer.postOnAnimation(flingRunnable);
    }
}
