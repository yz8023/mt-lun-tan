package com.forum.MT.model;

import java.util.List;

/**
 * 帖子投票数据模型
 *
 * 对应 Discuz! 移动端 HTML 中的 div.comiis_poll 结构：
 *   div.comiis_poll
 *     form#poll
 *       input[name=formhash]
 *       div.comiis_poll_top
 *         h2                      — 投票类型（"单选投票" / "多选投票"）
 *         p.f_c                   — 参与人数
 *         p.kmbtn span            — 投票状态（"投票已经结束" 等）
 *       div.comiis_poll_list
 *         ul
 *           li.kmnop > label      — 选项文本（与结果条交替出现）
 *           li.poll_ok > span > em — 进度条（width + background-color）
 *           li.poll_ok > em        — "80.00% (24)"
 *       div.comiis_poll_bottom     — 登录提示等
 */
public class Poll {

    /** 单个投票选项 */
    public static class Option {
        private final String text;        // 选项文本
        private final double percent;     // 百分比（0-100）
        private final int voteCount;      // 票数
        private final String barColor;    // 进度条颜色（如 "#E92725"）
        private String optionId;          // 选项 ID（投票提交用，对应 input value）

        public Option(String text, double percent, int voteCount, String barColor) {
            this.text = text;
            this.percent = percent;
            this.voteCount = voteCount;
            this.barColor = barColor;
        }

        public String getText() { return text; }
        public double getPercent() { return percent; }
        public int getVoteCount() { return voteCount; }
        public String getBarColor() { return barColor; }
        public String getOptionId() { return optionId; }
        public void setOptionId(String optionId) { this.optionId = optionId; }
    }

    private String pollType;           // "单选投票" / "多选投票"
    private int voterCount;            // 参与人数
    private boolean closed;            // 投票是否已结束
    private List<Option> options;      // 选项列表
    private String actionUrl;          // 投票提交 URL（POST action）
    private String formhash;           // 表单 hash
    private String bottomMessage;      // 底部提示（如"您已经投过票,谢谢您的参与"）

    public Poll() {}

    public String getPollType() { return pollType; }
    public void setPollType(String pollType) { this.pollType = pollType; }

    public int getVoterCount() { return voterCount; }
    public void setVoterCount(int voterCount) { this.voterCount = voterCount; }

    public boolean isClosed() { return closed; }
    public void setClosed(boolean closed) { this.closed = closed; }

    public List<Option> getOptions() { return options; }
    public void setOptions(List<Option> options) { this.options = options; }

    public String getActionUrl() { return actionUrl; }
    public void setActionUrl(String actionUrl) { this.actionUrl = actionUrl; }

    public String getFormhash() { return formhash; }
    public void setFormhash(String formhash) { this.formhash = formhash; }

    public String getBottomMessage() { return bottomMessage; }
    public void setBottomMessage(String bottomMessage) { this.bottomMessage = bottomMessage; }
}
