package com.forum.MT.session;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.forum.MT.R;

import java.util.Random;

/**
 * 签到音效播放器。使用 Application Context，避免 Fragment/Activity 生命周期结束后无法播放。
 */
public final class SignInSoundPlayer {
    private static final String TAG = "SignInSoundPlayer";
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static final Object LOCK = new Object();
    private static MediaPlayer activePlayer;

    private SignInSoundPlayer() {
    }

    public static void play(Context context) {
        if (context == null) return;
        // 检查提示音全局开关，关闭则不播放
        if (!SoundSettingsManager.isSoundEnabled(context)) return;
        Context appContext = context.getApplicationContext();
        MAIN_HANDLER.post(() -> playOnMain(appContext));
    }

    private static void playOnMain(Context context) {
        if (context == null) return;
        synchronized (LOCK) {
            releaseActivePlayer();
            int soundRes = new Random().nextBoolean()
                    ? R.raw.signin_success_1 : R.raw.signin_success_2;
            try {
                MediaPlayer player = MediaPlayer.create(context, soundRes);
                if (player == null) {
                    Log.e(TAG, "MediaPlayer.create returned null, res=" + soundRes);
                    return;
                }
                player.setVolume(1.0f, 1.0f);
                activePlayer = player;
                player.setOnCompletionListener(mp -> {
                    synchronized (LOCK) {
                        if (activePlayer == mp) activePlayer = null;
                    }
                    mp.release();
                });
                player.setOnErrorListener((mp, what, extra) -> {
                    Log.e(TAG, "sign-in sound error: " + what + ", " + extra);
                    synchronized (LOCK) {
                        if (activePlayer == mp) activePlayer = null;
                    }
                    mp.release();
                    return true;
                });
                player.start();
            } catch (Exception e) {
                Log.e(TAG, "Unable to play sign-in sound", e);
                releaseActivePlayer();
            }
        }
    }

    private static void releaseActivePlayer() {
        if (activePlayer != null) {
            try {
                if (activePlayer.isPlaying()) activePlayer.stop();
            } catch (Exception ignored) {
            }
            try {
                activePlayer.release();
            } catch (Exception ignored) {
            }
            activePlayer = null;
        }
    }
}
