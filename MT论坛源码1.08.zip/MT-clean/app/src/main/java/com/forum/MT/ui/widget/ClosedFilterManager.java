package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/** 管理「隐藏已关闭帖子」设置。 */
public final class ClosedFilterManager {
    private static final String PREF_NAME = "app_settings";
    private static final String KEY_HIDE_CLOSED = "hide_closed_threads";
    private static volatile boolean hideClosed;
    private static volatile boolean initialized;
    private static volatile Runnable listener;

    private ClosedFilterManager() {}

    public static void initialize(Context context) {
        if (context == null) return;
        hideClosed = prefs(context).getBoolean(KEY_HIDE_CLOSED, false);
        initialized = true;
    }

    public static boolean isEnabled(Context context) {
        if (!initialized && context != null) initialize(context);
        return hideClosed;
    }

    public static boolean isEnabled() {
        return hideClosed;
    }

    public static void setEnabled(Context context, boolean enabled) {
        hideClosed = enabled;
        initialized = true;
        if (context != null) prefs(context).edit().putBoolean(KEY_HIDE_CLOSED, enabled).apply();
        Runnable r = listener;
        if (r != null) r.run();
    }

    public static void setListener(Runnable listener) {
        ClosedFilterManager.listener = listener;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }
}
