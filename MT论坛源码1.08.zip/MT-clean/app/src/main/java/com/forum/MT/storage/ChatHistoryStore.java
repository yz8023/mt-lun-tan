package com.forum.MT.storage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.forum.MT.model.ChatMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * 私信本地持久化存储。
 *
 * <p>论坛服务端的私信有保留期限，过期后网页不再返回历史内容。开启持久化后，
 * 每次成功拉取的会话消息都会落到本地 SQLite，之后即使服务端不再返回，
 * 本地依然能完整展示。
 *
 * <p>排序完全依赖插入顺序（自增主键）：服务端返回的是从旧到新的顺序，
 * 新消息只会追加在末尾，因此按 _id 升序读出即为正确时间顺序。
 * 不解析 date/time 文本来排序，避免论坛的相对时间格式（“昨天”“前天”）导致错乱。
 */
public class ChatHistoryStore extends SQLiteOpenHelper {

    private static final String DB_NAME = "chat_history.db";
    /**
     * v2：新增 content_html 列，保存带内联表情的富文本，使历史消息重开也能显示表情。
     * v3：把正文里残留的 [img]url[/img] 裸代码升级成图片，并按新去重键合并重复行。
     * v4：去重键改用"剔除全部 [xxx] 记号"的稳定正文，一次性清掉历史遗留的重复行。
     * v5：新增 sort_ts 排序列。此前排序依赖 _id（插入顺序），导入备份时旧消息会拿到
     *     比库内现有行更大的 _id，整段历史被排到最新消息之后，界面上表现为日期混乱。
     */
    private static final int DB_VERSION = 5;

    private static final String TABLE = "chat_messages";
    private static final String COL_ID = "_id";
    /** 会话标识，使用 ChatActivity 的 pmid（对方 touid）。 */
    private static final String COL_CONV = "conv_id";
    /** 去重键，与解析器的去重规则一致：方向|时间|内容。 */
    private static final String COL_KEY = "msg_key";
    private static final String COL_AUTHOR = "author";
    private static final String COL_AUTHOR_UID = "author_uid";
    private static final String COL_AVATAR = "avatar_url";
    private static final String COL_CONTENT = "content";
    /** 带内联表情的富文本，可能为 null（纯文本消息）。 */
    private static final String COL_CONTENT_HTML = "content_html";
    private static final String COL_TIME = "time";
    private static final String COL_DATE = "date";
    private static final String COL_OUTGOING = "outgoing";
    private static final String COL_SAVED_AT = "saved_at";
    /**
     * 排序时间戳（毫秒），由 date + time 解析得出，解析不出时回落到"该会话当前最大值"。
     *
     * <p>不能再用 _id 排序：_id 是本机自增主键，导入备份时会把一整段历史消息
     * 排到已有的最新消息之后。
     */
    private static final String COL_SORT_TS = "sort_ts";

    private static volatile ChatHistoryStore instance;

    public static ChatHistoryStore getInstance(@NonNull Context context) {
        if (instance == null) {
            synchronized (ChatHistoryStore.class) {
                if (instance == null) {
                    instance = new ChatHistoryStore(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    private ChatHistoryStore(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_CONV + " TEXT NOT NULL, "
                + COL_KEY + " TEXT NOT NULL, "
                + COL_AUTHOR + " TEXT, "
                + COL_AUTHOR_UID + " TEXT, "
                + COL_AVATAR + " TEXT, "
                + COL_CONTENT + " TEXT, "
                + COL_CONTENT_HTML + " TEXT, "
                + COL_TIME + " TEXT, "
                + COL_DATE + " TEXT, "
                + COL_OUTGOING + " INTEGER NOT NULL DEFAULT 0, "
                + COL_SAVED_AT + " INTEGER NOT NULL DEFAULT 0, "
                + COL_SORT_TS + " INTEGER NOT NULL DEFAULT 0)");
        // 同一会话内同一条消息只保留一份，重复拉取靠 CONFLICT_IGNORE 静默跳过。
        db.execSQL("CREATE UNIQUE INDEX idx_conv_key ON " + TABLE
                + " (" + COL_CONV + ", " + COL_KEY + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // 已有历史消息没有富文本，保持 NULL 即可：适配器会回落到纯文本渲染，
            // 下一次拉取到同一条消息时也不会因为 CONFLICT_IGNORE 而补写，
            // 但新消息都会带上富文本，属于可接受的降级。
            try {
                db.execSQL("ALTER TABLE " + TABLE + " ADD COLUMN "
                        + COL_CONTENT_HTML + " TEXT");
            } catch (Exception ignored) {}
        }
        if (oldVersion < 4) {
            rebuildKeys(db);
        }
        if (oldVersion < 5) {
            try {
                db.execSQL("ALTER TABLE " + TABLE + " ADD COLUMN "
                        + COL_SORT_TS + " INTEGER NOT NULL DEFAULT 0");
            } catch (Exception ignored) {}
            backfillSortTs(db);
        }
    }

    /**
     * 给历史行补 sort_ts。
     *
     * <p>按 _id 升序遍历（升级前的库里 _id 顺序就是正确的时间顺序），能从 date+time
     * 解析出时间戳的直接写入；解析不出的（date 为空、或格式不认识）沿用"上一行的
     * 时间戳 + 1ms"，这样它仍夹在原来的两条邻居之间，不会跳位。
     */
    private static void backfillSortTs(SQLiteDatabase db) {
        Cursor c = null;
        try {
            c = db.query(TABLE, new String[]{COL_ID, COL_DATE, COL_TIME},
                    null, null, null, null, COL_ID + " ASC");
            int iId = c.getColumnIndexOrThrow(COL_ID);
            int iDate = c.getColumnIndexOrThrow(COL_DATE);
            int iTime = c.getColumnIndexOrThrow(COL_TIME);
            long previous = 0L;
            while (c.moveToNext()) {
                long parsed = parseSortTs(c.getString(iDate), c.getString(iTime));
                long ts = parsed > 0 ? parsed : previous + 1L;
                previous = ts;
                ContentValues cv = new ContentValues();
                cv.put(COL_SORT_TS, ts);
                try {
                    db.update(TABLE, cv, COL_ID + "=?",
                            new String[]{String.valueOf(c.getLong(iId))});
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }
    }

    /**
     * 由 date + time 文本算出排序用时间戳，失败返回 0。
     *
     * <p>date 已由 {@link #resolveDate} 归一化成 yyyy-MM-dd（相对日期在首次保存时
     * 就被换算掉了）。time 可能是 "HH:mm"、"HH:mm:ss"，也可能带日期前缀
     * （如 "2026-08-29 12:00:33"），后者优先直接采用。
     */
    static long parseSortTs(@Nullable String date, @Nullable String time) {
        String full = null;
        if (!TextUtils.isEmpty(time)) {
            java.util.regex.Matcher m = FULL_DATETIME.matcher(time);
            if (m.find()) full = m.group();
        }
        if (full == null && !TextUtils.isEmpty(date) && !TextUtils.isEmpty(time)) {
            java.util.regex.Matcher dm = DATE_ONLY.matcher(date);
            java.util.regex.Matcher tm = HH_MM.matcher(time);
            if (dm.find() && tm.find()) {
                String second = tm.group(3) == null ? "00" : tm.group(3);
                full = dm.group() + " "
                        + String.format(java.util.Locale.ROOT, "%02d:%02d:%s",
                                Integer.parseInt(tm.group(1)),
                                Integer.parseInt(tm.group(2)), second);
            }
        }
        if (full == null) return 0L;
        // 统一补齐到秒后解析，避免两套 format 分支。
        if (full.length() == 16) full = full + ":00";
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss", java.util.Locale.ROOT);
            java.util.Date parsed = f.parse(full);
            return parsed == null ? 0L : parsed.getTime();
        } catch (Exception e) {
            return 0L;
        }
    }

    private static final java.util.regex.Pattern FULL_DATETIME =
            java.util.regex.Pattern.compile(
                    "\\d{4}-\\d{1,2}-\\d{1,2}\\s+\\d{1,2}:\\d{2}(?::\\d{2})?");
    private static final java.util.regex.Pattern DATE_ONLY =
            java.util.regex.Pattern.compile("\\d{4}-\\d{1,2}-\\d{1,2}");

    /** 该会话当前最大的 sort_ts，用于给解析不出时间的新消息兜底排到末尾。 */
    private static long maxSortTs(SQLiteDatabase db, String convId) {
        Cursor c = null;
        try {
            c = db.rawQuery("SELECT MAX(" + COL_SORT_TS + ") FROM " + TABLE
                    + " WHERE " + COL_CONV + "=?", new String[]{convId});
            if (c.moveToFirst()) return c.getLong(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }
        return 0L;
    }

    /**
     * 按当前规则重算全表去重键，并删掉由旧规则遗留的重复行。
     *
     * <p>这一步是一次性的历史数据修复，只在升级时跑一次，之后正常写入靠唯一索引拦重复。
     *
     * <p>需要修复的原因：去重键含正文，而正文的表示形式随解析器演进变过几轮
     * （{@code [img]url[/img]} 裸码 → {@code [图片]}；表情 {@code <img>} → 表情名）。
     * 每变一次，同一条历史消息算出的键就换一个，唯一索引拦不住，
     * {@code CONFLICT_IGNORE} 静默放行，旧消息被当作新消息追加到表尾 ——
     * 界面上就是"最新消息底下又冒出几条更早的旧消息"。
     *
     * <p>做法：按 _id 升序遍历（即原始时间顺序），顺带把仍是裸 BBCode 的正文升级成
     * 图片；对每行算新键，同一会话内首次出现的保留并写回新键，重复的直接删除。
     * 保留最小 _id 那一份，因此原有的正确顺序不受影响。
     *
     * <p>遍历期间先摘掉唯一索引：逐行改键的中途会出现"新键撞上另一行尚未被处理的旧键"
     * 的瞬时冲突，有索引在会让更新失败。去重由内存里的 seen 集合负责，
     * 结束后再重建索引。
     */
    private static void rebuildKeys(SQLiteDatabase db) {
        try {
            db.execSQL("DROP INDEX IF EXISTS idx_conv_key");
        } catch (Exception ignored) {}

        List<Long> duplicates = new ArrayList<>();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        Cursor c = null;
        try {
            c = db.query(TABLE,
                    new String[]{COL_ID, COL_CONV, COL_CONTENT, COL_CONTENT_HTML,
                            COL_TIME, COL_OUTGOING},
                    null, null, null, null, COL_ID + " ASC");
            int iId = c.getColumnIndexOrThrow(COL_ID);
            int iConv = c.getColumnIndexOrThrow(COL_CONV);
            int iContent = c.getColumnIndexOrThrow(COL_CONTENT);
            int iHtml = c.getColumnIndexOrThrow(COL_CONTENT_HTML);
            int iTime = c.getColumnIndexOrThrow(COL_TIME);
            int iOutgoing = c.getColumnIndexOrThrow(COL_OUTGOING);
            while (c.moveToNext()) {
                long id = c.getLong(iId);
                String conv = c.getString(iConv);
                String content = c.getString(iContent);
                String html = c.getString(iHtml);
                // 仍是 [img]url[/img] 裸码的老行：先升级成"[图片] + 精简 HTML"，
                // 否则它在气泡里始终显示成一串裸代码。
                String[] upgraded =
                        com.forum.MT.network.ForumParser.upgradeChatBbImageContent(content);
                if (upgraded != null) {
                    content = upgraded[0];
                    if (!TextUtils.isEmpty(upgraded[1])) html = upgraded[1];
                }
                String key = (c.getInt(iOutgoing) == 1 ? "self" : "friend")
                        + "|" + normalizeTime(c.getString(iTime))
                        + "|" + com.forum.MT.network.ForumParser.chatDedupContentKey(content);
                if (!seen.add(conv + "\u0000" + key)) {
                    duplicates.add(id);
                    continue;
                }
                ContentValues cv = new ContentValues();
                cv.put(COL_KEY, key);
                cv.put(COL_CONTENT, content);
                cv.put(COL_CONTENT_HTML, html);
                try {
                    db.update(TABLE, cv, COL_ID + "=?", new String[]{String.valueOf(id)});
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }

        for (Long id : duplicates) {
            try {
                db.delete(TABLE, COL_ID + "=?", new String[]{String.valueOf(id)});
            } catch (Exception ignored) {}
        }
        try {
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_conv_key ON " + TABLE
                    + " (" + COL_CONV + ", " + COL_KEY + ")");
        } catch (Exception ignored) {}
    }

    /**
     * 去重键：方向 + 内容 + 归一化到 HH:mm 的时间。
     *
     * <p>不使用原始 time/date 文本，因为论坛会把新消息显示成相对时间（“昨天 12:00”），
     * 过一段时间又变成绝对时间（“2026-08-29 12:00:33”）。若把这些文本直接放进键里，
     * 同一条消息会因为文本变化被重复插入。HH:mm 在两种格式里都稳定存在。
     */
    public static String messageKey(@NonNull ChatMessage m) {
        return (m.isOutgoing() ? "self" : "friend")
                + "|" + normalizeTime(m.getTime())
                + "|" + com.forum.MT.network.ForumParser
                        .chatDedupContentKey(m.getContent());
    }

    private static final java.util.regex.Pattern HH_MM =
            java.util.regex.Pattern.compile("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?");

    private static String normalizeTime(@Nullable String time) {
        if (TextUtils.isEmpty(time)) return "";
        java.util.regex.Matcher matcher = HH_MM.matcher(time);
        if (matcher.find()) {
            String base = String.format(java.util.Locale.ROOT, "%02d:%02d",
                    Integer.parseInt(matcher.group(1)),
                    Integer.parseInt(matcher.group(2)));
            // 秒必须带上（论坛的私信时间就是到秒的）：纯图片、纯表情消息在
            // 归一化后正文为空，键只剩"方向+时间"，若精度只到分钟，同一分钟内
            // 连发两张图会被判成同一条，后一张永远存不进来。
            String second = matcher.group(3);
            return second == null ? base : base + ":" + second;
        }
        return time.trim();
    }

    /**
     * 把相对日期解析成绝对日期后再入库。
     *
     * <p>“今天/昨天/前天”只在写入当时成立，若原样保存，几天后回看历史会显示错误的日期。
     * 由于重复消息走 CONFLICT_IGNORE，这里的解析只在第一次保存时发生，那时相对日期是准确的。
     */
    private static String resolveDate(@Nullable String date) {
        if (TextUtils.isEmpty(date)) return "";
        int offsetDays;
        if (date.contains("今天")) offsetDays = 0;
        else if (date.contains("前天")) offsetDays = -2;
        else if (date.contains("昨天")) offsetDays = -1;
        else return date;
        java.util.Calendar calendar = java.util.Calendar.getInstance();
        calendar.add(java.util.Calendar.DAY_OF_YEAR, offsetDays);
        return new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ROOT)
                .format(calendar.getTime());
    }

    /**
     * 保存一个会话的消息列表。已存在的消息会被忽略，不会重复插入也不会改变原有顺序。
     * 待确认（pending）消息不落库，等服务端确认后的下一次拉取再保存。
     *
     * @return 实际新插入的条数
     */
    public int saveMessages(@Nullable String convId, @Nullable List<ChatMessage> messages) {
        if (TextUtils.isEmpty(convId) || messages == null || messages.isEmpty()) return 0;
        int inserted = 0;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long now = System.currentTimeMillis();
            // 解析不出时间的消息接在该会话末尾，逐条 +1ms 保持相对顺序。
            long fallback = maxSortTs(db, convId);
            for (ChatMessage m : messages) {
                if (m == null || m.isPending()) continue;
                if (TextUtils.isEmpty(m.getContent())) continue;
                String resolvedDate = resolveDate(m.getDate());
                long sortTs = parseSortTs(resolvedDate, m.getTime());
                if (sortTs <= 0) {
                    fallback += 1L;
                    sortTs = fallback;
                } else if (sortTs > fallback) {
                    fallback = sortTs;
                }
                ContentValues cv = new ContentValues();
                cv.put(COL_CONV, convId);
                cv.put(COL_KEY, messageKey(m));
                cv.put(COL_AUTHOR, m.getAuthor());
                cv.put(COL_AUTHOR_UID, m.getAuthorUid());
                cv.put(COL_AVATAR, m.getAvatarUrl());
                cv.put(COL_CONTENT, m.getContent());
                cv.put(COL_CONTENT_HTML, m.getContentHtml());
                cv.put(COL_TIME, m.getTime());
                cv.put(COL_DATE, resolvedDate);
                cv.put(COL_OUTGOING, m.isOutgoing() ? 1 : 0);
                cv.put(COL_SAVED_AT, now);
                cv.put(COL_SORT_TS, sortTs);
                long id = db.insertWithOnConflict(TABLE, null, cv,
                        SQLiteDatabase.CONFLICT_IGNORE);
                if (id > 0) inserted++;
            }
            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { db.endTransaction(); } catch (Exception ignored) {}
        }
        return inserted;
    }

    /** 读取一个会话的全部历史消息，按真实时间顺序（sort_ts）返回。 */
    @NonNull
    public List<ChatMessage> loadMessages(@Nullable String convId) {
        List<ChatMessage> result = new ArrayList<>();
        if (TextUtils.isEmpty(convId)) return result;
        Cursor c = null;
        try {
            c = getReadableDatabase().query(TABLE, null,
                    COL_CONV + "=?", new String[]{convId},
                    null, null, COL_SORT_TS + " ASC, " + COL_ID + " ASC");
            int iAuthor = c.getColumnIndexOrThrow(COL_AUTHOR);
            int iAuthorUid = c.getColumnIndexOrThrow(COL_AUTHOR_UID);
            int iAvatar = c.getColumnIndexOrThrow(COL_AVATAR);
            int iContent = c.getColumnIndexOrThrow(COL_CONTENT);
            int iContentHtml = c.getColumnIndex(COL_CONTENT_HTML);
            int iTime = c.getColumnIndexOrThrow(COL_TIME);
            int iDate = c.getColumnIndexOrThrow(COL_DATE);
            int iOutgoing = c.getColumnIndexOrThrow(COL_OUTGOING);
            while (c.moveToNext()) {
                ChatMessage m = new ChatMessage();
                m.setAuthor(c.getString(iAuthor));
                m.setAuthorUid(c.getString(iAuthorUid));
                m.setAvatarUrl(c.getString(iAvatar));
                m.setContent(c.getString(iContent));
                if (iContentHtml >= 0) m.setContentHtml(c.getString(iContentHtml));
                m.setTime(c.getString(iTime));
                m.setDate(c.getString(iDate));
                m.setOutgoing(c.getInt(iOutgoing) == 1);
                result.add(m);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }
        return result;
    }

    /** 已保存的消息总条数，用于设置页展示。 */
    public long countMessages() {
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + TABLE, null);
            if (c.moveToFirst()) return c.getLong(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }
        return 0;
    }

    /** 已保存的会话数量，用于设置页展示。 */
    public long countConversations() {
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery(
                    "SELECT COUNT(DISTINCT " + COL_CONV + ") FROM " + TABLE, null);
            if (c.moveToFirst()) return c.getLong(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }
        return 0;
    }

    // ---------------------------------------------------------------
    // 导入 / 导出
    // ---------------------------------------------------------------

    /** 备份文件格式版本。字段增减时递增，导入端据此做兼容处理。 */
    public static final int BACKUP_VERSION = 1;

    private static final String BK_TYPE = "mt_chat_history";

    /**
     * 把全部本地私信导出成 JSON 文本。
     *
     * <p>按会话分组，会话内保持 _id 升序（即真实时间顺序），导入端逐条 insert
     * 即可复原顺序。不导出 _id 与 saved_at：前者是本机自增主键无跨设备意义，
     * 后者会在导入时按导入时间重新写入。
     *
     * @return JSON 文本；库为空时返回只含头部、conversations 为空数组的 JSON
     */
    @NonNull
    public String exportToJson() throws Exception {
        org.json.JSONObject root = new org.json.JSONObject();
        root.put("type", BK_TYPE);
        root.put("version", BACKUP_VERSION);
        root.put("exported_at", System.currentTimeMillis());

        org.json.JSONArray conversations = new org.json.JSONArray();
        Cursor c = null;
        try {
            c = getReadableDatabase().query(TABLE, null, null, null, null, null,
                    COL_CONV + " ASC, " + COL_SORT_TS + " ASC, " + COL_ID + " ASC");
            int iConv = c.getColumnIndexOrThrow(COL_CONV);
            int iAuthor = c.getColumnIndexOrThrow(COL_AUTHOR);
            int iAuthorUid = c.getColumnIndexOrThrow(COL_AUTHOR_UID);
            int iAvatar = c.getColumnIndexOrThrow(COL_AVATAR);
            int iContent = c.getColumnIndexOrThrow(COL_CONTENT);
            int iContentHtml = c.getColumnIndex(COL_CONTENT_HTML);
            int iTime = c.getColumnIndexOrThrow(COL_TIME);
            int iDate = c.getColumnIndexOrThrow(COL_DATE);
            int iOutgoing = c.getColumnIndexOrThrow(COL_OUTGOING);

            String currentConv = null;
            org.json.JSONArray currentMessages = null;
            while (c.moveToNext()) {
                String conv = c.getString(iConv);
                if (currentConv == null || !currentConv.equals(conv)) {
                    currentConv = conv;
                    currentMessages = new org.json.JSONArray();
                    org.json.JSONObject convObj = new org.json.JSONObject();
                    convObj.put("conv_id", conv == null ? "" : conv);
                    convObj.put("messages", currentMessages);
                    conversations.put(convObj);
                }
                org.json.JSONObject m = new org.json.JSONObject();
                putIfPresent(m, "author", c.getString(iAuthor));
                putIfPresent(m, "author_uid", c.getString(iAuthorUid));
                putIfPresent(m, "avatar_url", c.getString(iAvatar));
                putIfPresent(m, "content", c.getString(iContent));
                if (iContentHtml >= 0) putIfPresent(m, "content_html", c.getString(iContentHtml));
                putIfPresent(m, "time", c.getString(iTime));
                putIfPresent(m, "date", c.getString(iDate));
                m.put("outgoing", c.getInt(iOutgoing) == 1);
                currentMessages.put(m);
            }
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }
        root.put("conversations", conversations);
        return root.toString();
    }

    /** 空值不写进 JSON，减小备份体积。 */
    private static void putIfPresent(org.json.JSONObject obj, String key, @Nullable String value)
            throws org.json.JSONException {
        if (!TextUtils.isEmpty(value)) obj.put(key, value);
    }

    /**
     * 导入备份 JSON。
     *
     * <p>走与在线拉取相同的 {@link #saveMessages} 路径，因此去重键、相对日期解析、
     * 唯一索引冲突忽略的行为完全一致：重复导入同一份文件不会产生重复消息。
     *
     * @return {新增条数, 跳过条数(已存在或无效)}
     * @throws IllegalArgumentException JSON 不是本应用的私信备份
     */
    @NonNull
    public int[] importFromJson(@Nullable String json) throws Exception {
        if (TextUtils.isEmpty(json)) throw new IllegalArgumentException("文件内容为空");
        org.json.JSONObject root = new org.json.JSONObject(json);
        if (!BK_TYPE.equals(root.optString("type"))) {
            throw new IllegalArgumentException("不是 MT 私信备份文件");
        }
        org.json.JSONArray conversations = root.optJSONArray("conversations");
        if (conversations == null) throw new IllegalArgumentException("备份文件缺少会话数据");

        int total = 0;
        int inserted = 0;
        for (int i = 0; i < conversations.length(); i++) {
            org.json.JSONObject convObj = conversations.optJSONObject(i);
            if (convObj == null) continue;
            String convId = convObj.optString("conv_id");
            org.json.JSONArray messages = convObj.optJSONArray("messages");
            if (TextUtils.isEmpty(convId) || messages == null) continue;

            List<ChatMessage> list = new ArrayList<>(messages.length());
            for (int j = 0; j < messages.length(); j++) {
                org.json.JSONObject mo = messages.optJSONObject(j);
                if (mo == null) continue;
                String content = mo.optString("content");
                if (TextUtils.isEmpty(content)) continue;
                ChatMessage m = new ChatMessage();
                m.setAuthor(emptyToNull(mo.optString("author")));
                m.setAuthorUid(emptyToNull(mo.optString("author_uid")));
                m.setAvatarUrl(emptyToNull(mo.optString("avatar_url")));
                m.setContent(content);
                m.setContentHtml(emptyToNull(mo.optString("content_html")));
                m.setTime(mo.optString("time"));
                m.setDate(mo.optString("date"));
                m.setOutgoing(mo.optBoolean("outgoing"));
                list.add(m);
                total++;
            }
            inserted += saveMessages(convId, list);
        }
        return new int[]{inserted, Math.max(0, total - inserted)};
    }

    @Nullable
    private static String emptyToNull(@Nullable String s) {
        return TextUtils.isEmpty(s) ? null : s;
    }

    /** 清空全部本地私信记录。 */
    public void clearAll() {
        try {
            getWritableDatabase().delete(TABLE, null, null);
        } catch (Exception ignored) {}
    }
}
