package com.forum.MT.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.BrowseHistory;
import com.forum.MT.ui.widget.CardBorderManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 浏览历史列表适配器。
 */
public class BrowseHistoryAdapter extends RecyclerView.Adapter<BrowseHistoryAdapter.HistoryViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(BrowseHistory item);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(BrowseHistory item, int position);
    }

    private final Context context;
    private final List<BrowseHistory> items = new ArrayList<>();
    private OnItemClickListener clickListener;
    private OnItemLongClickListener longClickListener;
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault());
    private final SimpleDateFormat todayFmt = new SimpleDateFormat("HH:mm", Locale.getDefault());

    public BrowseHistoryAdapter(Context context) {
        this.context = context;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.clickListener = listener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    public void setItems(List<BrowseHistory> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        if (position >= 0 && position < items.size()) {
            items.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, items.size() - position);
        }
    }

    public BrowseHistory getItem(int position) {
        return items.get(position);
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_browse_history, parent, false);
        // 浏览历史卡片与帖子列表（item_thread）使用同一套主题卡片样式：
        // 背景填充由 CardColorManager 控制，边框由 CardBorderManager 控制
        //（开启「卡片边框效果」时用静态描边，否则用流水灯，两者互斥）。
        CardBorderManager.applyBorder(view, 14f);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        BrowseHistory item = items.get(position);

        holder.tvTitle.setText(!TextUtils.isEmpty(item.getTitle()) ? item.getTitle() : "未知标题");

        // 版块名
        String forum = item.getForumName();
        holder.tvForum.setText(!TextUtils.isEmpty(forum) ? forum : "");

        // 作者
        holder.tvAuthor.setText(!TextUtils.isEmpty(item.getAuthor()) ? item.getAuthor() : "匿名");

        // 浏览时间
        if (item.getViewTime() > 0) {
            holder.tvTime.setText(formatTime(item.getViewTime()));
        } else {
            holder.tvTime.setText("");
        }

        // 头像
        String avatarUrl = item.getAvatarUrl();
        if (!TextUtils.isEmpty(avatarUrl)) {
            Glide.with(context)
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(holder.ivAvatar);
        } else {
            holder.ivAvatar.setImageResource(R.drawable.ic_account);
        }

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) clickListener.onItemClick(item);
        });
        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onItemLongClick(item, holder.getAdapterPosition());
                return true;
            }
            return false;
        });
    }

    /**
     * 格式化时间：今天显示 HH:mm，否则显示 MM-dd HH:mm
     */
    private String formatTime(long timestamp) {
        Date date = new Date(timestamp);
        Date now = new Date();
        // 判断是否今天
        SimpleDateFormat dayFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        if (dayFmt.format(date).equals(dayFmt.format(now))) {
            return "今天 " + todayFmt.format(date);
        }
        return dateFmt.format(date);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class HistoryViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivAvatar;
        final TextView tvTitle;
        final TextView tvForum;
        final TextView tvAuthor;
        final TextView tvTime;

        HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.iv_avatar);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvForum = itemView.findViewById(R.id.tv_forum);
            tvAuthor = itemView.findViewById(R.id.tv_author);
            tvTime = itemView.findViewById(R.id.tv_time);
        }
    }
}
