package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 底部导航栏样式管理器。
 * 关闭（默认）：胶囊悬浮样式（圆角+边距+阴影）
 * 开启：官方样式（全宽矩形贴底+系统导航栏inset）
 */
public class NavBarStyleManager {

    private static final String PREF_NAME = "app_settings";
    private static final String KEY_OFFICIAL_STYLE = "nav_bar_official_style";

    private static boolean officialStyle = false;

    public interface OnStyleChangedListener {
        void onStyleChanged();
    }

    private static volatile OnStyleChangedListener listener;

    public static void setListener(OnStyleChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnStyleChangedListener l = listener;
        if (l != null) l.onStyleChanged();
    }

    public static void initialize(Context context) {
        if (context == null) return;
        officialStyle = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_OFFICIAL_STYLE, false);
    }

    public static boolean isOfficialStyle() {
        return officialStyle;
    }

    public static void setOfficialStyle(Context context, boolean value) {
        officialStyle = value;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_OFFICIAL_STYLE, value).apply();
        }
        notifyChanged();
    }
}
