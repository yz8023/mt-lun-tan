package com.forum.MT.ui.message;
import com.forum.MT.ui.BaseActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.widget.ViewPager2;

import com.forum.MT.R;
import com.forum.MT.model.MessageTab;
import com.forum.MT.network.NoticeBadgeManager;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

/**
 * 消息主界面 - TabLayout + ViewPager2 布局
 * 对应官方APK的4Tab设计：私信/@我/帖子/系统通知
 */
public class NoticeActivity extends BaseActivity implements NoticeBadgeHost {

    private MessageViewModel viewModel;
    private ViewPager2 viewPager;
    private TabLayout tabLayout;
    private NoticePagerAdapter pagerAdapter;
    private TextView tvClearAll;

    /** Tab 下标 → 分类 key（与 MainActivity/NoticeBadgeManager 一致） */
    private static final String[] TAB_VIEW_TYPES = {
            "pm", "mypost_at", "mypost_post", "other"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice);

        viewModel = new ViewModelProvider(this).get(MessageViewModel.class);

        findViewById(R.id.tv_back).setOnClickListener(v -> finish());

        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.view_pager);
        tvClearAll = findViewById(R.id.tv_clear_all);

        // 设置ViewPager2适配器
        pagerAdapter = new NoticePagerAdapter(this);
        viewPager.setAdapter(pagerAdapter);
        viewPager.setOffscreenPageLimit(3); // 预加载所有Tab

        // 关联TabLayout和ViewPager2
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            tab.setText(MessageTab.fromIndex(position).getDisplayName());
        }).attach();

        // 显示各分类角标（不进入即清零；保留直到逐条已读或点“全部已读”）
        updateTabBadges();
        viewModel.getOtherMessagesBadgesUpdated().observe(this, value -> updateTabBadges());

        // 全部已读：清零所有分类角标并重置基线（不影响下次新消息统计）
        tvClearAll.setOnClickListener(v -> {
            NoticeBadgeManager.markAllViewed(this);
            clearTabBadges();
        });

        // Tab切换时更新ViewModel的currentTab
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                viewModel.setCurrentTab(MessageTab.fromIndex(position));
            }
        });

        // 初始加载数据
        viewModel.loadAll();

        // 应用全局强调色到「全部已读」与 TabLayout
        applyAccentColors();
        com.forum.MT.ui.widget.AccentColorManager.setListener(this::applyAccentColors);
    }

    /**
     * 将「全部已读」链接与 TabLayout 选中色/指示条统一为全局强调色。
     */
    private void applyAccentColors() {
        int accent = com.forum.MT.ui.widget.AccentColorManager.resolveAccentColor();
        if (tvClearAll != null) tvClearAll.setTextColor(accent);
        if (tabLayout != null) {
            tabLayout.setTabTextColors(
                    getResources().getColor(R.color.text_secondary, null), accent);
            tabLayout.setSelectedTabIndicatorColor(accent);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        com.forum.MT.ui.widget.AccentColorManager.setListener(null);
    }

    public MessageViewModel getViewModel() {
        return viewModel;
    }

    /**
     * 从 NoticeBadgeManager 读取各分类新增数，更新 Tab 角标。
     * 仅在有新增时显示角标；无新增时隐藏。
     * Tab 4 "其它消息" 的角标 = follower + interactive + system + app 之和。
     */
    public void updateTabBadges() {
        for (int i = 0; i < TAB_VIEW_TYPES.length && i < tabLayout.getTabCount(); i++) {
            int count;
            if ("other".equals(TAB_VIEW_TYPES[i])) {
                count = NoticeBadgeManager.getNewCount(this, "follower")
                        + NoticeBadgeManager.getNewCount(this, "interactive")
                        + NoticeBadgeManager.getNewCount(this, "system")
                        + NoticeBadgeManager.getNewCount(this, "app");
            } else {
                count = NoticeBadgeManager.getNewCount(this, TAB_VIEW_TYPES[i]);
            }
            setTabBadge(i, count);
        }
    }

    private void setTabBadge(int tabIndex, int count) {
        TabLayout.Tab tab = tabLayout.getTabAt(tabIndex);
        if (tab == null) return;
        BadgeDrawable badge = tab.getOrCreateBadge();
        if (count > 0) {
            badge.setVisible(true);
            badge.setNumber(count);
            badge.setBadgeTextColor(getColor(R.color.white));
            badge.setBackgroundColor(getColor(R.color.red_500));
        } else {
            badge.setVisible(false);
            badge.clearNumber();
        }
    }

    private void clearTabBadges() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            setTabBadge(i, 0);
        }
    }

    /**
     * 某分类下的一条内容被标记已读后调用，刷新对应 Tab 角标。
     *
     * @param viewType 与 TAB_VIEW_TYPES 对应的分类 key，或子分类 key（follower/interactive/system/app）
     */
    public void refreshTabBadge(String viewType) {
        if ("other".equals(viewType) || "follower".equals(viewType)
                || "interactive".equals(viewType) || "system".equals(viewType)
                || "app".equals(viewType)) {
            int count = NoticeBadgeManager.getNewCount(this, "follower")
                    + NoticeBadgeManager.getNewCount(this, "interactive")
                    + NoticeBadgeManager.getNewCount(this, "system")
                    + NoticeBadgeManager.getNewCount(this, "app");
            setTabBadge(3, count);
            return;
        }
        for (int i = 0; i < TAB_VIEW_TYPES.length; i++) {
            if (TAB_VIEW_TYPES[i].equals(viewType)) {
                int count = NoticeBadgeManager.getNewCount(this, viewType);
                setTabBadge(i, count);
                break;
            }
        }
    }

    /** 供 Fragment 数据加载完成后刷新对应 Tab 角标（可选）。 */
    public void refreshTabBadge(int tabIndex) {
        if (tabIndex < 0 || tabIndex >= TAB_VIEW_TYPES.length) return;
        int count = NoticeBadgeManager.getNewCount(this, TAB_VIEW_TYPES[tabIndex]);
        setTabBadge(tabIndex, count);
    }
}