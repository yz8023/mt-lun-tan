package com.forum.MT.model;

/**
 * 热帖排行榜条目。
 *
 * <p>对应 {@code misc.php?mod=ranklist&type=thread} 页面里 {@code div.comiis_postphb ul li}
 * 的一行。榜单页给出的字段比帖子列表少（没有摘要、封面图、版块名），
 * 但多一个"名次"和一个随榜单类型变化的指标值，因此不复用 {@link Thread}。
 *
 * <p>{@link #metricText} 直接保留网页原文（如 "4254热度" / "1244418人气" / "3847回复"），
 * 这样切换榜单类型时不需要在客户端拼单位，也避免把 "1244418" 这种数值再解析一次。
 */
public class RankThread {

    private int rank;            // 名次，从 1 开始
    private String tid;          // 帖子ID
    private String title;        // 标题
    private String author;       // 作者名
    private String authorUid;    // 作者UID
    private String avatarUrl;    // 作者头像URL
    private String metricText;   // 指标原文，如 "4254热度"
    private String publishTime;  // 发布时间，如 "2019-10-29 19:22"

    public int getRank() { return rank; }
    public void setRank(int rank) { this.rank = rank; }

    public String getTid() { return tid; }
    public void setTid(String tid) { this.tid = tid; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getAuthorUid() { return authorUid; }
    public void setAuthorUid(String authorUid) { this.authorUid = authorUid; }

    public String getAvatarUrl() { return avatarUrl; }
    public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }

    public String getMetricText() { return metricText; }
    public void setMetricText(String metricText) { this.metricText = metricText; }

    public String getPublishTime() { return publishTime; }
    public void setPublishTime(String publishTime) { this.publishTime = publishTime; }
}
