package com.forum.MT.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.Message;
import com.forum.MT.ui.widget.ForumCardColorManager;

import java.util.ArrayList;
import java.util.List;

/** 留言板列表适配器：头像 + 用户名 + 时间 + 引用块 + 内容，样式对齐评论区。 */
public class WallMessageAdapter extends RecyclerView.Adapter<WallMessageAdapter.ViewHolder> {

    private List<Message> list = new ArrayList<>();
    private final Context context;
    private OnItemClickListener listener;
    private OnActionClickListener actionListener;

    public interface OnItemClickListener {
        void onItemClick(Message message, int position);
    }

    /** 留言操作回调：编辑 / 删除 / 回复自己或他人的留言。 */
    public interface OnActionClickListener {
        void onEdit(Message message, int position);
        void onDelete(Message message, int position);
        void onReply(Message message, int position);
    }

    public WallMessageAdapter(Context context) {
        this.context = context;
    }

    public void setListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setActionListener(OnActionClickListener actionListener) {
        this.actionListener = actionListener;
    }

    public void setList(List<Message> list) {
        this.list = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    public Message getItem(int position) {
        if (position < 0 || position >= list.size()) return null;
        return list.get(position);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_wall_message, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Message m = list.get(position);
        boolean isReply = m.getType() == 3;

        // 留言卡片跟随主题设置中的内容卡片颜色，并保证文字对比度。
        h.itemView.setBackground(ForumCardColorManager.createCardBackground(context));
        int primaryTextColor = ForumCardColorManager.isDarkText()
                ? 0xFF212121 : 0xFFFFFFFF;
        int secondaryTextColor = ForumCardColorManager.isDarkText()
                ? 0xFF757575 : 0xFFEEEEEE;

        // 回复项左缩进，模拟官网的嵌套层级。
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) h.itemView.getLayoutParams();
        if (isReply) {
            lp.setMarginStart(48);
        } else {
            lp.setMarginStart(6);
        }
        h.itemView.setLayoutParams(lp);

        // 作者：有名字时显示，无名字时兜底"匿名"
        String author = m.getAuthor();
        h.tvAuthor.setVisibility(View.VISIBLE);
        h.tvAuthor.setText(TextUtils.isEmpty(author) ? "匿名" : author);
        h.tvAuthor.setTextColor(primaryTextColor);
        h.tvTime.setTextColor(secondaryTextColor);
        h.tvContent.setTextColor(primaryTextColor);

        String time = m.getTime();
        h.tvTime.setText(TextUtils.isEmpty(time) ? "" : time);
        h.tvTime.setVisibility(TextUtils.isEmpty(time) ? View.GONE : View.VISIBLE);

        String content = m.getSummary() != null ? m.getSummary() : m.getTitle();
        h.tvContent.setText(TextUtils.isEmpty(content) ? "" : content);

        // 引用块：网页端留言内嵌的灰色引用卡片（主人回复），只要有内容就显示。
        String quoted = m.getQuotedContent();
        if (!TextUtils.isEmpty(quoted)) {
            h.layoutQuote.setVisibility(View.VISIBLE);
            h.tvQuote.setText(quoted);
            h.tvQuote.setTextColor(secondaryTextColor);
        } else {
            h.layoutQuote.setVisibility(View.GONE);
        }

        String avatarUrl = m.getAvatarUrl();
        if (!TextUtils.isEmpty(avatarUrl)) {
            Glide.with(context)
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(h.avatar);
        } else {
            Glide.with(context).clear(h.avatar);
            h.avatar.setImageResource(R.drawable.ic_account);
        }

        // 只有网页端渲染了编辑/删除链接的留言（即自己发送的）才显示操作按钮。
        boolean canEdit = !TextUtils.isEmpty(m.getWallEditUrl());
        boolean canDelete = !TextUtils.isEmpty(m.getWallDeleteUrl());
        boolean canReply = !TextUtils.isEmpty(m.getWallReplyUrl());
        h.btnReply.setVisibility(canReply ? View.VISIBLE : View.GONE);
        h.btnEdit.setVisibility(canEdit ? View.VISIBLE : View.GONE);
        h.btnDelete.setVisibility(canDelete ? View.VISIBLE : View.GONE);
        h.btnReply.setOnClickListener(canReply ? v -> {
            int adapterPosition = h.getBindingAdapterPosition();
            if (actionListener != null && adapterPosition != RecyclerView.NO_POSITION) {
                actionListener.onReply(m, adapterPosition);
            }
        } : null);
        h.btnEdit.setOnClickListener(canEdit ? v -> {
            int adapterPosition = h.getBindingAdapterPosition();
            if (actionListener != null && adapterPosition != RecyclerView.NO_POSITION) {
                actionListener.onEdit(m, adapterPosition);
            }
        } : null);
        h.btnDelete.setOnClickListener(canDelete ? v -> {
            int adapterPosition = h.getBindingAdapterPosition();
            if (actionListener != null && adapterPosition != RecyclerView.NO_POSITION) {
                actionListener.onDelete(m, adapterPosition);
            }
        } : null);

        View.OnClickListener authorClick = v -> {
            int adapterPosition = h.getBindingAdapterPosition();
            if (listener != null && adapterPosition != RecyclerView.NO_POSITION) {
                listener.onItemClick(m, adapterPosition);
            }
        };
        h.avatar.setOnClickListener(authorClick);
        h.tvAuthor.setOnClickListener(authorClick);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView avatar;
        TextView tvAuthor;
        TextView tvTime;
        TextView tvContent;
        TextView btnReply;
        TextView btnEdit;
        TextView btnDelete;
        LinearLayout layoutQuote;
        TextView tvQuote;

        ViewHolder(View view) {
            super(view);
            avatar = view.findViewById(R.id.iv_wall_avatar);
            tvAuthor = view.findViewById(R.id.tv_wall_author);
            tvTime = view.findViewById(R.id.tv_wall_time);
            tvContent = view.findViewById(R.id.tv_wall_content);
            btnReply = view.findViewById(R.id.btn_wall_reply);
            btnEdit = view.findViewById(R.id.btn_wall_edit);
            btnDelete = view.findViewById(R.id.btn_wall_delete);
            layoutQuote = view.findViewById(R.id.layout_wall_quote);
            tvQuote = view.findViewById(R.id.tv_wall_quote);
        }
    }
}
