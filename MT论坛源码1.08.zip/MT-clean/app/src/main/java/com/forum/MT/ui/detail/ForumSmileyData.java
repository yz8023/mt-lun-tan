package com.forum.MT.ui.detail;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.Nullable;

import com.forum.MT.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 论坛表情数据（与官方 APK SmileyData 一致的本地资源映射）。
 * 缩略图直接加载本地 drawable 资源，不依赖 CDN。
 */
public final class ForumSmileyData {

    public static final class SmileyItem {
        public final String code;   // 表情代码，如 [#呵呵] [/呵呵] [doge]
        public final int iconRes;   // 本地 drawable 资源ID
        public SmileyItem(String code, int iconRes) {
            this.code = code;
            this.iconRes = iconRes;
        }
    }

    public static final class SmileyGroup {
        public final String id;
        public final String title;
        public final List<SmileyItem> items;
        public SmileyGroup(String id, String title, List<SmileyItem> items) {
            this.id = id;
            this.title = title;
            this.items = items;
        }
    }

    private static final SmileyItem[] TIEBA_ITEMS = new SmileyItem[] {
        new SmileyItem("[#呵呵]", R.drawable.smiley_tb_1),
        new SmileyItem("[#滑稽]", R.drawable.smiley_tb_10),
        new SmileyItem("[#哈哈]", R.drawable.smiley_tb_2),
        new SmileyItem("[#吐舌]", R.drawable.smiley_tb_3),
        new SmileyItem("[#啊]", R.drawable.smiley_tb_23),
        new SmileyItem("[#酷]", R.drawable.smiley_tb_22),
        new SmileyItem("[#怒]", R.drawable.smiley_tb_13),
        new SmileyItem("[#开心]", R.drawable.smiley_tb_39),
        new SmileyItem("[#汗]", R.drawable.smiley_tb_14),
        new SmileyItem("[#泪]", R.drawable.smiley_tb_16),
        new SmileyItem("[#黑线]", R.drawable.smiley_tb_15),
        new SmileyItem("[#鄙视]", R.drawable.smiley_tb_21),
        new SmileyItem("[#不高兴]", R.drawable.smiley_tb_12),
        new SmileyItem("[#真棒]", R.drawable.smiley_tb_17),
        new SmileyItem("[#钱]", R.drawable.smiley_tb_40),
        new SmileyItem("[#疑问]", R.drawable.smiley_tb_26),
        new SmileyItem("[#阴险]", R.drawable.smiley_tb_20),
        new SmileyItem("[#吐]", R.drawable.smiley_tb_34),
        new SmileyItem("[#咦]", R.drawable.smiley_tb_41),
        new SmileyItem("[#委屈]", R.drawable.smiley_tb_29),
        new SmileyItem("[#花心]", R.drawable.smiley_tb_6),
        new SmileyItem("[#呼～]", R.drawable.smiley_tb_42),
        new SmileyItem("[#激动]", R.drawable.smiley_tb_5),
        new SmileyItem("[#冷]", R.drawable.smiley_tb_43),
        new SmileyItem("[#可爱]", R.drawable.smiley_tb_4),
        new SmileyItem("[#What？]", R.drawable.smiley_tb_25),
        new SmileyItem("[#勉强]", R.drawable.smiley_tb_38),
        new SmileyItem("[#酸爽]", R.drawable.smiley_tb_27),
        new SmileyItem("[#狂汗]", R.drawable.smiley_tb_24),
        new SmileyItem("[#雅美蝶]", R.drawable.smiley_tb_28),
        new SmileyItem("[#乖]", R.drawable.smiley_tb_8),
        new SmileyItem("[#睡觉]", R.drawable.smiley_tb_31),
        new SmileyItem("[#惊哭]", R.drawable.smiley_tb_19),
        new SmileyItem("[#哼]", R.drawable.smiley_tb_44),
        new SmileyItem("[#笑尿]", R.drawable.smiley_tb_32),
        new SmileyItem("[#惊讶]", R.drawable.smiley_tb_30),
        new SmileyItem("[#小乖]", R.drawable.smiley_tb_7),
        new SmileyItem("[#喷]", R.drawable.smiley_tb_18),
        new SmileyItem("[#抠鼻]", R.drawable.smiley_tb_33),
        new SmileyItem("[#捂嘴笑]", R.drawable.smiley_tb_9),
        new SmileyItem("[#犀利]", R.drawable.smiley_tb_35),
        new SmileyItem("[#你懂的]", R.drawable.smiley_tb_11),
        new SmileyItem("[#小红脸]", R.drawable.smiley_tb_36),
        new SmileyItem("[#懒得理]", R.drawable.smiley_tb_37),
        new SmileyItem("[#爱心]", R.drawable.smiley_tb_45),
        new SmileyItem("[#心碎]", R.drawable.smiley_tb_46),
        new SmileyItem("[#玫瑰]", R.drawable.smiley_tb_47),
        new SmileyItem("[#礼物]", R.drawable.smiley_tb_48),
        new SmileyItem("[#彩虹]", R.drawable.smiley_tb_49),
        new SmileyItem("[#太阳]", R.drawable.smiley_tb_50),
        new SmileyItem("[#月亮]", R.drawable.smiley_tb_51),
        new SmileyItem("[#钱币]", R.drawable.smiley_tb_52),
        new SmileyItem("[#咖啡]", R.drawable.smiley_tb_53),
        new SmileyItem("[#蛋糕]", R.drawable.smiley_tb_54),
        new SmileyItem("[#大拇指]", R.drawable.smiley_tb_55),
        new SmileyItem("[#胜利]", R.drawable.smiley_tb_56),
        new SmileyItem("[#爱你]", R.drawable.smiley_tb_57),
        new SmileyItem("[#OK]", R.drawable.smiley_tb_58),
        new SmileyItem("[#弱]", R.drawable.smiley_tb_59),
        new SmileyItem("[#沙发]", R.drawable.smiley_tb_60),
        new SmileyItem("[#纸巾]", R.drawable.smiley_tb_61),
        new SmileyItem("[#香蕉]", R.drawable.smiley_tb_62),
        new SmileyItem("[#便便]", R.drawable.smiley_tb_63),
        new SmileyItem("[#药丸]", R.drawable.smiley_tb_64),
        new SmileyItem("[#红领巾]", R.drawable.smiley_tb_65),
        new SmileyItem("[#蜡烛]", R.drawable.smiley_tb_66),
        new SmileyItem("[#三道杠]", R.drawable.smiley_tb_67),
        new SmileyItem("[#音乐]", R.drawable.smiley_tb_68),
        new SmileyItem("[#灯泡]", R.drawable.smiley_tb_69),
    };

    private static final SmileyItem[] QQ_ITEMS = new SmileyItem[] {
        new SmileyItem("[呵呵]", R.drawable.smiley_qq001),
        new SmileyItem("[撇嘴]", R.drawable.smiley_qq002),
        new SmileyItem("[色]", R.drawable.smiley_qq003),
        new SmileyItem("[发呆]", R.drawable.smiley_qq004),
        new SmileyItem("[得意]", R.drawable.smiley_qq005),
        new SmileyItem("[流泪]", R.drawable.smiley_qq006),
        new SmileyItem("[害羞]", R.drawable.smiley_qq007),
        new SmileyItem("[闭嘴]", R.drawable.smiley_qq008),
        new SmileyItem("[睡]", R.drawable.smiley_qq009),
        new SmileyItem("[大哭]", R.drawable.smiley_qq010),
        new SmileyItem("[尴尬]", R.drawable.smiley_qq011),
        new SmileyItem("[发怒]", R.drawable.smiley_qq012),
        new SmileyItem("[调皮]", R.drawable.smiley_qq013),
        new SmileyItem("[呲牙]", R.drawable.smiley_qq014),
        new SmileyItem("[惊讶]", R.drawable.smiley_qq015),
        new SmileyItem("[难过]", R.drawable.smiley_qq016),
        new SmileyItem("[酷]", R.drawable.smiley_qq017),
        new SmileyItem("[冷汗]", R.drawable.smiley_qq018),
        new SmileyItem("[抓狂]", R.drawable.smiley_qq019),
        new SmileyItem("[吐]", R.drawable.smiley_qq020),
        new SmileyItem("[偷笑]", R.drawable.smiley_qq021),
        new SmileyItem("[可爱]", R.drawable.smiley_qq022),
        new SmileyItem("[白眼]", R.drawable.smiley_qq023),
        new SmileyItem("[傲慢]", R.drawable.smiley_qq024),
        new SmileyItem("[饥饿]", R.drawable.smiley_qq025),
        new SmileyItem("[困]", R.drawable.smiley_qq026),
        new SmileyItem("[惊恐]", R.drawable.smiley_qq027),
        new SmileyItem("[流汗]", R.drawable.smiley_qq028),
        new SmileyItem("[憨笑]", R.drawable.smiley_qq029),
        new SmileyItem("[装逼]", R.drawable.smiley_qq030),
        new SmileyItem("[奋斗]", R.drawable.smiley_qq031),
        new SmileyItem("[咒骂]", R.drawable.smiley_qq032),
        new SmileyItem("[疑问]", R.drawable.smiley_qq033),
        new SmileyItem("[嘘]", R.drawable.smiley_qq034),
        new SmileyItem("[晕]", R.drawable.smiley_qq035),
        new SmileyItem("[折磨]", R.drawable.smiley_qq036),
        new SmileyItem("[衰]", R.drawable.smiley_qq037),
        new SmileyItem("[骷髅]", R.drawable.smiley_qq038),
        new SmileyItem("[敲打]", R.drawable.smiley_qq039),
        new SmileyItem("[再见]", R.drawable.smiley_qq040),
        new SmileyItem("[擦汗]", R.drawable.smiley_qq041),
        new SmileyItem("[抠鼻]", R.drawable.smiley_qq042),
        new SmileyItem("[鼓掌]", R.drawable.smiley_qq043),
        new SmileyItem("[糗大了]", R.drawable.smiley_qq044),
        new SmileyItem("[坏笑]", R.drawable.smiley_qq045),
        new SmileyItem("[左哼哼]", R.drawable.smiley_qq046),
        new SmileyItem("[右哼哼]", R.drawable.smiley_qq047),
        new SmileyItem("[哈欠]", R.drawable.smiley_qq048),
        new SmileyItem("[鄙视]", R.drawable.smiley_qq049),
        new SmileyItem("[委屈]", R.drawable.smiley_qq050),
        new SmileyItem("[快哭了]", R.drawable.smiley_qq051),
        new SmileyItem("[阴脸]", R.drawable.smiley_qq052),
        new SmileyItem("[亲亲]", R.drawable.smiley_qq053),
        new SmileyItem("[吓]", R.drawable.smiley_qq054),
        new SmileyItem("[可怜]", R.drawable.smiley_qq055),
        new SmileyItem("[眨眼睛]", R.drawable.smiley_qq056),
        new SmileyItem("[笑哭]", R.drawable.smiley_qq057),
        new SmileyItem("[dogeQQ]", R.drawable.smiley_qq058),
        new SmileyItem("[泪奔]", R.drawable.smiley_qq059),
        new SmileyItem("[无奈]", R.drawable.smiley_qq060),
        new SmileyItem("[托腮]", R.drawable.smiley_qq061),
        new SmileyItem("[卖萌]", R.drawable.smiley_qq062),
        new SmileyItem("[斜眼笑]", R.drawable.smiley_qq063),
        new SmileyItem("[喷血]", R.drawable.smiley_qq064),
        new SmileyItem("[惊喜]", R.drawable.smiley_qq065),
        new SmileyItem("[骚扰]", R.drawable.smiley_qq066),
        new SmileyItem("[小纠结]", R.drawable.smiley_qq067),
        new SmileyItem("[我最美]", R.drawable.smiley_qq068),
        new SmileyItem("[菜刀]", R.drawable.smiley_qq069),
        new SmileyItem("[西瓜]", R.drawable.smiley_qq070),
        new SmileyItem("[啤酒]", R.drawable.smiley_qq071),
        new SmileyItem("[篮球]", R.drawable.smiley_qq072),
        new SmileyItem("[乒乓]", R.drawable.smiley_qq073),
        new SmileyItem("[咖啡]", R.drawable.smiley_qq074),
        new SmileyItem("[饭]", R.drawable.smiley_qq075),
        new SmileyItem("[猪]", R.drawable.smiley_qq076),
        new SmileyItem("[玫瑰]", R.drawable.smiley_qq077),
        new SmileyItem("[凋谢]", R.drawable.smiley_qq078),
        new SmileyItem("[示爱]", R.drawable.smiley_qq079),
        new SmileyItem("[爱心]", R.drawable.smiley_qq080),
        new SmileyItem("[心碎]", R.drawable.smiley_qq081),
        new SmileyItem("[蛋糕]", R.drawable.smiley_qq082),
        new SmileyItem("[闪电]", R.drawable.smiley_qq083),
        new SmileyItem("[炸弹]", R.drawable.smiley_qq084),
        new SmileyItem("[刀]", R.drawable.smiley_qq085),
        new SmileyItem("[足球]", R.drawable.smiley_qq086),
        new SmileyItem("[瓢虫]", R.drawable.smiley_qq087),
        new SmileyItem("[便便]", R.drawable.smiley_qq088),
        new SmileyItem("[月亮]", R.drawable.smiley_qq089),
        new SmileyItem("[太阳]", R.drawable.smiley_qq090),
        new SmileyItem("[礼物]", R.drawable.smiley_qq091),
        new SmileyItem("[抱抱]", R.drawable.smiley_qq092),
        new SmileyItem("[喝彩]", R.drawable.smiley_qq093),
        new SmileyItem("[祈祷]", R.drawable.smiley_qq094),
        new SmileyItem("[棒棒糖]", R.drawable.smiley_qq095),
        new SmileyItem("[药]", R.drawable.smiley_qq096),
        new SmileyItem("[赞]", R.drawable.smiley_qq097),
        new SmileyItem("[差劲2]", R.drawable.smiley_qq098),
        new SmileyItem("[握手]", R.drawable.smiley_qq099),
        new SmileyItem("[胜利]", R.drawable.smiley_qq100),
        new SmileyItem("[抱拳]", R.drawable.smiley_qq101),
        new SmileyItem("[勾引]", R.drawable.smiley_qq102),
        new SmileyItem("[拳头]", R.drawable.smiley_qq103),
        new SmileyItem("[差劲]", R.drawable.smiley_qq104),
        new SmileyItem("[爱你]", R.drawable.smiley_qq105),
        new SmileyItem("[NO]", R.drawable.smiley_qq106),
        new SmileyItem("[OK]", R.drawable.smiley_qq107),
    };

    private static final SmileyItem[] DOGE_ITEMS = new SmileyItem[] {
        new SmileyItem("[doge]", R.drawable.smiley_doge_1),
        new SmileyItem("[doge思考]", R.drawable.smiley_doge_2),
        new SmileyItem("[doge再见]", R.drawable.smiley_doge_3),
        new SmileyItem("[doge生气]", R.drawable.smiley_doge_4),
        new SmileyItem("[doge气哭]", R.drawable.smiley_doge_5),
        new SmileyItem("[doge笑哭]", R.drawable.smiley_doge_7),
        new SmileyItem("[doge调皮]", R.drawable.smiley_doge_6),
        new SmileyItem("[doge啊哈]", R.drawable.smiley_doge_8),
        new SmileyItem("[doge原谅TA]", R.drawable.smiley_doge_9),
        new SmileyItem("[miao]", R.drawable.smiley_doge_10),
        new SmileyItem("[miao思考]", R.drawable.smiley_doge_11),
        new SmileyItem("[miao拜拜]", R.drawable.smiley_doge_12),
        new SmileyItem("[miao生气]", R.drawable.smiley_doge_13),
        new SmileyItem("[miao气哭]", R.drawable.smiley_doge_14),
        new SmileyItem("[二哈]", R.drawable.smiley_doge_15),
        new SmileyItem("[摊手]", R.drawable.smiley_doge_19),
        new SmileyItem("[w并不简单]", R.drawable.smiley_doge_20),
        new SmileyItem("[w滑稽]", R.drawable.smiley_doge_21),
        new SmileyItem("[w色]", R.drawable.smiley_doge_22),
        new SmileyItem("[w爱你]", R.drawable.smiley_doge_23),
        new SmileyItem("[w拜拜]", R.drawable.smiley_doge_24),
        new SmileyItem("[w悲伤]", R.drawable.smiley_doge_25),
        new SmileyItem("[w鄙视]", R.drawable.smiley_doge_26),
        new SmileyItem("[w馋嘴]", R.drawable.smiley_doge_27),
        new SmileyItem("[w冷汗]", R.drawable.smiley_doge_28),
        new SmileyItem("[w打哈欠]", R.drawable.smiley_doge_29),
        new SmileyItem("[w打脸]", R.drawable.smiley_doge_30),
        new SmileyItem("[w敲打]", R.drawable.smiley_doge_31),
        new SmileyItem("[w生病]", R.drawable.smiley_doge_32),
        new SmileyItem("[w闭嘴]", R.drawable.smiley_doge_33),
        new SmileyItem("[w鼓掌]", R.drawable.smiley_doge_34),
        new SmileyItem("[w哈哈]", R.drawable.smiley_doge_35),
        new SmileyItem("[w害羞]", R.drawable.smiley_doge_36),
        new SmileyItem("[w呵呵]", R.drawable.smiley_doge_37),
        new SmileyItem("[w黑线]", R.drawable.smiley_doge_38),
        new SmileyItem("[w哼哼]", R.drawable.smiley_doge_39),
        new SmileyItem("[w调皮]", R.drawable.smiley_doge_40),
        new SmileyItem("[w可爱]", R.drawable.smiley_doge_41),
        new SmileyItem("[w可怜]", R.drawable.smiley_doge_42),
        new SmileyItem("[w酷]", R.drawable.smiley_doge_43),
        new SmileyItem("[w困]", R.drawable.smiley_doge_44),
        new SmileyItem("[w懒得理你]", R.drawable.smiley_doge_45),
        new SmileyItem("[w流泪]", R.drawable.smiley_doge_46),
        new SmileyItem("[w怒]", R.drawable.smiley_doge_47),
        new SmileyItem("[w怒骂]", R.drawable.smiley_doge_48),
        new SmileyItem("[w钱]", R.drawable.smiley_doge_49),
        new SmileyItem("[w亲亲]", R.drawable.smiley_doge_50),
        new SmileyItem("[w傻眼]", R.drawable.smiley_doge_51),
        new SmileyItem("[w便秘]", R.drawable.smiley_doge_52),
        new SmileyItem("[w失望]", R.drawable.smiley_doge_53),
        new SmileyItem("[w衰]", R.drawable.smiley_doge_54),
        new SmileyItem("[w睡觉]", R.drawable.smiley_doge_55),
        new SmileyItem("[w思考]", R.drawable.smiley_doge_56),
        new SmileyItem("[w开心]", R.drawable.smiley_doge_57),
        new SmileyItem("[w色舔]", R.drawable.smiley_doge_58),
        new SmileyItem("[w偷笑]", R.drawable.smiley_doge_59),
        new SmileyItem("[w吐]", R.drawable.smiley_doge_60),
        new SmileyItem("[w抠鼻]", R.drawable.smiley_doge_61),
        new SmileyItem("[w委屈]", R.drawable.smiley_doge_62),
        new SmileyItem("[w笑哭]", R.drawable.smiley_doge_63),
        new SmileyItem("[w嘻嘻]", R.drawable.smiley_doge_64),
        new SmileyItem("[w嘘]", R.drawable.smiley_doge_65),
        new SmileyItem("[w阴险]", R.drawable.smiley_doge_66),
        new SmileyItem("[w疑问]", R.drawable.smiley_doge_67),
        new SmileyItem("[w抓狂]", R.drawable.smiley_doge_70),
        new SmileyItem("[w晕]", R.drawable.smiley_doge_69),
        new SmileyItem("[w右哼哼]", R.drawable.smiley_doge_68),
        new SmileyItem("[w左哼哼]", R.drawable.smiley_doge_71),
        new SmileyItem("[w肥皂]", R.drawable.smiley_doge_77),
        new SmileyItem("[w奥特曼]", R.drawable.smiley_doge_78),
        new SmileyItem("[w草泥马]", R.drawable.smiley_doge_79),
        new SmileyItem("[w兔子]", R.drawable.smiley_doge_80),
        new SmileyItem("[w熊猫]", R.drawable.smiley_doge_81),
        new SmileyItem("[w猪头]", R.drawable.smiley_doge_82),
        new SmileyItem("[w→_→]", R.drawable.smiley_doge_83),
        new SmileyItem("[w给力]", R.drawable.smiley_doge_84),
        new SmileyItem("[w囧]", R.drawable.smiley_doge_85),
        new SmileyItem("[w萌]", R.drawable.smiley_doge_86),
        new SmileyItem("[w神马]", R.drawable.smiley_doge_87),
        new SmileyItem("[w威武]", R.drawable.smiley_doge_88),
    };

    public static final List<SmileyGroup> ALL_GROUPS = new ArrayList<>(Arrays.asList(
            new SmileyGroup("5", "贴吧", Arrays.asList(TIEBA_ITEMS)),
            new SmileyGroup("12", "QQ", Arrays.asList(QQ_ITEMS)),
            new SmileyGroup("14", "狗头", Arrays.asList(DOGE_ITEMS))
    ));

    // ==================== 表情代码 / CDN URL → 本地资源 ====================

    /**
     * 表情代码 → 本地 drawable。首次访问时由 {@link #ALL_GROUPS} 展开构建。
     */
    private static volatile java.util.Map<String, Integer> sCodeToIcon;

    /** CDN URL → 本地 drawable 的解析结果缓存，0 表示确认无对应本地资源。 */
    private static final ConcurrentHashMap<String, Integer> sUrlToIcon = new ConcurrentHashMap<>();

    /**
     * 论坛下发的表情图片路径。实测（2026-08-30 抓取正式站帖子与私信页）服务端只用这三种目录：
     * <pre>
     *   https://cdn.binmt.cc/static/image/smiley/comiis_tb/tb_1.png   贴吧
     *   https://cdn.binmt.cc/static/image/smiley/qq/qq003.gif         QQ
     *   https://cdn.binmt.cc/static/image/smiley/doge/1.png           狗头
     * </pre>
     * 它们与本项目的 {@code smiley_tb_N} / {@code smiley_qqNNN} / {@code smiley_doge_N}
     * 逐个对应，因此表情可以完全走本地资源，不必联网下载。
     *
     * <p>注意：参考源码里的 {@code smiley_mapping.json} 用的是 comiis_tb01 / comiis_tb02 /
     * comiis_4x 目录，这些路径在当前站点已全部 404，不能作为映射依据。
     */
    private static final Pattern SMILEY_URL_PATTERN = Pattern.compile(
            "/smiley/(comiis_tb/tb_|qq/qq|doge/)(\\d+)\\.[a-zA-Z]+", Pattern.CASE_INSENSITIVE);

    /** 表情代码（如 {@code [呵呵]}）对应的本地 drawable，找不到返回 0。 */
    public static int iconForCode(String code) {
        if (TextUtils.isEmpty(code)) return 0;
        java.util.Map<String, Integer> map = sCodeToIcon;
        if (map == null) {
            synchronized (ForumSmileyData.class) {
                map = sCodeToIcon;
                if (map == null) {
                    map = new java.util.HashMap<>(320);
                    for (SmileyGroup group : ALL_GROUPS) {
                        for (SmileyItem item : group.items) {
                            map.put(item.code, item.iconRes);
                        }
                    }
                    sCodeToIcon = map;
                }
            }
        }
        Integer res = map.get(code);
        return res == null ? 0 : res;
    }

    /**
     * 把服务端下发的表情图片 URL 映射到本地 drawable。
     *
     * @return drawable 资源 id；URL 不是已知表情目录或本地缺图时返回 0
     */
    public static int iconForUrl(Context context, String url) {
        if (context == null || TextUtils.isEmpty(url)) return 0;
        Integer cached = sUrlToIcon.get(url);
        if (cached != null) return cached;

        int resId = 0;
        Matcher matcher = SMILEY_URL_PATTERN.matcher(url);
        if (matcher.find()) {
            String dir = matcher.group(1).toLowerCase(java.util.Locale.ROOT);
            String number = matcher.group(2);
            String name;
            if (dir.startsWith("comiis_tb")) {
                name = "smiley_tb_" + stripLeadingZeros(number);
            } else if (dir.startsWith("qq")) {
                // qq 资源名保留三位补零（smiley_qq003），与 CDN 文件名一致。
                name = "smiley_qq" + padTo3(number);
            } else {
                name = "smiley_doge_" + stripLeadingZeros(number);
            }
            try {
                resId = context.getResources().getIdentifier(
                        name, "drawable", context.getPackageName());
            } catch (Exception ignored) {
                resId = 0;
            }
        }
        sUrlToIcon.put(url, resId);
        return resId;
    }

    /** 该 URL 是否指向论坛表情（无论本地是否有对应资源）。 */
    public static boolean isSmileyUrl(String url) {
        return !TextUtils.isEmpty(url) && SMILEY_URL_PATTERN.matcher(url).find();
    }

    /** 表情代码 → CDN 动图 URL 的解析结果缓存，空串表示确认没有动图版本。 */
    private static final ConcurrentHashMap<String, String> sCodeToGifUrl =
            new ConcurrentHashMap<>();

    /**
     * 表情代码对应的 CDN 动图 URL。
     *
     * <p>本项目内置的 256 个 {@code smiley_*} drawable 全部是静态 PNG，
     * 但服务端 QQ 分类的表情实际是多帧 GIF（{@code /smiley/qq/qqNNN.gif}），
     * 只用本地资源渲染出来的表情不会动。贴吧与狗头分类在服务端本身就是静态 PNG，
     * 因此只有 QQ 分类需要联网取动图。
     *
     * @return 动图 URL；该表情没有动图版本时返回 null
     */
    @Nullable
    public static String gifUrlForCode(Context context, String code) {
        if (context == null || TextUtils.isEmpty(code)) return null;
        String cached = sCodeToGifUrl.get(code);
        if (cached != null) return cached.isEmpty() ? null : cached;

        String url = "";
        int iconRes = iconForCode(code);
        if (iconRes != 0) {
            try {
                String name = context.getResources().getResourceEntryName(iconRes);
                // 资源名与 CDN 文件名一一对应：smiley_qq003 → qq/qq003.gif
                if (name != null && name.startsWith("smiley_qq")) {
                    url = SMILEY_CDN_BASE + "qq/" + name.substring("smiley_".length()) + ".gif";
                }
            } catch (Exception ignored) {
            }
        }
        sCodeToGifUrl.put(code, url);
        return url.isEmpty() ? null : url;
    }

    /**
     * 服务端下发的表情图片 URL 对应的动图 URL。
     *
     * <p>服务端在帖子/私信 HTML 里给 QQ 表情下发的就是 {@code .gif}，这种情况原样返回；
     * 其余（贴吧 / 狗头的 PNG）返回 null，它们本来就是静态图。
     */
    @Nullable
    public static String gifUrlForUrl(String url) {
        if (TextUtils.isEmpty(url)) return null;
        String lower = url.toLowerCase(java.util.Locale.ROOT);
        int query = lower.indexOf('?');
        if (query >= 0) lower = lower.substring(0, query);
        return lower.endsWith(".gif") ? url : null;
    }

    /** 表情静态资源与动图共用的 CDN 根路径。 */
    private static final String SMILEY_CDN_BASE =
            "https://cdn.binmt.cc/static/image/smiley/";

    private static String stripLeadingZeros(String number) {
        int i = 0;
        while (i < number.length() - 1 && number.charAt(i) == '0') i++;
        return number.substring(i);
    }

    private static String padTo3(String number) {
        String stripped = stripLeadingZeros(number);
        if (stripped.length() >= 3) return stripped;
        StringBuilder sb = new StringBuilder();
        for (int i = stripped.length(); i < 3; i++) sb.append('0');
        return sb.append(stripped).toString();
    }
}
