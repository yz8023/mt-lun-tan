package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

/**
 * 评论项描边边框 + 背景色管理。
 *
 * 与流水灯 {@link RainbowBorderDrawable} 不同，这里只做静态描边，
 * 不带动画，不依赖 Canvas 绘制——直接返回 GradientDrawable 供 View 背景使用。
 *
 * 偏好键：
 *   comment_border_enabled  (boolean, 默认 true)
 *   comment_border_color    (int,    0 表示使用默认描边色)
 *   comment_bg_color        (int,    0 表示使用默认浅色填充 #FAFBFC)
 */
public final class CommentBorderDrawable {

    public interface OnChangeListener {
        void onCommentBorderChanged();
    }

    private static volatile OnChangeListener listener;
    private static final Object LISTENER_LOCK = new Object();

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_ENABLED  = "comment_border_enabled";
    public static final String KEY_COLOR    = "comment_border_color";
    public static final String KEY_BG_COLOR = "comment_bg_color";

    /** 颜色为 0 时使用的默认描边色 */
    public static final int DEFAULT_BORDER_COLOR = Color.parseColor("#DADCE0");
    /** 默认填充色（浅橙） */
    public static final int DEFAULT_FILL_COLOR   = Color.parseColor("#FFF9E7");

    private static volatile boolean enabled = true;
    private static volatile int customColor = 0;
    private static volatile int bgColor = 0;

    private CommentBorderDrawable() {}

    /** 设置颜色/开关变更回调。注意：会覆盖之前的监听者。 */
    public static void setListener(OnChangeListener l) {
        synchronized (LISTENER_LOCK) {
            listener = l;
        }
    }

    private static void notifyChanged() {
        OnChangeListener l;
        synchronized (LISTENER_LOCK) {
            l = listener;
        }
        if (l != null) {
            try {
                l.onCommentBorderChanged();
            } catch (Exception ignored) {}
        }
    }

    /** 应用启动时调用，从磁盘恢复用户设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        enabled     = prefs.getBoolean(KEY_ENABLED, true);
        customColor = prefs.getInt(KEY_COLOR, 0);
        bgColor     = prefs.getInt(KEY_BG_COLOR, 0);
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(Context context, boolean value) {
        enabled = value;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_ENABLED, value).apply();
        }
        notifyChanged();
    }

    public static int getCustomColor() {
        return customColor;
    }

    public static void setCustomColor(Context context, int color) {
        customColor = color;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_COLOR, color).apply();
        }
        notifyChanged();
    }

    /** 当前背景色（0 表示默认浅色）。 */
    public static int getBgColor() {
        return bgColor;
    }

    public static void setBgColor(Context context, int color) {
        bgColor = color;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_BG_COLOR, color).apply();
        }
        notifyChanged();
    }

    /** 当前应使用的描边色（customColor!=0 时用自定义色，否则用默认色）。 */
    public static int resolveBorderColor() {
        return customColor != 0 ? customColor : DEFAULT_BORDER_COLOR;
    }

    /** 当前应使用的背景填充色。 */
    public static int resolveBgColor() {
        return bgColor != 0 ? bgColor : DEFAULT_FILL_COLOR;
    }

    /**
     * 创建一个描边 GradientDrawable（圆角矩形 + 描边 + 背景填充）。
     * 当评论描边关闭时返回 null，调用方应保留原背景。
     */
    public static Drawable create(Context context) {
        if (!enabled) return null;
        float density = context.getResources().getDisplayMetrics().density;
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(12f * density);
        drawable.setColor(resolveBgColor());
        drawable.setStroke((int) (1f * density + 0.5f), resolveBorderColor());
        return drawable;
    }
}
