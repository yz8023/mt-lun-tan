package com.forum.MT.ui.message;

import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.Message;
import com.forum.MT.network.NoticeBadgeManager;
import com.forum.MT.session.UnreadHighlightManager;
import com.forum.MT.ui.widget.RainbowBorderDrawable;
import com.forum.MT.ui.widget.RainbowBorderHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * 私信列表适配器 - 适用于私信Tab
 * 显示头像、用户名、摘要、时间，点击进入聊天页
 */
public class PrivateMessageAdapter extends RecyclerView.Adapter<PrivateMessageAdapter.ViewHolder> {

    private List<Message> messages = new ArrayList<>();
    private String viewType = "pm";
    private NoticeBadgeHost badgeHost;
    private android.content.Context context;

    public void setMessages(List<Message> messages) {
        this.messages = messages != null ? messages : new ArrayList<>();
        notifyDataSetChanged();
    }

    /** 全部已读/点击单条后刷新未读条显示（不改数据，仅重绘）。 */
    public void refreshUnreadBars() {
        notifyDataSetChanged();
    }

    /** 设置分类 key（pm）。 */
    public void setViewType(String viewType) {
        this.viewType = viewType != null ? viewType : "pm";
    }

    /** 绑定角标宿主（用于点击后刷新 Tab 角标）。 */
    public void setBadgeHost(NoticeBadgeHost host) {
        this.badgeHost = host;
    }

    /** 设置 Context。 */
    public void setContext(android.content.Context context) {
        this.context = context != null ? context.getApplicationContext() : null;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message, parent, false);
        RainbowBorderHelper.applyToItem(view, parent.getContext());
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Message msg = messages.get(position);
        holder.tvAuthor.setText(msg.getAuthor() != null ? msg.getAuthor() : "未知");

        // 消息最后一条内容：优先 summary；为空时退回 title
        String summaryText = msg.getSummary() != null ? msg.getSummary().trim() : "";
        if (summaryText.isEmpty()) summaryText = msg.getTitle() != null ? msg.getTitle().trim() : "";
        holder.tvTitle.setText(summaryText);
        // tv_summary 保持隐藏，避免与 tv_title 重复显示同一内容
        holder.tvSummary.setText(summaryText);
        holder.tvSummary.setVisibility(View.GONE);
        holder.tvTime.setText(msg.getTime() != null ? msg.getTime() : "");

        // 未读：红点 + 仅左侧色条高亮（卡片背景不变）
        String pmidForUnread = msg.getPmid();
        if (TextUtils.isEmpty(pmidForUnread)) pmidForUnread = msg.getAuthorUid();
        int unreadDelta = (!TextUtils.isEmpty(pmidForUnread) && context != null)
                ? NoticeBadgeManager.getPmUnreadDelta(context, pmidForUnread) : 0;
        boolean unread = isConversationUnread(msg, unreadDelta);
        boolean highlightEnabled = UnreadHighlightManager.isEnabled(context);
        if (com.forum.MT.util.Dbg.ON) {
            android.util.Log.e("MT_PM_DBG", "onBind: author=" + msg.getAuthor() + " pmid=" + msg.getPmid() + " isRead(server)=" + msg.isRead() + " unreadDelta=" + unreadDelta + " unread(computed)=" + unread + " highlightEnabled=" + highlightEnabled);
        }
        if (holder.tvUnread != null) {
            holder.tvUnread.setVisibility(unread ? View.VISIBLE : View.GONE);
        }
        if (holder.viewUnreadBar != null) {
            boolean showBar = unread && highlightEnabled;
            // 保持左侧条始终参与布局，避免 match_parent + RecyclerView 复用时测量为 0；
            // 未读时显示颜色，已读/关闭高亮时仅透明隐藏。
            holder.viewUnreadBar.setVisibility(View.VISIBLE);
            holder.viewUnreadBar.setAlpha(showBar ? 1f : 0f);
            if (holder.breathListener != null) {
                RainbowBorderDrawable.removeBreathListener(holder.breathListener);
                holder.breathListener = null;
            }
            holder.viewUnreadBar.setScaleX(1f);
        }

        // 加载头像
        String avatarUrl = msg.getAvatarUrl();
        if (avatarUrl != null && !avatarUrl.isEmpty()) {
            Glide.with(holder.ivAvatar.getContext())
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(holder.ivAvatar);
        } else {
            holder.ivAvatar.setImageResource(R.drawable.ic_account);
        }

        // 点击进入聊天页，同时标记该会话本地已读
        holder.itemView.setOnClickListener(v -> {
            String pmid = msg.getPmid();
            if (pmid == null || pmid.isEmpty()) {
                // 尝试用 authorUid 作为会话ID
                pmid = msg.getAuthorUid();
            }
            if (pmid != null && !pmid.isEmpty()) {
                // 标记本地已读并刷新角标/高亮
                NoticeBadgeManager.markItemRead(context, viewType, pmid);
                notifyItemChanged(holder.getBindingAdapterPosition());
                if (badgeHost != null) badgeHost.refreshTabBadge(viewType);

                Intent intent = new Intent(v.getContext(), ChatActivity.class);
                intent.putExtra(ChatActivity.EXTRA_PMID, pmid);
                intent.putExtra(ChatActivity.EXTRA_UID, msg.getAuthorUid());
                intent.putExtra(ChatActivity.EXTRA_NAME, msg.getAuthor());
                intent.putExtra(ChatActivity.EXTRA_AVATAR, msg.getAvatarUrl());
                v.getContext().startActivity(intent);
            }
        });
    }

    /**
     * 私信列表单条未读判断。
     *
     * ★ 修复"左侧色条有一部分不显示、计数也不显示（像被点进去过）"：
     *   旧实现只信 NoticeBadgeManager 的 PM 快照差值（current - baseline）。
     *   该差值有三种情况会被抹平，而服务端仍然是未读：
     *     1) 首次建基线：saveCurrentAndGetNewCount 直接 baseline=current，
     *        安装后/清数据后已存在的未读会话差值恒为 0；
     *     2) 点过"全部已读"或 markViewed("pm") 后 baseline=current；
     *     3) buildPmSnapshot 依赖会话详情统计对方消息数，请求失败时退化为 1，
     *        与基线相同 → 差值 0。
     *   结果就是部分会话（尤其老会话）永远不亮色条、不显示红点。
     *
     * 新判据：本地相对新增 > 0，或者「服务端标记未读且用户没在本 App 点过该会话」。
     * 用户点击会话时 markItemRead 会写入 clicked 集合，因此点开后立即转已读，
     * 而之后再来新消息会让 unreadDelta > 0，重新亮起。
     */
    private boolean isConversationUnread(Message msg, int unreadDelta) {
        if (msg == null) return false;
        if (unreadDelta > 0) return true;
        if (msg.isRead()) return false;
        // 服务端说未读：只有本地明确点击过该会话才压制未读态。
        String pmid = msg.getPmid();
        if (TextUtils.isEmpty(pmid)) pmid = msg.getAuthorUid();
        if (context == null || TextUtils.isEmpty(pmid)) return true;
        return !NoticeBadgeManager.isPmClicked(context, pmid);
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    @Override
    public void onViewAttachedToWindow(@NonNull ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(true, false);
        }
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull ViewHolder holder) {
        if (holder.breathListener != null) {
            RainbowBorderDrawable.removeBreathListener(holder.breathListener);
            holder.breathListener = null;
        }
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(false, false);
        }
        super.onViewDetachedFromWindow(holder);
    }

    @Override
    public void onViewRecycled(@NonNull ViewHolder holder) {
        if (holder.breathListener != null) {
            RainbowBorderDrawable.removeBreathListener(holder.breathListener);
            holder.breathListener = null;
        }
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(false, false);
        }
        super.onViewRecycled(holder);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        androidx.cardview.widget.CardView cardRoot;
        ImageView ivAvatar;
        TextView tvAuthor, tvTitle, tvSummary, tvTime, tvUnread;
        View viewUnreadBar;
        RainbowBorderDrawable.BreathListener breathListener;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardRoot = itemView.findViewById(R.id.card_root);
            ivAvatar = itemView.findViewById(R.id.iv_avatar);
            tvAuthor = itemView.findViewById(R.id.tv_author);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvSummary = itemView.findViewById(R.id.tv_summary);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvUnread = itemView.findViewById(R.id.tv_unread);
            viewUnreadBar = itemView.findViewById(R.id.view_unread_bar);
            if (viewUnreadBar != null) {
                float density = itemView.getResources().getDisplayMetrics().density;
                float cardRadius = cardRoot != null ? cardRoot.getRadius() : 8f * density;
                if (cardRadius <= 0f) cardRadius = 8f * density;
                boolean rainbowOn = RainbowBorderDrawable.isGloballyEnabled();
                android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
                gd.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                gd.setColor(com.forum.MT.ui.widget.HomeBarColorManager.resolveUnreadBarColor());
                android.widget.LinearLayout.LayoutParams lp = (android.widget.LinearLayout.LayoutParams) viewUnreadBar.getLayoutParams();
                if (rainbowOn) {
                    float inset = 2.5f * density;
                    gd.setCornerRadii(new float[]{cardRadius, cardRadius, 0, 0, 0, 0, cardRadius, cardRadius});
                    lp.topMargin = Math.round(inset);
                    lp.bottomMargin = Math.round(inset);
                    lp.setMarginStart(Math.round(inset));
                    if (cardRoot != null) {
                        final RainbowBorderDrawable overlayBorder = new RainbowBorderDrawable(
                                com.forum.MT.ui.widget.CardColorManager.resolveCardColor(),
                                cardRadius, density, true);
                        cardRoot.getOverlay().add(overlayBorder);
                        cardRoot.addOnLayoutChangeListener(new android.view.View.OnLayoutChangeListener() {
                            @Override
                            public void onLayoutChange(View v, int left, int top, int right, int bottom,
                                                       int oldLeft, int oldTop, int oldRight, int oldBottom) {
                                overlayBorder.setBounds(0, 0, v.getWidth(), v.getHeight());
                            }
                        });
                        overlayBorder.setCallback(cardRoot);
                    }
                } else {
                    gd.setCornerRadii(new float[]{cardRadius, cardRadius, 0, 0, 0, 0, cardRadius, cardRadius});
                    lp.topMargin = 0;
                    lp.bottomMargin = 0;
                    lp.setMarginStart(0);
                }
                viewUnreadBar.setBackground(gd);
                viewUnreadBar.setLayoutParams(lp);
            }
        }
    }
}