package com.forum.MT.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.Thread;
import com.forum.MT.session.FollowStateManager;
import com.forum.MT.ui.space.UserProfileActivity;
import com.forum.MT.ui.widget.RainbowBorderDrawable;
import com.forum.MT.ui.widget.CardBorderManager;
import com.forum.MT.ui.widget.ThreadTagColorManager;
import com.forum.MT.ui.widget.ClosedFilterManager;

import java.util.ArrayList;
import java.util.List;

/**
 * 帖子列表 RecyclerView Adapter
 */
public class ThreadAdapter extends RecyclerView.Adapter<ThreadAdapter.ViewHolder> {

    /** 全局颜色变更监听器，用于在颜色设置变化时刷新列表 */
    private static Runnable colorChangeListener;

    /**
     * 所有存活的 Adapter 实例（弱引用，不阻止回收）。
     *
     * <p>颜色监听器是"后注册覆盖前一个"的单例语义，只能刷新最近创建的列表；
     * 而「隐藏带回收站的帖子」开关在设置页切换后，需要让所有已存在的列表
     * （首页各栏目、版块、搜索、个人主题）都重新过滤，因此这里单独维护实例表，
     * 并在类加载时注册一次永不取消的监听。
     */
    private static final java.util.Set<ThreadAdapter> LIVE_ADAPTERS =
            java.util.Collections.newSetFromMap(new java.util.WeakHashMap<>());

    static {
        com.forum.MT.ui.widget.RecycleFilterManager.setListener(() -> {
            List<ThreadAdapter> snapshot;
            synchronized (LIVE_ADAPTERS) {
                snapshot = new ArrayList<>(LIVE_ADAPTERS);
            }
            for (ThreadAdapter a : snapshot) {
                if (a != null) a.applyRecycleFilter();
            }
        });
    }

    static {
        ClosedFilterManager.setListener(() -> {
            List<ThreadAdapter> snapshot;
            synchronized (LIVE_ADAPTERS) {
                snapshot = new ArrayList<>(LIVE_ADAPTERS);
            }
            for (ThreadAdapter a : snapshot) {
                if (a != null) a.applyRecycleFilter();
            }
        });
    }

    /** 服务端返回的完整列表（未过滤），开关切换时据此重新过滤。 */
    private List<Thread> sourceList = new ArrayList<>();
    /** 实际展示的列表（可能已剔除回收站帖子）。 */
    private List<Thread> threadList = new ArrayList<>();
    private Context context;
    private OnItemClickListener listener;
    private OnUserClickListener userClickListener;
    private volatile java.util.Set<String> serverFollowingUids;
    private volatile boolean serverFollowingLoaded;
    private boolean followStateLoading;
    private final Object followStateLock = new Object();

    /**
     * 注册全局颜色变更监听器。
     * 当板块标签或关注按钮颜色在主题设置页变更时，自动刷新所有 Adapter 实例。
     */
    public static void registerColorChangeListener(RecyclerView.Adapter<?> adapter) {
        unregisterColorChangeListener();
        colorChangeListener = () -> {
            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }
        };
        ThreadTagColorManager.setListener(colorChangeListener);
        // 字号/卡片大小变化时同样触发列表刷新（恢复默认、滑块调整均需即时生效）
        com.forum.MT.ui.widget.ThreadTextSizeManager.setTextSizeChangeListener(colorChangeListener);
    }

    public static void unregisterColorChangeListener() {
        if (colorChangeListener != null) {
            ThreadTagColorManager.setListener(null);
            com.forum.MT.ui.widget.ThreadTextSizeManager.unregisterTextSizeChangeListener();
            colorChangeListener = null;
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Thread thread, int position);
    }

    public interface OnUserClickListener {
        void onUserClick(Thread thread);
    }

    public ThreadAdapter(Context context) {
        this.context = context;
        synchronized (LIVE_ADAPTERS) {
            LIVE_ADAPTERS.add(this);
        }
    }

    public void setThreadList(List<Thread> list) {
        this.sourceList = list != null ? new ArrayList<>(list) : new ArrayList<>();
        this.threadList = filterThreads(sourceList);
        serverFollowingUids = null;
        serverFollowingLoaded = false;
        followStateLoading = false;
        notifyDataSetChanged();
    }

    public void addThreads(List<Thread> list) {
        if (list == null || list.isEmpty()) return;
        sourceList.addAll(list);
        // 只把通过过滤的新增项插入展示列表，避免整表刷新导致滚动位置跳动
        List<Thread> accepted = filterThreads(list);
        if (accepted.isEmpty()) return;
        int start = threadList.size();
        threadList.addAll(accepted);
        notifyItemRangeInserted(start, accepted.size());
    }

    /**
     * 按「隐藏带回收站的帖子」设置重新过滤展示列表。
     * 开关在设置页切换后由 {@code RecycleFilterManager} 回调触发。
     */
    public void applyRecycleFilter() {
        this.threadList = filterThreads(sourceList);
        notifyDataSetChanged();
    }

    /** 过滤掉已回收帖子；开关关闭时原样返回副本。 */
    private List<Thread> filterThreads(List<Thread> input) {
        List<Thread> result = new ArrayList<>();
        if (input == null || input.isEmpty()) return result;
        boolean hide = com.forum.MT.ui.widget.RecycleFilterManager.isEnabled(context);
        for (Thread t : input) {
            if (t == null) continue;
            if (hide && t.isRecycled()) continue;
            if (ClosedFilterManager.isEnabled(context) && t.isClosed()) continue;
            result.add(t);
        }
        return result;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setOnUserClickListener(OnUserClickListener listener) {
        this.userClickListener = listener;
    }

    public Thread getItem(int position) {
        if (position >= 0 && position < threadList.size()) return threadList.get(position);
        return null;
    }

    public void removeItem(int position) {
        if (position >= 0 && position < threadList.size()) {
            Thread removed = threadList.remove(position);
            // 同步源列表，否则开关切换重新过滤时被删项会"复活"
            if (removed != null) sourceList.remove(removed);
            notifyItemRemoved(position);
        }
    }

    public List<Thread> getThreadList() {
        return threadList;
    }

    public void updateThread(int position, Thread thread) {
        if (position >= 0 && position < threadList.size()) {
            Thread old = threadList.set(position, thread);
            int srcIndex = old != null ? sourceList.indexOf(old) : -1;
            if (srcIndex >= 0) {
                sourceList.set(srcIndex, thread);
            }
            notifyItemChanged(position);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_thread, parent, false);
        // ThreadAdapter 被首页、版块、搜索、个人帖子等所有帖子列表复用，统一在这里挂载边框。
        // 开启「卡片边框效果」时使用静态描边，否则使用流水灯边框（两者互斥）。
        CardBorderManager.applyBorder(view, 14f);
        return new ViewHolder(view);
    }

    @Override
    public void onViewAttachedToWindow(@NonNull ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(true, false);
        }
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull ViewHolder holder) {
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(false, false);
        }
        super.onViewDetachedFromWindow(holder);
    }

    @Override
    public void onViewRecycled(@NonNull ViewHolder holder) {
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(false, false);
        }
        super.onViewRecycled(holder);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Thread thread = threadList.get(position);
        // ★ 应用"显示大小-帖子列表"设置：标题随基准字号，摘要按 15/20 比例
        float listSize = com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(
                context, com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_LIST);
        holder.tvTitle.setTextSize(listSize * 20f / 15f);
        holder.tvSummary.setTextSize(listSize);
        // ★ 应用"显示大小-帖子卡片"设置：内边距/外边距/头像按百分比缩放（100% = 原本布局）
        float k = com.forum.MT.ui.widget.ThreadTextSizeManager.getCardScalePercent(context) / 100f;
        int pad = Math.round(12f * k);
        int marginH = Math.round(12f * k);
        int marginV = Math.max(2, Math.round(6f * k));
        holder.itemView.setPadding(pad, pad, pad, pad);
        android.view.ViewGroup.MarginLayoutParams lp =
                (android.view.ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams();
        if (lp != null) {
            lp.setMargins(marginH, marginV, marginH, marginV);
            lp.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;
            holder.itemView.setLayoutParams(lp);
        }
        int avatarSize = Math.round(46f * k);
        android.view.ViewGroup.LayoutParams avLp = holder.ivAvatar.getLayoutParams();
        if (avLp != null) {
            avLp.width = avatarSize;
            avLp.height = avatarSize;
            holder.ivAvatar.setLayoutParams(avLp);
        }
        holder.tvTitle.setText(thread.getTitle());
        // 回收站徽章：仅当解析到服务端输出的回收站标记时显示
        if (holder.tvRecycleFlag != null) {
            if (thread.isRecycled()) {
                holder.tvRecycleFlag.setVisibility(View.VISIBLE);
                // 徽章跟随标题字号等比缩放，保持视觉比例
                holder.tvRecycleFlag.setTextSize(listSize * 12f / 15f);
            } else {
                holder.tvRecycleFlag.setVisibility(View.GONE);
            }
        }
        if (holder.tvClosedFlag != null) {
            holder.tvClosedFlag.setVisibility(thread.isClosed() ? View.VISIBLE : View.GONE);
            holder.tvClosedFlag.setTextSize(listSize * 12f / 15f);
        }
        holder.tvAuthor.setText(thread.getAuthor());
        holder.tvTime.setText(thread.getPublishTime());
        holder.tvForum.setText(thread.getForumName());
        // 应用板块标签自定义颜色
        ThreadTagColorManager.applyTagBg(holder.tvForum);
        holder.tvForum.setTextColor(ThreadTagColorManager.textColorForBg(ThreadTagColorManager.resolveTagBg()));

        // 摘要
        String summary = thread.getSummary();
        if (summary != null && !summary.isEmpty()) {
            holder.tvSummary.setVisibility(View.VISIBLE);
            holder.tvSummary.setText(summary);
        } else {
            holder.tvSummary.setVisibility(View.GONE);
        }

        // 等级
        String level = thread.getAuthorLevel();
        if (level != null && !level.isEmpty()) {
            holder.tvLevel.setVisibility(View.VISIBLE);
            holder.tvLevel.setText(level);
        } else {
            holder.tvLevel.setVisibility(View.GONE);
        }

        // 统计信息
        holder.tvViews.setText(formatCount(thread.getViews()));
        holder.tvReplies.setText(formatCount(thread.getReplies()));
        holder.tvLikes.setText(formatCount(thread.getLikes()));

    // 关注状态统一从服务端关注列表恢复；网络确认失败时才使用已有本地状态。
         if (!TextUtils.isEmpty(thread.getAuthorUid())) {
             java.util.Set<String> serverSet = serverFollowingUids;
             if (serverSet != null) {
                 thread.setFollowed(serverSet.contains(thread.getAuthorUid()));
             } else {
                 thread.setFollowed(FollowStateManager.resolve(context, thread.getAuthorUid(), thread.isFollowed()));
                 loadServerFollowingIfNeeded();
             }
         }
         holder.btnFollow.setText(thread.isFollowed() ? "已关注" : "关注");
        // 应用关注按钮自定义颜色
        ThreadTagColorManager.applyFollowBg(holder.btnFollow);
        holder.btnFollow.setTextColor(ThreadTagColorManager.textColorForBg(ThreadTagColorManager.resolveFollowBg()));
        holder.btnFollow.setOnClickListener(v -> {
            if (!FollowStateManager.isLoggedIn(context)) {
                Toast.makeText(context, "请先登录后再关注", Toast.LENGTH_SHORT).show();
                return;
            }
            String uid = thread.getAuthorUid();
            if (TextUtils.isEmpty(uid)) {
                Toast.makeText(context, "无法获取用户ID", Toast.LENGTH_SHORT).show();
                return;
            }
            final boolean targetState = !thread.isFollowed();
            holder.btnFollow.setEnabled(false);
        new java.lang.Thread(() -> {
            boolean success = FollowStateManager.syncFollow(context, uid, targetState);
            android.os.Handler main = new android.os.Handler(android.os.Looper.getMainLooper());
            main.post(() -> {
                holder.btnFollow.setEnabled(true);
                if (success) {
                    thread.setFollowed(targetState);
                    holder.btnFollow.setText(targetState ? "已关注" : "关注");
                    Toast.makeText(context, targetState
                            ? R.string.action_follow_success
                            : R.string.action_unfollow_success, Toast.LENGTH_SHORT).show();
                    java.util.Set<String> current = serverFollowingUids;
                    if (current != null) {
                        java.util.Set<String> updated = new java.util.HashSet<>(current);
                        if (targetState) updated.add(uid); else updated.remove(uid);
                        serverFollowingUids = updated;
                    }
                } else {
                    Toast.makeText(context, "关注操作失败，请稍后重试", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
        });

        // 置顶标记（图标形式，无文字）
        if (thread.isSticky()) {
            holder.tvSticky.setVisibility(View.VISIBLE);
            holder.tvSticky.setText("📌");
        } else {
            holder.tvSticky.setVisibility(View.GONE);
        }

        // 头像加载
        String avatarUrl = thread.getAvatarUrl();
        if (avatarUrl != null && !avatarUrl.isEmpty()) {
            Glide.with(context)
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(holder.ivAvatar);
        } else {
            holder.ivAvatar.setImageResource(R.drawable.ic_account);
        }
        // 帖子封面图：所有页面统一使用单行并列样式（最多四张图横排一行）；没有图片列表时回退到单图封面
        holder.ivThumbnail.setVisibility(View.GONE);
        holder.llThreadImages.setVisibility(View.GONE);
        holder.llThreadImages.removeAllViews();
        Glide.with(context).clear(holder.ivThumbnail);

        List<String> imageUrls = thread.getImageUrls();
        if (imageUrls != null && !imageUrls.isEmpty()) {
            int count = Math.min(4, imageUrls.size());
            holder.llThreadImages.setVisibility(View.VISIBLE);
            int gap = dp(3);
            // 固定方形缩略图：宽高相等，按比例缩小，避免拉长变形
            int thumbSize = dp(72);
            for (int i = 0; i < count; i++) {
                ImageView imageView = new ImageView(context);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(thumbSize, thumbSize);
                if (i < count - 1) {
                    params.setMarginEnd(gap);
                }
                imageView.setLayoutParams(params);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setBackgroundResource(R.drawable.thread_image_bg);
                imageView.setClipToOutline(true);
                Glide.with(context)
                        .load(imageUrls.get(i))
                        .placeholder(R.drawable.ic_image_placeholder)
                        .error(R.drawable.ic_image_error)
                        .centerCrop()
                        .into(imageView);
                holder.llThreadImages.addView(imageView);
            }
        } else {
            String thumbnailUrl = thread.getThumbnailUrl();
            if (thumbnailUrl != null && !thumbnailUrl.isEmpty()) {
                holder.ivThumbnail.setVisibility(View.VISIBLE);
                Glide.with(context)
                        .load(thumbnailUrl)
                        .placeholder(R.drawable.ic_image_placeholder)
                        .error(R.drawable.ic_image_error)
                        .centerCrop()
                        .into(holder.ivThumbnail);
            }
        }


        holder.ivAvatar.setOnClickListener(v -> {
            if (userClickListener != null && !TextUtils.isEmpty(thread.getAuthorUid())) {
                userClickListener.onUserClick(thread);
            }
        });
        holder.tvAuthor.setOnClickListener(v -> {
            if (userClickListener != null && !TextUtils.isEmpty(thread.getAuthorUid())) {
                userClickListener.onUserClick(thread);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(thread, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return threadList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar;
        ImageView ivThumbnail;
        LinearLayout llThreadImages;
        TextView btnFollow;
        TextView tvTitle, tvAuthor, tvLevel, tvTime, tvForum, tvSummary;
        TextView tvViews, tvReplies, tvLikes, tvSticky;
        TextView tvRecycleFlag, tvClosedFlag;

        ViewHolder(View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.iv_avatar);
            ivThumbnail = itemView.findViewById(R.id.iv_thumbnail);
            llThreadImages = itemView.findViewById(R.id.ll_thread_images);
            btnFollow = itemView.findViewById(R.id.btn_thread_follow);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvRecycleFlag = itemView.findViewById(R.id.tv_recycle_flag);
            tvClosedFlag = itemView.findViewById(R.id.tv_closed_flag);
            tvAuthor = itemView.findViewById(R.id.tv_author);
            tvLevel = itemView.findViewById(R.id.tv_level);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvForum = itemView.findViewById(R.id.tv_forum);
            tvSummary = itemView.findViewById(R.id.tv_summary);
            tvViews = itemView.findViewById(R.id.tv_views);
            tvReplies = itemView.findViewById(R.id.tv_replies);
            tvLikes = itemView.findViewById(R.id.tv_likes);
            tvSticky = itemView.findViewById(R.id.tv_sticky);
        }
    }

    private void openUserProfile(Thread thread) {
        if (thread == null || TextUtils.isEmpty(thread.getAuthorUid())) return;
        if (userClickListener != null) {
            userClickListener.onUserClick(thread);
            return;
        }
        Intent intent = new Intent(context, UserProfileActivity.class);
        intent.putExtra("uid", thread.getAuthorUid());
        intent.putExtra("username", thread.getAuthor());
        if (!(context instanceof android.app.Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(intent);
    }

    private void loadServerFollowingIfNeeded() {
        if (serverFollowingUids != null) return;
        if (serverFollowingLoaded || followStateLoading
                || !FollowStateManager.isLoggedIn(context)) return;
        synchronized (followStateLock) {
            if (serverFollowingUids != null || serverFollowingLoaded || followStateLoading) return;
            followStateLoading = true;
        }
        new java.lang.Thread(() -> {
            java.util.Set<String> result = FollowStateManager.queryServerFollowingUids(context);
            serverFollowingUids = result;
            serverFollowingLoaded = true;
            followStateLoading = false;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(this::notifyDataSetChanged);
        }).start();
    }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private String formatCount(int count) {
        if (count >= 10000) {
            return String.format("%.1fw", count / 10000.0);
        } else if (count >= 1000) {
            return String.format("%.1fk", count / 1000.0);
        }
        return String.valueOf(count);
    }
}