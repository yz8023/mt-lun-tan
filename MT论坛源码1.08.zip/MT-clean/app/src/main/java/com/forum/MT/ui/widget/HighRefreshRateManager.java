package com.forum.MT.ui.widget;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

/**
 * 高刷新率模式管理器。
 * 在 Android 11 及以上优先请求设备当前屏幕支持的最高刷新率；
 * 低版本无法可靠切换显示模式时仅展示检测到的刷新率，不强行修改系统行为。
 */
public final class HighRefreshRateManager {
    private static final String PREFS = "display_performance_settings";
    private static final String KEY_ENABLED = "high_refresh_rate_enabled";

    private HighRefreshRateManager() {}

    public static boolean isEnabled(Context context) {
        return context != null && context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        if (context == null) return;
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    /** 应用到指定 Activity 的 Window。 */
    public static void apply(Activity activity) {
        if (activity == null) return;
        Display display = activity.getWindowManager().getDefaultDisplay();
        if (display == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Window window = activity.getWindow();
            WindowManager.LayoutParams params = window.getAttributes();
            if (isEnabled(activity)) {
                Display.Mode highest = getHighestMode(display);
                if (highest != null) {
                    // Window 公开 API 通过 LayoutParams 提交显示模式偏好。
                    params.preferredDisplayModeId = highest.getModeId();
                    params.preferredRefreshRate = highest.getRefreshRate();
                    window.setAttributes(params);
                }
            } else {
                // 0/0f 表示清除应用对显示模式的偏好，交回系统管理。
                params.preferredDisplayModeId = 0;
                params.preferredRefreshRate = 0f;
                window.setAttributes(params);
            }
        }
    }

    /** 返回设备当前默认屏幕支持的最高刷新率。 */
    public static float getHighestRefreshRate(Context context) {
        if (context == null) return 0f;
        DisplayManager manager = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
        Display display = manager != null ? manager.getDisplay(Display.DEFAULT_DISPLAY) : null;
        if (display == null) return 0f;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Display.Mode highest = getHighestMode(display);
            if (highest != null && highest.getRefreshRate() > 0f) return highest.getRefreshRate();
        }
        return display.getRefreshRate();
    }

    private static Display.Mode getHighestMode(Display display) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null;
        Display.Mode[] modes = display.getSupportedModes();
        if (modes == null || modes.length == 0) return display.getMode();

        Display.Mode current = display.getMode();
        Display.Mode highest = null;
        for (Display.Mode mode : modes) {
            if (mode == null) continue;
            // 优先保持当前分辨率，避免为了刷新率改变分辨率。
            if (current != null && (mode.getPhysicalWidth() != current.getPhysicalWidth()
                    || mode.getPhysicalHeight() != current.getPhysicalHeight())) continue;
            if (highest == null || mode.getRefreshRate() > highest.getRefreshRate()) highest = mode;
        }
        if (highest != null) return highest;
        for (Display.Mode mode : modes) {
            if (mode != null && (highest == null || mode.getRefreshRate() > highest.getRefreshRate())) {
                highest = mode;
            }
        }
        return highest;
    }
}