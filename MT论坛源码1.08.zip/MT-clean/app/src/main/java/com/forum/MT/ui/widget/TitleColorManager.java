package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/**
 * 首页标题颜色管理（"MT论坛" 标题文字颜色）。
 *
 * 颜色为 0 时表示使用默认颜色（与主题主色 #FF4081 一致）。
 *
 * 偏好键：
 *   title_color (int, 0 表示默认主色 #FF4081)
 */
public final class TitleColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_TITLE_COLOR = "title_color";

    /** 默认标题颜色（与 R.color.primary 一致） */
    public static final int DEFAULT_TITLE_COLOR = 0xFF2196F3;

    private static volatile int titleColor = 0;

    private TitleColorManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        titleColor = prefs.getInt(KEY_TITLE_COLOR, 0);
    }

    public static int getCustomColor() { return titleColor; }

    /** 设置自定义标题颜色，0 表示恢复默认。持久化。 */
    public static void setCustomColor(Context context, int color) {
        titleColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_TITLE_COLOR, color).apply();
        }
        notifyChanged();
    }

    /** 当前应使用的标题颜色。 */
    public static int resolveTitleColor() {
        return titleColor != 0 ? titleColor : DEFAULT_TITLE_COLOR;
    }

    public interface OnTitleColorChangedListener {
        void onTitleColorChanged();
    }

    private static volatile OnTitleColorChangedListener listener;

    public static void setListener(OnTitleColorChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnTitleColorChangedListener l = listener;
        if (l != null) l.onTitleColorChanged();
    }
}