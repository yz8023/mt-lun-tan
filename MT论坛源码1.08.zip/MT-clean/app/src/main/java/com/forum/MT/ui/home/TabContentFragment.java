package com.forum.MT.ui.home;
import com.forum.MT.ui.BaseFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.forum.MT.R;
import com.forum.MT.adapter.ThreadAdapter;
import com.forum.MT.model.Thread;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.ui.detail.ThreadDetailActivity;
import com.forum.MT.ui.space.UserProfileActivity;

import java.util.List;

/**
 * 首页 Tab 内容 Fragment
 * 每个 Tab（热门/最新/抢沙发/精华）各自独立实例，拥有自己的 RecyclerView 和加载状态
 */
public class TabContentFragment extends BaseFragment {

    private static final String ARG_TAB_TYPE = "tab_type";
    private static final int PAGE_SIZE = 20;

    private String tabType;
    private RecyclerView recyclerView;
    private androidx.swiperefreshlayout.widget.SwipeRefreshLayout swipeRefresh;
    private ThreadAdapter threadAdapter;
    private HttpClient httpClient;
    private int currentPage = 1;
    private boolean isLoading = false;
    private boolean hasMore = true;

    public static TabContentFragment newInstance(String tabType) {
        TabContentFragment fragment = new TabContentFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TAB_TYPE, tabType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            tabType = getArguments().getString(ARG_TAB_TYPE);
        }
        httpClient = HttpClient.getInstance();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab_content, container, false);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        recyclerView = view.findViewById(R.id.recycler_view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        threadAdapter = new ThreadAdapter(requireContext());
        // 注册颜色变更监听器，当主题设置页调整板块标签/关注按钮颜色时自动刷新列表
        ThreadAdapter.registerColorChangeListener(threadAdapter);
        threadAdapter.setOnItemClickListener((thread, position) -> {
            Intent intent = new Intent(requireContext(), ThreadDetailActivity.class);
            intent.putExtra("tid", thread.getTid());
            startActivity(intent);
        });
        threadAdapter.setOnUserClickListener(thread -> {
            if (thread == null || thread.getAuthorUid() == null || thread.getAuthorUid().isEmpty()) return;
            Intent intent = new Intent(requireContext(), UserProfileActivity.class);
            intent.putExtra("uid", thread.getAuthorUid());
            intent.putExtra("username", thread.getAuthor());
            startActivity(intent);
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerView.setAdapter(threadAdapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                super.onScrolled(rv, dx, dy);
                if (dy <= 0 || isLoading || !hasMore) return;
                LinearLayoutManager lm = (LinearLayoutManager) rv.getLayoutManager();
                if (lm != null) {
                    int visibleItemCount = lm.getChildCount();
                    int totalItemCount = lm.getItemCount();
                    int firstVisibleItemPosition = lm.findFirstVisibleItemPosition();
                    if (visibleItemCount + firstVisibleItemPosition >= totalItemCount - 2) {
                        loadMore();
                    }
                }
            }
        });

        swipeRefresh.setOnRefreshListener(this::refresh);
        swipeRefresh.setColorSchemeResources(
                com.google.android.material.R.color.design_default_color_primary,
                android.R.color.holo_orange_light,
                android.R.color.holo_green_light
        );

        if (threadAdapter.getItemCount() == 0) {
            refresh();
        }
    }

    /** 双击底部导航栏时触发：显示刷新指示器并重新加载当前页 */
    public void triggerRefresh() {
        if (swipeRefresh != null) swipeRefresh.setRefreshing(true);
        // ★ 双击刷新时同时回到顶部
        if (recyclerView != null) {
            recyclerView.scrollToPosition(0);
        }
        refresh();
    }

    private void refresh() {
        currentPage = 1;
        hasMore = true;
        loadData(currentPage, true);
    }

    private void loadMore() {
        if (isLoading || !hasMore) return;
        currentPage++;
        loadData(currentPage, false);
    }

    private String getTabUrl(int page) {
        switch (tabType) {
            case "hot":
                return ForumParser.getGuideUrl("hot", page);
            case "first_reply":
                return ForumParser.getGuideUrl("sofa", page);
            case "digest":
                return ForumParser.getGuideUrl("digest", page);
            case "newthread":
            default:
                return ForumParser.getHomeUrl(page);
        }
    }

    private void loadData(int page, boolean isRefresh) {
        isLoading = true;
        swipeRefresh.setRefreshing(true);

        new java.lang.Thread(() -> {
            try {
                String url = getTabUrl(page);
                String html = httpClient.get(url);
                List<com.forum.MT.model.Thread> threads = ForumParser.parseThreadList(html);

                if (!isAdded()) return;
                requireActivity().runOnUiThread(() -> {
                    if (!isAdded()) return;
                    if (threads != null && !threads.isEmpty()) {
                        if (isRefresh) {
                            threadAdapter.setThreadList(threads);
                        } else {
                            threadAdapter.addThreads(threads);
                        }
                        hasMore = threads.size() >= PAGE_SIZE;
                    } else {
                        hasMore = false;
                        if (isRefresh) {
                            threadAdapter.setThreadList(null);
                        }
                    }
                    isLoading = false;
                    swipeRefresh.setRefreshing(false);
                });
            } catch (Exception e) {
                if (!isAdded()) return;
                requireActivity().runOnUiThread(() -> {
                    if (!isAdded()) return;
                    isLoading = false;
                    swipeRefresh.setRefreshing(false);
                    if (isRefresh && threadAdapter.getItemCount() == 0) {
                        android.widget.Toast.makeText(requireContext(),
                                "加载失败: " + e.getMessage(), android.widget.Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).start();
    }
}