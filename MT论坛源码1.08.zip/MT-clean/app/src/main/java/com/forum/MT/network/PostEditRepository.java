package com.forum.MT.network;

import android.text.TextUtils;

import com.forum.MT.model.PostEditForm;
import com.forum.MT.model.PostEditResult;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * 编辑帖子/评论的网络层。
 *
 * <p>全部方法都是阻塞式，必须在后台线程调用。
 */
public final class PostEditRepository {

    private PostEditRepository() {}

    /**
     * 拉取编辑表单。
     *
     * <p>Discuz 的编辑页对 fid/page 敏感：参数不匹配时会返回只有 formhash 的空壳表单，
     * 若直接拿这个空壳提交，原帖正文会被清空。因此这里按三级策略请求：
     * <ol>
     *   <li>移动模板（mobile=2）直取；</li>
     *   <li>失败则回到真实帖子页，找服务端自己输出的该 pid 的编辑链接再重试
     *       （以服务端的真实定位为准，不猜 fid/page）；</li>
     *   <li>仍失败则用桌面模板兜底，兼容旧帖在移动模板下只返回表单壳的情况。</li>
     * </ol>
     *
     * @throws Exception 网络异常，或服务端明确拒绝（无权限/帖子不存在）
     */
    public static PostEditForm loadEditForm(String fid, String tid, String pid, int page)
            throws Exception {
        HttpClient http = HttpClient.getInstance();
        PostEditForm fallback = new PostEditForm();
        fallback.setFid(nullToEmpty(fid));
        fallback.setTid(nullToEmpty(tid));
        fallback.setPid(nullToEmpty(pid));
        fallback.setPage(Math.max(1, page));

        String viewReferer = HttpClient.BASE_URL
                + "forum.php?mod=viewthread&tid=" + tid + "&page=" + Math.max(1, page) + "&mobile=2";

        String body = http.getWithReferer(buildEditUrl(fid, tid, pid, page, true), viewReferer);
        PostEditForm form = PostEditParser.parseEditForm(body, fallback);
        if (PostEditParser.hasRealEditor(form)) return form;

        // 第二级：从帖子页拿服务端输出的真实编辑链接。
        try {
            String threadBody = http.getWithReferer(
                    ForumParser.getThreadDetailUrl(tid, Math.max(1, page), null), viewReferer);
            String actualEditUrl = findEditUrlForPid(threadBody, pid);
            if (!TextUtils.isEmpty(actualEditUrl)) {
                String actualBody = http.getWithReferer(actualEditUrl, viewReferer);
                PostEditForm actualForm = PostEditParser.parseEditForm(actualBody, fallback);
                if (PostEditParser.hasRealEditor(actualForm)) return actualForm;
            }
        } catch (Exception ignored) {
            // 辅助定位失败不直接暴露给 UI，继续走桌面兜底。
        }

        // 第三级：桌面模板。
        try {
            String desktopBody = http.getDesktop(buildEditUrl(fid, tid, pid, page, false));
            PostEditForm desktopForm = PostEditParser.parseEditForm(desktopBody, fallback);
            if (PostEditParser.hasRealEditor(desktopForm)) return desktopForm;
        } catch (Exception ignored) {
        }

        String message = PostEditParser.extractMessage(body);
        if (!TextUtils.isEmpty(message)) {
            throw new IllegalStateException(message);
        }
        if (form.isUsable()) {
            throw new IllegalStateException("编辑页未返回原文，可能没有编辑权限或已超过编辑时限");
        }
        throw new IllegalStateException("未获取到编辑表单，请重新登录后重试");
    }

    /**
     * 提交编辑的可选项，对应编辑页的"高级"面板。
     *
     * <p>Discuz 的这三个开关是"勾选才提交"的语义：不勾就必须完全不带该字段，
     * 带上 {@code 0} 会被某些模板当成已勾选。
     */
    public static final class EditOptions {
        public boolean useSig = true;
        public boolean smileyOff = false;
        public boolean bbcodeOff = false;
        /** 回帖仅作者可见；仅当表单支持时才会提交。 */
        public boolean hiddenReplies = false;
        /** 回帖倒序排列；仅当表单支持时才会提交。 */
        public boolean orderReverse = false;
    }

    /**
     * 提交编辑。
     *
     * @param newSubject   新标题；仅主题第一楼有效，评论楼层传空
     * @param newMessage   新正文
     * @param newAttachAids 本次新上传的附件 aid（会与原有附件一起绑定）
     * @param options      高级选项；传 null 用表单原值
     */
    public static PostEditResult submitEdit(PostEditForm form, String newSubject,
                                            String newMessage, Set<String> newAttachAids,
                                            EditOptions options)
            throws Exception {
        if (form == null || !form.isUsable()) {
            return PostEditResult.fail("编辑表单已失效，请重新打开编辑页");
        }
        String content = newMessage == null ? "" : newMessage.trim();
        if (content.isEmpty()) {
            return PostEditResult.fail("正文不能为空");
        }

        Map<String, String> params = new HashMap<>();
        params.put("formhash", form.getFormhash());
        params.put("posttime", form.getPosttime());
        params.put("delete", form.getDeleteValue());
        params.put("htmlon", "0");
        params.put("fid", form.getFid());
        params.put("tid", form.getTid());
        params.put("pid", form.getPid());
        params.put("page", String.valueOf(form.getPage()));
        params.put("editsubmit", "yes");
        params.put("wysiwyg", "0");
        params.put("message", content);
        params.put("save", "");
        // 只有第一楼能改标题；给评论楼层提交 subject 会被服务端忽略，
        // 但为兼容部分模板必须带上空值字段。
        params.put("subject", form.isFirstPost() && newSubject != null ? newSubject.trim() : "");
        if (!"0".equals(form.getAllowNoticeAuthor())) {
            params.put("allownoticeauthor", "1");
        }
        boolean useSig = options != null ? options.useSig : !"0".equals(form.getUseSig());
        if (useSig) params.put("usesig", "1");
        if (options != null && options.smileyOff) params.put("smileyoff", "1");
        if (options != null && options.bbcodeOff) params.put("bbcodeoff", "1");
        // 主题属性只在编辑页确实输出了对应开关时提交，避免给评论楼层带上无效字段。
        if (form.isHiddenRepliesSupported()) {
            boolean on = options != null ? options.hiddenReplies : form.isHiddenReplies();
            if (on) params.put("hiddenreplies", "1");
        }
        if (form.isOrderTypeSupported()) {
            boolean on = options != null ? options.orderReverse : form.isOrderReverse();
            if (on) params.put("ordertype", "1");
        }

        // 原有附件必须重新绑定，否则保存后会被清空。
        Set<String> allAids = new LinkedHashSet<>(form.getAttachmentAids());
        for (String aid : allAids) {
            if (aid == null || !aid.matches("\\d+")) continue;
            params.put("attachnew[" + aid + "][description]", "");
            params.put("attachnew[" + aid + "][readperm]", "");
            params.put("attachnew[" + aid + "][price]", "");
        }
        if (newAttachAids != null) {
            for (String aid : newAttachAids) {
                if (aid == null || !aid.matches("\\d+") || allAids.contains(aid)) continue;
                params.put("attachnew[" + aid + "][description]", "");
            }
        }

        String submitUrl = HttpClient.BASE_URL
                + "forum.php?mod=post&action=edit&extra=&editsubmit=yes"
                + "&mobile=2&handlekey=postform&inajax=1";
        String referer = buildEditUrl(form.getFid(), form.getTid(), form.getPid(),
                form.getPage(), true);
        String response = HttpClient.getInstance().postAjax(submitUrl, params, referer);
        return PostEditParser.parseEditResult(response);
    }

    /** 兼容旧调用：不带高级选项，沿用表单原值。 */
    public static PostEditResult submitEdit(PostEditForm form, String newSubject,
                                            String newMessage, Set<String> newAttachAids)
            throws Exception {
        return submitEdit(form, newSubject, newMessage, newAttachAids, null);
    }

    /**
     * 删除帖子或评论。
     *
     * <p>走的是 Discuz 编辑接口自带的删除通道，而不是版主的 topicadmin 批量删除：
     * 编辑页的 {@code delete=1} 是"作者删除自己的帖子"，普通会员在编辑时限内即可使用；
     * topicadmin 需要版主权限，对普通用户必然失败。
     *
     * <p>请求与保存编辑几乎一致，差别只在 {@code delete=1}，并且必须照样带上
     * {@code message}：部分 Discuz 版本在 message 为空时会先撞上"内容不能为空"
     * 校验而根本走不到删除分支。因此这里回传原文。
     *
     * <p>删除第一楼等于删除整个主题，调用方需要在 UI 上说清后果。
     */
    public static PostEditResult submitDelete(PostEditForm form) throws Exception {
        if (form == null || !form.isUsable()) {
            return PostEditResult.fail("编辑表单已失效，请重新打开编辑页");
        }

        Map<String, String> params = new HashMap<>();
        params.put("formhash", form.getFormhash());
        params.put("posttime", form.getPosttime());
        params.put("delete", "1");
        params.put("htmlon", "0");
        params.put("fid", form.getFid());
        params.put("tid", form.getTid());
        params.put("pid", form.getPid());
        params.put("page", String.valueOf(form.getPage()));
        params.put("editsubmit", "yes");
        params.put("wysiwyg", "0");
        // 原文照回传：空 message 会先触发"请输入正文"而走不到删除逻辑。
        params.put("message", form.getMessage() == null ? "" : form.getMessage());
        params.put("subject", form.isFirstPost() && form.getSubject() != null
                ? form.getSubject() : "");
        params.put("save", "");

        String submitUrl = HttpClient.BASE_URL
                + "forum.php?mod=post&action=edit&extra=&editsubmit=yes"
                + "&mobile=2&handlekey=postform&inajax=1";
        String referer = buildEditUrl(form.getFid(), form.getTid(), form.getPid(),
                form.getPage(), true);
        String response = HttpClient.getInstance().postAjax(submitUrl, params, referer);
        return PostEditParser.parseDeleteResult(response);
    }

    /** 解析该 pid 所在页码；失败返回 1。 */
    public static int resolvePage(String tid, String pid) {
        try {
            String page = HttpClient.getInstance().resolveFindPostPage(tid, pid);
            if (page != null && page.matches("\\d+")) {
                return Math.max(1, Integer.parseInt(page));
            }
        } catch (Exception ignored) {
        }
        return 1;
    }

    private static String buildEditUrl(String fid, String tid, String pid, int page,
                                       boolean mobile) {
        StringBuilder sb = new StringBuilder(HttpClient.BASE_URL)
                .append("forum.php?mod=post&action=edit");
        if (!TextUtils.isEmpty(fid)) sb.append("&fid=").append(fid);
        sb.append("&tid=").append(nullToEmpty(tid))
                .append("&pid=").append(nullToEmpty(pid))
                .append("&page=").append(Math.max(1, page));
        if (mobile) sb.append("&mobile=2");
        return sb.toString();
    }

    /** 在帖子页 HTML 中找服务端为该 pid 输出的编辑链接。 */
    private static String findEditUrlForPid(String html, String pid) {
        if (TextUtils.isEmpty(html) || TextUtils.isEmpty(pid)) return null;
        Document doc = Jsoup.parse(html, HttpClient.BASE_URL);
        for (Element a : doc.select("a[href*=action=edit]")) {
            String abs = a.absUrl("href");
            if (TextUtils.isEmpty(abs)) abs = a.attr("href").replace("&amp;", "&");
            if (abs.contains("pid=" + pid + "&") || abs.endsWith("pid=" + pid)) {
                return abs;
            }
        }
        return null;
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }
}
