package com.forum.MT.session;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * “从消息进入帖子时，同帖通知全部标记为已读”设置管理器。
 * 默认关闭，关闭后保持逐条标记已读的原有行为。
 */
public final class SameThreadReadManager {
    private static final String PREF_NAME = "same_thread_read_pref";
    private static final String KEY_ENABLED = "same_thread_read_enabled";
    private static final boolean DEFAULT_ENABLED = false;

    private SameThreadReadManager() {}

    public static boolean isEnabled(Context context) {
        if (context == null) return DEFAULT_ENABLED;
        return context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, DEFAULT_ENABLED);
    }

    public static void setEnabled(Context context, boolean enabled) {
        if (context == null) return;
        SharedPreferences preferences = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        preferences.edit().putBoolean(KEY_ENABLED, enabled).apply();
    }
}
