package com.forum.MT.session;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 用户空间操作的 Discuz!/Comiis 接口封装。
 * 所有方法必须在后台线程调用；结果只代表网页端接口是否明确接受了操作。
 */
public final class DiscuzUserActionManager {

    private DiscuzUserActionManager() {}

    public static boolean addFriend(Context context, String uid, String note) {
        if (TextUtils.isEmpty(uid)) return false;
        try {
            HttpClient client = prepareClient();
            String actionUrl = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=friend&op=add&uid=" + uid
                    + "&handlekey=friendhk&inajax=1";
            String page = client.get(actionUrl);
            String formhash = getFormhash(client, page, context);
            if (TextUtils.isEmpty(formhash)) return false;

            Map<String, String> params = new HashMap<>();
            params.put("formhash", formhash);
            params.put("addsubmit", "true");
            params.put("uid", uid);
            params.put("note", TextUtils.isEmpty(note) ? "来自手机端" : note);
            String result = client.post(actionUrl, params);
            return accepted(result, "好友申请已发送", "好友添加成功", "已添加为好友",
                    "已是好友", "申请成功", "请求已发送");
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * 批准好友申请（通知页"批准申请"按钮）。
     * 网页端通过 showWindow 发起 AJAX 请求，此处用 postAjax 模拟。
     * 返回 null 表示成功，非 null 为错误信息。
     */
    public static String acceptFriendRequest(Context context, String uid) {
        if (TextUtils.isEmpty(uid)) return "缺少用户ID";
        try {
            HttpClient client = prepareClient();
            String actionUrl = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=friend&op=add&uid=" + uid
                    + "&from=notice&handlekey=friendhk&inajax=1";
            // 通知页用桌面UA加载，此处也用桌面UA，避免 WAF 对 UA 切换的拦截。
            String page = client.getDesktop(actionUrl);
            String formhash = getFormhash(client, page, context);
            if (TextUtils.isEmpty(formhash)) return "无法获取formhash";
            Map<String, String> params = new HashMap<>();
            params.put("formhash", formhash);
            // ★ 网页端表单隐藏字段是 add2submit（不是 addsubmit），缺少此项服务器返回表单页而非执行操作。
            params.put("add2submit", "true");
            params.put("agree", "1");
            params.put("uid", uid);
            params.put("handlekey", "friendhk");
            params.put("from", "notice");
            // 网页端表单含 gid（好友分组），默认"1"对应"通过本站认识"（默认选中）。
            params.put("gid", "1");
            // Discuz 表单提交需要 referer 字段，否则部分版本拒绝执行。
            params.put("referer", actionUrl);
            String result = client.postAjax(actionUrl, params, actionUrl);
            boolean ok = accepted(result, "已添加为好友", "添加好友成功", "好友申请已接受",
                    "申请成功", "请求已接受", "操作成功", "succeedhandle_friend",
                    "succeed", "success", "已成为好友", "你们已成为好友", "已是好友");
            Log.e("MT_FRIEND", "accept result=" + ok
                    + " resp_size=" + (result != null ? result.length() : 0));
            return ok ? null : "服务器未确认成功";
        } catch (Exception e) {
            Log.e("MT_FRIEND", "exception: " + e.getMessage());
            return "异常: " + e.getMessage();
        }
    }

    /**
     * 解除好友关系。
     * 网页端通过 home.php?mod=spacecp&ac=friend&op=ignore 执行（不是 op=del）。
     */
    public static boolean removeFriend(Context context, String uid) {
        if (TextUtils.isEmpty(uid)) return false;
        try {
            HttpClient client = prepareClient();
            String handlekey = "ignorefriendhk_" + uid;
            String actionUrl = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=friend&op=ignore&uid=" + uid
                    + "&handlekey=" + handlekey + "&inajax=1";
            String page = client.get(actionUrl);
            String formhash = getFormhash(client, page, context);
            if (TextUtils.isEmpty(formhash)) return false;
            Map<String, String> params = new HashMap<>();
            params.put("formhash", formhash);
            params.put("friendsubmit", "true");
            params.put("uid", uid);
            params.put("handlekey", handlekey);
            params.put("from", "");
            params.put("referer", actionUrl);
            String result = client.post(actionUrl, params);
            return accepted(result, "操作成功", "解除好友成功",
                    "已解除", "succeedhandle_ignorefriendhk", "succeed",
                    "成功", "不再是好友");
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean sendPoke(Context context, String uid, String message) {
        if (TextUtils.isEmpty(uid)) return false;
        try {
            HttpClient client = prepareClient();
            String actionUrl = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=poke&op=send&uid=" + uid
                    + "&handlekey=propoke&inajax=1";
            String page = client.get(actionUrl);
            String formhash = getFormhash(client, page, context);
            if (TextUtils.isEmpty(formhash)) return false;

            String text = TextUtils.isEmpty(message) ? "你好！" : message.trim();
            Map<String, String> params = new HashMap<>();
            params.put("formhash", formhash);
            params.put("pokesubmit", "true");
            params.put("uid", uid);
            params.put("message", text);
            String result = client.post(actionUrl, params);
            return accepted(result, "打招呼成功", "已向", "招呼已发送", "发送成功");
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean sendPrivateMessage(Context context, String uid,
                                               String subject, String message) {
        if (TextUtils.isEmpty(uid) || TextUtils.isEmpty(message)) return false;
        try {
            HttpClient client = prepareClient();
            String chatUrl = HttpClient.BASE_URL
                    + "home.php?mod=space&do=pm&subop=view&touid=" + uid + "&mobile=2&_ts="
                    + System.currentTimeMillis();
            String page = client.get(chatUrl);
            if (TextUtils.isEmpty(page) || ForumParser.isLoginPage(page)) return false;

            org.jsoup.nodes.Document doc = Jsoup.parse(page, HttpClient.BASE_URL);
            Element form = doc.select("form#pmform, form[name=pmform]").first();
            if (form == null) return false;

            String action = form.attr("abs:action");
            if (TextUtils.isEmpty(action)) action = form.attr("action");
            if (TextUtils.isEmpty(action)) {
                action = HttpClient.BASE_URL
                        + "home.php?mod=spacecp&ac=pm&op=send&mobile=2";
            }

            String formhash = form.select("input[name=formhash]").attr("value");
            if (TextUtils.isEmpty(formhash)) formhash = ForumParser.parseFormhash(page);
            if (TextUtils.isEmpty(formhash)) return false;

            String targetUid = form.select("input[name=touid]").attr("value");
            if (TextUtils.isEmpty(targetUid)) targetUid = uid;

            Map<String, String> params = new HashMap<>();
            params.put("formhash", formhash);
            params.put("touid", targetUid);
            params.put("message", message.trim());
            // Comiis 移动版聊天表单的真实提交方式。
            params.put("pmsubmit", "yes");
            String result = client.post(action, params);

            // 成功响应中可能同时包含 errorhandle_pmform 脚本，不能简单搜索 "error" 判失败。
            if (isExplicitActionFailure(result)) return false;
            if (containsAnyIgnoreCase(result, "发送成功", "消息已发送", "succeed", "success")) {
                return true;
            }

            // 某些 Comiis 版本返回空 XML/脚本；重新读取聊天页确认消息是否已经落库。
            String verify = client.get(chatUrl + "&verify=" + System.currentTimeMillis());
            return containsMessage(context, verify, message.trim());
        } catch (Exception ignored) {
            return false;
        }
    }

    /** 使用私信列表中网页端生成的完整删除地址删除会话。 */
    public static boolean deletePrivateMessage(Context context, String uid, String formhash,
                                                String pageDeleteUrl) {
        if (TextUtils.isEmpty(uid)) return false;
        try {
            HttpClient client = prepareClient();
            String deleteUrl = pageDeleteUrl;
            if (TextUtils.isEmpty(deleteUrl)) {
                if (TextUtils.isEmpty(formhash)) {
                    String page = client.get(HttpClient.BASE_URL
                            + "home.php?mod=space&do=pm&mobile=2&_ts="
                            + System.currentTimeMillis());
                    formhash = ForumParser.parseFormhash(page);
                }
                deleteUrl = HttpClient.BASE_URL
                        + "home.php?mod=spacecp&ac=pm&op=delete"
                        + "&deletepm_deluid%5B%5D=" + uid
                        + "&uid=" + uid
                        + "&handlekey=pmdeletehk_0"
                        + (TextUtils.isEmpty(formhash) ? "" : "&formhash=" + formhash)
                        + "&deletesubmit=1&mobile=2";
            }
            if (!deleteUrl.contains("inajax=")) {
                deleteUrl += (deleteUrl.contains("?") ? "&" : "?") + "inajax=1";
            }

            // 直接复用网页端 a.kmdel 的 open_href，避免丢失网页生成的 formhash/参数。
            client.get(deleteUrl);

            String verifyHtml = client.get(HttpClient.BASE_URL
                    + "home.php?mod=space&do=pm&mobile=2&_delete_verify="
                    + System.currentTimeMillis());
            if (ForumParser.isLoginPage(verifyHtml)) return false;
            for (com.forum.MT.model.Message item :
                    ForumParser.parsePmList(verifyHtml)) {
                if (uid.equals(item.getAuthorUid())) return false;
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    /** 兼容旧调用：没有网页端 open_href 时再回退到拼接接口。 */
    public static boolean deletePrivateMessage(Context context, String uid, String formhash) {
        return deletePrivateMessage(context, uid, formhash, null);
    }

    /**
     * 核验聊天页里是否已经出现刚发出的这条消息。
     *
     * <p>不能直接用 {@code Jsoup.parse(html).text().contains(message)}：消息里的
     * 表情代码（{@code [#呵呵]}）在页面上是 {@code <img>}，纯文本里一个字都没有，
     * 纯表情消息会被永远判成"没发出去"。这里改用与
     * {@link com.forum.MT.util.PmContentMatcher} 一致的规范键比对。
     */
    private static boolean containsMessage(Context context, String html, String message) {
        if (TextUtils.isEmpty(html) || TextUtils.isEmpty(message)) return false;
        try {
            String selfUid = UserSessionManager.getInstance().getUid(context);
            java.util.List<com.forum.MT.model.ChatMessage> messages =
                    ForumParser.parseChatMessages(html, selfUid, null);
            if (com.forum.MT.util.PmContentMatcher.containsLocalText(
                    context, messages, message)) {
                return true;
            }
        } catch (Exception ignored) {}
        // 兜底：纯文字消息按纯文本包含判断。
        return Jsoup.parse(html).text().contains(message);
    }

    private static boolean containsAnyIgnoreCase(String text, String... words) {
        if (TextUtils.isEmpty(text)) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        for (String word : words) {
            if (word != null && lower.contains(word.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private static boolean isExplicitActionFailure(String result) {
        // 空响应在 Comiis AJAX 接口中可能代表已处理，交给后续重新读取页面确认。
        if (TextUtils.isEmpty(result)) return false;
        if (ForumParser.isLoginPage(result)) return true;
        return containsAnyIgnoreCase(result, "请先登录", "formhash错误", "没有权限",
                "非法操作", "操作失败", "发送失败", "删除失败", "ajaxerror");
    }

    public static boolean blockUser(Context context, String uid, String username) {
        if (TextUtils.isEmpty(uid) || TextUtils.isEmpty(username)) return false;
        try {
            HttpClient client = prepareClient();
            String profileUrl = HttpClient.BASE_URL
                    + "home.php?mod=space&uid=" + uid + "&do=profile&mobile=2";
            String page = client.get(profileUrl);
            String formhash = getFormhash(client, page, context);
            if (TextUtils.isEmpty(formhash)) return false;
            String url = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=friend&op=blacklist&start=&inajax=1";
            Map<String, String> params = new HashMap<>();
            params.put("blacklistsubmit", "true");
            params.put("formhash", formhash);
            params.put("username", username.trim());
            String result = client.postAjax(url, params, profileUrl);
            return accepted(result, "操作成功", "拉黑成功", "已拉黑",
                    "succeedhandle", "succeed");
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * 解除拉黑（Comiis 黑名单）。
     * 网页端链接 home.php?mod=spacecp&ac=friend&op=blacklist&subop=delete&uid=XXX&start=
     * 直接 GET 即返回"操作成功"。
     */
    public static boolean unblockUser(Context context, String uid) {
        if (TextUtils.isEmpty(uid)) return false;
        try {
            HttpClient client = prepareClient();
            String url = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=friend&op=blacklist&subop=delete&uid=" + uid
                    + "&start=&inajax=1";
            String result = client.get(url);
            return accepted(result, "操作成功", "已解除", "解除拉黑成功",
                    "succeedhandle", "succeed");
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * 在用户留言板发布留言。
     * 实际表单 POST 到 home.php?mod=spacecp&ac=comment，字段 id/idtype/handlekey/commentsubmit/quickcomment/message。
     */
    public static boolean postWallMessage(Context context, String uid, String message) {
        if (TextUtils.isEmpty(uid) || TextUtils.isEmpty(message)) return false;
        try {
            HttpClient client = prepareClient();
            String wallUrl = HttpClient.BASE_URL
                    + "home.php?mod=space&uid=" + uid + "&do=wall&mobile=2";
            String page = client.get(wallUrl);
            String formhash = getFormhash(client, page, context);
            if (TextUtils.isEmpty(formhash)) return false;
            String actionUrl = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=comment&inajax=1";
            Map<String, String> params = new HashMap<>();
            params.put("formhash", formhash);
            params.put("referer", "home.php?mod=space&uid=" + uid + "&do=wall");
            params.put("id", uid);
            params.put("idtype", "uid");
            params.put("handlekey", "qcwall_" + uid);
            params.put("commentsubmit", "true");
            params.put("quickcomment", "true");
            params.put("message", message.trim());
            String result = client.postAjax(actionUrl, params, wallUrl);
            return accepted(result, "留言成功", "留言已发布", "操作成功",
                    "succeedhandle_comment", "succeed");
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * 编辑自己在留言板上发布的留言。
     * 网页端流程：
     *   1) GET home.php?mod=spacecp&ac=comment&op=edit&cid=XXX&handlekey=editcommenthk_XXX&inajax=1
     *      返回编辑对话框表单（含 formhash、action、handlekey）
     *   2) POST 到表单 action，字段 referer/editsubmit/handlekey/formhash/message
     */
    public static boolean editWallMessage(Context context, String cid, String message) {
        if (TextUtils.isEmpty(cid) || TextUtils.isEmpty(message)) return false;
        try {
            HttpClient client = prepareClient();
            String dialogUrl = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=comment&op=edit&cid=" + cid
                    + "&handlekey=editcommenthk_" + cid + "&inajax=1";
            String dialog = client.get(dialogUrl);
            if (TextUtils.isEmpty(dialog) || ForumParser.isLoginPage(dialog)) return false;

            // 编辑对话框返回 AJAX XML（<root><![CDATA[<form…>]]></root>），
            // Jsoup 直接 parse 时 CDATA 内 HTML 不被解析，必须先提取 CDATA 内容。
            String cdata = extractAjaxCdata(dialog);
            Element form = Jsoup.parse(cdata != null ? cdata : dialog)
                    .selectFirst("form[id*=editcommentform]");
            if (form == null) return false;
            String actionUrl = form.attr("action");
            if (TextUtils.isEmpty(actionUrl)) return false;
            actionUrl = actionUrl.startsWith("http")
                    ? actionUrl : HttpClient.BASE_URL + actionUrl;
            // 表单 action 不含 inajax=1，补上才能拿到 AJAX 成功响应
            if (!actionUrl.contains("inajax=")) {
                actionUrl += (actionUrl.contains("?") ? "&" : "?") + "inajax=1";
            }

            String formhash = form.selectFirst("input[name=formhash]") != null
                    ? form.selectFirst("input[name=formhash]").attr("value") : "";
            String handlekey = form.selectFirst("input[name=handlekey]") != null
                    ? form.selectFirst("input[name=handlekey]").attr("value") : "";
            String referer = form.selectFirst("input[name=referer]") != null
                    ? form.selectFirst("input[name=referer]").attr("value") : HttpClient.BASE_URL;
            if (TextUtils.isEmpty(formhash)) return false;

            Map<String, String> params = new HashMap<>();
            params.put("referer", referer);
            params.put("editsubmit", "true");
            params.put("handlekey", handlekey);
            params.put("formhash", formhash);
            params.put("message", message.trim());
            String result = client.postAjax(actionUrl, params, referer);
            return accepted(result, "编辑成功", "留言已更新", "修改成功", "操作成功",
                    "succeedhandle_editcomment", "succeed");
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * 回复留言板上某条留言。
     * 网页端流程：
     *   1) GET home.php?mod=spacecp&ac=comment&op=reply&cid=XXX&handlekey=replycommenthk_XXX&inajax=1
     *      返回回复表单（含 id/idtype/cid/commentsubmit/handlekey/formhash）
     *   2) POST 到 home.php?mod=spacecp&ac=comment，字段 id/idtype/cid/commentsubmit/handlekey/formhash/message
     */
    public static boolean replyWallMessage(Context context, String cid, String message) {
        if (TextUtils.isEmpty(cid) || TextUtils.isEmpty(message)) return false;
        try {
            HttpClient client = prepareClient();
            String dialogUrl = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=comment&op=reply&cid=" + cid
                    + "&feedid=&handlekey=replycommenthk_" + cid + "&inajax=1";
            String dialog = client.get(dialogUrl);
            if (TextUtils.isEmpty(dialog) || ForumParser.isLoginPage(dialog)) return false;

            String cdata = extractAjaxCdata(dialog);
            Element form = Jsoup.parse(cdata != null ? cdata : dialog)
                    .selectFirst("form[id*=replycommentform]");
            if (form == null) return false;
            String actionUrl = form.attr("action");
            if (TextUtils.isEmpty(actionUrl)) return false;
            actionUrl = actionUrl.startsWith("http")
                    ? actionUrl : HttpClient.BASE_URL + actionUrl;
            if (!actionUrl.contains("inajax=")) {
                actionUrl += (actionUrl.contains("?") ? "&" : "?") + "inajax=1";
            }

            String formhash = form.selectFirst("input[name=formhash]") != null
                    ? form.selectFirst("input[name=formhash]").attr("value") : "";
            String handlekey = form.selectFirst("input[name=handlekey]") != null
                    ? form.selectFirst("input[name=handlekey]").attr("value") : "";
            String referer = form.selectFirst("input[name=referer]") != null
                    ? form.selectFirst("input[name=referer]").attr("value") : HttpClient.BASE_URL;
            String id = form.selectFirst("input[name=id]") != null
                    ? form.selectFirst("input[name=id]").attr("value") : "";
            String idtype = form.selectFirst("input[name=idtype]") != null
                    ? form.selectFirst("input[name=idtype]").attr("value") : "uid";
            if (TextUtils.isEmpty(formhash)) return false;

            Map<String, String> params = new HashMap<>();
            params.put("referer", referer);
            params.put("id", id);
            params.put("idtype", idtype);
            params.put("cid", cid);
            params.put("commentsubmit", "true");
            params.put("handlekey", handlekey);
            params.put("formhash", formhash);
            params.put("message", message.trim());
            String result = client.postAjax(actionUrl, params, referer);
            return accepted(result, "回复成功", "留言已发布", "操作成功",
                    "succeedhandle_replycomment", "succeed");
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * 删除自己在留言板上发布的留言。
     * 网页端流程：
     *   1) GET home.php?mod=spacecp&ac=comment&op=delete&cid=XXX&handlekey=delcommenthk_XXX&inajax=1
     *      返回删除确认对话框（含 formhash）
     *   2) POST 到表单 action，字段 referer/deletesubmit/formhash/handlekey/deletesubmitbtn
     */
    public static boolean deleteWallMessage(Context context, String cid) {
        if (TextUtils.isEmpty(cid)) return false;
        try {
            HttpClient client = prepareClient();
            String dialogUrl = HttpClient.BASE_URL
                    + "home.php?mod=spacecp&ac=comment&op=delete&cid=" + cid
                    + "&handlekey=delcommenthk_" + cid + "&inajax=1";
            String dialog = client.get(dialogUrl);
            if (TextUtils.isEmpty(dialog) || ForumParser.isLoginPage(dialog)) return false;

            String cdata = extractAjaxCdata(dialog);
            Element form = Jsoup.parse(cdata != null ? cdata : dialog)
                    .selectFirst("form[id*=deletecommentform]");
            if (form == null) return false;
            String actionUrl = form.attr("action");
            if (TextUtils.isEmpty(actionUrl)) return false;
            actionUrl = actionUrl.startsWith("http")
                    ? actionUrl : HttpClient.BASE_URL + actionUrl;
            if (!actionUrl.contains("inajax=")) {
                actionUrl += (actionUrl.contains("?") ? "&" : "?") + "inajax=1";
            }

            String formhash = form.selectFirst("input[name=formhash]") != null
                    ? form.selectFirst("input[name=formhash]").attr("value") : "";
            String handlekey = form.selectFirst("input[name=handlekey]") != null
                    ? form.selectFirst("input[name=handlekey]").attr("value") : "";
            String referer = form.selectFirst("input[name=referer]") != null
                    ? form.selectFirst("input[name=referer]").attr("value") : HttpClient.BASE_URL;
            if (TextUtils.isEmpty(formhash)) return false;

            Map<String, String> params = new HashMap<>();
            params.put("referer", referer);
            params.put("deletesubmit", "true");
            params.put("formhash", formhash);
            params.put("handlekey", handlekey);
            params.put("deletesubmitbtn", "true");
            String result = client.postAjax(actionUrl, params, referer);
            return accepted(result, "删除成功", "已删除", "操作成功",
                    "succeedhandle_delcomment", "succeed");
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * Discuz AJAX 对话框返回 <root><![CDATA[…HTML…]]></root>，
     * Jsoup 直接 parse 时 CDATA 内的 HTML 不被解析为元素，
     * 必须先提取 CDATA 文本再交给 Jsoup 解析。
     */
    private static String extractAjaxCdata(String html) {
        if (html == null) return null;
        int s = html.indexOf("<![CDATA[");
        int e = html.indexOf("]]>");
        if (s >= 0 && e > s) return html.substring(s + 9, e);
        return null;
    }

    private static HttpClient prepareClient() {
        HttpClient client = HttpClient.getInstance();
        if (!client.isLoggedIn()) client.syncFromCookieManager();
        return client;
    }

    private static String getFormhash(HttpClient client, String page, Context context) throws Exception {
        String formhash = ForumParser.parseFormhash(page);
        if (!TextUtils.isEmpty(formhash)) return formhash;

        String currentUid = UserSessionManager.getInstance().getUid(
                context != null ? context.getApplicationContext() : null);
        String profileUrl = HttpClient.BASE_URL + "home.php?mod=space&do=profile&mobile=2";
        if (!TextUtils.isEmpty(currentUid)) profileUrl += "&uid=" + currentUid;
        formhash = ForumParser.parseFormhash(client.get(profileUrl));
        if (!TextUtils.isEmpty(formhash)) return formhash;

        formhash = ForumParser.parseFormhash(client.get(HttpClient.BASE_URL + "forum.php?mobile=2"));
        if (!TextUtils.isEmpty(formhash)) return formhash;
        return ForumParser.parseFormhash(client.getDesktop(HttpClient.BASE_URL + "forum.php"));
    }

    private static boolean accepted(String result, String... successWords) {
        if (TextUtils.isEmpty(result) || ForumParser.isLoginPage(result)) return false;
        if (containsFailure(result)) return false;
        String lower = result.toLowerCase(Locale.ROOT);
        for (String word : successWords) {
            if (lower.contains(word.toLowerCase(Locale.ROOT))) return true;
        }
        // Discuz AJAX 成功响应：succeedhandle/showmessage/refresh 等。
        // 注意：不能排除含 "error" 的响应，因为 errorhandle_xxx 是 Discuz 的标准回调函数名，
        // 成功和失败响应中都会出现。
        return lower.contains("succeedhandle")
                || lower.contains("showmessage('")
                || lower.contains("showmessage(\"")
                || lower.contains("refresh");
    }

    private static boolean containsFailure(String result) {
        if (TextUtils.isEmpty(result)) return true;
        String lower = result.toLowerCase(Locale.ROOT);
        // 注意：不能匹配裸 "error"，因为 Discuz AJAX 响应中 errorhandle_xxx 是成功回调函数名。
        return lower.contains("请先登录") || lower.contains("formhash错误")
                || lower.contains("没有权限") || lower.contains("非法操作")
                || lower.contains("操作失败") || lower.contains("发生错误")
                || lower.contains("失败");
    }
}
