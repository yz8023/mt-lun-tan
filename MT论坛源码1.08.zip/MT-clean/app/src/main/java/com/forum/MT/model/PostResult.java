package com.forum.MT.model;

/**
 * 发帖结果（对应官方APK PostResult）
 * 由 PostPageParser.parsePostResult 解析
 */
public class PostResult {
    private final boolean success;
    private final String message;
    private final String tid;
    private final String redirectUrl;

    public PostResult(boolean success, String message, String tid, String redirectUrl) {
        this.success = success;
        this.message = message;
        this.tid = tid;
        this.redirectUrl = redirectUrl;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public String getTid() {
        return tid;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }
}
