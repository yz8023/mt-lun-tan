package com.forum.MT.network;

import android.util.Log;

import java.io.IOException;
import java.util.concurrent.Semaphore;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Cookie;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * 阿里云 WAF acw_sc__v2 JS 挑战自动求解拦截器（应用层拦截器）。
 *
 * 网站开启反爬盾后，所有请求先返回一个约 4KB 的混淆 JS 挑战页，
 * 浏览器执行 JS 算出 acw_sc__v2 cookie 后重载才能拿到真实页面。
 * 这里用纯 Java 复现该算法（unsbox + hexXor）：检测到挑战页时
 * 计算 cookie 写入 HttpClient 的 CookieJar，并重放原请求。
 *
 * 注意：必须注册为应用层拦截器（addInterceptor）。
 * 网络拦截器拿到的是未解压的 gzip 原始流，无法检测挑战文本。
 */
public class AcwChallengeInterceptor implements Interceptor {

    private static final String TAG = "AcwChallenge";
    private static final Pattern ARG1_PATTERN = Pattern.compile("var arg1='([0-9a-fA-F]+)'");
    private static final String COOKIE_NAME = "acw_sc__v2";

    /** 挑战 JS 中固定的置换表 */
    private static final int[] BOX = {
            0xf, 0x23, 0x1d, 0x18, 0x21, 0x10, 0x1, 0x26, 0xa, 0x9,
            0x13, 0x1f, 0x28, 0x1b, 0x16, 0x17, 0x19, 0xd, 0x6, 0xb,
            0x27, 0x12, 0x14, 0x8, 0xe, 0x15, 0x20, 0x1a, 0x2, 0x1e,
            0x7, 0x4, 0x11, 0x5, 0x3, 0x1c, 0x22, 0x25, 0xc, 0x24
    };

    /** 挑战 JS 中固定的异或密钥 */
    private static final String HEX_KEY = "3000176000856006061501533003690027800375";

    /** 最近一次求解出的 cookie 值（供 WebView 同步等场景使用） */
    private static volatile String solvedCookie = null;

    /** 热请求（acw_sc__v2 已缓存）允许并发，上限 2（实测 3 并发带正确 cookie 全 200，
     *  但持续 3 并发高频刷新容易触发 WAF 全局限流，降到 2 更安全）。 */
    private static final Semaphore WARM_PERMITS = new Semaphore(2);
    /** 冷启动（无 acw_sc__v2）的挑战求解独占锁：同一时刻只有一个请求获取挑战并求解，
     *  避免并发挑战响应互相覆盖 acw_tc 导致 cookie 不配对。 */
    private static final Semaphore COLD_LOCK = new Semaphore(1);
    /** 冷路径两次请求（挑战+重试）之间的最小间隔，防止纯速率触发限流 */
    private static final long COLD_GAP_MS = 500;
    private static volatile long lastColdReqTime = 0L;
    /** 命中 403 后的退避截止时间，期间后续请求排队等待，避免反复重试延长封禁 */
    private static volatile long penaltyUntil = 0L;

    /** ★ 全局防封禁节流：所有 bbs.binmt.cc 请求（热/冷路径统一）的最小间隔。
     *  刷帖子场景（列表→点开→返回→再点）很容易在几秒内发出 5-10 个请求，
     *  即使并发被限制为 2，无间隔的持续请求仍会触发阿里云 WAF 限流。
     *  这里强制相邻请求至少间隔 MIN_GAP_MS + [0, JITTER_MS) 随机抖动，
     *  模拟人类浏览节奏（固定间隔反而容易被识别为机器）。 */
    private static final long MIN_GAP_MS = 300;
    private static final long JITTER_MS = 150;
    /** 全局下一次请求的时间槽（AtomicLong 保证并发请求按时间槽排队，天然串行化突发） */
    private static final java.util.concurrent.atomic.AtomicLong nextRequestSlot = new java.util.concurrent.atomic.AtomicLong(0L);

    /** ★ 403 动态指数退避：连续 403 每次翻倍，封顶 10 分钟。
     *  阿里云 WAF IP 封禁窗口通常 5-30 分钟，短退避（3-60秒）等于退避刚结束就继续撞封禁。
     *  15s→30s→60s→120s→240s→480s→600s（封顶），给 IP 足够时间解封。 */
    private static final long PENALTY_BASE_MS = 15_000L;
    private static final long PENALTY_CAP_MS = 600_000L;
    /** 连续 403 计数（成功后重置 0） */
    private static volatile int consecutive403 = 0;

    /** 全局最小间隔排队：每个请求抢占一个递增的时间槽，并发突发自动变成间隔 300ms+ 的串行队列 */
    private static void waitGlobalGap() {
        long now = System.currentTimeMillis();
        long jitter = (long) (Math.random() * JITTER_MS);
        long slot = nextRequestSlot.getAndSet(now + MIN_GAP_MS + jitter);
        long wait = slot - now;
        if (wait > 0) {
            try { Thread.sleep(wait); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    /** 记录一次 403：动态退避，连续次数越多退避越长 */
    private static void record403() {
        int n = ++consecutive403;
        long backoff = PENALTY_BASE_MS;
        for (int i = 1; i < n; i++) {
            backoff = Math.min(backoff * 2, PENALTY_CAP_MS);
        }
        penaltyUntil = System.currentTimeMillis() + backoff;
    }

    /** 记录一次成功响应：重置连续 403 计数，让退避恢复基础值 */
    private static void recordSuccess() {
        consecutive403 = 0;
    }

    public static String getSolvedCookie() {
        return solvedCookie;
    }

    /** 退避检查：处于 403 退避期则快速失败（抛异常），不 sleep 等待。
     *  sleep 等待会让 UI 卡死（最长 10 分钟），快速失败让上层立即显示"访问频繁"。 */
    private static void waitPenalty() throws IOException {
        long remaining = penaltyUntil - System.currentTimeMillis();
        if (remaining > 0) {
            throw new IOException("访问过于频繁，IP 被临时限制，请约 "
                    + (remaining / 1000) + " 秒后再试");
        }
    }

    /** 冷路径节流：最小间隔后执行请求 */
    private Response coldProceed(Chain chain, Request request) throws IOException {
        waitPenalty();
        long gap = System.currentTimeMillis() - lastColdReqTime;
        if (gap < COLD_GAP_MS) {
            try { Thread.sleep(COLD_GAP_MS - gap); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        lastColdReqTime = System.currentTimeMillis();
        return chain.proceed(request);
    }

    private static void clearWafCookies(HttpClient hc, String host) {
        hc.removeRuntimeCookie(host, COOKIE_NAME);
        hc.removeRuntimeCookie(host, "acw_tc");
        hc.removeRuntimeCookie(host, "cdn_sec_tc");
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        String host = request.url().host();
        if (!host.contains("binmt.cc") && !host.contains("mt2.cn")) {
            return chain.proceed(request);
        }

        // ★ 全局防封禁节流（热/冷路径统一）：
        //   1) 退避等待：正处于 403 退避期则排队等退避结束，避免反复撞限流尾巴
        //   2) 最小间隔排队：强制相邻请求间隔 MIN_GAP_MS + 随机抖动，模拟人类浏览节奏
        waitPenalty();
        waitGlobalGap();

        HttpClient hc = HttpClient.getInstance();
        boolean hasCookie = hc.getCookieValue(host, COOKIE_NAME) != null;

        // 热路径：acw_sc__v2 已缓存 → 并发执行（上限 2）
        // 冷路径：无 acw_sc__v2 → 独占求解，避免并发挑战覆盖 acw_tc
        if (hasCookie) {
            return interceptWarm(chain, request, host, hc);
        } else {
            return interceptCold(chain, request, host, hc);
        }
    }

    /** 热路径：带缓存 cookie 并发请求 */
    private Response interceptWarm(Chain chain, Request request, String host, HttpClient hc) throws IOException {
        try {
            WARM_PERMITS.acquire();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return chain.proceed(request);
        }
        boolean released = false;
        try {
            Response response = chain.proceed(request);
            if (response.code() == 403) {
                record403();
                clearWafCookies(hc, host);
                return response;
            }
            if (response.code() < 500) {
                recordSuccess();
            }
            // cookie 可能中途过期，收到挑战页 → 转独占冷路径重新求解
            if (isChallengeResponse(response)) {
                WARM_PERMITS.release();
                released = true;
                return solveWithLock(chain, request, host, hc, response);
            }
            return response;
        } finally {
            if (!released) WARM_PERMITS.release();
        }
    }

    /** 冷路径：独占求解挑战 */
    private Response interceptCold(Chain chain, Request request, String host, HttpClient hc) throws IOException {
        try {
            COLD_LOCK.acquire();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return chain.proceed(request);
        }
        try {
            // double-check：等待期间其他线程可能已求解
            if (hc.getCookieValue(host, COOKIE_NAME) != null) {
                // cookie 已就绪，直接并发执行
                return interceptWarm(chain, request, host, hc);
            }
            Response response = coldProceed(chain, request);
            if (response.code() == 403) {
                record403();
                clearWafCookies(hc, host);
                return response;
            }
            if (response.code() < 500) {
                recordSuccess();
            }
            if (!isChallengeResponse(response)) {
                return response;
            }
            // 持有 COLD_LOCK，直接求解
            return solveInternal(chain, request, host, hc, response);
        } finally {
            COLD_LOCK.release();
        }
    }

    /** 热路径发现挑战后：获取独占锁，double-check cookie 是否已被其他线程求解，再决定求解或直接重试 */
    private Response solveWithLock(Chain chain, Request request, String host, HttpClient hc,
                                   Response challengeResponse) throws IOException {
        try {
            COLD_LOCK.acquire();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            challengeResponse.close();
            return chain.proceed(request);
        }
        try {
            // double-check：等待锁期间其他线程可能已求解
            if (hc.getCookieValue(host, COOKIE_NAME) != null) {
                challengeResponse.close();
                Response resp = coldProceed(chain, request.newBuilder().build());
                if (resp.code() == 403) {
                    record403();
                    clearWafCookies(hc, host);
                } else if (resp.code() < 500) {
                    recordSuccess();
                }
                return resp;
            }
            return solveInternal(chain, request, host, hc, challengeResponse);
        } finally {
            COLD_LOCK.release();
        }
    }

    /** 判断响应是否为 WAF 挑战页（peekBody 不消费原始流） */
    private boolean isChallengeResponse(Response response) throws IOException {
        ResponseBody body = response.body();
        MediaType ct = body != null ? body.contentType() : null;
        if (body == null || ct == null || !"text".equals(ct.type())) {
            return false;
        }
        try {
            return response.peekBody(8192).string().contains(COOKIE_NAME);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 独占求解挑战并重试（调用方已持有 COLD_LOCK）。
     * challengeResponse 的 body 尚未被消费（仅 peek 过），这里 string() 消费。
     */
    private Response solveInternal(Chain chain, Request request, String host, HttpClient hc,
                                   Response challengeResponse) throws IOException {
        ResponseBody body = challengeResponse.body();
        MediaType ct = body != null ? body.contentType() : null;
        if (body == null || ct == null || !"text".equals(ct.type())) {
            return challengeResponse;
        }
        String html;
        try {
            html = body.string();
        } catch (Exception e) {
            return challengeResponse;
        }
        if (!html.contains(COOKIE_NAME)) {
            return rebuild(challengeResponse, ct, html);
        }
        Matcher m = ARG1_PATTERN.matcher(html);
        if (!m.find()) {
            return rebuild(challengeResponse, ct, html);
        }
        String cookieValue;
        try {
            cookieValue = solve(m.group(1));
        } catch (Exception e) {
            Log.w(TAG, "solve failed", e);
            return rebuild(challengeResponse, ct, html);
        }
        solvedCookie = cookieValue;
        Log.i(TAG, "Solved acw_sc__v2 for " + host + ", retrying request");
        hc.addRuntimeCookie(host, COOKIE_NAME, cookieValue,
                System.currentTimeMillis() + 50L * 60 * 1000);
        challengeResponse.close();
        // 重放（独占，间隔节流）
        Response retried = coldProceed(chain, request.newBuilder().build());
        if (retried.code() == 403) {
            record403();
            clearWafCookies(hc, host);
        } else if (retried.code() < 500) {
            recordSuccess();
        }
        Log.i(TAG, "Retry result: code=" + retried.code()
                + " tengine=" + retried.header("x-tengine-error")
                + " jar_acwSc=" + hc.getCookieValue(host, COOKIE_NAME)
                + " jar_acwTc=" + hc.getCookieValue(host, "acw_tc"));
        return retried;
    }

    /** 已读取 body 后重建响应，避免下游重复消费流 */
    private static Response rebuild(Response response, MediaType contentType, String html) {
        return response.newBuilder()
                .body(ResponseBody.create(contentType, html))
                .build();
    }

    /**
     * 复现挑战 JS 的算法：
     * 1) unsbox：按固定置换表重排 arg1 的字符
     * 2) hexXor：与固定密钥按字节异或
     */
    static String solve(String arg1) {
        char[] q = new char[BOX.length];
        for (int x = 0; x < arg1.length(); x++) {
            char ch = arg1.charAt(x);
            for (int z = 0; z < BOX.length; z++) {
                if (BOX[z] == x + 1) {
                    q[z] = ch;
                }
            }
        }
        String u = new String(q);
        StringBuilder v = new StringBuilder();
        int len = Math.min(u.length(), HEX_KEY.length());
        for (int i = 0; i + 2 <= len; i += 2) {
            int a = Integer.parseInt(u.substring(i, i + 2), 16)
                    ^ Integer.parseInt(HEX_KEY.substring(i, i + 2), 16);
            v.append(String.format("%02x", a));
        }
        return v.toString();
    }
}
