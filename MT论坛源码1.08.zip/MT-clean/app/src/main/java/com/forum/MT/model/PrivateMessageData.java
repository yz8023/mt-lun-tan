package com.forum.MT.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 私信数据 - 对应官方APK的PrivateMessageData
 * 私信列表（会话列表）
 */
public class PrivateMessageData {
    private List<Message> messages = new ArrayList<>();
    private boolean isLoading;
    private String error;
    private boolean hasMore = true;

    public PrivateMessageData() {}

    public PrivateMessageData(List<Message> messages, boolean isLoading, String error) {
        this.messages = messages != null ? messages : new ArrayList<>();
        this.isLoading = isLoading;
        this.error = error;
    }

    public List<Message> getMessages() { return messages; }
    public void setMessages(List<Message> messages) { this.messages = messages != null ? messages : new ArrayList<>(); }

    public boolean isLoading() { return isLoading; }
    public void setLoading(boolean loading) { isLoading = loading; }

    public String getError() { return error; }
    public void setError(String error) { this.error = error; }

    public boolean hasMore() { return hasMore; }
    public void setHasMore(boolean hasMore) { this.hasMore = hasMore; }
}