package com.forum.MT.ui.space;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.forum.MT.R;
import com.forum.MT.databinding.ActivityFunctionSettingsBinding;
import com.forum.MT.session.AutoSignInManager;
import com.forum.MT.session.FollowerLevelSettingsManager;
import com.forum.MT.session.SoundSettingsManager;
import com.forum.MT.session.UnreadHighlightManager;
import com.forum.MT.session.SameThreadReadManager;
import com.forum.MT.ui.BaseActivity;
import com.forum.MT.ui.widget.AutoLoadMoreManager;
import com.forum.MT.ui.widget.ChatPersistenceManager;
import com.forum.MT.ui.widget.HighRefreshRateManager;
import com.forum.MT.ui.widget.LoadAllRepliesManager;
import com.forum.MT.ui.widget.NestedScrollRepliesManager;
import com.forum.MT.ui.widget.RainbowBorderHelper;
import com.forum.MT.ui.widget.RecycleFilterManager;
import com.forum.MT.ui.widget.ReplyBlacklistManager;
import com.forum.MT.ui.widget.SwipeCommentManager;

public class FunctionSettingsActivity extends BaseActivity {
    private ActivityFunctionSettingsBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFunctionSettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        RainbowBorderHelper.applyToCardViews(binding.getRoot(), this);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        binding.toolbar.setNavigationIcon(null);

        binding.switchAutoSignIn.setChecked(AutoSignInManager.isEnabled(this));
        binding.switchAutoSignIn.setOnCheckedChangeListener((v, checked) -> AutoSignInManager.setEnabled(this, checked));
        binding.switchFollowerLevel.setChecked(FollowerLevelSettingsManager.isEnabled(this));
        binding.switchFollowerLevel.setOnCheckedChangeListener((v, checked) -> FollowerLevelSettingsManager.setEnabled(this, checked));
        binding.switchReplyOrder.setChecked(getSharedPreferences("reply_order_pref", MODE_PRIVATE).getBoolean("replies_descending_default", true));
        binding.switchReplyOrder.setOnCheckedChangeListener((v, checked) -> getSharedPreferences("reply_order_pref", MODE_PRIVATE).edit().putBoolean("replies_descending_default", checked).apply());
        binding.switchSound.setChecked(SoundSettingsManager.isSoundEnabled(this));
        binding.switchSound.setOnCheckedChangeListener((v, checked) -> SoundSettingsManager.setSoundEnabled(this, checked));
        binding.switchUnreadHighlight.setChecked(UnreadHighlightManager.isEnabled(this));
        binding.switchUnreadHighlight.setOnCheckedChangeListener((v, checked) -> UnreadHighlightManager.setEnabled(this, checked));
        binding.switchSameThreadRead.setChecked(SameThreadReadManager.isEnabled(this));
        binding.switchSameThreadRead.setOnCheckedChangeListener((v, checked) -> SameThreadReadManager.setEnabled(this, checked));
        binding.switchChatPersistence.setChecked(ChatPersistenceManager.isEnabled(this));
        binding.switchChatPersistence.setOnCheckedChangeListener((v, checked) -> ChatPersistenceManager.setEnabled(this, checked));
        binding.switchHomeTabSwipe.setChecked(com.forum.MT.ui.widget.HomeTabSwipeManager.isSwipeEnabled());
        binding.switchHomeTabSwipe.setOnCheckedChangeListener((v, checked) -> com.forum.MT.ui.widget.HomeTabSwipeManager.setSwipeEnabled(this, checked));
        updateHighRefreshRateInfo();
        binding.switchHighRefresh.setChecked(HighRefreshRateManager.isEnabled(this));
        binding.switchHighRefresh.setOnCheckedChangeListener((v, checked) -> { HighRefreshRateManager.setEnabled(this, checked); HighRefreshRateManager.apply(this); });
        binding.switchHideRecycled.setChecked(RecycleFilterManager.isEnabled(this));
        binding.switchHideRecycled.setOnCheckedChangeListener((v, checked) -> RecycleFilterManager.setEnabled(this, checked));
        binding.switchHideClosed.setChecked(com.forum.MT.ui.widget.ClosedFilterManager.isEnabled(this));
        binding.switchHideClosed.setOnCheckedChangeListener((v, checked) -> com.forum.MT.ui.widget.ClosedFilterManager.setEnabled(this, checked));
        binding.switchLoadAllReplies.setChecked(LoadAllRepliesManager.isEnabled(this));
        binding.switchLoadAllReplies.setOnCheckedChangeListener((v, checked) -> LoadAllRepliesManager.setEnabled(this, checked));
        binding.switchNestedScrollReplies.setChecked(NestedScrollRepliesManager.isEnabled(this));
        binding.switchNestedScrollReplies.setOnCheckedChangeListener((v, checked) -> { NestedScrollRepliesManager.setEnabled(this, checked); if (checked && binding.switchSwipeComment.isChecked()) binding.switchSwipeComment.setChecked(false); });
        binding.switchSwipeComment.setChecked(SwipeCommentManager.isEnabled(this));
        binding.switchSwipeComment.setOnCheckedChangeListener((v, checked) -> { SwipeCommentManager.setEnabled(this, checked); if (checked && binding.switchNestedScrollReplies.isChecked()) binding.switchNestedScrollReplies.setChecked(false); });
        binding.switchAutoLoadMore.setChecked(AutoLoadMoreManager.isEnabled(this));
        binding.switchAutoLoadMore.setOnCheckedChangeListener((v, checked) -> AutoLoadMoreManager.setEnabled(this, checked));
        ReplyBlacklistManager blacklistMgr = ReplyBlacklistManager.getInstance(this);
        binding.spinnerBlacklistMatchMode.setSelection(blacklistMgr.getMatchMode());
        binding.spinnerBlacklistMatchMode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int position, long id) { blacklistMgr.setMatchMode(position); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
        binding.switchAiReplyFilter.setChecked(com.forum.MT.ui.widget.AiReplyFilterManager.isEnabled(this));
        binding.switchAiReplyFilter.setOnCheckedChangeListener((v, checked) -> com.forum.MT.ui.widget.AiReplyFilterManager.setEnabled(this, checked));
    }

    @Override protected void onResume() {
        super.onResume();
        HighRefreshRateManager.apply(this);
        if (binding != null) updateHighRefreshRateInfo();
    }

    private void updateHighRefreshRateInfo() {
        float highest = HighRefreshRateManager.getHighestRefreshRate(this);
        if (highest > 0f) {
            binding.tvHighRefreshInfo.setText(highest == Math.round(highest)
                    ? String.format(java.util.Locale.US, "设备最高刷新率：%dHz", Math.round(highest))
                    : String.format(java.util.Locale.US, "设备最高刷新率：%.1fHz", highest));
        } else {
            binding.tvHighRefreshInfo.setText("暂无法检测设备刷新率");
        }
    }
}
