package com.forum.MT.ui.widget;

/**
 * 主题配色全局版本号管理器。
 * <p>
 * 每次主题设置页保存任何配色（代码块、引用、表格、行内代码等）都会 {@link #bump()} 递增，
 * 详情页等已渲染页面在 onResume 时对比版本号，若变化则自动重渲染正文区，
 * 从而让新配色无需重新进入页面即可生效。
 */
public final class ThemeVersionManager {

    private static volatile int sVersion = 0;

    private ThemeVersionManager() {}

    public static void bump() {
        sVersion++;
    }

    public static int getVersion() {
        return sVersion;
    }

    /**
     * 计算当前所有相关配色参数的指纹，供 ThreadDetailActivity 在 onResume 时对比。
     * 包含代码块、引用、表格、行内代码等与渲染相关的颜色。
     */
    public static int fingerprint(android.content.Context context) {
        int h = 0;
        // 代码块
        h = h * 31 + CodeBlockColorManager.getBgColor(context);
        h = h * 31 + CodeBlockColorManager.getTextColor(context);
        h = h * 31 + CodeBlockColorManager.getBorderColor(context);
        h = h * 31 + CodeBlockColorManager.getTitleBgColor(context);
        h = h * 31 + CodeBlockColorManager.getTitleTextColor(context);
        // 引用卡
        h = h * 31 + QuoteBgColorManager.getBgColor(context);
        h = h * 31 + QuoteBgColorManager.getBorderColor(context);
        h = h * 31 + QuoteBgColorManager.getTitleColor(context);
        h = h * 31 + QuoteBgColorManager.getTextColor(context);
        // 表格
        h = h * 31 + TableColorManager.getBorderColor(context);
        h = h * 31 + TableColorManager.getHeaderBg(context);
        h = h * 31 + TableColorManager.getCellBg(context);
        h = h * 31 + TableColorManager.getTextColor(context);
        // 行内代码
        h = h * 31 + InlineHighlightManager.getBgColor(context);
        h = h * 31 + InlineHighlightManager.getTextColor(context);
        return h;
    }
}