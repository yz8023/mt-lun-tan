package com.forum.MT.network;

import android.text.Html;
import android.text.TextUtils;

import com.forum.MT.model.PostEditForm;
import com.forum.MT.model.PostEditResult;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Discuz! 编辑帖子/评论的表单解析与结果解析。
 *
 * <p>编辑接口与发帖接口共用 {@code form#postform}，但多了三个必须原样回传的字段：
 * {@code posttime}、{@code delete}、以及已有附件的 {@code attachnew[aid][description]}。
 * 漏掉 posttime 会被判为过期请求，漏掉附件绑定会导致保存后原帖附件被清空。
 */
public final class PostEditParser {

    private PostEditParser() {}

    /**
     * 解析编辑页 HTML。
     *
     * @param html     编辑页响应
     * @param fallback 请求时已知的 fid/tid/pid/page，用于页面未输出对应 input 时兜底
     */
    public static PostEditForm parseEditForm(String html, PostEditForm fallback) {
        PostEditForm form = new PostEditForm();
        if (fallback != null) {
            form.setFid(nullToEmpty(fallback.getFid()));
            form.setTid(nullToEmpty(fallback.getTid()));
            form.setPid(nullToEmpty(fallback.getPid()));
            form.setPage(Math.max(1, fallback.getPage()));
        }
        if (TextUtils.isEmpty(html)) return form;

        Document doc = Jsoup.parse(html);
        Element postForm = doc.selectFirst("form#postform");
        if (postForm == null) postForm = doc.selectFirst("form[action*=mod=post]");

        form.setFormhash(valueOf(doc, postForm, "formhash"));
        form.setPosttime(valueOf(doc, postForm, "posttime"));

        String fid = valueOf(doc, postForm, "fid");
        if (!fid.isEmpty()) form.setFid(fid);
        String tid = valueOf(doc, postForm, "tid");
        if (!tid.isEmpty()) form.setTid(tid);
        String pid = valueOf(doc, postForm, "pid");
        if (!pid.isEmpty()) form.setPid(pid);
        String page = valueOf(doc, postForm, "page");
        if (page.matches("\\d+")) form.setPage(Math.max(1, Integer.parseInt(page)));

        // 删除开关：Discuz 编辑页的 delete 字段在有删除权限时是
        // <input type="checkbox" name="delete" value="1">，无权限时不输出。
        // 这里绝不能直接取它的 value 当提交值——那会是 "1"，等于每次普通编辑
        // 都带上"删除本帖"。因此：checkbox 一律按未勾选（"0"）提交，
        // 只有 hidden 字段才沿用页面给的原值。
        Element deleteInput = firstIn(doc, postForm, "input[name=delete]");
        boolean deleteIsCheckbox = deleteInput != null
                && "checkbox".equalsIgnoreCase(deleteInput.attr("type"));
        form.setDeleteSupported(deleteIsCheckbox);
        if (deleteInput == null || deleteIsCheckbox) {
            form.setDeleteValue("0");
        } else {
            String deleteValue = deleteInput.attr("value").trim();
            form.setDeleteValue(deleteValue.isEmpty() ? "0" : deleteValue);
        }
        String allowNotice = valueOf(doc, postForm, "allownoticeauthor");
        form.setAllowNoticeAuthor(allowNotice.isEmpty() ? "1" : allowNotice);
        String useSig = valueOf(doc, postForm, "usesig");
        form.setUseSig(useSig.isEmpty() ? "1" : useSig);

        // 主题属性开关：只有编辑第一楼且论坛开放该权限时，编辑页才会输出这两个
        // checkbox。页面没输出就不能提交对应字段，否则会被当成非法请求。
        Element hiddenReplies = firstIn(doc, postForm, "input[name=hiddenreplies]");
        form.setHiddenRepliesSupported(hiddenReplies != null);
        form.setHiddenReplies(isChecked(hiddenReplies));
        Element orderType = firstIn(doc, postForm, "input[name=ordertype]");
        form.setOrderTypeSupported(orderType != null);
        form.setOrderReverse(isChecked(orderType));

        // 标题：Discuz 编辑评论时同样会输出 input[name=subject]（评论标题，多为空），
        // 因此这里只记录原值，firstPost 仅作参考，最终由调用方的入口语义决定。
        Element subjectInput = firstIn(doc, postForm, "input[name=subject]");
        form.setSubject(subjectInput == null ? "" : unescape(subjectInput.attr("value")));
        form.setFirstPost(subjectInput != null);

        // 正文：必须取 textarea 的原始文本（BBCode 源码），不能用 html() 或 text()，
        // 前者会带上实体转义，后者会丢换行。
        Element messageArea = firstIn(doc, postForm, "textarea[name=message]");
        if (messageArea != null) {
            form.setMessage(messageArea.wholeText());
        }

        form.setUploadUid(extractUploadValue(html, "uid"));
        form.setUploadHash(extractUploadValue(html, "hash"));
        form.setAttachmentAids(extractAttachmentAids(doc));
        return form;
    }

    /**
     * 编辑器是否真实可用。
     *
     * <p>Discuz 在 fid/page 定位不准时会返回一个只有 formhash 的空表单壳，
     * 若只检查 formhash 就会给用户一个空编辑器并在保存时清空原帖。
     * 因此必须同时确认正文 textarea 存在且原文非空。
     */
    public static boolean hasRealEditor(PostEditForm form) {
        return form != null && form.isUsable() && !TextUtils.isEmpty(form.getMessage().trim());
    }

    /** 从编辑页/提交响应里提取可直接展示的提示文案。 */
    public static String extractMessage(String html) {
        if (TextUtils.isEmpty(html)) return "";
        String raw = unwrapCdata(html);
        Document doc = Jsoup.parse(raw);
        for (String selector : new String[]{
                "div.alert_error", "div.alert_right", "div.alert_info",
                ".alert_error", ".alert_right", "#messagetext p", "#messagetext",
                "div.f_c", "div.c"}) {
            Element el = doc.selectFirst(selector);
            if (el == null) continue;
            String text = el.text().trim();
            if (!text.isEmpty()) return text;
        }
        String text = doc.text().trim();
        return text.length() > 200 ? text.substring(0, 200) : text;
    }

    /** 解析编辑提交响应。 */
    public static PostEditResult parseEditResult(String html) {
        if (TextUtils.isEmpty(html)) {
            return PostEditResult.fail("服务器未返回结果");
        }
        String raw = unwrapCdata(html);

        // 明确失败信号优先判定，避免"编辑成功"字样出现在页面模板其它位置时误判。
        if (containsAny(raw, "formhash 错误", "formhash错误", "请先登录", "您没有权限",
                "没有权限", "非法操作", "抱歉，您无权", "编辑失败", "超时",
                "帖子编辑失败")) {
            String message = extractMessage(raw);
            return PostEditResult.fail(TextUtils.isEmpty(message) ? "编辑失败" : message);
        }
        if (containsAny(raw, "帖子编辑成功", "编辑成功", "修改成功", "操作成功")) {
            return PostEditResult.ok("编辑成功");
        }
        // 部分模板成功后直接跳回帖子页，只输出 location.href / succeedhandle。
        if (raw.contains("succeedhandle_") || Pattern
                .compile("location\\.href\\s*=\\s*['\"][^'\"]*(?:thread-|mod=viewthread)")
                .matcher(raw).find()) {
            return PostEditResult.ok("编辑成功");
        }
        String message = extractMessage(raw);
        return PostEditResult.fail(TextUtils.isEmpty(message) ? "编辑失败" : message);
    }

    /**
     * 解析删除提交响应。
     *
     * <p>与编辑成功的判据分开：删除成功的文案是"删除成功""已删除"，
     * 而 Discuz 删除后往往直接跳回版块页（而不是帖子页），
     * 若复用 parseEditResult 的 viewthread 跳转判据会漏判。
     */
    public static PostEditResult parseDeleteResult(String html) {
        if (TextUtils.isEmpty(html)) {
            return PostEditResult.fail("服务器未返回结果");
        }
        String raw = unwrapCdata(html);

        if (containsAny(raw, "formhash 错误", "formhash错误", "请先登录", "您没有权限",
                "没有权限", "非法操作", "抱歉，您无权", "无权删除", "删除失败",
                "超时", "不能删除")) {
            String message = extractMessage(raw);
            return PostEditResult.fail(TextUtils.isEmpty(message) ? "删除失败" : message);
        }
        if (containsAny(raw, "删除成功", "已删除", "操作成功", "帖子删除成功")) {
            return PostEditResult.ok("删除成功");
        }
        // 删除后常见跳转目标是版块页或首页，不是帖子页。
        if (raw.contains("succeedhandle_") || Pattern
                .compile("location\\.href\\s*=\\s*['\"][^'\"]*(?:forum-|mod=forumdisplay|forum\\.php)")
                .matcher(raw).find()) {
            return PostEditResult.ok("删除成功");
        }
        String message = extractMessage(raw);
        return PostEditResult.fail(TextUtils.isEmpty(message) ? "删除失败" : message);
    }

    // ==================== 内部工具 ====================

    private static String valueOf(Document doc, Element form, String name) {
        Element el = firstIn(doc, form, "input[name=" + name + "]");
        if (el == null) return "";
        return el.attr("value").trim();
    }

    /** checkbox 是否已勾选：Discuz 用 checked 属性回显当前状态。 */
    private static boolean isChecked(Element el) {
        return el != null && (el.hasAttr("checked")
                || "checked".equalsIgnoreCase(el.attr("checked")));
    }

    /**
     * 优先在 form 内查找；移动模板偶尔会改 form 包裹层导致字段落在 form 外，
     * 此时回落到整页查找。
     */
    private static Element firstIn(Document doc, Element form, String selector) {
        if (form != null) {
            Element el = form.selectFirst(selector);
            if (el != null) return el;
        }
        return doc.selectFirst(selector);
    }

    private static List<String> extractAttachmentAids(Document doc) {
        Set<String> aids = new LinkedHashSet<>();
        Pattern p = Pattern.compile(
                "^attachnew\\[(\\d+)\\]\\[(?:description|readperm|price)\\]$",
                Pattern.CASE_INSENSITIVE);
        for (Element input : doc.select("input[name]")) {
            Matcher m = p.matcher(input.attr("name"));
            if (m.matches()) aids.add(m.group(1));
        }
        // 有些模板把已有附件放在 attachlist 的 delete 勾选框上。
        Pattern del = Pattern.compile("^attachdel\\[\\]|^attachupdate\\[(\\d+)\\]",
                Pattern.CASE_INSENSITIVE);
        for (Element input : doc.select("input[name^=attachupdate]")) {
            Matcher m = del.matcher(input.attr("name"));
            if (m.find() && m.group(1) != null) aids.add(m.group(1));
        }
        return new ArrayList<>(aids);
    }

    /** 上传凭证在 JS 的 uploadformdata 里，不是普通 input，必须单独抓。 */
    private static String extractUploadValue(String html, String key) {
        String block = "";
        Matcher blockM = Pattern.compile("uploadformdata\\s*:\\s*\\{([^}]*)\\}",
                Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(html);
        if (blockM.find()) block = blockM.group(1);

        if (!block.isEmpty()) {
            Matcher m = Pattern.compile("['\"]?" + Pattern.quote(key)
                    + "['\"]?\\s*:\\s*['\"]?([A-Za-z0-9]+)['\"]?",
                    Pattern.CASE_INSENSITIVE).matcher(block);
            if (m.find()) return m.group(1);
        }

        if ("uid".equals(key)) {
            Matcher m = Pattern.compile(
                    "(?:var\\s+|\\b)discuz_uid\\s*(?:=|:)\\s*['\"]([1-9]\\d*)['\"]",
                    Pattern.CASE_INSENSITIVE).matcher(html);
            if (m.find()) return m.group(1);
        }
        if ("hash".equals(key)) {
            Matcher m = Pattern.compile(
                    "<input[^>]+name\\s*=\\s*['\"]hash['\"][^>]+value\\s*=\\s*['\"]([^'\"]+)['\"]",
                    Pattern.CASE_INSENSITIVE).matcher(html);
            if (m.find()) return m.group(1);
            m = Pattern.compile("(?:var\\s+|\\b)hash\\s*(?:=|:)\\s*['\"]([A-Za-z0-9]+)['\"]",
                    Pattern.CASE_INSENSITIVE).matcher(html);
            if (m.find()) return m.group(1);
        }
        return "";
    }

    /** inajax 响应外层是 CDATA，先剥壳再解析。 */
    public static String unwrapCdata(String body) {
        if (TextUtils.isEmpty(body)) return "";
        Matcher m = Pattern.compile("<!\\[CDATA\\[(.*?)\\]\\]>", Pattern.DOTALL).matcher(body);
        if (m.find()) return m.group(1);
        return body;
    }

    private static boolean containsAny(String text, String... keys) {
        if (text == null) return false;
        for (String key : keys) {
            if (text.contains(key)) return true;
        }
        return false;
    }

    private static String unescape(String value) {
        if (TextUtils.isEmpty(value)) return "";
        return Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString();
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }
}
