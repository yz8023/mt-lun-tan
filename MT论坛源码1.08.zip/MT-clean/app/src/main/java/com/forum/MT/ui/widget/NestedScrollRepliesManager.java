package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 管理"回复区独立滚动"的设置。
 * 开启后，回复列表使用固定高度 + 嵌套滚动，只测量可见项，
 * 避免在 NestedScrollView 内 wrap_content 测量全部子项导致 ANR。
 * 关闭后，回复列表使用 wrap_content，所有回复随页面整体滚动。
 */
public class NestedScrollRepliesManager {
    private static final String PREF_NAME = "nested_scroll_replies_pref";
    private static final String KEY_ENABLED = "enabled";

    /**
     * 默认开启：回复多时自动切换固定高度防止 ANR。
     */
    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
    }
}
