package com.forum.MT.mcp;

import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 本机只读 MCP JSON-RPC 服务。
 *
 * 安全边界：
 * - 只绑定 127.0.0.1，外部设备无法连接
 * - 默认关闭，需用户在设置页手动开启
 * - 无令牌时所有请求返回 403
 * - 工具输出使用字段白名单，绝不返回 cookie、password、token、formhash 等认证字段
 * - 所有工具均为只读，不提供任何写操作
 */
public final class McpServerManager {
    private static final String TAG = "McpServer";
    private static final String PREFS = "mcp_settings";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_TOKEN = "token";
    private static final int PORT = 9797;
    private static final String HOST = "127.0.0.1";

    /** 出站脱敏黑名单：这些 key 的值永远不会出现在 MCP 响应中。 */
    private static final Set<String> SENSITIVE_KEYS = new HashSet<>();
    static {
        SENSITIVE_KEYS.add("cookie");
        SENSITIVE_KEYS.add("cookies");
        SENSITIVE_KEYS.add("cookiestring");
        SENSITIVE_KEYS.add("password");
        SENSITIVE_KEYS.add("token");
        SENSITIVE_KEYS.add("accesstoken");
        SENSITIVE_KEYS.add("refreshtoken");
        SENSITIVE_KEYS.add("secret");
        SENSITIVE_KEYS.add("authorization");
        SENSITIVE_KEYS.add("formhash");
        SENSITIVE_KEYS.add("registerip");
        SENSITIVE_KEYS.add("realname");
        SENSITIVE_KEYS.add("qq");
        SENSITIVE_KEYS.add("sessionkey");
    }

    private static volatile McpServerManager instance;
    private final Context appContext;
    private final ExecutorService clients = Executors.newCachedThreadPool();
    private volatile ServerSocket serverSocket;
    private volatile boolean running;

    private McpServerManager(Context context) {
        appContext = context.getApplicationContext();
    }

    public static McpServerManager getInstance(Context context) {
        if (instance == null) {
            synchronized (McpServerManager.class) {
                if (instance == null) instance = new McpServerManager(context);
            }
        }
        return instance;
    }

    // ==================== 设置页接口 ====================

    public boolean isEnabled() { return prefs().getBoolean(KEY_ENABLED, false); }
    public boolean isRunning() { return running && serverSocket != null && !serverSocket.isClosed(); }
    public String getEndpoint() { return "http://" + HOST + ":" + PORT + "/mcp"; }

    public String getToken() {
        String token = prefs().getString(KEY_TOKEN, "");
        if (token.isEmpty()) {
            token = generateToken();
            prefs().edit().putString(KEY_TOKEN, token).apply();
        }
        return token;
    }

    /** 返回令牌前 8 位 + …，用于设置页展示。 */
    public String getTokenMasked() {
        String t = getToken();
        if (t.length() <= 8) return t;
        return t.substring(0, 8) + "…" + t.substring(t.length() - 4);
    }

    public void setEnabled(boolean enabled) {
        prefs().edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (enabled) start(); else stop();
    }

    public String regenerateToken() {
        String token = generateToken();
        prefs().edit().putString(KEY_TOKEN, token).apply();
        return token;
    }

    /** 复制令牌到剪贴板，供设置页按钮调用。 */
    public void copyTokenToClipboard(Context context) {
        String token = getToken();
        ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("MCP token", token));
        }
    }

    // ==================== 服务生命周期 ====================

    public synchronized void start() {
        if (isRunning()) return;
        if (!isEnabled()) return;
        getToken(); // 确保令牌存在
        running = true;
        clients.submit(() -> {
            try (ServerSocket socket = new ServerSocket(PORT, 20, InetAddress.getByName(HOST))) {
                serverSocket = socket;
                while (running) {
                    try {
                        Socket client = socket.accept();
                        clients.submit(() -> handleClient(client));
                    } catch (IOException ignored) {
                        if (running) break;
                    }
                }
            } catch (IOException ignored) {
            } finally {
                serverSocket = null;
                running = false;
            }
        });
    }

    public synchronized void stop() {
        running = false;
        ServerSocket socket = serverSocket;
        serverSocket = null;
        if (socket != null) { try { socket.close(); } catch (IOException ignored) {} }
    }

    // ==================== HTTP + JSON-RPC 处理 ====================

    private void handleClient(Socket socket) {
        try (Socket client = socket;
             BufferedReader reader = new BufferedReader(new InputStreamReader(
                     client.getInputStream(), StandardCharsets.UTF_8));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                     client.getOutputStream(), StandardCharsets.UTF_8))) {
            String requestLine = reader.readLine();
            if (requestLine == null || !requestLine.startsWith("POST ")) {
                writeHttp(writer, 405, jsonError(null, -32600, "只支持 POST"));
                return;
            }
            String authorization = "";
            int contentLength = 0;
            String line;
            while ((line = reader.readLine()) != null && !line.isEmpty()) {
                int colon = line.indexOf(':');
                if (colon <= 0) continue;
                String name = line.substring(0, colon).trim();
                String value = line.substring(colon + 1).trim();
                if ("authorization".equalsIgnoreCase(name)) authorization = value;
                if ("content-length".equalsIgnoreCase(name)) {
                    try { contentLength = Integer.parseInt(value); } catch (NumberFormatException ignored) {}
                }
            }
            if (!authorized(authorization)) {
                writeHttp(writer, 403, jsonError(null, -32001, "需要有效的本机访问令牌"));
                return;
            }
            if (contentLength <= 0 || contentLength > 1024 * 1024) {
                writeHttp(writer, 400, jsonError(null, -32600, "请求体无效"));
                return;
            }
            char[] chars = new char[contentLength];
            int read = 0;
            while (read < contentLength) {
                int n = reader.read(chars, read, contentLength - read);
                if (n < 0) break;
                read += n;
            }
            JSONObject request = new JSONObject(new String(chars, 0, read));
            Object id = request.has("id") ? request.get("id") : JSONObject.NULL;
            String method = request.optString("method", "");
            JSONObject result;
            if ("initialize".equals(method)) {
                result = new JSONObject()
                        .put("protocolVersion", "2025-03-26")
                        .put("serverInfo", new JSONObject().put("name", "MT论坛 MCP").put("version", "1"))
                        .put("capabilities", new JSONObject().put("tools", new JSONObject()));
            } else if ("tools/list".equals(method)) {
                result = new JSONObject().put("tools", toolList());
            } else if ("tools/call".equals(method)) {
                JSONObject params = request.optJSONObject("params");
                String name = params == null ? "" : params.optString("name", "");
                JSONObject args = params == null ? new JSONObject() : params.optJSONObject("arguments");
                if (args == null) args = new JSONObject();
                result = callTool(name, args);
            } else {
                writeHttp(writer, 200, jsonError(id, -32601, "方法未实现"));
                return;
            }
            writeHttp(writer, 200, new JSONObject().put("jsonrpc", "2.0").put("id", id).put("result", result));
        } catch (Exception ignored) {
        }
    }

    private boolean authorized(String header) {
        String prefix = "Bearer ";
        if (header == null || !header.startsWith(prefix)) return false;
        String presented = header.substring(prefix.length()).trim();
        String expected = prefs().getString(KEY_TOKEN, "");
        return !expected.isEmpty() && constantTimeEquals(presented, expected);
    }

    // ==================== 工具声明 ====================

    private JSONArray toolList() throws Exception {
        JSONArray tools = new JSONArray();
        // help
        tools.put(new JSONObject().put("name", "help")
                .put("description", "返回 MCP 能力清单、工具列表和使用说明")
                .put("inputSchema", new JSONObject().put("type", "object")));
        // get_app_info
        tools.put(new JSONObject().put("name", "get_app_info")
                .put("description", "读取应用基本信息（不含账号和认证数据）")
                .put("inputSchema", new JSONObject().put("type", "object")));
        // get_thread_list
        tools.put(new JSONObject().put("name", "get_thread_list")
                .put("description", "获取导读帖子列表（最新/热门/精华/新帖）")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("view", new JSONObject().put("type", "string")
                                        .put("description", "new/hot/digest/newthread，默认 new")
                                        .put("default", "new"))
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray())));
        // get_thread_detail
        tools.put(new JSONObject().put("name", "get_thread_detail")
                .put("description", "获取帖子详情，包含标题、正文、作者和回复列表")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("tid", new JSONObject().put("type", "string")
                                        .put("description", "帖子 ID"))
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "回复页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray().put("tid"))));
        // get_forum_list
        tools.put(new JSONObject().put("name", "get_forum_list")
                .put("description", "获取论坛版块分类列表")
                .put("inputSchema", new JSONObject().put("type", "object")));
        // get_forum_threads
        tools.put(new JSONObject().put("name", "get_forum_threads")
                .put("description", "获取指定版块的帖子列表")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("fid", new JSONObject().put("type", "string")
                                        .put("description", "版块 ID"))
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray().put("fid"))));
        // get_user_profile
        tools.put(new JSONObject().put("name", "get_user_profile")
                .put("description", "获取用户资料（UID、用户名、等级、积分等公开信息）")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("uid", new JSONObject().put("type", "string")
                                        .put("description", "用户 UID")))
                        .put("required", new JSONArray().put("uid"))));
        // search_threads
        tools.put(new JSONObject().put("name", "search_threads")
                .put("description", "搜索论坛帖子")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("keyword", new JSONObject().put("type", "string")
                                        .put("description", "搜索关键词"))
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray().put("keyword"))));
        // get_ranklist
        tools.put(new JSONObject().put("name", "get_ranklist")
                .put("description", "获取热帖排行榜")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("view", new JSONObject().put("type", "string")
                                        .put("description", "heats/views/replies/favtimes，默认 heats")
                                        .put("default", "heats"))
                                .put("orderby", new JSONObject().put("type", "string")
                                        .put("description", "today/week/month/all，默认 today")
                                        .put("default", "today")))
                        .put("required", new JSONArray())));
        // get_notices
        tools.put(new JSONObject().put("name", "get_notices")
                .put("description", "获取当前用户的通知列表（回复提醒、@我、系统通知等）")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("type", new JSONObject().put("type", "string")
                                        .put("description", "reply/quote/at/post/comment/system，留空返回全部"))
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray())));
        // get_pm_list
        tools.put(new JSONObject().put("name", "get_pm_list")
                .put("description", "获取当前用户的私信列表")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray())));
        // get_favorites
        tools.put(new JSONObject().put("name", "get_favorites")
                .put("description", "获取当前用户的收藏帖子列表")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray())));
        // get_followers
        tools.put(new JSONObject().put("name", "get_followers")
                .put("description", "获取指定用户的粉丝列表")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("uid", new JSONObject().put("type", "string")
                                        .put("description", "用户 UID，留空则查当前用户"))
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray())));
        // get_friends
        tools.put(new JSONObject().put("name", "get_friends")
                .put("description", "获取指定用户的好友列表")
                .put("inputSchema", new JSONObject().put("type", "object")
                        .put("properties", new JSONObject()
                                .put("uid", new JSONObject().put("type", "string")
                                        .put("description", "用户 UID，留空则查当前用户"))
                                .put("page", new JSONObject().put("type", "integer")
                                        .put("description", "页码，默认 1")
                                        .put("default", 1)))
                        .put("required", new JSONArray())));
        return tools;
    }

    // ==================== 工具调用 ====================

    private JSONObject callTool(String name, JSONObject args) throws Exception {
        switch (name) {
            case "help": return toolHelp();
            case "get_app_info": return toolGetAppInfo();
            case "get_thread_list": return toolGetThreadList(args);
            case "get_thread_detail": return toolGetThreadDetail(args);
            case "get_forum_list": return toolGetForumList();
            case "get_forum_threads": return toolGetForumThreads(args);
            case "get_user_profile": return toolGetUserProfile(args);
            case "search_threads": return toolSearchThreads(args);
            case "get_ranklist": return toolGetRanklist(args);
            case "get_notices": return toolGetNotices(args);
            case "get_pm_list": return toolGetPmList(args);
            case "get_favorites": return toolGetFavorites(args);
            case "get_followers": return toolGetFollowers(args);
            case "get_friends": return toolGetFriends(args);
            default:
                throw new IllegalArgumentException("未知工具: " + name);
        }
    }

    // ---- help ----
    private JSONObject toolHelp() throws Exception {
        JSONObject info = new JSONObject()
                .put("service", "MT论坛 MCP 只读本机服务")
                .put("endpoint", getEndpoint())
                .put("auth", "需要 Bearer 令牌")
                .put("security", "Cookie/密码/Token/formhash 永不输出；无写操作")
                .put("tools", new JSONArray()
                        .put("help - 本说明")
                        .put("get_app_info - 应用信息")
                        .put("get_thread_list - 导读帖子列表")
                        .put("get_thread_detail - 帖子详情+回复")
                        .put("get_forum_list - 版块分类列表")
                        .put("get_forum_threads - 版块帖子列表")
                        .put("get_user_profile - 用户资料")
                        .put("search_threads - 搜索帖子")
                        .put("get_ranklist - 热帖排行榜")
                        .put("get_notices - 通知列表")
                        .put("get_pm_list - 私信列表")
                        .put("get_favorites - 收藏列表")
                        .put("get_followers - 粉丝列表")
                        .put("get_friends - 好友列表"));
        return textResult(info);
    }

    // ---- get_app_info ----
    private JSONObject toolGetAppInfo() throws Exception {
        JSONObject info = new JSONObject()
                .put("app", "MT论坛")
                .put("version", "1.07")
                .put("mcp", "只读本机服务")
                .put("security", "认证数据隔离：cookie/password/token/formhash 永不输出");
        return textResult(info);
    }

    // ---- get_thread_list ----
    private JSONObject toolGetThreadList(JSONObject args) throws Exception {
        String view = args.optString("view", "new");
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getGuideUrl(view, page);
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.Thread> threads = com.forum.MT.network.ForumParser.parseThreadList(html);
        return textResult(threadListToJson(threads, view, page));
    }

    // ---- get_thread_detail ----
    private JSONObject toolGetThreadDetail(JSONObject args) throws Exception {
        String tid = args.optString("tid", "");
        if (tid.isEmpty()) throw new IllegalArgumentException("tid 不能为空");
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getThreadDetailUrl(tid, page, null);
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        com.forum.MT.model.PostDetail detail = com.forum.MT.network.ForumParser.parseThreadDetail(html);
        return textResult(postDetailToJson(detail));
    }

    // ---- get_forum_list ----
    private JSONObject toolGetForumList() throws Exception {
        String url = com.forum.MT.network.ForumParser.getBaseDomain() + "forum.php?mobile=2";
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.ForumCategory> cats = com.forum.MT.network.ForumParser.parseForumCategories(html);
        JSONArray arr = new JSONArray();
        for (com.forum.MT.model.ForumCategory cat : cats) {
            JSONObject catJson = new JSONObject().put("category", cat.getName());
            JSONArray forumsArr = new JSONArray();
            if (cat.getForums() != null) {
                for (com.forum.MT.model.ForumCategory.Forum f : cat.getForums()) {
                    JSONObject fJson = new JSONObject()
                            .put("fid", safeStr(f.getFid()))
                            .put("name", safeStr(f.getName()))
                            .put("description", safeStr(f.getDescription()))
                            .put("todayPosts", f.getTodayPosts())
                            .put("totalThreads", f.getTotalThreads());
                    forumsArr.put(fJson);
                }
            }
            catJson.put("forums", forumsArr);
            arr.put(catJson);
        }
        return textResult(new JSONObject().put("categories", arr));
    }

    // ---- get_forum_threads ----
    private JSONObject toolGetForumThreads(JSONObject args) throws Exception {
        String fid = args.optString("fid", "");
        if (fid.isEmpty()) throw new IllegalArgumentException("fid 不能为空");
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getThreadListUrl(fid, page);
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.Thread> threads = com.forum.MT.network.ForumParser.parseForumThreadList(html);
        return textResult(threadListToJson(threads, "fid=" + fid, page));
    }

    // ---- get_user_profile ----
    private JSONObject toolGetUserProfile(JSONObject args) throws Exception {
        String uid = args.optString("uid", "");
        if (uid.isEmpty()) throw new IllegalArgumentException("uid 不能为空");
        String url = com.forum.MT.network.ForumParser.getUserSpaceUrl(uid);
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        com.forum.MT.model.UserProfile profile = com.forum.MT.network.ForumParser.parseUserProfile(html);
        JSONObject p = new JSONObject()
                .put("uid", safeStr(profile.getUid()))
                .put("username", safeStr(profile.getUsername()))
                .put("level", safeStr(profile.getLevel()))
                .put("groupName", safeStr(profile.getGroupName()))
                .put("credits", profile.getCredits())
                .put("gold", profile.getGold())
                .put("threads", profile.getThreads())
                .put("posts", profile.getPosts())
                .put("friends", profile.getFriends())
                .put("followers", profile.getFollowers())
                .put("following", profile.getFollowing())
                .put("views", profile.getViews())
                .put("regDate", safeStr(profile.getRegDate()))
                .put("lastVisit", safeStr(profile.getLastVisit()))
                .put("signature", safeStr(profile.getSignature()))
                .put("online", profile.isOnline());
        return textResult(p);
    }

    // ---- search_threads ----
    private JSONObject toolSearchThreads(JSONObject args) throws Exception {
        String keyword = args.optString("keyword", "");
        if (keyword.isEmpty()) throw new IllegalArgumentException("keyword 不能为空");
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getBaseDomain()
                + "search.php?mod=forum&searchsubmit=yes&srchtxt="
                + java.net.URLEncoder.encode(keyword, "UTF-8")
                + "&page=" + page + "&mobile=2";
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.Thread> threads = com.forum.MT.network.ForumParser.parseSearchResults(html);
        return textResult(threadListToJson(threads, "search:" + keyword, page));
    }

    // ---- get_ranklist ----
    private JSONObject toolGetRanklist(JSONObject args) throws Exception {
        String view = args.optString("view", "heats");
        String orderby = args.optString("orderby", "today");
        String url = com.forum.MT.network.ForumParser.getThreadRanklistUrl(view, orderby);
        String html = com.forum.MT.network.HttpClient.getInstance().getDesktop(url);
        List<com.forum.MT.model.RankThread> ranks = com.forum.MT.network.ForumParser.parseThreadRanklist(html);
        JSONArray arr = new JSONArray();
        for (com.forum.MT.model.RankThread r : ranks) {
            arr.put(new JSONObject()
                    .put("rank", r.getRank())
                    .put("tid", safeStr(r.getTid()))
                    .put("title", safeStr(r.getTitle()))
                    .put("author", safeStr(r.getAuthor()))
                    .put("authorUid", safeStr(r.getAuthorUid()))
                    .put("metric", safeStr(r.getMetricText()))
                    .put("publishTime", safeStr(r.getPublishTime())));
        }
        return textResult(new JSONObject().put("ranklist", arr).put("view", view).put("orderby", orderby));
    }

    // ---- get_notices ----
    private JSONObject toolGetNotices(JSONObject args) throws Exception {
        String type = args.optString("type", "");
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getBaseDomain()
                + "home.php?mod=space&do=notice" + (type.isEmpty() ? "" : "&view=" + type)
                + "&page=" + page + "&mobile=2";
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.NoticeItem> notices = com.forum.MT.network.ForumParser.parseNoticeItems(html);
        JSONArray arr = new JSONArray();
        for (com.forum.MT.model.NoticeItem n : notices) {
            arr.put(new JSONObject()
                    .put("noticeId", safeStr(n.getNoticeId()))
                    .put("username", safeStr(n.getUsername()))
                    .put("uid", safeStr(n.getUid()))
                    .put("content", htmlToText(safeStr(n.getContent())))
                    .put("threadTitle", safeStr(n.getThreadTitle()))
                    .put("time", safeStr(n.getTime()))
                    .put("type", safeStr(n.getType()))
                    .put("unread", n.isBold()));
        }
        return textResult(new JSONObject().put("notices", arr).put("page", page).put("count", notices.size()));
    }

    // ---- get_pm_list ----
    private JSONObject toolGetPmList(JSONObject args) throws Exception {
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getBaseDomain()
                + "home.php?mod=space&do=pm&page=" + page + "&mobile=2";
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.Message> messages = com.forum.MT.network.ForumParser.parsePmList(html);
        return textResult(messageListToJson(messages, "pm", page));
    }

    // ---- get_favorites ----
    private JSONObject toolGetFavorites(JSONObject args) throws Exception {
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getBaseDomain()
                + "home.php?mod=space&do=favorite&type=thread&page=" + page + "&mobile=2";
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.Thread> favorites = com.forum.MT.network.ForumParser.parseFavoriteList(html);
        return textResult(threadListToJson(favorites, "favorites", page));
    }

    // ---- get_followers ----
    private JSONObject toolGetFollowers(JSONObject args) throws Exception {
        String uid = args.optString("uid", "");
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getBaseDomain()
                + "home.php?mod=space" + (uid.isEmpty() ? "" : "&uid=" + uid)
                + "&do=friend&view=follower&page=" + page + "&mobile=2";
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.Friend> followers = com.forum.MT.network.ForumParser.parseFriendList(html);
        return textResult(friendListToJson(followers, "followers", page));
    }

    // ---- get_friends ----
    private JSONObject toolGetFriends(JSONObject args) throws Exception {
        String uid = args.optString("uid", "");
        int page = args.optInt("page", 1);
        if (page < 1) page = 1;
        String url = com.forum.MT.network.ForumParser.getBaseDomain()
                + "home.php?mod=space" + (uid.isEmpty() ? "" : "&uid=" + uid)
                + "&do=friend&page=" + page + "&mobile=2";
        String html = com.forum.MT.network.HttpClient.getInstance().get(url);
        List<com.forum.MT.model.Friend> friends = com.forum.MT.network.ForumParser.parseFriendList(html);
        return textResult(friendListToJson(friends, "friends", page));
    }

    // ==================== 模型 → JSON（字段白名单） ====================

    private JSONObject threadListToJson(List<com.forum.MT.model.Thread> threads, String source, int page) throws Exception {
        JSONArray arr = new JSONArray();
        for (com.forum.MT.model.Thread t : threads) {
            arr.put(new JSONObject()
                    .put("tid", safeStr(t.getTid()))
                    .put("title", safeStr(t.getTitle()))
                    .put("author", safeStr(t.getAuthor()))
                    .put("authorUid", safeStr(t.getAuthorUid()))
                    .put("forumName", safeStr(t.getForumName()))
                    .put("summary", safeStr(t.getSummary()))
                    .put("publishTime", safeStr(t.getPublishTime()))
                    .put("views", t.getViews())
                    .put("replies", t.getReplies())
                    .put("likes", t.getLikes()));
        }
        return new JSONObject().put("threads", arr).put("source", source).put("page", page).put("count", threads.size());
    }

    private JSONObject postDetailToJson(com.forum.MT.model.PostDetail detail) throws Exception {
        JSONObject d = new JSONObject()
                .put("tid", safeStr(detail.getTid()))
                .put("title", safeStr(detail.getTitle()))
                .put("forumName", safeStr(detail.getForumName()))
                .put("author", safeStr(detail.getAuthor()))
                .put("authorUid", safeStr(detail.getAuthorUid()))
                .put("authorLevel", safeStr(detail.getAuthorLevel()))
                .put("publishTime", safeStr(detail.getPublishTime()))
                .put("views", detail.getViews())
                .put("replyCount", detail.getReplyCount())
                .put("likeCount", detail.getLikeCount())
                .put("favoriteCount", detail.getFavoriteCount())
                .put("currentPage", detail.getCurrentPage())
                .put("totalPages", detail.getTotalPages());
        // 正文：剥离 HTML 标签，只返回纯文本
        d.put("contentText", htmlToText(safeStr(detail.getContentHtml())));
        // 回复列表
        JSONArray repliesArr = new JSONArray();
        if (detail.getReplies() != null) {
            for (com.forum.MT.model.ReplyItem r : detail.getReplies()) {
                repliesArr.put(new JSONObject()
                        .put("pid", safeStr(r.getPid()))
                        .put("floor", r.getFloorNumber())
                        .put("author", safeStr(r.getAuthor()))
                        .put("authorUid", safeStr(r.getAuthorUid()))
                        .put("authorLevel", safeStr(r.getAuthorLevel()))
                        .put("time", safeStr(r.getTime()))
                        .put("contentText", htmlToText(safeStr(r.getContentText())))
                        .put("isOP", r.isOP())
                        .put("isPinned", r.isPinned()));
            }
        }
        d.put("replies", repliesArr);
        return d;
    }

    // ==================== 出站脱敏 ====================

    private JSONObject messageListToJson(List<com.forum.MT.model.Message> messages, String source, int page) throws Exception {
        JSONArray arr = new JSONArray();
        for (com.forum.MT.model.Message m : messages) {
            arr.put(new JSONObject()
                    .put("pmid", safeStr(m.getPmid()))
                    .put("author", safeStr(m.getAuthor()))
                    .put("authorUid", safeStr(m.getAuthorUid()))
                    .put("title", safeStr(m.getTitle()))
                    .put("summary", safeStr(m.getSummary()))
                    .put("time", safeStr(m.getTime()))
                    .put("isRead", m.isRead())
                    .put("type", m.getType()));
        }
        return new JSONObject().put("messages", arr).put("source", source).put("page", page).put("count", messages.size());
    }

    private JSONObject friendListToJson(List<com.forum.MT.model.Friend> friends, String source, int page) throws Exception {
        JSONArray arr = new JSONArray();
        for (com.forum.MT.model.Friend f : friends) {
            arr.put(new JSONObject()
                    .put("uid", safeStr(f.getUid()))
                    .put("username", safeStr(f.getUsername()))
                    .put("level", safeStr(f.getLevel()))
                    .put("groupName", safeStr(f.getGroupName()))
                    .put("credits", safeStr(f.getCredits())));
        }
        return new JSONObject().put("list", arr).put("source", source).put("page", page).put("count", friends.size());
    }

    // ==================== 脱敏过滤 ====================

    /** 递归过滤 JSONObject/JSONArray 中的敏感字段。 */
    private static Object sanitize(Object value) {
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            JSONObject out = new JSONObject();
            for (java.util.Iterator<String> it = obj.keys(); it.hasNext(); ) {
                String key = it.next();
                if (SENSITIVE_KEYS.contains(key.toLowerCase())) continue;
                try { out.put(key, sanitize(obj.get(key))); } catch (Exception ignored) {}
            }
            return out;
        }
        if (value instanceof JSONArray) {
            JSONArray arr = (JSONArray) value;
            JSONArray out = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                try { out.put(sanitize(arr.get(i))); } catch (Exception ignored) {}
            }
            return out;
        }
        return value;
    }

    // ==================== 工具方法 ====================

    private static String safeStr(String s) { return s == null ? "" : s; }

    private static String htmlToText(String html) {
        if (html == null || html.isEmpty()) return "";
        return html.replaceAll("<[^>]+>", "").trim();
    }

    private JSONObject textResult(JSONObject data) throws Exception {
        // 所有出站数据统一过脱敏
        JSONObject sanitized = (JSONObject) sanitize(data);
        return new JSONObject().put("content", new JSONArray().put(
                new JSONObject().put("type", "text").put("text", sanitized.toString())));
    }

    private static JSONObject jsonError(Object id, int code, String message) {
        try {
            return new JSONObject().put("jsonrpc", "2.0").put("id", id == null ? JSONObject.NULL : id)
                    .put("error", new JSONObject().put("code", code).put("message", message));
        } catch (Exception e) { return new JSONObject(); }
    }

    private static void writeHttp(BufferedWriter writer, int status, JSONObject body) throws IOException {
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        writer.write("HTTP/1.1 " + status + (status == 200 ? " OK" : " Error") + "\r\n");
        writer.write("Content-Type: application/json; charset=utf-8\r\n");
        writer.write("Content-Length: " + bytes.length + "\r\n");
        writer.write("Connection: close\r\n\r\n");
        writer.write(new String(bytes, StandardCharsets.UTF_8));
        writer.flush();
    }

    private SharedPreferences prefs() {
        return appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String generateToken() {
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private static boolean constantTimeEquals(String a, String b) {
        byte[] x = a.getBytes(StandardCharsets.UTF_8);
        byte[] y = b.getBytes(StandardCharsets.UTF_8);
        int diff = x.length ^ y.length;
        int max = Math.max(x.length, y.length);
        for (int i = 0; i < max; i++) {
            byte xb = i < x.length ? x[i] : 0;
            byte yb = i < y.length ? y[i] : 0;
            diff |= xb ^ yb;
        }
        return diff == 0;
    }
}
