package com.forum.MT.ui.detail;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextPaint;

import java.util.ArrayList;
import java.util.List;

/**
 * 将表格数据绘制成带边框的 Bitmap，用于 ImageSpan 内联渲染。
 * 表格以位图形式嵌入 TextView 文本流中，位置天然正确（在正文原位置显示），
 * 外观是真正的表格（边框、表头底色、单元格内换行自适应）。
 *
 * 支持自定义配色：表头背景、单元格背景、边框、文字颜色，
 * 全部颜色参数化，传入的配色值可为 0（表示使用内置默认色）。
 */
public class TableBitmapRenderer {

    /** 内置默认色 */
    private static final int DEFAULT_BORDER_COLOR = 0xFFBDBDBD;
    private static final int DEFAULT_HEADER_BG = 0xFFF5F5F5;
    private static final int DEFAULT_CELL_BG = Color.WHITE;
    private static final int DEFAULT_TEXT_COLOR = Color.BLACK;

    private static final float BORDER_WIDTH_DP = 1f;
    private static final float TEXT_SIZE_SP = 12f;
    private static final float CELL_PADDING_DP = 8f;

    /** 表格配色数据（任一字段为 0 表示使用默认色） */
    public static class TableColors {
        public int borderColor;
        public int headerBg;
        public int cellBg;
        public int textColor;

        public TableColors(int borderColor, int headerBg, int cellBg, int textColor) {
            this.borderColor = borderColor;
            this.headerBg = headerBg;
            this.cellBg = cellBg;
            this.textColor = textColor;
        }

        /** 未配置任何自定义颜色时的默认配色 */
        public static TableColors defaults() {
            return new TableColors(0, 0, 0, 0);
        }
    }

    /** 兼容旧调用：使用默认配色渲染 */
    public static Bitmap renderTable(float density, int maxWidthPx, List<List<String>> rows) {
        return renderTable(density, maxWidthPx, rows, TableColors.defaults());
    }

    /**
     * 渲染表格为 Bitmap。
     *
     * @param density    屏幕密度 (getResources().getDisplayMetrics().density)
     * @param maxWidthPx 表格最大宽度（超过则内部换行）
     * @param rows       行数据（每一行是一个 List<String>）
     * @param colors     配色；字段为 0 时使用默认色
     */
    public static Bitmap renderTable(float density, int maxWidthPx, List<List<String>> rows,
                                     TableColors colors) {
        if (rows == null || rows.isEmpty()) return null;

        int borderColor = colors != null && colors.borderColor != 0
                ? colors.borderColor : DEFAULT_BORDER_COLOR;
        int headerBg = colors != null && colors.headerBg != 0
                ? colors.headerBg : DEFAULT_HEADER_BG;
        int cellBg = colors != null && colors.cellBg != 0
                ? colors.cellBg : DEFAULT_CELL_BG;
        int textColor = colors != null && colors.textColor != 0
                ? colors.textColor : DEFAULT_TEXT_COLOR;

        int maxCols = 0;
        for (List<String> row : rows) {
            maxCols = Math.max(maxCols, row == null ? 0 : row.size());
        }
        if (maxCols == 0) return null;

        float borderWidth = BORDER_WIDTH_DP * density;
        float textSize = TEXT_SIZE_SP * density;
        float cellPad = CELL_PADDING_DP * density;

        TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(textSize);
        paint.setTypeface(Typeface.DEFAULT);

        // 1) 计算每列宽度和每行高度（支持单元格内换行）
        int[] colWidths = new int[maxCols];

        // 先按原始单元格填充矩阵
        String[][] rawCells = new String[rows.size()][maxCols];
        for (int r = 0; r < rows.size(); r++) {
            List<String> row = rows.get(r);
            for (int c = 0; c < maxCols; c++) {
                rawCells[r][c] = (row != null && c < row.size()) ? row.get(c) : "";
            }
        }

        // 计算每列自然宽度
        float screenWidthPx = Math.max(maxWidthPx, 1);
        float maxColPx = screenWidthPx * 1.2f + cellPad * 2;
        float[] naturalWidths = new float[maxCols];
        for (int c = 0; c < maxCols; c++) {
            float maxW = textSize * 2;
            for (int r = 0; r < rows.size(); r++) {
                String cell = rawCells[r][c];
                for (String paragraph : cell.split("\n", -1)) {
                    maxW = Math.max(maxW, paint.measureText(paragraph));
                }
            }
            naturalWidths[c] = Math.min(maxW, maxColPx);
        }
        for (int c = 0; c < maxCols; c++) {
            colWidths[c] = (int) Math.ceil(naturalWidths[c]) + (int) (cellPad * 2);
        }

        // 2) 计算每行高度
        int[] rowHeights = new int[rows.size()];
        for (int r = 0; r < rows.size(); r++) {
            int maxLines = 1;
            for (int c = 0; c < maxCols; c++) {
                int lines = wrapTextLines(paint, rawCells[r][c], colWidths[c] - (int)(cellPad * 2)).size();
                maxLines = Math.max(maxLines, lines);
            }
            rowHeights[r] = (int)(maxLines * (textSize * 1.4f) + cellPad * 2);
        }

        int totalWidth = 0;
        for (int w : colWidths) totalWidth += w;
        totalWidth += (int)(borderWidth * 2);

        int totalHeight = 0;
        for (int h : rowHeights) totalHeight += h;
        totalHeight += (int)(borderWidth * 2);

        // 3) 绘制
        Bitmap bmp = Bitmap.createBitmap(totalWidth, totalHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);

        // 背景
        canvas.drawColor(cellBg);

        Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(borderWidth);
        borderPaint.setColor(borderColor);

        Paint headerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        headerPaint.setStyle(Paint.Style.FILL);
        headerPaint.setColor(headerBg);

        boolean hasHeader = true;

        int y = (int) borderWidth;
        for (int r = 0; r < rows.size(); r++) {
            int rowH = rowHeights[r];
            int x = (int) borderWidth;
            for (int c = 0; c < maxCols; c++) {
                int cellW = colWidths[c];
                // 单元格背景
                if (r == 0 && hasHeader) {
                    canvas.drawRect(x, y, x + cellW, y + rowH, headerPaint);
                }
                // 绘制文本，支持多行
                String cell = rawCells[r][c];
                List<String> lines = wrapTextLines(paint, cell, cellW - (int)(cellPad * 2));
                float lineHeight = textSize * 1.4f;
                float textY = y + cellPad + textSize;
                Paint textPaint = r == 0 && hasHeader
                        ? makeTextPaint(textSize, true, textColor)
                        : makeTextPaint(textSize, false, textColor);
                for (String line : lines) {
                    float textX = x + cellPad;
                    canvas.drawText(line, textX, textY, textPaint);
                    textY += lineHeight;
                }
                x += cellW;
            }
            y += rowH;
        }

        // 绘制边框（先画横线再画竖线）
        int yy = (int) borderWidth;
        for (int r = 0; r <= rows.size(); r++) {
            canvas.drawLine(0, yy, totalWidth, yy, borderPaint);
            if (r < rows.size()) yy += rowHeights[r];
        }
        int xx = (int) borderWidth;
        for (int c = 0; c <= maxCols; c++) {
            canvas.drawLine(xx, 0, xx, totalHeight, borderPaint);
            if (c < maxCols) xx += colWidths[c];
        }

        return bmp;
    }

    private static Paint makeTextPaint(float textSize, boolean bold, int textColor) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(textSize);
        p.setColor(textColor);
        if (bold) p.setTypeface(Typeface.DEFAULT_BOLD);
        return p;
    }

    /** 文本自动换行：根据给定像素宽度断行 */
    private static List<String> wrapTextLines(Paint paint, String cell, int maxWidthPx) {
        List<String> lines = new ArrayList<>();
        if (cell == null || cell.isEmpty()) {
            lines.add(" ");
            return lines;
        }
        for (String paragraph : cell.split("\n", -1)) {
            StringBuilder line = new StringBuilder();
            for (int i = 0; i < paragraph.length(); ) {
                int cp = paragraph.codePointAt(i);
                String ch = new String(Character.toChars(cp));
                String probe = line.toString() + ch;
                if (paint.measureText(probe) <= maxWidthPx || line.length() == 0) {
                    line.append(ch);
                } else {
                    lines.add(line.toString());
                    line.setLength(0);
                    line.append(ch);
                }
                i += Character.charCount(cp);
            }
            lines.add(line.toString());
        }
        if (lines.isEmpty()) lines.add(" ");
        return lines;
    }

    private static boolean isCJK(int cp) {
        return (cp >= 0x2E80 && cp <= 0x9FFF)
                || (cp >= 0xF900 && cp <= 0xFAFF)
                || (cp >= 0xFE30 && cp <= 0xFE4F)
                || (cp >= 0xFF01 && cp <= 0xFF60);
    }
}