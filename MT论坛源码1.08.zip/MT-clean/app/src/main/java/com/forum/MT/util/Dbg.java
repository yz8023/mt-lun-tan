package com.forum.MT.util;

/**
 * 调试日志开关。
 *
 * <p>排查问题期间在帖子详情页/回复适配器里加了大量 Log.d/Log.e，其中不少位于
 * “每条回复、每张图片都会走一遍”的热路径上。这些日志的开销主要不在 Log 调用本身，
 * 而在调用前就已经发生的字符串拼接与集合 toString（例如把整个图片缓存 keySet
 * 拼进日志），会在列表滚动和渲染时造成明显掉帧。
 *
 * <p>用编译期常量 false 包住这些日志，javac/d8 可直接消除整段代码，
 * 需要排查时改成 true 重新构建即可。异常日志（Log.w/Log.e 带 Throwable）
 * 不受此开关影响，始终保留。
 */
public final class Dbg {

    /** 全局调试日志开关。发布构建保持 false。 */
    public static final boolean ON = false;

    private Dbg() {
    }
}
