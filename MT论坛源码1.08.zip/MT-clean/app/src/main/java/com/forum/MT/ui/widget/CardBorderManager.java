package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * 卡片静态边框管理（与流水灯边框互斥）。
 *
 * 卡片边框效果：所有卡片（帖子、板块、好友、消息、置顶帖等）使用静态描边边框（无动画），
 * 颜色与流水灯共用 {@link RainbowBorderDrawable#getCustomColor()}。
 * 开启卡片边框效果时自动关闭流水灯效果；开启流水灯时自动关闭卡片边框。
 *
 * 偏好键：
 *   card_border_enabled  (boolean, 默认 false)
 */
public final class CardBorderManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_ENABLED = "card_border_enabled";

    /** 未设置自定义颜色时的默认描边色 */
    private static final int DEFAULT_STROKE_COLOR = Color.parseColor("#FF707646");

    private static volatile boolean enabled = true;

    /** 已应用卡片边框的 View（弱引用），开关/颜色变化时统一刷新。 */
    private static final Set<View> APPLIED_VIEWS =
            Collections.newSetFromMap(new WeakHashMap<>());

    /** 开关变化监听器（供 MainActivity 等注册，刷新导航栏等非 CardView） */
    public interface OnEnabledChangedListener {
        void onEnabledChanged(boolean enabled);
    }
    private static volatile OnEnabledChangedListener enabledListener;

    private CardBorderManager() {}

    /** 应用启动时调用，从磁盘恢复用户设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        enabled = prefs.getBoolean(KEY_ENABLED, true);
    }

    public static boolean isEnabled() {
        return enabled;
    }

    /**
     * 为卡片 View 应用正确的边框：开启时用静态描边，关闭时用流水灯。
     * 已跟踪的 View 会在开关/颜色变化时自动刷新。
     */
    public static void applyBorder(View view, float radiusDp) {
        if (view == null) return;
        Context context = view.getContext();
        float density = context.getResources().getDisplayMetrics().density;
        if (enabled) {
            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.RECTANGLE);
            drawable.setCornerRadius(radiusDp * density);
            drawable.setColor(CardColorManager.resolveCardColor());
            drawable.setStroke((int) (2f * density + 0.5f), resolveStrokeColor());
            view.setBackground(drawable);
        } else {
            view.setBackground(new RainbowBorderDrawable(CardColorManager.resolveCardColor(), radiusDp * density, density));
        }
        synchronized (APPLIED_VIEWS) {
            APPLIED_VIEWS.add(view);
        }
    }

    /** 设置卡片边框效果开关；开启时会强制关闭流水灯效果（互斥）。 */
    public static void setEnabled(Context context, boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_ENABLED, value).apply();
        }
        if (value) {
            // 互斥：开启卡片边框时关闭流水灯
            RainbowBorderDrawable.setGlobalEnabled(context, false);
        }
        refreshAll();
        // 通知外部监听器（如 MainActivity 刷新导航栏）
        if (enabledListener != null) {
            enabledListener.onEnabledChanged(enabled);
        }
    }

    /** 注册开关变化监听器。 */
    public static void setListener(OnEnabledChangedListener l) {
        enabledListener = l;
    }

    /** 刷新所有已应用边框的 View（颜色变化、开关变化时调用）。 */
    public static void refreshAll() {
        synchronized (APPLIED_VIEWS) {
            for (View view : APPLIED_VIEWS) {
                if (view == null) continue;
                applyBorder(view, 14f);
            }
        }
    }

    /** 当前应使用的描边色：优先共用自定义颜色，否则用默认。 */
    public static int resolveStrokeColor() {
        int custom = RainbowBorderDrawable.getCustomColor();
        return custom != RainbowBorderDrawable.CUSTOM_COLOR_NONE
                ? custom : DEFAULT_STROKE_COLOR;
    }
}