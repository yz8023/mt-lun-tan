package com.forum.MT.ui.login;
import com.forum.MT.ui.BaseActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.forum.MT.R;
import com.forum.MT.databinding.LoginActivityBinding;
import com.forum.MT.model.UserProfile;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.ui.widget.RainbowBorderHelper;
import com.forum.MT.session.UserSessionManager;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.HashMap;
import java.util.Map;

/**
 * 登录界面 Activity
 * 流程：加载登录页 → 提取 formhash → 提交用户名/密码
 */
public class LoginActivity extends BaseActivity {

    private LoginActivityBinding binding;
    private HttpClient httpClient;
    private String currentFormhash;
    /** 从登录页 form action 提取的提交地址（含动态 loginhash） */
    private String currentLoginPostUrl;
    /** 安全提问编号 0=未设置，1-7 对应官网选项 */
    private int currentQuestionId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // ★ FLAG_SECURE：防止截图/录屏工具捕获密码输入框内容
        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE);
        binding = LoginActivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        RainbowBorderHelper.applyToCardViews(binding.getRoot(), this);

        httpClient = HttpClient.getInstance();

        // 安全提问下拉
        String[] questions = getResources().getStringArray(R.array.security_questions);
        android.widget.ArrayAdapter<String> qa = new android.widget.ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, questions);
        binding.actvQuestion.setText(questions[0], false);
        binding.actvQuestion.setAdapter(qa);
        binding.actvQuestion.setOnItemClickListener((p, v, pos, id) -> {
            currentQuestionId = pos;
            // 选了"未设置"时隐藏答案框
            binding.tilAnswer.setVisibility(pos == 0 ? View.GONE : View.VISIBLE);
        });
        binding.tilAnswer.setVisibility(View.GONE);

        // Toolbar 返回
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        // ★ 移除返回箭头图标
        binding.toolbar.setNavigationIcon(null);

        // 登录按钮
        binding.btnLogin.setOnClickListener(v -> attemptLogin());

        // Cookie 登录切换
        binding.tvSwitchCookieLogin.setOnClickListener(v -> {
            boolean visible = binding.cardCookieLogin.getVisibility() == View.VISIBLE;
            binding.cardCookieLogin.setVisibility(visible ? View.GONE : View.VISIBLE);
            binding.tvSwitchCookieLogin.setText(visible ? "Cookie 登录" : "← 帐号密码登录");
        });

        // Cookie 登录按钮
        binding.btnCookieLogin.setOnClickListener(v -> attemptCookieLogin());

        // 页面加载后，提前获取 formhash
        fetchFormhash();
    }

    /**
     * 第一步：加载登录页面 HTML，提取 formhash 与含 loginhash 的提交地址
     */
    private void fetchFormhash() {
        new Thread(() -> {
            try {
                String loginUrl = ForumParser.getLoginUrl();
                String html = httpClient.get(loginUrl);
                String formhash = ForumParser.parseFormhash(html);
                if (formhash != null) {
                    currentFormhash = formhash;
                }
                // 提取 form action（含动态 loginhash），按官网流程提交
                currentLoginPostUrl = ForumParser.extractLoginPostUrl(html);
            } catch (Exception ignored) {
                // 静默失败，登录时再尝试获取
            }
        }).start();
    }

    /**
     * 第二步：尝试登录
     */
    private void attemptLogin() {
        String username = binding.etUsername.getText().toString().trim();
        String password = binding.etPassword.getText().toString().trim();
        String answer = binding.etAnswer.getText() != null
                ? binding.etAnswer.getText().toString().trim() : "";

        // 输入校验
        if (TextUtils.isEmpty(username)) {
            binding.tilUsername.setError("请输入帐号");
            binding.etUsername.requestFocus();
            return;
        } else {
            binding.tilUsername.setError(null);
        }
        if (TextUtils.isEmpty(password)) {
            binding.tilPassword.setError("请输入密码");
            binding.etPassword.requestFocus();
            return;
        } else {
            binding.tilPassword.setError(null);
        }

        // 显示加载
        showLoading(true);
        binding.tvError.setVisibility(View.GONE);

        new Thread(() -> {
            try {
                // 如果还未获取到 formhash，再取一次（同时提取提交地址）
                if (currentFormhash == null) {
                    String loginHtml = httpClient.get(ForumParser.getLoginUrl());
                    currentFormhash = ForumParser.parseFormhash(loginHtml);
                    currentLoginPostUrl = ForumParser.extractLoginPostUrl(loginHtml);
                }
                if (currentFormhash == null) {
                    runOnUiThread(() -> {
                        showLoading(false);
                        showError("获取登录信息失败");
                    });
                    return;
                }
                // 兜底：若未提取到含 loginhash 的 action，退回默认地址
                if (currentLoginPostUrl == null || currentLoginPostUrl.isEmpty()) {
                    currentLoginPostUrl = ForumParser.getLoginPostUrl();
                }

                // 构造登录提交参数（严格对齐官网 comiis 登录表单）
                Map<String, String> params = new HashMap<>();
                params.put("formhash", currentFormhash);
                params.put("referer", ForumParser.getBaseDomain());
                params.put("fastloginfield", "username");
                params.put("cookietime", "31104000");
                params.put("username", username);
                params.put("password", password);
                // 安全提问：questionid=0 表示未设置，1-7 对应官网选项
                params.put("questionid", String.valueOf(currentQuestionId));
                params.put("answer", currentQuestionId == 0 ? "" : answer);
                params.put("loginsubmit", "yes");

                // 提交到官网 form action（含 loginhash），不再把 formhash 拼到 URL 末尾
                String result = httpClient.post(currentLoginPostUrl, params);

                // 判断是否登录成功（通过 cookie 或返回内容）
                if (httpClient.isLoggedIn()) {
                    // 登录成功 → 持久化 Cookie 到磁盘
                    httpClient.commitCookieStore(LoginActivity.this);

                    // 获取用户信息并持久化
                    try {
                        String spaceHtml = httpClient.get(ForumParser.getBaseDomain() + "home.php?mod=space&do=profile&mobile=2");
                        UserProfile profile = ForumParser.parseUserProfile(spaceHtml);
                        if (profile.getUsername() == null) {
                            profile.setUsername(username);
                        }
                        Map<String, String> loginInfo = new HashMap<>();
                        loginInfo.put("username", profile.getUsername() != null ? profile.getUsername() : username);
                        loginInfo.put("uid", profile.getUid() != null ? profile.getUid() : "0");
                        loginInfo.put("avatarUrl", profile.getAvatarUrl() != null ? profile.getAvatarUrl() : "");
                        loginInfo.put("level", profile.getLevel() != null ? profile.getLevel() : "");
                        UserSessionManager.getInstance().saveLoginInfo(LoginActivity.this, loginInfo);
                    } catch (Exception ignored) {
                        // 静默失败，不影响登录主流程
                    }

                    runOnUiThread(() -> {
                        showLoading(false);
                        setResult(RESULT_OK);
                        finish();
                    });
                } else {
                    // 解析 Discuz 登录错误信息（覆盖安全提问、密码错误、锁定等常见情况）
                    String errorMsg = ForumParser.parseLoginError(result);
                    final String msg = errorMsg != null ? errorMsg : "登录失败，请检查帐号和密码";
                    runOnUiThread(() -> {
                        showLoading(false);
                        showError(msg);
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    showLoading(false);
                    showError("网络错误：" + e.getMessage());
                });
            }
        }).start();
    }

    private void showLoading(boolean show) {
        binding.progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.btnLogin.setEnabled(!show);
        binding.btnLogin.setText(show ? "" : getString(R.string.action_login));
    }

    /**
     * Cookie 登录：将用户粘贴的 Cookie 字符串设置到 HttpClient，
     * 然后验证登录态（请求个人中心页面）。
     */
    private void attemptCookieLogin() {
        String cookieStr = binding.etCookie.getText().toString().trim();
        if (TextUtils.isEmpty(cookieStr)) {
            binding.tilCookie.setError("请输入 Cookie 字符串");
            binding.etCookie.requestFocus();
            return;
        }
        binding.tilCookie.setError(null);
        showCookieLoading(true);
        binding.tvError.setVisibility(View.GONE);

        new Thread(() -> {
            try {
                // 设置 Cookie
                httpClient.setCookiesFromString(cookieStr);
                // 持久化
                httpClient.commitCookieStore(LoginActivity.this);

                // 验证登录态
                if (!httpClient.isLoggedIn()) {
                    runOnUiThread(() -> {
                        showCookieLoading(false);
                        showError("Cookie 无效或已过期，请重新获取");
                    });
                    return;
                }

                // 获取用户信息
                try {
                    String spaceHtml = httpClient.get(ForumParser.getBaseDomain() + "home.php?mod=space&do=profile&mobile=2");
                    com.forum.MT.model.UserProfile profile = ForumParser.parseUserProfile(spaceHtml);
                    java.util.Map<String, String> loginInfo = new java.util.HashMap<>();
                    loginInfo.put("username", profile.getUsername() != null ? profile.getUsername() : "未知用户");
                    loginInfo.put("uid", profile.getUid() != null ? profile.getUid() : "0");
                    loginInfo.put("avatarUrl", profile.getAvatarUrl() != null ? profile.getAvatarUrl() : "");
                    loginInfo.put("level", profile.getLevel() != null ? profile.getLevel() : "");
                    com.forum.MT.session.UserSessionManager.getInstance().saveLoginInfo(LoginActivity.this, loginInfo);
                } catch (Exception ignored) {}

                runOnUiThread(() -> {
                    showCookieLoading(false);
                    setResult(RESULT_OK);
                    finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    showCookieLoading(false);
                    showError("Cookie 登录失败：" + e.getMessage());
                });
            }
        }).start();
    }

    private void showCookieLoading(boolean show) {
        binding.progressBarCookie.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.btnCookieLogin.setEnabled(!show);
        binding.btnCookieLogin.setText(show ? "" : "使用 Cookie 登录");
    }

    private void showError(String msg) {
        binding.tvError.setText(msg);
        binding.tvError.setVisibility(View.VISIBLE);
    }
}