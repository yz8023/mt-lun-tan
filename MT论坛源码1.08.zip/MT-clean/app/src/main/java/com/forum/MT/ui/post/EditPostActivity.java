package com.forum.MT.ui.post;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.forum.MT.R;
import com.forum.MT.model.PostEditForm;
import com.forum.MT.model.PostEditResult;
import com.forum.MT.network.HttpClient;
import com.forum.MT.network.PostEditRepository;
import com.forum.MT.session.UserSessionManager;
import com.forum.MT.ui.BaseActivity;
import com.forum.MT.ui.widget.SmileyPanelHelper;
import com.forum.MT.util.MarkdownBbcodeConverter;
import com.forum.MT.util.MarkdownImportHelper;
import com.forum.MT.util.ImageUploadHelper;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 编辑已发布的帖子或评论。
 *
 * <p>主题第一楼可改标题与正文，评论楼层只改正文。正文以论坛 BBCode 源码形式展示，
 * 与网页端编辑器一致：{@code [attachimg]} 等标签保持原样，用户删掉标签就等于从帖子中
 * 移除对应图片。
 *
 * <p>关键约束：拉取原文失败时绝不显示空编辑器，否则用户保存会清空原帖。
 */
public class EditPostActivity extends BaseActivity {

    public static final String EXTRA_TID = "extra_tid";
    public static final String EXTRA_PID = "extra_pid";
    public static final String EXTRA_FID = "extra_fid";
    public static final String EXTRA_PAGE = "extra_page";
    public static final String EXTRA_IS_FIRST_POST = "extra_is_first_post";

    /** 编辑成功后回传，供调用方局部刷新。 */
    public static final String RESULT_NEW_MESSAGE = "result_new_message";
    public static final String RESULT_NEW_SUBJECT = "result_new_subject";
    public static final String RESULT_PID = "result_pid";
    /**
     * 是否为删除操作。调用方据此区分"刷新本页"与"整帖已不存在需要退出"。
     */
    public static final String RESULT_DELETED = "result_deleted";
    /** 删除的是否是主题第一楼（等于整帖被删）。 */
    public static final String RESULT_DELETED_THREAD = "result_deleted_thread";

    private static final int REQUEST_IMAGE_PICK = 2101;
    private static final int REQUEST_FILE_PICK = 2102;

    private TextView tvCancel;
    private TextView tvEditTitle;
    private MaterialButton btnSave;
    private ImageView btnDelete;
    private LinearLayout llLoading;
    private LinearLayout llLoadError;
    private TextView tvLoadError;
    private MaterialButton btnRetry;
    private ScrollView svEditContent;
    private TextInputEditText etTitle;
    private View dividerTitle;
    private TextInputEditText etContent;
    private TextView tvTitleCount;
    private LinearLayout llImagePreview;
    private LinearLayout llAttachList;
    private LinearLayout llAdvancedOptions;
    private TextView tvError;
    private LinearLayout llSmileyPanel;
    private LinearLayout llAtPanel;
    private TextInputEditText etAtUsername;
    private TextView btnAtInsert;
    private com.google.android.material.tabs.TabLayout tlSmileyTabs;
    private androidx.viewpager.widget.ViewPager vpSmiley;
    private LinearLayout btnSmiley;
    private LinearLayout btnAt;
    private LinearLayout btnInsert;
    private LinearLayout btnMarkdown;
    private LinearLayout btnImage;
    private LinearLayout btnAttach;
    private LinearLayout btnAdvanced;
    private ImageView ivToolSmiley;
    private TextView tvToolSmiley;
    private ImageView ivToolAt;
    private TextView tvToolAt;
    private ImageView ivToolAdvanced;
    private TextView tvToolAdvanced;
    private CheckBox cbUsesig;
    private CheckBox cbSmileyOff;
    private CheckBox cbBbcodeOff;
    private LinearLayout llThreadOptions;
    private CheckBox cbHiddenReplies;
    private CheckBox cbReverseOrder;

    private String tid;
    private String pid;
    private String fid;
    private int page = 1;
    private boolean isFirstPostHint;

    private PostEditForm editForm;
    /** 本次会话新上传的附件 aid，提交时与原有附件一并绑定。 */
    private final Set<String> newAttachAids = new LinkedHashSet<>();
    /** 新上传的非图片附件 aid → 文件名，仅用于附件列表展示与删除。 */
    private final java.util.LinkedHashMap<String, String> newAttachNames =
            new java.util.LinkedHashMap<>();

    private String originalSubject = "";
    private String originalMessage = "";
    private boolean isSubmitting = false;
    /** 删除单飞标记：删除不可撤销，重复提交会打出第二次无意义请求。 */
    private boolean isDeleting = false;

    private static final int TITLE_MAX = 80;

    /**
     * 启动编辑页。
     *
     * @param isFirstPost 是否为主题第一楼（可编辑标题）；不确定时传 false，
     *                    实际能力仍以服务端返回的表单为准
     */
    public static Intent newIntent(Context context, String tid, String pid, String fid,
                                   int page, boolean isFirstPost) {
        Intent intent = new Intent(context, EditPostActivity.class);
        intent.putExtra(EXTRA_TID, tid);
        intent.putExtra(EXTRA_PID, pid);
        intent.putExtra(EXTRA_FID, fid);
        intent.putExtra(EXTRA_PAGE, page);
        intent.putExtra(EXTRA_IS_FIRST_POST, isFirstPost);
        return intent;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_post);

        tid = getIntent().getStringExtra(EXTRA_TID);
        pid = getIntent().getStringExtra(EXTRA_PID);
        fid = getIntent().getStringExtra(EXTRA_FID);
        page = Math.max(1, getIntent().getIntExtra(EXTRA_PAGE, 1));
        isFirstPostHint = getIntent().getBooleanExtra(EXTRA_IS_FIRST_POST, false);

        bindViews();

        if (!UserSessionManager.getInstance().isLoggedIn(this)) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        if (TextUtils.isEmpty(tid) || TextUtils.isEmpty(pid)) {
            Toast.makeText(this, "缺少帖子信息，无法编辑", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvEditTitle.setText(isFirstPostHint
                ? R.string.edit_post_title : R.string.edit_reply_title);
        // 标题行默认按"评论"隐藏，等表单确认是第一楼再显示，避免加载中闪出标题栏。
        etTitle.setVisibility(View.GONE);
        dividerTitle.setVisibility(View.GONE);
        tvTitleCount.setVisibility(View.GONE);
        loadEditForm();
    }

    private void bindViews() {
        tvCancel = findViewById(R.id.tv_cancel);
        tvEditTitle = findViewById(R.id.tv_edit_title);
        btnSave = findViewById(R.id.btn_save);
        btnDelete = findViewById(R.id.btn_delete);
        llLoading = findViewById(R.id.ll_loading);
        llLoadError = findViewById(R.id.ll_load_error);
        tvLoadError = findViewById(R.id.tv_load_error);
        btnRetry = findViewById(R.id.btn_retry);
        svEditContent = findViewById(R.id.sv_edit_content);
        etTitle = findViewById(R.id.et_title);
        dividerTitle = findViewById(R.id.divider_title);
        etContent = findViewById(R.id.et_content);
        tvTitleCount = findViewById(R.id.tv_title_count);
        llImagePreview = findViewById(R.id.ll_image_preview);
        llAttachList = findViewById(R.id.ll_attach_list);
        llAdvancedOptions = findViewById(R.id.ll_advanced_options);
        tvError = findViewById(R.id.tv_error);
        llSmileyPanel = findViewById(R.id.ll_smiley_panel);
        llAtPanel = findViewById(R.id.ll_at_panel);
        etAtUsername = findViewById(R.id.et_at_username);
        btnAtInsert = findViewById(R.id.btn_at_insert);
        tlSmileyTabs = findViewById(R.id.tl_smiley_tabs);
        vpSmiley = findViewById(R.id.vp_smiley);
        btnSmiley = findViewById(R.id.btn_smiley);
        btnAt = findViewById(R.id.btn_at);
        btnInsert = findViewById(R.id.btn_insert);
        btnMarkdown = findViewById(R.id.btn_markdown);
        btnImage = findViewById(R.id.btn_image);
        btnAttach = findViewById(R.id.btn_attach);
        btnAdvanced = findViewById(R.id.btn_advanced);
        ivToolSmiley = findViewById(R.id.iv_tool_smiley);
        tvToolSmiley = findViewById(R.id.tv_tool_smiley);
        ivToolAt = findViewById(R.id.iv_tool_at);
        tvToolAt = findViewById(R.id.tv_tool_at);
        ivToolAdvanced = findViewById(R.id.iv_tool_advanced);
        tvToolAdvanced = findViewById(R.id.tv_tool_advanced);
        cbUsesig = findViewById(R.id.cb_usesig);
        cbSmileyOff = findViewById(R.id.cb_smiley_off);
        cbBbcodeOff = findViewById(R.id.cb_bbcode_off);
        llThreadOptions = findViewById(R.id.ll_thread_options);
        cbHiddenReplies = findViewById(R.id.cb_hidden_replies);
        cbReverseOrder = findViewById(R.id.cb_reverse_order);

        tvCancel.setOnClickListener(v -> attemptExit());
        btnSave.setOnClickListener(v -> attemptSave());
        btnDelete.setOnClickListener(v -> confirmDelete());
        btnRetry.setOnClickListener(v -> loadEditForm());
        btnSmiley.setOnClickListener(v -> toggleSmileyPanel());
        btnImage.setOnClickListener(v -> pickImage());
        btnAttach.setOnClickListener(v -> pickFile());
        btnInsert.setOnClickListener(v -> showInsertDialog());
        btnMarkdown.setOnClickListener(v -> showMarkdownHelp());
        btnAt.setOnClickListener(v -> toggleAtPanel());
        btnAdvanced.setOnClickListener(v -> toggleAdvancedPanel());
        btnAtInsert.setOnClickListener(v -> insertAtUser());

        etTitle.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { updateTitleCount(); }
        });
        // 保存按钮在原文加载完成前不可用，避免提交空正文覆盖原帖。
        btnSave.setEnabled(false);
    }

    // ==================== 加载 ====================

    private void loadEditForm() {
        showState(State.LOADING);
        new Thread(() -> {
            try {
                HttpClient.getInstance().syncFromCookieManager();
                // 页码影响 Discuz 编辑页定位；传入页码不可靠时用 findpost 换算。
                int resolvedPage = page > 1 ? page : PostEditRepository.resolvePage(tid, pid);
                PostEditForm form = PostEditRepository.loadEditForm(fid, tid, pid, resolvedPage);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    applyForm(form);
                });
            } catch (Exception e) {
                final String message = TextUtils.isEmpty(e.getMessage())
                        ? getString(R.string.network_error) : e.getMessage();
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    tvLoadError.setText(message);
                    showState(State.ERROR);
                });
            }
        }).start();
    }

    private void applyForm(PostEditForm form) {
        editForm = form;
        originalSubject = form.getSubject();
        originalMessage = form.getMessage();

        // 是否第一楼以调用方传入为准。解析器用"页面是否有 input[name=subject]"来判断，
        // 而 Discuz 编辑评论时同样会输出该字段（评论标题，通常为空），据此判断会把
        // 评论误当成主题第一楼，导致冒出标题栏、顶部文案变成"编辑帖子"。
        boolean canEditTitle = isFirstPostHint && form.isFirstPost();
        // 同步回表单，提交时才不会给评论楼层带上 subject。
        form.setFirstPost(canEditTitle);
        etTitle.setVisibility(canEditTitle ? View.VISIBLE : View.GONE);
        dividerTitle.setVisibility(canEditTitle ? View.VISIBLE : View.GONE);
        tvTitleCount.setVisibility(canEditTitle ? View.VISIBLE : View.GONE);
        tvEditTitle.setText(canEditTitle
                ? R.string.edit_post_title : R.string.edit_reply_title);
        if (canEditTitle) {
            etTitle.setText(originalSubject);
            updateTitleCount();
        }

        etContent.setText(originalMessage);
        etContent.setSelection(etContent.getText() == null ? 0 : etContent.getText().length());
        btnSave.setEnabled(true);
        // 高级选项以服务端表单原值为初值，避免保存时把用户原本的设置改掉。
        if (cbUsesig != null) cbUsesig.setChecked(!"0".equals(form.getUseSig()));
        // 主题属性开关只对第一楼有意义；评论楼层即使页面输出了也不显示、不提交。
        if (!canEditTitle) {
            form.setHiddenRepliesSupported(false);
            form.setOrderTypeSupported(false);
        }
        boolean hiddenSupported = form.isHiddenRepliesSupported();
        boolean orderSupported = form.isOrderTypeSupported();
        if (llThreadOptions != null) {
            llThreadOptions.setVisibility(
                    hiddenSupported || orderSupported ? View.VISIBLE : View.GONE);
        }
        if (cbHiddenReplies != null) {
            cbHiddenReplies.setVisibility(hiddenSupported ? View.VISIBLE : View.GONE);
            cbHiddenReplies.setChecked(form.isHiddenReplies());
        }
        if (cbReverseOrder != null) {
            cbReverseOrder.setVisibility(orderSupported ? View.VISIBLE : View.GONE);
            cbReverseOrder.setChecked(form.isOrderReverse());
        }
        // 论坛不允许上传时隐藏图片/附件按钮，而不是让用户点了才失败。
        boolean canUpload = form.canUploadImages();
        btnImage.setVisibility(canUpload ? View.VISIBLE : View.GONE);
        btnAttach.setVisibility(canUpload ? View.VISIBLE : View.GONE);
        // 删除入口：原文已成功加载就显示。
        // 不用 form.isDeleteSupported() 做硬门槛——移动模板经常精简掉那个
        // checkbox，只按它判断会让按钮几乎永远不出现；而编辑入口本身已限定为
        // 自己的楼层，真实权限由服务端响应判定。
        btnDelete.setVisibility(View.VISIBLE);
        // 图标按钮无文字，无障碍朗读与长按提示靠 contentDescription 区分删帖/删评论。
        btnDelete.setContentDescription(getString(canEditTitle
                ? R.string.edit_post_delete_thread_action : R.string.edit_post_delete));
        updateImagePreview();
        updateAttachList();
        showState(State.CONTENT);
    }

    private enum State { LOADING, ERROR, CONTENT }

    private void showState(State state) {
        llLoading.setVisibility(state == State.LOADING ? View.VISIBLE : View.GONE);
        llLoadError.setVisibility(state == State.ERROR ? View.VISIBLE : View.GONE);
        svEditContent.setVisibility(state == State.CONTENT ? View.VISIBLE : View.GONE);
        if (state != State.CONTENT) {
            hideAllPanels();
            tvError.setVisibility(View.GONE);
        }
    }

    private void updateTitleCount() {
        Editable text = etTitle.getText();
        int length = text == null ? 0 : text.length();
        tvTitleCount.setText(length + "/" + TITLE_MAX);
    }

    // ==================== 保存 ====================

    private void attemptSave() {
        if (isSubmitting) return;
        if (editForm == null || !editForm.isUsable()) {
            showError("编辑表单已失效，请返回重试");
            return;
        }
        final String newMessage = etContent.getText() == null
                ? "" : etContent.getText().toString().trim();
        if (newMessage.isEmpty()) {
            showError(getString(R.string.edit_post_empty));
            return;
        }
        final String newSubject = editForm.isFirstPost() && etTitle.getText() != null
                ? etTitle.getText().toString().trim() : "";
        if (editForm.isFirstPost() && newSubject.isEmpty()) {
            showError("标题不能为空");
            return;
        }
        if (!hasChanges(newSubject, newMessage)) {
            Toast.makeText(this, R.string.edit_post_no_change, Toast.LENGTH_SHORT).show();
            return;
        }

        isSubmitting = true;
        tvError.setVisibility(View.GONE);
        btnSave.setEnabled(false);
        btnSave.setText(R.string.edit_post_saving);
        hideAllPanels();

        final PostEditRepository.EditOptions options = new PostEditRepository.EditOptions();
        options.useSig = cbUsesig != null && cbUsesig.isChecked();
        options.smileyOff = cbSmileyOff != null && cbSmileyOff.isChecked();
        options.bbcodeOff = cbBbcodeOff != null && cbBbcodeOff.isChecked();
        options.hiddenReplies = cbHiddenReplies != null && cbHiddenReplies.isChecked();
        options.orderReverse = cbReverseOrder != null && cbReverseOrder.isChecked();

        new Thread(() -> {
            PostEditResult result;
            try {
                result = PostEditRepository.submitEdit(editForm, newSubject, newMessage,
                        newAttachAids, options);
            } catch (Exception e) {
                result = PostEditResult.fail(TextUtils.isEmpty(e.getMessage())
                        ? getString(R.string.network_error) : e.getMessage());
            }
            final PostEditResult finalResult = result;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                isSubmitting = false;
                btnSave.setEnabled(true);
                btnSave.setText(R.string.edit_post_save);
                if (finalResult.isSuccess()) {
                    Toast.makeText(this, R.string.edit_post_success, Toast.LENGTH_SHORT).show();
                    Intent data = new Intent();
                    data.putExtra(RESULT_PID, pid);
                    data.putExtra(RESULT_NEW_MESSAGE, newMessage);
                    data.putExtra(RESULT_NEW_SUBJECT, newSubject);
                    setResult(Activity.RESULT_OK, data);
                    finish();
                } else {
                    showError(finalResult.getMessage());
                }
            });
        }).start();
    }

    private boolean hasChanges(String newSubject, String newMessage) {
        if (!newMessage.equals(originalMessage.trim())) return true;
        if (editForm.isFirstPost() && !newSubject.equals(originalSubject.trim())) return true;
        // 只改高级选项也是有效改动，否则会被误判为"未修改"而拒绝保存。
        if (cbUsesig != null && cbUsesig.isChecked() == "0".equals(editForm.getUseSig())) {
            return true;
        }
        if (cbSmileyOff != null && cbSmileyOff.isChecked()) return true;
        if (cbBbcodeOff != null && cbBbcodeOff.isChecked()) return true;
        if (editForm.isHiddenRepliesSupported() && cbHiddenReplies != null
                && cbHiddenReplies.isChecked() != editForm.isHiddenReplies()) {
            return true;
        }
        if (editForm.isOrderTypeSupported() && cbReverseOrder != null
                && cbReverseOrder.isChecked() != editForm.isOrderReverse()) {
            return true;
        }
        // 新上传但还没体现在正文里的附件也算改动。
        return !newAttachAids.isEmpty();
    }

    private void showError(String message) {
        tvError.setText(TextUtils.isEmpty(message) ? getString(R.string.network_error) : message);
        tvError.setVisibility(View.VISIBLE);
    }

    // ==================== 面板 ====================

    /** 收起全部面板；返回收起前是否有面板处于展开状态。 */
    private boolean hideAllPanels() {
        boolean any = (llSmileyPanel != null && llSmileyPanel.getVisibility() == View.VISIBLE)
                || (llAtPanel != null && llAtPanel.getVisibility() == View.VISIBLE)
                || (llAdvancedOptions != null
                        && llAdvancedOptions.getVisibility() == View.VISIBLE);
        if (llSmileyPanel != null) llSmileyPanel.setVisibility(View.GONE);
        if (llAtPanel != null) llAtPanel.setVisibility(View.GONE);
        if (llAdvancedOptions != null) llAdvancedOptions.setVisibility(View.GONE);
        updateToolStates();
        return any;
    }

    /** 面板开合后把对应工具按钮染成主题色，与发帖页保持一致的反馈。 */
    private void updateToolStates() {
        applyToolState(ivToolSmiley, tvToolSmiley,
                llSmileyPanel != null && llSmileyPanel.getVisibility() == View.VISIBLE);
        applyToolState(ivToolAt, tvToolAt,
                llAtPanel != null && llAtPanel.getVisibility() == View.VISIBLE);
        applyToolState(ivToolAdvanced, tvToolAdvanced,
                llAdvancedOptions != null
                        && llAdvancedOptions.getVisibility() == View.VISIBLE);
    }

    private void applyToolState(ImageView icon, TextView label, boolean active) {
        int color = androidx.core.content.ContextCompat.getColor(this,
                active ? R.color.accent_primary : R.color.text_secondary);
        if (icon != null) icon.setColorFilter(color);
        if (label != null) label.setTextColor(color);
    }

    private void toggleSmileyPanel() {
        boolean show = llSmileyPanel.getVisibility() != View.VISIBLE;
        hideAllPanels();
        if (!show) return;
        hideKeyboard();
        SmileyPanelHelper.setUp(tlSmileyTabs, vpSmiley, 7, 44, this::insertSmiley);
        llSmileyPanel.setVisibility(View.VISIBLE);
        updateToolStates();
    }

    private void toggleAtPanel() {
        boolean show = llAtPanel.getVisibility() != View.VISIBLE;
        hideAllPanels();
        if (!show) return;
        llAtPanel.setVisibility(View.VISIBLE);
        etAtUsername.requestFocus();
        updateToolStates();
    }

    private void insertAtUser() {
        String name = etAtUsername.getText() == null
                ? "" : etAtUsername.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "请输入用户名", Toast.LENGTH_SHORT).show();
            return;
        }
        insertIntoContent("@" + name + " ");
        llAtPanel.setVisibility(View.GONE);
        etAtUsername.setText("");
        updateToolStates();
        Toast.makeText(this, "已插入 @" + name, Toast.LENGTH_SHORT).show();
    }

    private void toggleAdvancedPanel() {
        boolean show = llAdvancedOptions.getVisibility() != View.VISIBLE;
        hideAllPanels();
        if (!show) return;
        hideKeyboard();
        llAdvancedOptions.setVisibility(View.VISIBLE);
        updateToolStates();
        // 高级选项在页面底部，展开后滚到底才看得见。
        svEditContent.post(() -> svEditContent.fullScroll(View.FOCUS_DOWN));
    }

    /** 打开「导入 Markdown」底部面板，首行 # 标题自动提取到标题栏（仅第一楼可编辑标题）。 */
    private void showMarkdownHelp() {
        MarkdownImportHelper.show(this, etContent, etTitle);
    }

    private void showInsertDialog() {
        hideAllPanels();
        final String[] items = {"引用", "代码", "免费信息", "隐藏内容"};
        new AlertDialog.Builder(this)
                .setTitle("插入内容")
                .setItems(items, (dialog, which) -> {
                    String bbcode;
                    switch (which) {
                        case 0: bbcode = "\n[quote]请输入引用内容[/quote]\n"; break;
                        case 1: bbcode = "\n[code]请输入代码[/code]\n"; break;
                        case 2: bbcode = "\n[free]请输入免费内容[/free]\n"; break;
                        case 3: bbcode = "\n[hide]请输入隐藏内容[/hide]\n"; break;
                        default: bbcode = ""; break;
                    }
                    insertIntoContent(bbcode);
                    Toast.makeText(this, "已插入" + items[which], Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    /**
     * 在光标处插入表情代码，并套一层 ImageSpan 让用户直接看到图；
     * 提交时 toString() 拿到的仍是论坛能识别的代码。
     */
    private void insertSmiley(String code, int iconRes) {
        Editable editable = etContent.getText();
        if (editable == null) {
            etContent.setText(code);
            return;
        }
        int start = etContent.getSelectionStart();
        int end = etContent.getSelectionEnd();
        if (start < 0) start = editable.length();
        if (end < start) end = start;
        if (end > start) editable.delete(start, end);
        editable.insert(start, code);

        if (iconRes != 0) {
            Drawable d = androidx.core.content.ContextCompat.getDrawable(this, iconRes);
            if (d != null) {
                int size = (int) (etContent.getTextSize() * 1.3f);
                d.setBounds(0, 0, size, size);
                editable.setSpan(new ImageSpan(d, ImageSpan.ALIGN_BOTTOM),
                        start, start + code.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        etContent.setSelection(start + code.length());
    }

    // ==================== 图片与附件 ====================

    private void pickImage() {
        hideAllPanels();
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setData(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, REQUEST_IMAGE_PICK);
    }

    private void pickFile() {
        hideAllPanels();
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_FILE_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == REQUEST_FILE_PICK) {
            Uri uri = data.getData();
            if (uri != null) uploadAttachment(uri);
            return;
        }
        if (requestCode != REQUEST_IMAGE_PICK) return;

        List<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
            int count = data.getClipData().getItemCount();
            for (int i = 0; i < count; i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                if (uri != null) uris.add(uri);
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (!uris.isEmpty()) uploadImages(uris);
    }

    private void uploadImages(List<Uri> uris) {
        if (editForm == null || !editForm.canUploadImages()) {
            showError("当前帖子不支持追加图片");
            return;
        }
        Toast.makeText(this, R.string.edit_post_uploading, Toast.LENGTH_SHORT).show();
        final String uid = editForm.getUploadUid();
        final String hash = editForm.getUploadHash();
        new Thread(() -> {
            int success = 0;
            String firstError = null;
            for (Uri uri : uris) {
                ImageUploadHelper.Outcome outcome =
                        ImageUploadHelper.uploadImage(this, uri, uid, hash);
                if (!outcome.isSuccess()) {
                    if (firstError == null) firstError = outcome.error;
                    continue;
                }
                success++;
                final String bbcode = "\n[attachimg]" + outcome.aid + "[/attachimg]\n";
                newAttachAids.add(outcome.aid);
                runOnUiThread(() -> {
                    insertIntoContent(bbcode);
                    updateImagePreview();
                });
            }
            final int okCount = success;
            final int failCount = uris.size() - success;
            final String reason = firstError;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                // 提示必须反映真实结果：全失败时不能说"完成"。
                if (okCount > 0 && failCount == 0) {
                    Toast.makeText(this, "已上传 " + okCount + " 张图片",
                            Toast.LENGTH_SHORT).show();
                } else if (okCount > 0) {
                    Toast.makeText(this, "成功 " + okCount + " 张，失败 " + failCount + " 张",
                            Toast.LENGTH_LONG).show();
                } else {
                    showError(TextUtils.isEmpty(reason) ? "图片上传失败" : "图片上传失败：" + reason);
                }
            });
        }).start();
    }

    /** 上传非图片附件；图片扩展名仍走 attachimg，以便正文里能直接显示。 */
    private void uploadAttachment(Uri uri) {
        if (editForm == null || !editForm.canUploadImages()) {
            showError("当前帖子不支持追加附件");
            return;
        }
        final String fileName = ImageUploadHelper.getFileNameFromUri(uri);
        Toast.makeText(this, "正在上传附件…", Toast.LENGTH_SHORT).show();
        final String uid = editForm.getUploadUid();
        final String hash = editForm.getUploadHash();
        new Thread(() -> {
            final ImageUploadHelper.Outcome outcome = ImageUploadHelper.isImageFileName(fileName)
                    ? ImageUploadHelper.uploadImage(this, uri, uid, hash)
                    : ImageUploadHelper.uploadAttachment(this, uri, fileName, uid, hash);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (!outcome.isSuccess()) {
                    showError("附件上传失败：" + (TextUtils.isEmpty(outcome.error)
                            ? "未知原因" : outcome.error));
                    return;
                }
                boolean asImage = ImageUploadHelper.isImageFileName(fileName);
                String bbcode = asImage
                        ? "\n[attachimg]" + outcome.aid + "[/attachimg]\n"
                        : "\n[attach]" + outcome.aid + "[/attach]\n";
                newAttachAids.add(outcome.aid);
                if (!asImage) newAttachNames.put(outcome.aid, fileName);
                insertIntoContent(bbcode);
                updateAttachList();
                updateImagePreview();
                Toast.makeText(this, "附件已上传：" + fileName, Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    /**
     * 列出本次会话新上传的非图片附件，并提供删除。
     *
     * <p>原帖已有的附件不在这里列出：它们由正文中的 BBCode 表示，用户删标签即可移除，
     * 而 {@code attachnew} 的重新绑定由提交逻辑统一处理。
     */
    private void updateAttachList() {
        llAttachList.removeAllViews();
        if (newAttachNames.isEmpty()) {
            llAttachList.setVisibility(View.GONE);
            return;
        }
        llAttachList.setVisibility(View.VISIBLE);
        for (java.util.Map.Entry<String, String> entry
                : new java.util.LinkedHashMap<>(newAttachNames).entrySet()) {
            final String aid = entry.getKey();
            TextView tv = new TextView(this);
            tv.setText("📎 " + entry.getValue());
            tv.setPadding(8, 8, 8, 8);
            tv.setTextSize(13);
            tv.setTextColor(androidx.core.content.ContextCompat
                    .getColor(this, R.color.text_primary));
            tv.setCompoundDrawablesWithIntrinsicBounds(
                    0, 0, android.R.drawable.ic_menu_delete, 0);
            tv.setOnClickListener(v -> removeAttachment(aid));
            llAttachList.addView(tv);
        }
    }

    /** 移除新上传附件：同时清掉正文里对应的 BBCode，避免"已删除"却仍随帖提交。 */
    private void removeAttachment(String aid) {
        if (aid == null || !aid.matches("\\d+")) return;
        newAttachAids.remove(aid);
        newAttachNames.remove(aid);
        Editable editable = etContent.getText();
        if (editable != null) {
            String cleaned = editable.toString().replaceAll(
                    "\\[attach(?:img)?\\]\\s*" + aid + "\\s*\\[/attach(?:img)?\\]", "")
                    .replaceAll("\n{3,}", "\n\n");
            etContent.setText(cleaned);
            etContent.setSelection(Math.min(cleaned.length(),
                    Math.max(0, etContent.getSelectionStart())));
        }
        updateAttachList();
        updateImagePreview();
    }

    /**
     * 正文里 {@code [attachimg]} 的顺序即帖子内图片顺序，这里按同一顺序展示缩略图，
     * 让用户在编辑 BBCode 时能确认改动效果。
     */
    private void updateImagePreview() {
        llImagePreview.removeAllViews();
        List<String> aids = new ArrayList<>();
        Editable editable = etContent.getText();
        if (editable != null) {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("\\[attachimg\\]\\s*(\\d+)\\s*\\[/attachimg\\]")
                    .matcher(editable.toString());
            while (m.find()) {
                if (!aids.contains(m.group(1))) aids.add(m.group(1));
            }
        }
        if (aids.isEmpty()) {
            llImagePreview.setVisibility(View.GONE);
            return;
        }
        llImagePreview.setVisibility(View.VISIBLE);
        TextView header = new TextView(this);
        header.setText("帖子内图片（" + aids.size() + "）");
        header.setTextSize(12);
        header.setTextColor(androidx.core.content.ContextCompat
                .getColor(this, R.color.text_secondary));
        llImagePreview.addView(header);

        for (String aid : aids) {
            TextView tv = new TextView(this);
            String label = newAttachNames.containsKey(aid)
                    ? newAttachNames.get(aid) : "attachimg " + aid;
            tv.setText("🖼 " + label + (newAttachAids.contains(aid) ? "（本次新增）" : ""));
            tv.setPadding(0, 8, 0, 8);
            tv.setTextSize(13);
            tv.setTextColor(androidx.core.content.ContextCompat
                    .getColor(this, R.color.text_primary));
            llImagePreview.addView(tv);
        }
    }

    private void insertIntoContent(String text) {
        Editable editable = etContent.getText();
        if (editable == null) {
            etContent.setText(text);
            return;
        }
        int start = etContent.getSelectionStart();
        if (start < 0) start = editable.length();
        editable.insert(start, text);
        etContent.setSelection(start + text.length());
    }

    // ==================== 删除 ====================

    /**
     * 删除前确认。删除不可恢复，第一楼与评论用不同措辞，
     * 让用户明确知道删第一楼会带走整个帖子。
     */
    private void confirmDelete() {
        if (editForm == null || isSubmitting || isDeleting) return;
        hideAllPanels();
        boolean isThread = editForm.isFirstPost();
        new AlertDialog.Builder(this)
                .setTitle(isThread
                        ? R.string.edit_post_delete_thread_title
                        : R.string.edit_post_delete_reply_title)
                .setMessage(isThread
                        ? R.string.edit_post_delete_thread_message
                        : R.string.edit_post_delete_reply_message)
                .setNegativeButton(R.string.action_cancel, null)
                .setPositiveButton(R.string.edit_post_delete_confirm, (d, w) -> performDelete())
                .show();
    }

    private void performDelete() {
        if (editForm == null || isDeleting) return;
        isDeleting = true;
        tvError.setVisibility(View.GONE);
        // ImageView 没有文字态，用禁用 + 半透明表示"正在删除"，并挡住重复点击。
        btnDelete.setEnabled(false);
        btnDelete.setAlpha(0.4f);
        btnSave.setEnabled(false);

        final boolean deletedThread = editForm.isFirstPost();
        new Thread(() -> {
            PostEditResult result;
            try {
                result = PostEditRepository.submitDelete(editForm);
            } catch (Exception e) {
                result = PostEditResult.fail(TextUtils.isEmpty(e.getMessage())
                        ? getString(R.string.network_error) : e.getMessage());
            }
            final PostEditResult finalResult = result;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                isDeleting = false;
                btnDelete.setEnabled(true);
                btnDelete.setAlpha(1f);
                btnSave.setEnabled(true);
                if (finalResult.isSuccess()) {
                    Toast.makeText(this, R.string.edit_post_delete_success,
                            Toast.LENGTH_SHORT).show();
                    Intent data = new Intent();
                    data.putExtra(RESULT_PID, pid);
                    data.putExtra(RESULT_DELETED, true);
                    data.putExtra(RESULT_DELETED_THREAD, deletedThread);
                    setResult(Activity.RESULT_OK, data);
                    finish();
                } else {
                    showError(finalResult.getMessage());
                }
            });
        }).start();
    }

    // ==================== 退出 ====================

    private void attemptExit() {
        String currentMessage = etContent.getText() == null
                ? "" : etContent.getText().toString().trim();
        String currentSubject = etTitle.getText() == null
                ? "" : etTitle.getText().toString().trim();
        boolean dirty = editForm != null && svEditContent.getVisibility() == View.VISIBLE
                && hasChanges(currentSubject, currentMessage);
        if (!dirty) {
            finish();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.edit_post_discard_title)
                .setMessage(R.string.edit_post_discard_message)
                .setNegativeButton(R.string.action_cancel, null)
                .setPositiveButton("退出", (d, w) -> finish())
                .show();
    }

    @Override
    public void onBackPressed() {
        // 有面板展开时先收面板，避免一次返回既收面板又退出编辑。
        if (hideAllPanels()) return;
        attemptExit();
    }

    private void hideKeyboard() {
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager)
                        getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null && getCurrentFocus() != null) {
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }
}
