package com.forum.MT.ui.message;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.forum.MT.R;
import com.forum.MT.adapter.ChatMessageAdapter;
import com.forum.MT.model.ChatMessage;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.network.ImageHostUploader;
import com.forum.MT.session.DiscuzUserActionManager;
import com.forum.MT.session.UserSessionManager;
import com.forum.MT.storage.ChatHistoryStore;
import com.forum.MT.ui.BaseActivity;
import com.forum.MT.ui.widget.ChatPersistenceManager;
import com.forum.MT.ui.widget.SmileyPanelHelper;
import com.forum.MT.util.PmContentMatcher;

import java.text.SimpleDateFormat;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** 原生私信聊天页。网络回调必须服从 Activity 生命周期，避免返回后继续更新已销毁页面。 */
public class ChatActivity extends BaseActivity {
    public static final String EXTRA_PMID = "pmid";
    public static final String EXTRA_UID = "uid";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_AVATAR = "avatar";

    /**
     * 本地回显转圈的最长存活时间。超时后只清除转圈、保留消息本身。
     *
     * <p>清除 pending 依赖"发送成功 → 重新拉取 → 正文匹配上"这条链路，
     * 链路上任一环失败都会让转圈永久停留。这里给一个上限做兜底。
     */
    private static final long PENDING_SPINNER_TIMEOUT_MS = 8000L;

    /** 相册选图请求码。 */
    private static final int REQUEST_IMAGE_PICK = 2001;

    private String pmid, uid, name, avatar;
    private ChatMessageAdapter adapter;
    private RecyclerView recycler;
    private LinearLayoutManager layoutManager;
    private ProgressBar progress;
    private EditText input;
    private TextView status;
    private TextView empty;
    private TextView send;
    private View emojiPanel;
    private android.widget.ImageButton emojiButton;
    private android.widget.ImageButton imageButton;
    /** 图片上传进行中。仅主线程读写。 */
    private boolean uploadingImage = false;
    private final AtomicBoolean loading = new AtomicBoolean(false);
    /** 已发送但服务端列表尚未返回的消息，避免刷新时短暂消失。仅在主线程访问。 */
    private final List<PendingEcho> pendingEchoes = new ArrayList<>();
    /**
     * 已发起的服务端拉取次数，用于区分"发送前就在路上的旧请求"与"发送成功后
     * 新发起的请求"。只有后者的返回结果才能用来判定本地回显是否已被服务端接收。
     */
    private int fetchStartSeq = 0;
    /** 本轮合并中是否有回显的 pending 状态被改写，决定是否强制刷新列表。 */
    /**
     * 首屏是否已经上过屏。
     *
     * <p>只有第一次上屏需要等图片解码：此后图片已在内存缓存里，
     * {@code obtain()} 会同步返回带内容的 Drawable，不存在空窗。
     * 用它保证预热最多只做一次，不会让后续每次刷新都被推迟。
     */
    private volatile boolean firstPaintDone = false;
    private boolean pendingStateChanged = false;
    private volatile boolean reloadAfterSend = false;
    private volatile boolean destroyed = false;
    private boolean sending = false;

    /**
     * 一条本地回显（发送后立刻显示、等待服务端确认的消息）。
     *
     * <p>只用 content 做标识是不够的：服务端返回的正文经过 Jsoup {@code text()}
     * 处理，换行与连续空白会被压成单个空格，表情码会渲染成 {@code <img>} 从而
     * 完全不产生文本。因此这里额外记录发送确认状态，作为匹配失败时的兜底依据。
     */
    private static final class PendingEcho {
        final ChatMessage message;
        /** 发送成功时的 {@link #fetchStartSeq} 快照；-1 表示尚未确认发送成功。 */
        int confirmSeq = -1;
        /** 发送确认后已经完成的新拉取次数。 */
        int refreshesAfterSend = 0;
        /**
         * 发送前"服务端已知的自己发出的消息"条数。
         *
         * <p>正文比对对纯表情消息天生无效（本地是 {@code [#呵呵]}，服务端渲染成
         * {@code <img>}，两边都归一化成空串），这时改用条数是否增长来判断消息
         * 是否真的送达。
         */
        int serverOutgoingBefore = -1;
        /**
         * 发送接口报失败。不代表真的没发出去：Comiis 的成功响应形态多变，
         * 带表情或换行的消息核验必然对不上。置位后先拉一次服务端核实，
         * 确认服务端确实没有这条消息才撤回气泡。
         */
        boolean sendFailed = false;

        PendingEcho(ChatMessage message) {
            this.message = message;
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        pmid = getIntent().getStringExtra(EXTRA_PMID);
        uid = getIntent().getStringExtra(EXTRA_UID);
        name = getIntent().getStringExtra(EXTRA_NAME);
        avatar = getIntent().getStringExtra(EXTRA_AVATAR);

        TextView title = findViewById(R.id.tv_chat_title);
        status = findViewById(R.id.tv_chat_status);
        TextView back = findViewById(R.id.tv_chat_back);
        recycler = findViewById(R.id.chat_recycler);
        progress = findViewById(R.id.chat_progress);
        empty = findViewById(R.id.chat_empty);
        input = findViewById(R.id.chat_input);
        send = findViewById(R.id.chat_send);
        emojiPanel = findViewById(R.id.ll_emoji_panel);
        emojiButton = findViewById(R.id.chat_emoji);
        imageButton = findViewById(R.id.chat_image);

        title.setText(TextUtils.isEmpty(name) ? "消息" : name);
        title.setClickable(true);
        title.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(uid) && !"0".equals(uid)) {
                Intent intent = new Intent(this, com.forum.MT.ui.space.UserProfileActivity.class);
                intent.putExtra("uid", uid);
                if (!TextUtils.isEmpty(name)) intent.putExtra("username", name);
                startActivity(intent);
            } else {
                Toast.makeText(this, "无法获取该用户的UID", Toast.LENGTH_SHORT).show();
            }
        });
        status.setVisibility(View.GONE);
        back.setOnClickListener(v -> finish());

        adapter = new ChatMessageAdapter(this);
        adapter.setOnMessageLongClickListener(this::copyMessage);
        // stackFromEnd：内容不足一屏时贴底显示，符合聊天页习惯，
        // 同时软键盘弹出（adjustResize）后会自然保持在最后一条。
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        recycler.setLayoutManager(layoutManager);
        recycler.setAdapter(adapter);
        recycler.setItemAnimator(null);
        // 气泡高度差异大，关闭固定尺寸假设但打开 view 缓存，减少回滚时重新 bind。
        recycler.setItemViewCacheSize(12);

        send.setOnClickListener(v -> sendMessage());
        if (imageButton != null) imageButton.setOnClickListener(v -> pickImage());
        setUpEmojiPanel();
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { updateSendEnabled(); }
        });
        updateSendEnabled();

        // 软键盘弹出会缩小列表高度，这里在布局变化后把最后一条重新顶到可见区域。
        recycler.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (b < ob) scrollToBottom(false);
        });

        loadCachedMessages();
        loadMessages();
    }

    /**
     * 网络返回前先渲染本地已保存的历史，让打开会话时立刻有内容，
     * 也保证断网或加载失败时依然能查看过往私信。
     */
    private void loadCachedMessages() {
        if (TextUtils.isEmpty(pmid)) return;
        if (!ChatPersistenceManager.isEnabled(getApplicationContext())) return;
        new Thread(() -> {
            List<ChatMessage> cached;
            try {
                cached = ChatHistoryStore.getInstance(getApplicationContext())
                        .loadMessages(pmid);
            } catch (Exception e) {
                return;
            }
            if (cached.isEmpty()) return;
            runOnUiThread(() -> {
                if (!canUpdateUi() || adapter == null) return;
                // 网络已经先返回时不要用旧缓存覆盖更完整的结果。
                if (adapter.getItemCount() > 0) return;
                progress.setVisibility(View.GONE);
                adapter.setItems(mergePendingMessages(cached));
                firstPaintDone = true;
                scrollToBottom(false);
                updateEmptyState();
            });
        }, "chat-cache").start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 从主题设置页返回后同步新配色；仅在颜色确实变化时才整表刷新。
        if (adapter != null && adapter.reloadColors() && recycler != null) {
            // 配色写在 onCreateViewHolder 上，必须让已缓存的 holder 全部重建。
            recycler.setAdapter(adapter);
            scrollToBottom(false);
        }
    }

    /** 输入为空或正在发送时禁用发送按钮，selector 会同步变灰。 */
    private void updateSendEnabled() {
        if (send == null || input == null) return;
        CharSequence text = input.getText();
        boolean hasText = text != null && text.toString().trim().length() > 0;
        send.setEnabled(hasText && !sending);
    }

    private void copyMessage(ChatMessage message) {
        if (message == null || TextUtils.isEmpty(message.getContent())) return;
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(android.content.ClipData.newPlainText(
                        "message", message.getContent()));
                Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ignored) {}
    }

    private boolean canUpdateUi() {
        return !destroyed && !isFinishing() && !isDestroyed();
    }

    /**
     * 上屏前把首屏可见范围内的图片解码进内存缓存。
     *
     * <p>必须在后台线程调用。整体耗时有上限兜底，超时就退回异步加载路径。
     *
     * <p>当前未启用：实测在缓存/网络两条路径上做同步预热都会推迟首屏上屏，
     * 表现为进入会话时整屏闪一下，比它想解决的图片空窗更明显。
     * 保留代码供后续改成"随滚动异步预取"时复用。
     */
    @SuppressWarnings("unused")
    private void preloadFirstScreenImages(List<ChatMessage> messages) {
        if (firstPaintDone) return;
        try {
            List<String> urls = ChatMessageAdapter.collectImageUrls(messages, 5);
            if (urls.isEmpty()) return;
            com.forum.MT.ui.widget.ChatImageLoader.preload(
                    getApplicationContext(), urls, 400L);
        } catch (Exception ignored) {}
    }

    /** 滚到最后一条。smooth=false 用于加载完成/键盘弹出等需要立即到位的场景。 */
    private void scrollToBottom(boolean smooth) {
        if (adapter == null || recycler == null) return;
        int last = adapter.getItemCount() - 1;
        if (last < 0) return;
        if (smooth) recycler.smoothScrollToPosition(last);
        else layoutManager.scrollToPositionWithOffset(last, 0);
    }

    private void updateEmptyState() {
        if (empty == null || adapter == null) return;
        boolean isEmpty = adapter.getItemCount() == 0;
        empty.setVisibility(isEmpty && !loading.get() ? View.VISIBLE : View.GONE);
    }

    private void loadMessages() {
        // 会话标识：pmid 与 uid 在 Comiis 模板下都是对方 uid，任一存在即可拉取。
        if (TextUtils.isEmpty(pmid) && TextUtils.isEmpty(uid)) {
            Toast.makeText(this, "缺少会话ID", Toast.LENGTH_SHORT).show();
            // 没有会话标识时不会再有服务端确认，立刻把转圈停掉，消息仍保留在界面上。
            stopAllPendingSpinners();
            return;
        }
        if (!loading.compareAndSet(false, true)) {
            // 首次加载或其他刷新尚未完成，发送成功后必须在其结束时补刷新。
            reloadAfterSend = true;
            return;
        }
        reloadAfterSend = false;
        final int fetchSeq = ++fetchStartSeq;
        if (canUpdateUi()) {
            // 已有内容时不再显示中间的大转圈，避免每次轮询都闪一下。
            boolean firstLoad = adapter == null || adapter.getItemCount() == 0;
            progress.setVisibility(firstLoad ? View.VISIBLE : View.GONE);
            if (empty != null) empty.setVisibility(View.GONE);
        }

        final String currentUid = UserSessionManager.getInstance()
                .getUid(getApplicationContext());
        // 会话地址必须与发送时用的 touid 完全一致，否则拉的是另一个会话，
        // 刚发出的消息永远出现不了。发送用的是 uid，这里优先用 uid，
        // 仅在没有 uid 时退回 pmid（Comiis 模板里 pmid 存的就是 touid）。
        final String conversationUid = TextUtils.isEmpty(uid) ? pmid : uid;
        new Thread(() -> {
            try {
                HttpClient client = HttpClient.getInstance();
                client.syncFromCookieManager();
                String url = HttpClient.BASE_URL
                        + "home.php?mod=space&do=pm&subop=view&touid=" + conversationUid
                        + "&mobile=2&_ts=" + System.currentTimeMillis();
                String html = client.get(url);
                List<ChatMessage> messages = ForumParser.parseChatMessages(
                        html, currentUid, avatar);
                // 持久化开启时：先把本次拉取落库，再整体读回。
                // 读回结果 = 本地历史 ∪ 本次服务端返回，且保持插入顺序，
                // 因此服务端已过期不再返回的旧消息依然会出现在列表里。
                final String convId = TextUtils.isEmpty(pmid) ? conversationUid : pmid;
                if (ChatPersistenceManager.isEnabled(getApplicationContext())
                        && !TextUtils.isEmpty(convId)) {
                    try {
                        ChatHistoryStore store =
                                ChatHistoryStore.getInstance(getApplicationContext());
                        store.saveMessages(convId, messages);
                        List<ChatMessage> full = store.loadMessages(convId);
                        // 回读结果必须至少覆盖本次服务端返回，否则宁可用服务端原始列表，
                        // 避免读库异常导致刚发出的消息在界面上消失。
                        if (full.size() >= messages.size()) messages = full;
                    } catch (Exception ignored) {}
                }
                final List<ChatMessage> parsedMessages = messages;
                String parsedStatus = ForumParser.parseChatOnlineStatus(html);
                final String onlineText = parsedStatus == null ? "" : parsedStatus;

                runOnUiThread(() -> {
                    loading.set(false);
                    if (!canUpdateUi()) return;
                    progress.setVisibility(View.GONE);
                    if (TextUtils.isEmpty(onlineText)) {
                        status.setVisibility(View.GONE);
                    } else {
                        status.setVisibility(View.VISIBLE);
                        status.setText(onlineText);
                        status.setTextColor(onlineText.contains("在线")
                                ? 0xFF35A853
                                : getResources().getColor(R.color.text_secondary, null));
                    }
                    List<ChatMessage> visibleMessages =
                            mergePendingMessages(parsedMessages, fetchSeq);
                    // 本地回显对象是原地修改 pending 标记的，与 adapter 里是同一个
                    // 引用，必须强制刷新才能让转圈真正消失。
                    boolean forceRefresh = pendingStateChanged;
                    pendingStateChanged = false;
                    int before = adapter.getItemCount();
                    adapter.setItems(visibleMessages, forceRefresh);
                    firstPaintDone = true;
                    // 内容没变化时 setItems 会跳过刷新，此时不要强行重置滚动位置。
                    if (adapter.getItemCount() != before || before == 0) {
                        scrollToBottom(false);
                    }
                    updateEmptyState();
                    // 发送请求可能与首次加载并发：如果发送完成时首次加载仍在进行，
                    // loadMessages() 会被 loading 标记拦截。这里在本次加载结束后补做一次刷新，
                    // 确保刚发送的消息不会因为竞态而只能在重新进入页面后出现。
                    if (reloadAfterSend) {
                        reloadAfterSend = false;
                        recycler.postDelayed(this::loadMessages, 120);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    loading.set(false);
                    if (!canUpdateUi()) return;
                    progress.setVisibility(View.GONE);
                    // 拉取失败时必须把已确认发送的回显转圈停掉：
                    // 本页没有轮询，loadMessages() 只在进入页面与发送成功后各调一次，
                    // 若这唯一一次拉取抛异常，pending 标记再没有机会被清除，
                    // 气泡上的小转圈会一直转到用户重进会话。
                    stopConfirmedPendingSpinners();
                    updateEmptyState();
                    Toast.makeText(this, "聊天记录加载失败", Toast.LENGTH_SHORT).show();
                });
            }
        }, "chat-load").start();
    }

    private List<ChatMessage> mergePendingMessages(List<ChatMessage> messages) {
        return mergePendingMessages(messages, -1);
    }

    /**
     * 把尚未被服务端确认的本地回显拼到服务端列表末尾。
     *
     * <p>"发送后界面看不到、退出重进才出现"的根因是本地回显被过早撤回：
     * <ul>
     *   <li>发送接口返回形态不确定，{@code sendPrivateMessage} 一旦误判失败，
     *       旧实现立刻 {@code removePendingMessage} 删掉气泡，而消息其实已经
     *       落到服务端 —— 于是只能等下次进入会话重新拉取才看到；</li>
     *   <li>正文比对天生对不上：本地是表情代码 {@code [#呵呵]}，服务端是
     *       {@code <img>}；旧的归一化把两边表情全剥掉，纯表情消息双方都变成
     *       空串，再叠加 {@code refreshesAfterSend >= 2} 的丢弃分支，
     *       回显同样会在服务端列表尚未包含它的时候被扔掉。</li>
     * </ul>
     *
     * <p>现在的规则：<b>只有确认服务端列表里真的有这条消息，才移除本地回显。</b>
     * 判定依据两条，命中任一即可：
     * <ol>
     *   <li>{@link PmContentMatcher} 规范键相等（表情按 drawable 资源 id 折算，
     *       与服务端图片 URL 可比）；</li>
     *   <li>发送后新拉取的服务端列表里"自己发出的消息"条数比发送前多 ——
     *       正文完全无法比对时（例如服务端重写了排版）用条数增长兜底。</li>
     * </ol>
     * 都不满足时只停掉转圈，消息本身一直保留在界面上。
     *
     * @param fetchSeq 本次结果对应的拉取序号，{@code -1} 表示不是服务端返回
     *                 （例如本地缓存渲染），此时不推进确认计数
     */
    private List<ChatMessage> mergePendingMessages(List<ChatMessage> messages, int fetchSeq) {
        List<ChatMessage> merged = new ArrayList<>();
        if (messages != null) merged.addAll(messages);
        int serverOutgoing = PmContentMatcher.countConfirmedOutgoing(messages);

        for (int i = 0; i < pendingEchoes.size(); ) {
            PendingEcho echo = pendingEchoes.get(i);
            if (echo == null || echo.message == null) {
                pendingEchoes.remove(i);
                continue;
            }

            boolean freshServerResult = fetchSeq > 0 && fetchSeq > echo.confirmSeq;
            boolean matched = PmContentMatcher.containsLocalText(
                    getApplicationContext(), messages, echo.message.getContent());
            // 条数增长只在"发送之后新发起的拉取"里才有意义，
            // 否则可能把对方或旧请求带来的变化误当成自己这条消息。
            boolean grew = freshServerResult
                    && echo.serverOutgoingBefore >= 0
                    && serverOutgoing > echo.serverOutgoingBefore;

            if (matched || grew) {
                // 服务端列表已经包含这条消息，本地回显功成身退（不会导致消息消失）。
                pendingEchoes.remove(i);
                pendingStateChanged = true;
                // 后续回显的基线同步抬高，避免同一次增长被重复消费。
                for (PendingEcho other : pendingEchoes) {
                    if (other != null && other.serverOutgoingBefore >= 0
                            && other.serverOutgoingBefore < serverOutgoing) {
                        other.serverOutgoingBefore = serverOutgoing;
                    }
                }
                continue;
            }

            if (freshServerResult && echo.sendFailed) {
                // 发送接口报了失败，且服务端确实没有这条消息 → 这次是真失败。
                pendingEchoes.remove(i);
                pendingStateChanged = true;
                restoreFailedMessage(echo.message.getContent());
                continue;
            }

            if (freshServerResult && echo.confirmSeq >= 0) {
                echo.refreshesAfterSend++;
                // 服务端已确认发送成功，正文却匹配不上：保留消息，只停转圈。
                if (echo.message.isPending()) {
                    echo.message.setPending(false);
                    pendingStateChanged = true;
                }
            }
            merged.add(echo.message);
            i++;
        }
        return merged;
    }

    /** 确认发送真的失败后，把文本还回输入框，避免用户内容丢失。 */
    private void restoreFailedMessage(String text) {
        if (!canUpdateUi() || TextUtils.isEmpty(text)) return;
        if (input == null) return;
        // 用户可能已经在输入下一条，此时不要覆盖。
        CharSequence current = input.getText();
        if (current != null && current.length() > 0) {
            Toast.makeText(this, "发送失败，请检查登录状态", Toast.LENGTH_SHORT).show();
            return;
        }
        input.setText(text);
        input.setSelection(input.getText().length());
        updateSendEnabled();
        Toast.makeText(this, "发送失败，请检查登录状态", Toast.LENGTH_SHORT).show();
    }

    private ChatMessage createPendingMessage(String text) {
        Date now = new Date();
        ChatMessage message = new ChatMessage();
        message.setContent(text);
        message.setAvatarUrl(avatar);
        message.setAuthorUid(UserSessionManager.getInstance().getUid(getApplicationContext()));
        message.setDate(new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(now));
        message.setTime(new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(now));
        message.setOutgoing(true);
        message.setPending(true);
        return message;
    }

    private PendingEcho showPendingMessage(String text) {
        ChatMessage pending = createPendingMessage(text);
        PendingEcho echo = new PendingEcho(pending);
        pendingEchoes.add(echo);
        // 只追加当前消息，不覆盖已经显示的历史消息。
        adapter.addItem(pending);
        updateEmptyState();
        recycler.post(() -> scrollToBottom(false));
        // 兜底：无论后续网络怎么走，转圈最多显示 PENDING_SPINNER_TIMEOUT_MS。
        // 本页没有轮询，清除 pending 完全依赖"发送成功后再拉一次"这条链路，
        // 链路上任何一环失败（拉取超时、解析异常、正文比对不上）都会让转圈永久停留。
        recycler.postDelayed(() -> stopPendingSpinner(echo), PENDING_SPINNER_TIMEOUT_MS);
        return echo;
    }

    /**
     * 强制停止某条本地回显的转圈（不移除消息本身）。
     *
     * <p>只改 pending 标记，消息仍留在列表里：此时消息很可能确实已发送成功，
     * 只是服务端返回的正文与本地原文对不上（表情、空白被重写），
     * 直接删掉会让用户以为消息丢了。
     */
    private void stopPendingSpinner(PendingEcho echo) {
        if (echo == null || echo.message == null) return;
        if (!canUpdateUi() || adapter == null) return;
        if (!echo.message.isPending()) return;
        echo.message.setPending(false);
        adapter.notifyItemChangedByIdentity(echo.message);
    }

    /** 把所有"发送已确认成功"的回显转圈停掉。用于拉取失败等无法再确认的场景。 */
    private void stopConfirmedPendingSpinners() {
        for (PendingEcho echo : pendingEchoes) {
            if (echo != null && echo.confirmSeq >= 0) stopPendingSpinner(echo);
        }
    }

    /** 停掉全部回显转圈（连服务端确认渠道都不存在时使用）。 */
    private void stopAllPendingSpinners() {
        for (PendingEcho echo : pendingEchoes) stopPendingSpinner(echo);
    }

    private void sendMessage() {
        if (!canUpdateUi() || sending) return;
        String text = input.getText() == null ? "" : input.getText().toString().trim();
        if (text.isEmpty()) return;
        if (TextUtils.isEmpty(uid)) {
            Toast.makeText(this, "缺少对方UID，无法发送", Toast.LENGTH_SHORT).show();
            return;
        }
        // 先清空输入框，用户不必等网络往返才看到自己的消息。
        input.setText("");
        dispatchSend(text);
    }

    /**
     * 真正发起一条私信。正文已经是最终提交给服务端的形式
     * （表情为 {@code [code]}、图片为 {@code [img]url[/img]}）。
     *
     * <p>从 {@link #sendMessage()} 里抽出来是为了让"发送图片"复用同一套
     * 回显 / pending 确认 / 失败兜底逻辑，而不是另写一份。
     */
    private void dispatchSend(String text) {
        if (!canUpdateUi() || sending) return;
        if (TextUtils.isEmpty(text) || TextUtils.isEmpty(uid)) return;

        sending = true;
        input.setEnabled(false);
        updateSendEnabled();
        final PendingEcho echo = showPendingMessage(text);
        // 发送前服务端已知的"自己发出"条数，作为送达判定的兜底基线。
        echo.serverOutgoingBefore = countServerOutgoingInAdapter();

        new Thread(() -> {
            boolean success = DiscuzUserActionManager.sendPrivateMessage(
                    getApplicationContext(), uid, "", text);
            runOnUiThread(() -> {
                sending = false;
                if (!canUpdateUi()) return;
                input.setEnabled(true);
                updateSendEnabled();
                // 记录确认时刻的拉取序号：只有此后新发起的请求返回，
                // 才能作为"服务端已经收到这条消息"的判定依据。
                echo.confirmSeq = fetchStartSeq;
                echo.refreshesAfterSend = 0;
                // 关键：即使发送接口报失败也不立刻撤回气泡。
                // Comiis 的成功响应形态多变（空 XML、脚本、errorhandle_pmform 混杂），
                // 带表情或换行的消息核验必然对不上，误判为失败的概率很高；
                // 旧实现在这里直接删掉本地回显，于是消息"看不见"，
                // 但服务端其实已经收到 —— 退出重进就冒出来了。
                // 现在统一先拉一次服务端，由 mergePendingMessages 依据
                // 服务端列表决定是撤回还是保留。
                echo.sendFailed = !success;
                loadMessages();
            });
        }, "chat-send").start();
    }

    /** 当前列表里"已被服务端确认的自己发出的消息"条数。 */
    private int countServerOutgoingInAdapter() {
        if (adapter == null) return 0;
        int count = 0;
        for (int i = 0; i < adapter.getItemCount(); i++) {
            ChatMessage item = adapter.getItem(i);
            if (item != null && item.isOutgoing() && !item.isPending()) count++;
        }
        return count;
    }

    // ---- 🖼 发送图片 ----

    /**
     * 打开系统相册选图。
     *
     * <p>只允许单选：私信正文一条一张，多张会连续触发多次发送请求，
     * Discuz 对同一会话的连续提交有频率限制，容易整批失败。
     */
    private void pickImage() {
        if (uploadingImage) {
            Toast.makeText(this, R.string.chat_image_uploading, Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(uid)) {
            Toast.makeText(this, "缺少对方UID，无法发送", Toast.LENGTH_SHORT).show();
            return;
        }
        hideEmojiPanel();
        try {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setDataAndType(
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
            startActivityForResult(intent, REQUEST_IMAGE_PICK);
        } catch (Exception e) {
            // 少数机型没有 ACTION_PICK 的处理者，退回通用文件选择。
            try {
                Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                fallback.setType("image/*");
                fallback.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(fallback, REQUEST_IMAGE_PICK);
            } catch (Exception ignored) {
                Toast.makeText(this, "无法打开相册", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_IMAGE_PICK) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        uploadAndInsertImage(data.getData());
    }

    /**
     * 上传选中的图片到图床，成功后把 {@code [img]url[/img]} 插入输入框光标处。
     *
     * <p>不直接发送：插入后用户还能继续补文字、再插一张、或删掉重选，
     * 与发帖页 {@code insertIntoContent} 的行为一致。
     *
     * <p>为什么不走论坛附件上传：私信正文不接受 {@code [attachimg]aid[/attachimg]}
     * （附件归属于帖子，且上传授权按版块签发），服务端只识别绝对 URL 形式的
     * {@code [img]}。详见 {@link ImageHostUploader} 的类注释。
     */
    private void uploadAndInsertImage(android.net.Uri uri) {
        if (uri == null || uploadingImage) return;
        uploadingImage = true;
        updateImageButtonEnabled();
        Toast.makeText(this, R.string.chat_image_uploading, Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            File temp = null;
            String bbcode = null;
            String error = null;
            try {
                // 图床限制 5MB：先按需压缩，避免用户原图动辄 8~12MB 必然被拒。
                temp = ChatImagePicker.prepareUploadFile(getApplicationContext(), uri);
                if (temp == null) {
                    error = "读取图片失败";
                } else {
                    bbcode = ImageHostUploader.upload(temp).bbcode;
                }
            } catch (Exception e) {
                error = TextUtils.isEmpty(e.getMessage()) ? "图片上传失败" : e.getMessage();
            } finally {
                if (temp != null) {
                    // 上传完成后立刻删掉临时副本，不在缓存目录里堆积原图。
                    try { temp.delete(); } catch (Exception ignored) {}
                }
            }

            final String finalBbcode = bbcode;
            final String finalError = error;
            runOnUiThread(() -> {
                uploadingImage = false;
                if (!canUpdateUi()) return;
                updateImageButtonEnabled();
                if (finalBbcode == null) {
                    Toast.makeText(this,
                            finalError == null ? "图片上传失败" : finalError,
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                insertImageBbcode(finalBbcode);
            });
        }, "chat-image-upload").start();
    }

    /**
     * 在光标处插入图片 BBCode。
     *
     * <p>与表情不同，这里不盖 ImageSpan：图片链接本身就是用户要看到、
     * 可以手动改或删的内容，隐藏成一个缩略图反而让"删掉这张图"变得难操作。
     */
    private void insertImageBbcode(String bbcode) {
        if (input == null || TextUtils.isEmpty(bbcode)) return;
        Editable editable = input.getText();
        if (editable == null) return;
        int start = Math.max(0, input.getSelectionStart());
        int end = Math.max(start, input.getSelectionEnd());
        editable.replace(start, end, bbcode);
        input.setSelection(Math.min(start + bbcode.length(), editable.length()));
        input.requestFocus();
    }

    /** 上传进行中禁用图片按钮，避免同一会话并发提交。 */
    private void updateImageButtonEnabled() {
        if (imageButton == null) return;
        imageButton.setEnabled(!uploadingImage);
        imageButton.setAlpha(uploadingImage ? 0.4f : 1f);
    }

    /**
     * 装配输入栏表情面板。面板结构与评论区、发帖页共用 {@link SmileyPanelHelper}，
     * 三分类（贴吧 / QQ / 狗头）全部走本地 drawable，不联网。
     */
    private void setUpEmojiPanel() {
        if (emojiButton == null || emojiPanel == null) return;
        emojiButton.setOnClickListener(v -> toggleEmojiPanel());
        // 面板收起后重新聚焦输入框，避免键盘和面板同时消失导致焦点丢失。
        input.setOnClickListener(v -> hideEmojiPanel());
        SmileyPanelHelper.setUp(
                findViewById(R.id.tl_emoji_tabs),
                findViewById(R.id.vp_dialog_emoji),
                7, 44,
                (code, iconRes) -> insertSmiley(code, iconRes));
    }

    private void toggleEmojiPanel() {
        if (emojiPanel == null) return;
        if (emojiPanel.getVisibility() == View.VISIBLE) {
            hideEmojiPanel();
            showKeyboard();
        } else {
            showEmojiPanel();
        }
    }

    private void showEmojiPanel() {
        if (emojiPanel == null) return;
        hideKeyboard();
        emojiPanel.setVisibility(View.VISIBLE);
        // 面板挤压列表高度后最后一条会被推出可视区，这里补一次贴底。
        recycler.post(() -> scrollToBottom(false));
    }

    private void hideEmojiPanel() {
        if (emojiPanel != null) emojiPanel.setVisibility(View.GONE);
    }

    /** 表情面板是否处于展开状态（返回键优先收起面板而不是退出页面）。 */
    private boolean isEmojiPanelShown() {
        return emojiPanel != null && emojiPanel.getVisibility() == View.VISIBLE;
    }

    /**
     * 在光标处插入表情。
     *
     * <p>底层文本必须保持服务端要求的 {@code [code]} 形式（发送时原样提交），
     * 但输入框里直接显示 {@code [doge]} 这样的字符串体验很差，因此在插入的
     * 那段文本上盖一个 {@link android.text.style.ImageSpan}：
     * 界面看到的是表情图，{@code getText().toString()} 拿到的仍是表情代码。
     */
    private void insertSmiley(String code, int iconRes) {
        if (TextUtils.isEmpty(code) || input == null) return;
        Editable editable = input.getText();
        if (editable == null) return;
        int start = Math.max(0, input.getSelectionStart());
        int end = Math.max(start, input.getSelectionEnd());
        editable.replace(start, end, code);
        if (iconRes != 0) {
            android.graphics.drawable.Drawable icon =
                    androidx.core.content.ContextCompat.getDrawable(this, iconRes);
            if (icon != null) {
                int size = (int) (input.getTextSize() * 1.35f);
                // 本地资源是静态 PNG，QQ 表情在服务端是多帧 GIF；
                // 输入框里也走同一套"先静后动"替换，和气泡里的观感保持一致。
                android.graphics.drawable.Drawable display =
                        com.forum.MT.ui.widget.AnimatedSmileyLoader.obtain(
                                this,
                                com.forum.MT.ui.detail.ForumSmileyData.gifUrlForCode(this, code),
                                icon, size, input);
                if (display != null) {
                    editable.setSpan(new android.text.style.ImageSpan(
                                    display, android.text.style.ImageSpan.ALIGN_BOTTOM),
                            start, start + code.length(),
                            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        }
        input.setSelection(start + code.length());
    }

    private void showKeyboard() {
        input.requestFocus();
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager)
                        getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(input, 0);
    }

    private void hideKeyboard() {
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager)
                        getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
    }

    @Override
    public void onBackPressed() {
        if (isEmojiPanelShown()) {
            hideEmojiPanel();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        loading.set(false);
        // 不再在这里 setAdapter(null)：Activity 销毁时 RecyclerView 会自行解绑，
        // 而主动置空会触发 onViewRecycled 回调链，容易在已销毁的 Activity 上做无效操作。
        adapter = null;
        super.onDestroy();
    }
}
