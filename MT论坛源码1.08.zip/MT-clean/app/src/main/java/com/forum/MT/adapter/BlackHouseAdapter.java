package com.forum.MT.adapter;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.BannedUser;
import java.util.ArrayList;
import java.util.List;

/**
 * 小黑屋列表适配器。
 *
 * <p>数据来自 JSON API（ajaxdata=json），每页 15 条，
 * 支持分页加载（cid 参数）。
 */
public class BlackHouseAdapter extends RecyclerView.Adapter<BlackHouseAdapter.BannedViewHolder> {

    public interface OnUserClickListener {
        void onUserClick(BannedUser user);
    }

    public interface OnLoadMoreListener {
        void onLoadMore();
    }

    private final Context context;
    private final List<BannedUser> items = new ArrayList<>();
    private OnUserClickListener listener;
    private OnLoadMoreListener loadMoreListener;
    private boolean isloadingMore = false;

    /** 封禁类型颜色：禁止访问=红，禁止发言=橙 */
    private static final int COLOR_BAN_ACCESS = 0xFFE53935;
    private static final int COLOR_BAN_SPEAK = 0xFFFB8C00;

    public BlackHouseAdapter(Context context) {
        this.context = context;
    }

    public void setOnUserClickListener(OnUserClickListener listener) {
        this.listener = listener;
    }

    public void setOnLoadMoreListener(OnLoadMoreListener listener) {
        this.loadMoreListener = listener;
    }

    /** 替换全部数据（下拉刷新用） */
    public void setItems(List<BannedUser> list) {
        items.clear();
        if (list != null) items.addAll(list);
        isloadingMore = false;
        notifyDataSetChanged();
    }

    /** 追加数据（分页加载用） */
    public void appendItems(List<BannedUser> list) {
        if (list != null && !list.isEmpty()) {
            int start = items.size();
            items.addAll(list);
            notifyItemRangeInserted(start, list.size());
        }
        isloadingMore = false;
    }

    public boolean isLoadingMore() {
        return isloadingMore;
    }

    public void setLoadingMore(boolean loading) {
        isloadingMore = loading;
    }

    @NonNull
    @Override
    public BannedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_banned_user, parent, false);
        return new BannedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BannedViewHolder holder, int position) {
        BannedUser item = items.get(position);

        holder.tvUsername.setText(item.getUsername());
        holder.tvAction.setText(item.getAction());

        // 封禁类型徽章背景色
        int badgeColor = item.getAction().contains("访问") ? COLOR_BAN_ACCESS : COLOR_BAN_SPEAK;
        GradientDrawable badge = new GradientDrawable();
        badge.setCornerRadius(dp(4));
        badge.setColor(badgeColor);
        holder.tvAction.setBackground(badge);

        // 到期时间
        String expiry = item.isPermanent() ? "永久封禁" : "到期: " + item.getGroupexpiry();
        holder.tvExpiry.setText(expiry);

        // 操作时间
        holder.tvDateline.setText(item.getDateline());

        // 封禁原因
        if (!TextUtils.isEmpty(item.getReason())) {
            holder.tvReason.setText("原因: " + item.getReason());
            holder.tvReason.setVisibility(View.VISIBLE);
        } else {
            holder.tvReason.setVisibility(View.GONE);
        }

        // 操作人
        if (!TextUtils.isEmpty(item.getOperator())) {
            holder.tvOperator.setText(item.getOperator());
            holder.layoutOperator.setVisibility(View.VISIBLE);

            // 加载操作人头像 — 头像在独立域名 avatar.mt2.cn
            String avatarUrl = "https://avatar.mt2.cn/uc_server/avatar.php?uid="
                    + item.getOperatorid() + "&size=small";
            Glide.with(context)
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_profile)
                    .error(R.drawable.ic_profile)
                    .circleCrop()
                    .into(holder.ivOperatorAvatar);
        } else {
            holder.layoutOperator.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onUserClick(item);
        });

        // 触发加载更多
        if (loadMoreListener != null && !isloadingMore && position == items.size() - 1) {
            isloadingMore = true;
            loadMoreListener.onLoadMore();
        }
    }

    private int dp(int value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class BannedViewHolder extends RecyclerView.ViewHolder {
        final TextView tvUsername;
        final TextView tvAction;
        final TextView tvExpiry;
        final TextView tvDateline;
        final TextView tvReason;
        final LinearLayout layoutOperator;
        final ImageView ivOperatorAvatar;
        final TextView tvOperator;

        BannedViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tv_username);
            tvAction = itemView.findViewById(R.id.tv_action);
            tvExpiry = itemView.findViewById(R.id.tv_expiry);
            tvDateline = itemView.findViewById(R.id.tv_dateline);
            tvReason = itemView.findViewById(R.id.tv_reason);
            layoutOperator = itemView.findViewById(R.id.layout_operator);
            ivOperatorAvatar = itemView.findViewById(R.id.iv_operator_avatar);
            tvOperator = itemView.findViewById(R.id.tv_operator);
        }
    }
}
