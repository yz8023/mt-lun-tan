package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/**
 * 状态栏背景颜色管理。
 *
 * 颜色为 0 时表示使用默认颜色（白色 #FFFFFF）。
 *
 * 偏好键：
 *   status_bar_color (int, 0 表示默认白色)
 */
public final class StatusBarColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_STATUS_BAR_COLOR = "status_bar_color";

    /** 默认状态栏颜色（白色） */
    public static final int DEFAULT_STATUS_BAR_COLOR = 0xFF2196F3;

    private static volatile int statusBarColor = 0;

    private StatusBarColorManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        statusBarColor = prefs.getInt(KEY_STATUS_BAR_COLOR, 0);
    }

    public static int getCustomColor() { return statusBarColor; }

    /** 设置自定义状态栏颜色，0 表示恢复默认。持久化。 */
    public static void setCustomColor(Context context, int color) {
        statusBarColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_STATUS_BAR_COLOR, color).apply();
        }
        notifyChanged();
    }

    /** 当前应使用的状态栏颜色。 */
    public static int resolveStatusBarColor() {
        return statusBarColor != 0 ? statusBarColor : DEFAULT_STATUS_BAR_COLOR;
    }

    public interface OnStatusBarColorChangedListener {
        void onStatusBarColorChanged();
    }

    private static volatile OnStatusBarColorChangedListener listener;

    public static void setListener(OnStatusBarColorChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnStatusBarColorChangedListener l = listener;
        if (l != null) l.onStatusBarColorChanged();
    }
}