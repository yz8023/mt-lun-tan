package com.forum.MT.storage;

import android.content.Context;
import android.content.SharedPreferences;

import com.forum.MT.model.BrowseHistory;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * 浏览历史本地存储（SharedPreferences + JSON）。
 *
 * <p>去重策略：以 tid 为唯一键，同一帖子再次浏览时更新时间并移到列表头部。
 * 容量限制：最多保留 {@link #MAX_HISTORY} 条，超出自动淘汰尾部旧记录。
 */
public class HistoryStore {

    private static final String PREFS_NAME = "browse_history";
    private static final String KEY_LIST = "history_list";
    private static final int MAX_HISTORY = 500;

    private final SharedPreferences prefs;

    public HistoryStore(Context context) {
        prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /**
     * 添加一条浏览记录。
     * 同 tid 的旧记录会被移除，新记录插入到列表头部。
     */
    public synchronized void add(BrowseHistory item) {
        if (item == null || item.getTid() == null) return;

        List<BrowseHistory> list = getAll();
        // 去重：移除同 tid 的旧记录
        list.removeIf(h -> item.getTid().equals(h.getTid()));
        // 插入头部
        list.add(0, item);
        // 截断到最大容量
        if (list.size() > MAX_HISTORY) {
            list = list.subList(0, MAX_HISTORY);
        }
        save(list);
    }

    /**
     * 获取全部浏览历史（按时间倒序，最新在前）。
     */
    public synchronized List<BrowseHistory> getAll() {
        String json = prefs.getString(KEY_LIST, "[]");
        List<BrowseHistory> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                BrowseHistory h = new BrowseHistory();
                h.setTid(obj.optString("tid", ""));
                h.setTitle(obj.optString("title", ""));
                h.setAuthor(obj.optString("author", ""));
                h.setAuthorUid(obj.optString("authorUid", ""));
                h.setAvatarUrl(obj.optString("avatarUrl", ""));
                h.setForumName(obj.optString("forumName", ""));
                h.setViewTime(obj.optLong("viewTime", 0));
                list.add(h);
            }
        } catch (JSONException e) {
            // JSON 损坏时返回空列表，下次写入会覆盖
        }
        return list;
    }

    /**
     * 清空全部浏览历史。
     */
    public synchronized void clear() {
        prefs.edit().remove(KEY_LIST).apply();
    }

    /**
     * 删除指定 tid 的记录。
     */
    public synchronized void remove(String tid) {
        if (tid == null) return;
        List<BrowseHistory> list = getAll();
        list.removeIf(h -> tid.equals(h.getTid()));
        save(list);
    }

    /**
     * 序列化并保存列表。
     */
    private void save(List<BrowseHistory> list) {
        JSONArray arr = new JSONArray();
        for (BrowseHistory h : list) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("tid", h.getTid());
                obj.put("title", h.getTitle());
                obj.put("author", h.getAuthor());
                obj.put("authorUid", h.getAuthorUid());
                obj.put("avatarUrl", h.getAvatarUrl());
                obj.put("forumName", h.getForumName());
                obj.put("viewTime", h.getViewTime());
                arr.put(obj);
            } catch (JSONException e) {
                // 跳过单条损坏数据
            }
        }
        prefs.edit().putString(KEY_LIST, arr.toString()).apply();
    }
}
