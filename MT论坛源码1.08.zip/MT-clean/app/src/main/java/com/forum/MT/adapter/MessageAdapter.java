package com.forum.MT.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.Message;
import com.forum.MT.network.NoticeBadgeManager;
import com.forum.MT.session.SameThreadReadManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.forum.MT.ui.widget.CardBorderManager;
import com.forum.MT.ui.widget.RainbowBorderDrawable;

import java.util.ArrayList;
import java.util.List;

/**
 * 消息/私信列表 RecyclerView Adapter
 * 支持删除和屏蔽按钮回调
 */
public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {

    private List<Message> messageList = new ArrayList<>();
    private Context context;
    private OnItemClickListener listener;
    private OnAvatarClickListener avatarListener;
    private OnUsernameClickListener usernameListener;
    private OnActionClickListener actionListener;
    // ★ v3：接入 NoticeBadgeManager 的 readSet 未读模型。
    //   markViewed 不再批量吞并已读后，若列表侧不逐条推进 readSet，
    //   "其它消息"下互动/系统/应用三类的角标将永远清不掉。
    private String viewType = "";

    public interface OnItemClickListener {
        void onItemClick(Message message, int position);
    }

    /** 头像/用户名点击回调：与整行点击区分，避免点卡片空白处也跳转主页 */
    public interface OnAvatarClickListener {
        void onAvatarClick(Message message, int position);
    }

    /** 用户名点击回调：私信列表中点击用户名跳转到用户主页 */
    public interface OnUsernameClickListener {
        void onUsernameClick(Message message, int position);
    }

    /** 删除/屏蔽按钮回调 */
    public interface OnActionClickListener {
        void onDelete(Message message, int position);
        void onBlock(Message message, int position);
        default void onFriendAction(Message message, int position) {}
    }

    public MessageAdapter(Context context) {
        this.context = context;
    }

    public void setMessageList(List<Message> list) {
        this.messageList = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setOnAvatarClickListener(OnAvatarClickListener avatarListener) {
        this.avatarListener = avatarListener;
    }

    public void setOnUsernameClickListener(OnUsernameClickListener usernameListener) {
        this.usernameListener = usernameListener;
    }

    public void setOnActionClickListener(OnActionClickListener listener) {
        this.actionListener = listener;
    }

    /** 设置该列表所属通知分类（interactive/system/app/follower/pm），用于未读判定。 */
    public void setViewType(String viewType) {
        this.viewType = viewType != null ? viewType : "";
    }

    public void removeItem(int position) {
        if (position >= 0 && position < messageList.size()) {
            messageList.remove(position);
            notifyItemRemoved(position);
        }
    }

    /** 按 Message 对象引用查找当前列表中的位置（用于条目更新而非删除）。 */
    public int findItemPosition(Message target) {
        if (target == null) return -1;
        for (int i = 0; i < messageList.size(); i++) {
            if (messageList.get(i) == target) return i;
        }
        return -1;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_message, parent, false);
        CardBorderManager.applyBorder(view, 8f);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Message msg = messageList.get(position);
        holder.tvAuthor.setText(msg.getAuthor());
        holder.tvTitle.setText(msg.getTitle());
        holder.tvTime.setText(msg.getTime());

        String summary = msg.getSummary();
        if (summary != null && !summary.isEmpty()) {
            holder.tvSummary.setVisibility(View.VISIBLE);
            holder.tvSummary.setText(summary);
        } else {
            holder.tvSummary.setVisibility(View.GONE);
        }

        // 已读/未读状态
        // ★ v3：通知类改用 readSet 判据（与角标同源），不再只信服务端 isRead。
        //   服务端 ntc_l 会被后台角标轮询提前清掉，单靠 isRead 会漏报未读。
        boolean unread = isUnreadMessage(msg);
        holder.unreadBar.setVisibility(unread ? View.VISIBLE : View.GONE);
        if (!unread) {
            holder.tvUnread.setVisibility(View.GONE);
            holder.tvTitle.setTextColor(holder.tvTitle.getContext()
                    .getResources().getColor(R.color.text_secondary, null));
        } else {
            holder.tvUnread.setVisibility(View.VISIBLE);
            holder.tvTitle.setTextColor(holder.tvTitle.getContext()
                    .getResources().getColor(R.color.text_primary, null));
        }

        // 消息类型
        if (msg.getType() == 1) {
            holder.tvType.setVisibility(View.VISIBLE);
            holder.tvType.setText("系统");
        } else if (msg.getType() == 2) {
            holder.tvType.setVisibility(View.VISIBLE);
            holder.tvType.setText("回复");
        } else {
            holder.tvType.setVisibility(View.GONE);
        }

        // 显示删除/屏蔽按钮（仅通知类有pmid时显示）
        boolean hasNoticeId = msg.getPmid() != null && !msg.getPmid().isEmpty();
        boolean hasUid = msg.getAuthorUid() != null && !msg.getAuthorUid().isEmpty();
        holder.ivDelete.setVisibility(hasNoticeId ? View.VISIBLE : View.GONE);
        holder.ivBlock.setVisibility(hasUid ? View.VISIBLE : View.GONE);
        boolean isFriendRequest = "interactive_friend".equals(viewType)
                && isFriendRequestMessage(msg);
        // ★ 检查该 UID 的好友申请是否已被批准过（持久化），已批准则隐藏按钮。
        if (isFriendRequest && hasUid
                && NoticeBadgeManager.isFriendAccepted(holder.itemView.getContext(), msg.getAuthorUid())) {
            isFriendRequest = false;
        }
        holder.btnFriendAction.setVisibility(isFriendRequest ? View.VISIBLE : View.GONE);
        if (isFriendRequest) {
            holder.btnFriendAction.setOnClickListener(v -> {
                if (actionListener != null) actionListener.onFriendAction(msg, position);
            });
        } else {
            holder.btnFriendAction.setOnClickListener(null);
        }

        // 头像
        String avatarUrl = msg.getAvatarUrl();
        if (avatarUrl != null && !avatarUrl.isEmpty()) {
            Glide.with(context)
                    .load(avatarUrl)
                    .placeholder(android.R.drawable.sym_def_app_icon)
                    .error(android.R.drawable.sym_def_app_icon)
                    .circleCrop()
                    .into(holder.ivAvatar);
        } else {
            holder.ivAvatar.setImageResource(android.R.drawable.sym_def_app_icon);
        }

        // ★ 头像/用户名点击：触发 onAvatarClick（跳转主页），
        //   与整行点击分开，避免点卡片空白处也跳转。
        View.OnClickListener avatarClick = v -> {
            if (!viewType.isEmpty() && !"pm".equals(viewType) && v.getContext() != null) {
                String key = NoticeBadgeManager.stableKeyFor(msg);
                NoticeBadgeManager.markItemRead(v.getContext(), viewType, key);
                NoticeBadgeManager.markNoticeClicked(v.getContext(), viewType, key);
                int pos = holder.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos);
            }
            if (avatarListener != null) {
                int currentPosition = holder.getBindingAdapterPosition();
                avatarListener.onAvatarClick(msg, currentPosition != RecyclerView.NO_POSITION ? currentPosition : position);
            }
        };
        holder.ivAvatar.setOnClickListener(avatarClick);
        holder.tvAuthor.setOnClickListener(v -> {
            if (usernameListener != null) {
                int currentPosition = holder.getBindingAdapterPosition();
                usernameListener.onUsernameClick(msg, currentPosition != RecyclerView.NO_POSITION ? currentPosition : position);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            // 通知类点击后推进 readSet；开关开启且能识别 tid 时，批量处理当前列表中的同帖消息。
            if (!viewType.isEmpty() && !"pm".equals(viewType) && v.getContext() != null) {
                String tid = extractThreadId(msg);
                if (SameThreadReadManager.isEnabled(v.getContext()) && !TextUtils.isEmpty(tid)) {
                    for (Message candidate : messageList) {
                        if (tid.equals(extractThreadId(candidate))) {
                            String candidateKey = NoticeBadgeManager.stableKeyFor(candidate);
                            NoticeBadgeManager.markItemRead(v.getContext(), viewType, candidateKey);
                            NoticeBadgeManager.markNoticeClicked(v.getContext(), viewType, candidateKey);
                        }
                    }
                    notifyDataSetChanged();
                } else {
                    String key = NoticeBadgeManager.stableKeyFor(msg);
                    NoticeBadgeManager.markItemRead(v.getContext(), viewType, key);
                    NoticeBadgeManager.markNoticeClicked(v.getContext(), viewType, key);
                    int pos = holder.getBindingAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos);
                }
            }
            if (listener != null) {
                int currentPosition = holder.getBindingAdapterPosition();
                listener.onItemClick(msg, currentPosition != RecyclerView.NO_POSITION ? currentPosition : position);
            }
        });

        // 删除按钮点击
        holder.ivDelete.setOnClickListener(v -> {
            if (actionListener != null) {
                actionListener.onDelete(msg, position);
            }
        });

        // 屏蔽按钮点击
        holder.ivBlock.setOnClickListener(v -> {
            if (actionListener != null) {
                actionListener.onBlock(msg, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    private boolean isFriendRequestMessage(Message message) {
        if (message == null) return false;
        String text = ((message.getTitle() == null ? "" : message.getTitle()) + " "
                + (message.getSummary() == null ? "" : message.getSummary())).toLowerCase();
        boolean completed = text.contains("成为了好友") || text.contains("已成为好友")
                || text.contains("已经是好友") || text.contains("好友添加成功")
                || text.contains("添加好友成功");
        if (completed) return false;
        return (text.contains("请求加您为好友") || text.contains("请求添加您为好友")
                || text.contains("申请加您为好友") || text.contains("申请添加好友")
                || text.contains("请求加为好友"));
    }

    /** 从消息标题或摘要中的隐藏参数提取帖子 tid。 */
    private String extractThreadId(Message message) {
        if (message == null) return null;
        String[] sources = {message.getTitle(), message.getSummary(), message.getDeleteUrl()};
        Pattern[] patterns = {
                Pattern.compile("tid=(\\d+)"),
                Pattern.compile("thread-(\\d+)")
        };
        for (String source : sources) {
            if (TextUtils.isEmpty(source)) continue;
            for (Pattern pattern : patterns) {
                Matcher matcher = pattern.matcher(source);
                if (matcher.find()) return matcher.group(1);
            }
        }
        return null;
    }

    /**
     * 未读判定：通知类以 readSet 为唯一判据（与角标同源），
     * PM / 粉丝 及未设置 viewType 时沿用服务端 isRead。
     */
    private boolean isUnreadMessage(Message msg) {
        if (msg == null) return false;
        if (viewType.isEmpty() || "pm".equals(viewType) || "follower".equals(viewType)) {
            return !msg.isRead();
        }
        if (context == null) return !msg.isRead();
        String key = NoticeBadgeManager.stableKeyFor(msg);
        if (NoticeBadgeManager.isNoticeClicked(context, viewType, key)) return false;
        if (NoticeBadgeManager.isNoticeUnread(context, viewType, key)) return true;
        return !msg.isRead();
    }

    @Override
    public void onViewAttachedToWindow(@NonNull ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        holder.itemView.getBackground().setVisible(true, false);
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull ViewHolder holder) {
        holder.itemView.getBackground().setVisible(false, false);
        super.onViewDetachedFromWindow(holder);
    }

    @Override
    public void onViewRecycled(@NonNull ViewHolder holder) {
        holder.itemView.getBackground().setVisible(false, false);
        super.onViewRecycled(holder);
    }



    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar, ivDelete, ivBlock;
        View unreadBar;
        TextView tvAuthor, tvTitle, tvSummary, tvTime, tvUnread, tvType, btnFriendAction;

        ViewHolder(View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.iv_avatar);
            unreadBar = itemView.findViewById(R.id.view_unread_bar);
            tvAuthor = itemView.findViewById(R.id.tv_author);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvSummary = itemView.findViewById(R.id.tv_summary);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvUnread = itemView.findViewById(R.id.tv_unread);
            tvType = itemView.findViewById(R.id.tv_type);
            btnFriendAction = itemView.findViewById(R.id.btn_friend_action);
            ivDelete = itemView.findViewById(R.id.iv_delete);
            ivBlock = itemView.findViewById(R.id.iv_block);
        }
    }
}