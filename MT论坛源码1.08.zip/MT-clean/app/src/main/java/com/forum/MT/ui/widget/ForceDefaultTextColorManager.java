package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 帖子正文强制默认颜色管理器。
 * 开启后：帖子正文中带颜色字体（<font color="#xxxxxx">）强制恢复为默认文字颜色，
 * 避免帖子中五颜六色的字体干扰阅读。
 */
public class ForceDefaultTextColorManager {

    private static final String PREF_NAME = "app_settings";
    private static final String KEY_FORCE_DEFAULT_COLOR = "force_default_text_color";

    private static boolean forceDefaultColor = false;

    public static void initialize(Context context) {
        if (context == null) return;
        forceDefaultColor = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_FORCE_DEFAULT_COLOR, false);
    }

    public static boolean isEnabled() {
        return forceDefaultColor;
    }

    public static void setEnabled(Context context, boolean value) {
        forceDefaultColor = value;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_FORCE_DEFAULT_COLOR, value).apply();
        }
    }
}