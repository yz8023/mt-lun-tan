package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

/**
 * 全局背景颜色管理。
 *
 * 用户在主题设置页可自定义 App 背景颜色（0 表示使用默认白色）。
 * 各 Activity 在 setContentView 后调用 {@link #apply(View)} 即可生效。
 *
 * 偏好键：
 *   background_custom_color  (int, 0 表示默认白色)
 */
public final class BackgroundColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_COLOR = "background_custom_color";

    public static final int DEFAULT_BACKGROUND = 0xFFF5FAFF;

    private static volatile int customColor = 0;

    private BackgroundColorManager() {}

    /** 应用启动时调用，从磁盘恢复用户设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        customColor = prefs.getInt(KEY_COLOR, 0);
    }

    /** 获取当前自定义背景色，0 表示未设置（默认白色）。 */
    public static int getCustomColor() {
        return customColor;
    }

    /** 设置自定义背景色，0 表示恢复默认白色。持久化。 */
    public static void setCustomColor(Context context, int color) {
        customColor = color;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_COLOR, color).apply();
        }
    }

    /** 当前应使用的背景色。 */
    public static int resolveColor() {
        return customColor != 0 ? customColor : DEFAULT_BACKGROUND;
    }

    /** 判断当前背景是否为深色（自定义深色背景时文字需变白）。 */
    public static boolean isDark() {
        int color = resolveColor();
        double r = Color.red(color) / 255.0;
        double g = Color.green(color) / 255.0;
        double b = Color.blue(color) / 255.0;
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance < 0.45;
    }

    /**
     * 给一个 View 应用背景色（不递归，仅根布局）。
     * 各 Activity onCreate 中 setContentView 后调用。
     */
    public static void apply(View root) {
        if (root == null) return;
        root.setBackgroundColor(resolveColor());
    }

    /**
     * 递归给 root 下所有带 @color/background 默认背景的 View 应用背景色。
     * 用于设置页内部等关键区域，避免深色背景时底色不一致。
     */
    public static void applyRecursive(View root) {
        if (root == null) return;
        apply(root);
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = 0; i < group.getChildCount(); i++) {
                applyRecursive(group.getChildAt(i));
            }
        }
    }
}