package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 回复内容黑名单管理器。
 * 用户添加关键词，包含该关键词的回复将被隐藏。
 * 持久化到 SharedPreferences。
 */
public class ReplyBlacklistManager {

    private static final String PREFS_NAME = "reply_blacklist_prefs";
    private static final String KEY_KEYWORDS = "blacklist_keywords";
    private static final String KEY_ENABLED = "blacklist_enabled";
    private static final String KEY_MATCH_MODE = "blacklist_match_mode";
    // matchMode: 0=精准, 1=模糊

    private static volatile ReplyBlacklistManager instance;

    private final SharedPreferences prefs;
    private final Set<String> keywords = new HashSet<>();
    private boolean enabled = true;
    private int matchMode = 0; // 0=精准, 1=模糊

    private ReplyBlacklistManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        load();
    }

    public static ReplyBlacklistManager getInstance(Context context) {
        if (instance == null) {
            synchronized (ReplyBlacklistManager.class) {
                if (instance == null) {
                    instance = new ReplyBlacklistManager(context);
                }
            }
        }
        return instance;
    }

    private void load() {
        String saved = prefs.getString(KEY_KEYWORDS, "");
        keywords.clear();
        if (saved != null && !saved.isEmpty()) {
            String[] parts = saved.split("\n");
            for (String p : parts) {
                String trimmed = p.trim();
                if (!trimmed.isEmpty()) {
                    keywords.add(trimmed);
                }
            }
        }
        enabled = prefs.getBoolean(KEY_ENABLED, true);
        matchMode = prefs.getInt(KEY_MATCH_MODE, 0);
    }

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (String kw : keywords) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(kw);
        }
        prefs.edit()
                .putString(KEY_KEYWORDS, sb.toString())
                .putBoolean(KEY_ENABLED, enabled)
                .putInt(KEY_MATCH_MODE, matchMode)
                .apply();
    }

    /** 是否启用黑名单过滤 */
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        save();
    }

    /** 获取匹配模式：0=精准，1=模糊 */
    public int getMatchMode() {
        return matchMode;
    }

    /** 设置匹配模式：0=精准，1=模糊 */
    public void setMatchMode(int mode) {
        if (mode != 0 && mode != 1) return;
        this.matchMode = mode;
        save();
    }

    /** 获取所有黑名单关键词 */
    public List<String> getKeywords() {
        return new ArrayList<>(keywords);
    }

    /** 添加关键词，返回是否实际新增（false=已存在重复） */
    public boolean addKeyword(String keyword) {
        if (keyword == null) return false;
        String trimmed = keyword.trim();
        if (trimmed.isEmpty()) return false;
        // 繁简统一去重：检查是否已有等价的简体形式
        String simplified = toSimplified(trimmed);
        for (String existing : keywords) {
            if (toSimplified(existing).equals(simplified)) {
                return false; // 已存在等价关键词
            }
        }
        keywords.add(trimmed);
        save();
        return true;
    }

    /** 移除关键词 */
    public void removeKeyword(String keyword) {
        if (keyword == null) return;
        keywords.remove(keyword.trim());
        save();
    }

    /** 清空黑名单 */
    public void clear() {
        keywords.clear();
        save();
    }

    // ==================== 简繁转换 ====================

    // 常见繁体→简体映射（每对：繁体在前，简体在后，平行字符串）
    private static final String T =
        "萬與醜專業叢東絲丟兩嚴喪個爿豐臨為麗習麼萬買賣麥車長東鳥馬魚鳳龜麗廠廣慶"
      + "樹機應國際紙東掃葉條麥碼劉歐陽邁運進遠選還這連過達邁運進遠選還這連過達遲"
      + "廳叢優億僅僑歐殲殘殤歿殯槍殮殲殘殤歿殯槍殮籲瘧癘癟癬癰癤癢癤癥癧癩癬癭癮"
      + "癱癲皺皺盞鹽監蓋盤瞘矇矓瞤瞞矓矚矜砲碯磧碼磠磣磣硃碯磧磠磣硃確碼磠磣硃確"
      + "鹼鹹鹺鹽鹽麗麥麵麯麼黃黌點黨黲黶黷黽黿鼉鼴齊齋齎齏齏齒齔齕齗齙齦齲齶齲"
      + "齶齷龍龎龐龔龕龜龠齣內行業叢東絲丟兩嚴喪個豐臨為麗麼萬買賣麥車長東鳥馬魚"
      + "鳳龜麗廠廣慶樹機應國際紙東掃葉條麥碼劉歐陽邁運進遠選還這連過達遲廳叢優億"
      + "僅僑歐殲殘殤歿殯槍殮籲瘧癘癟癬癰癤癢癤癥癧癩癬癭癮癱癲皺盞鹽監蓋盤瞘矇矓"
      + "瞤瞞矓矚矜砲碯磧碼磠磣硃確鹼鹹鹺鹽麗麥麵麯麼黃黌點黨黲黶黷黽黿鼉鼴齊齋"
      + "齎齏齒齔齕齗齙齦齲齶齷龍龎龐龔龕龜龠齣"
      + "東車馬龍鳥魚龜麥東車馬龍鳥魚龜麥東車馬龍鳥魚龜麥"
      + "國會來發達產從東車馬龍鳥魚龜麥國會來發達產從東車馬龍鳥魚龜麥國會來發達產"
      + "義務書畫學習醫療衛生環境計劃經濟技術發展農業工業商業建設運輸郵電財政金融"
      + "稅收法律制度政策選舉民主自由平等權利義務責任道德品質文化教育科學藝術體育"
      + "歷史地理政治社會國際關係和平戰爭軍事國防安全穩定繁榮進步文明精神物質";
    private static final String S =
        "万与丑专业丛东丝丢两严丧个丰临为丽习么万买卖麦车长东鸟马鱼凤龟丽厂广庆"
      + "树机应国际纸东扫叶条麦码刘欧阳迈运进远选还这连过达迈运进远选还这连过达迟"
      + "厅丛优亿仅侨欧歼残殇殁殡椁殓歼残殇殁殡椁殓吁疟疠瘪癣痈疖痒疖症疬癞癣瘿瘾"
      + "瘫癫皱皱盏盐监盖盘瞘蒙眬瞤瞒眬矜矜矜炮碋碛码磠碔硃碋碛砖碔硃确码砖碔硃确"
      + "碱咸咸盐丽麦面曲么黄黉点党黲黶黷黾鼋鼍鼹齐斋赍齑齑齿龀龃龆龆龈龉龈龉龊"
      + "龌龙庞庞龚龛龟龠出内行业丛东丝丢两严丧个丰临为丽么万买卖麦车长东鸟马鱼"
      + "凤龟丽厂广庆树机应国际纸东扫叶条麦码刘欧阳迈运进远选还这连过达迟厅丛优亿"
      + "仅侨欧歼残殇殁殡椁殓吁疟疠瘪癣痈疖痒疖症疬癞癣瘿瘾瘫癫皱盏盐监盖盘瞘蒙眬"
      + "瞤瞒眬矜矜矜炮碋碛码砖碔硃确碱咸咸盐丽麦面曲么黄黉点党黲黶黷黾鼋鼍鼹齐斋"
      + "赍齑齿龀龃龆龆龈龉龈龊龙庞庞龚龛龟龠出"
      + "东车马龙鸟鱼龟麦东车马龙鸟鱼龟麦东车马龙鸟鱼龟麦"
      + "国会来发达产从东车马龙鸟鱼龟麦国会来发达产从东车马龙鸟鱼龟麦国会来发达产"
      + "义务书画学习医疗卫生环境计划经济技术发展农业工业商业建设运输邮电财政金融"
      + "税收法律制度政策选举民主自由平等权利义务责任道德品质文化教育科学艺术体育"
      + "历史地理政治社会国际关系和平战争军事国防安全稳定繁荣进步文明精神物质";

    private static final Map<Character, Character> t2sMap = new java.util.HashMap<>();
    private static boolean sMapsInitialized = false;

    private static void initMaps() {
        if (sMapsInitialized) return;
        sMapsInitialized = true;
        int len = Math.min(T.length(), S.length());
        for (int i = 0; i < len; i++) {
            t2sMap.put(T.charAt(i), S.charAt(i));
        }
    }

    /** 将文本中的繁体字转为简体字 */
    public static String toSimplified(String text) {
        if (text == null || text.isEmpty()) return "";
        if (!sMapsInitialized) initMaps();
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            Character sc = t2sMap.get(c);
            sb.append(sc != null ? sc : c);
        }
        return sb.toString();
    }

    // ==================== 边界检测 ====================

    /** 判断字符是否为边界字符（空格、标点、换行等） */
    private static boolean isBoundaryChar(char c) {
        if (Character.isWhitespace(c) || Character.isISOControl(c)) return true;
        // CJK标点 \u3000-\u303F
        if (c >= 0x3000 && c <= 0x303F) return true;
        // 全角形式 \uFF00-\uFFEF
        if (c >= 0xFF00 && c <= 0xFFEF) return true;
        // ASCII标点
        if (c >= 0x21 && c <= 0x2F) return true;  // ! " # $ % & ' ( ) * + , - . /
        if (c >= 0x3A && c <= 0x40) return true;  // : ; < = > ? @
        if (c >= 0x5B && c <= 0x60) return true;  // [ \ ] ^ _ `
        if (c >= 0x7B && c <= 0x7E) return true;  // { | } ~
        return false;
    }

    /**
     * 精准匹配：检查关键词是否作为独立词段出现在内容中。
     * 关键词前后必须是边界字符（空格/标点/换行）或字符串首尾。
     * 不再用 splitWords 分割，避免关键词含空格或标点时无法匹配。
     */
    private static boolean containsWithBoundary(String content, String kw) {
        if (kw == null || kw.isEmpty() || content.length() < kw.length()) return false;
        int idx = content.indexOf(kw);
        while (idx >= 0) {
            boolean startOk = (idx == 0) || isBoundaryChar(content.charAt(idx - 1));
            int endIdx = idx + kw.length();
            boolean endOk = (endIdx >= content.length()) || isBoundaryChar(content.charAt(endIdx));
            if (startOk && endOk) return true;
            idx = content.indexOf(kw, idx + 1);
        }
        return false;
    }

    /**
     * 检查内容是否匹配黑名单。
     * 精准模式：关键词作为独立词段出现（前后是边界字符），支持含空格/标点的关键词。
     * 模糊模式：内容中包含关键词即匹配。
     * 繁简不敏感：匹配前统一转为简体。
     * @param content 回复的纯文本内容
     * @return true 表示内容被黑名单命中，应隐藏
     */
    public boolean isBlocked(String content) {
        if (!enabled || content == null || content.isEmpty()) return false;
        if (keywords.isEmpty()) return false;

        // 繁简统一：把内容和关键词都转为简体再比较
        String normalizedContent = toSimplified(content);

        if (matchMode == 1) {
            // 模糊匹配
            for (String kw : keywords) {
                String nkw = toSimplified(kw);
                if (normalizedContent.contains(nkw)) return true;
            }
        } else {
            // 精准匹配：整条回复内容与关键词完全一致（一字不差）才过滤
            String trimmedContent = normalizedContent.trim();
            for (String kw : keywords) {
                String nkw = toSimplified(kw).trim();
                if (trimmedContent.equals(nkw)) return true;
            }
        }
        return false;
    }

    /** 黑名单关键词数量 */
    public int size() {
        return keywords.size();
    }
}
