package com.forum.MT.ui.detail;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

import androidx.appcompat.widget.AppCompatImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * 支持双指缩放、单指拖动的 ImageView
 * 加载图片后自动适应屏幕大小，居中显示
 */
public class ZoomableImageView extends AppCompatImageView {

    private static final float MAX_SCALE = 5.0f;
    private static final float MIN_SCALE = 0.5f;

    private final Matrix matrix = new Matrix();
    private final Matrix savedMatrix = new Matrix();
    private final ScaleGestureDetector scaleDetector;

    private PointF lastFinger = new PointF();
    private int mode = NONE;
    private static final int NONE = 0;
    private static final int DRAG = 1;
    private static final int ZOOM = 2;

    private float cumulativeScale = 1f;

    public ZoomableImageView(@NonNull Context context) {
        this(context, null);
    }

    public ZoomableImageView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setScaleType(ScaleType.MATRIX);
        scaleDetector = new ScaleGestureDetector(context, new ScaleListener());
    }

    @Override
    public void setImageDrawable(@Nullable Drawable drawable) {
        super.setImageDrawable(drawable);
        // 图片加载完成后，马上适应屏幕（如果视图已有尺寸）
        if (drawable != null && getWidth() > 0 && getHeight() > 0) {
            fitToScreen();
        }
    }

    @Override
    public void setImageBitmap(android.graphics.Bitmap bm) {
        super.setImageBitmap(bm);
        if (bm != null && getWidth() > 0 && getHeight() > 0) {
            fitToScreen();
        }
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        // 布局完成后，如果图片已加载则适应屏幕
        if (getWidth() > 0 && getHeight() > 0 && getDrawable() != null) {
            fitToScreen();
        }
    }

    /** 计算并设置适应屏幕的初始矩阵 */
    private void fitToScreen() {
        Drawable d = getDrawable();
        if (d == null) return;
        int imgW = d.getIntrinsicWidth();
        int imgH = d.getIntrinsicHeight();
        if (imgW <= 0 || imgH <= 0) return;

        int viewW = getWidth();
        int viewH = getHeight();
        if (viewW <= 0 || viewH <= 0) return;

        // 计算缩放比例：使图片完整可见（宽高都填满取较小值）
        float scale = Math.min((float) viewW / imgW, (float) viewH / imgH);
        // 如果图片比屏幕小，不放大
        if (scale > 1.0f) scale = 1.0f;
        // 居中
        float dx = (viewW - imgW * scale) / 2f;
        float dy = (viewH - imgH * scale) / 2f;
        matrix.reset();
        matrix.postScale(scale, scale);
        matrix.postTranslate(dx, dy);
        setImageMatrix(matrix);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                savedMatrix.set(matrix);
                lastFinger.set(event.getX(), event.getY());
                mode = DRAG;
                break;
            }
            case MotionEvent.ACTION_POINTER_DOWN: {
                savedMatrix.set(matrix);
                cumulativeScale = 1f;
                mode = ZOOM;
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (mode == DRAG && event.getPointerCount() == 1) {
                    float dx = event.getX() - lastFinger.x;
                    float dy = event.getY() - lastFinger.y;
                    matrix.set(savedMatrix);
                    matrix.postTranslate(dx, dy);
                    setImageMatrix(matrix);
                }
                break;
            }
            case MotionEvent.ACTION_UP: {
                mode = NONE;
                break;
            }
            case MotionEvent.ACTION_POINTER_UP: {
                savedMatrix.set(matrix);
                mode = NONE;
                break;
            }
        }

        return true;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            if (mode != ZOOM) return true;

            float scale = detector.getScaleFactor();
            float[] values = new float[9];
            savedMatrix.getValues(values);
            float baseScale = values[Matrix.MSCALE_X];

            cumulativeScale *= scale;
            float totalScale = baseScale * cumulativeScale;

            if (totalScale > MAX_SCALE) {
                cumulativeScale = MAX_SCALE / baseScale;
            } else if (totalScale < MIN_SCALE) {
                cumulativeScale = MIN_SCALE / baseScale;
            }

            matrix.set(savedMatrix);
            matrix.postScale(cumulativeScale, cumulativeScale,
                    detector.getFocusX(), detector.getFocusY());
            setImageMatrix(matrix);
            return true;
        }
    }
}