package com.forum.MT.network;

import android.text.TextUtils;

import com.forum.MT.model.PostPageData;
import com.forum.MT.model.PostResult;
import com.forum.MT.model.PostType;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * 发帖页面解析器（对齐官方APK PostPageParser）
 *
 * 解析 Discuz! 发帖页面的 form#postform：
 *   - formhash: input[name=formhash]
 *   - postUrl: form#postform 的 action 属性
 *   - 帖子类型: #typeid option
 *   - 权限错误: .alert_error / #messagetext / .alert_info
 *
 * 解析发帖结果（对齐官方 parsePostResult 逻辑顺序）：
 *   1. .alert_error → 失败
 *   2. .alert_right → 成功，从 a[href*=thread] 提取tid和url
 *   3. 正则匹配 location.href 跳转URL → 成功
 *   4. 正则匹配 var tid = parseInt(...) → 成功，构建 thread URL
 *   5. link[rel=canonical][href*=thread-] → 成功
 *   6. a[href*=thread-].s.xst → 成功
 *   7. .alert_info → 失败
 *   8. #messagetext → 失败
 *   9. 兜底: "发帖失败，请稍后重试"
 */
public class PostPageParser {

    private static final String BASE_DOMAIN = "https://bbs.binmt.cc/";

    // ==================== parsePostPage ====================

    /**
     * 解析发帖页面（对齐官方 parsePostPage）
     *
     * @param html 发帖页面HTML
     * @param fid 当前板块ID
     * @return PostPageData
     */
    public static PostPageData parsePostPage(String html, String fid) {
        if (TextUtils.isEmpty(html)) {
            return new PostPageData(fid, null, null, null,
                    new ArrayList<>(), false, "页面内容为空");
        }

        try {
            Document doc = Jsoup.parse(html);

            // 1. 检查权限错误
            String permissionError = checkPermissionError(doc);
            if (permissionError != null) {
                return new PostPageData(fid, null, null, null,
                        new ArrayList<>(), false, permissionError);
            }

            // 2. 获取表单（对齐官方: form#postform）
            Element form = doc.selectFirst("form#postform");
            if (form == null) {
                // 兜底: form[name=postform]
                form = doc.select("form[name=postform]").first();
            }

            String formhash = null;
            String postUrl = null;

            if (form != null) {
                // 从 form 的 action 属性获取 postUrl（对齐官方）
                String action = form.attr("action");
                if (!TextUtils.isEmpty(action)) {
                    if (action.contains("http")) {
                        postUrl = action;
                    } else {
                        postUrl = BASE_DOMAIN + action;
                    }
                }
            }

            // 从 input[name=formhash] 获取 formhash（对齐官方: 全局搜索 input[name=formhash]）
            Element hashInput = doc.selectFirst("input[name=formhash]");
            if (hashInput != null) {
                formhash = hashInput.attr("value");
            }

            // 兜底：从 JS 变量中提取 formhash
            if (TextUtils.isEmpty(formhash)) {
                Matcher m = Pattern.compile("formhash\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(html);
                if (m.find()) {
                    formhash = m.group(1);
                }
            }

            // 3. 获取板块名（对齐官方: #pt a[href*="forum-{fid}"] → #pt .z a:last-child）
            String forumName = null;
            if (fid != null) {
                Element forumLink = doc.selectFirst("#pt a[href*=\"forum-" + fid + "\"]");
                if (forumLink != null) {
                    forumName = extractTitleText(forumLink);
                }
            }
            if (TextUtils.isEmpty(forumName)) {
                Element lastCrumb = doc.select("#pt .z a").last();
                if (lastCrumb != null) {
                    forumName = extractTitleText(lastCrumb);
                }
            }

            // 4. 解析帖子类型列表（对齐官方: #typeid option）
            List<PostType> postTypes = new ArrayList<>();
            Elements options = doc.select("#typeid option");
            if (options.isEmpty()) {
                // 兜底
                Element typeidSelect = doc.select("select[name=typeid]").first();
                if (typeidSelect != null) {
                    options = typeidSelect.select("option");
                }
            }
            for (Element option : options) {
                String value = option.attr("value");
                String name = option.text().trim();
                // 对齐官方: 过滤 value 为空或 "0" 的默认项
                if (!TextUtils.isEmpty(value) && value.length() > 0 && !"0".equals(value)) {
                    postTypes.add(new PostType(value, name));
                }
            }

            return new PostPageData(fid, forumName, formhash, postUrl,
                    postTypes, false, null);

        } catch (Exception e) {
            return new PostPageData(fid, null, null, null,
                    new ArrayList<>(), false, "解析页面失败: " + e.getMessage());
        }
    }

    // ==================== checkPermissionError ====================

    /**
     * 检查权限错误（对齐官方 checkPermissionError）
     * 检查 .alert_error / #messagetext / .alert_info 是否有权限错误
     *
     * @param doc 解析后的Document
     * @return 错误消息，null表示无错误
     */
    public static String checkPermissionError(Document doc) {
        if (doc == null) return null;

        // 检查 .alert_error
        Element alertError = doc.selectFirst(".alert_error");
        if (alertError != null) {
            String text = alertError.text().trim();
            if (!TextUtils.isEmpty(text)) {
                return text;
            }
        }

        // 检查 #messagetext
        Element messageText = doc.selectFirst("#messagetext");
        if (messageText != null) {
            String text = messageText.text().trim();
            if (!TextUtils.isEmpty(text)) {
                return text;
            }
        }

        // 检查 .alert_info
        Element alertInfo = doc.selectFirst(".alert_info");
        if (alertInfo != null) {
            String text = alertInfo.text().trim();
            if (!TextUtils.isEmpty(text)) {
                return text;
            }
        }

        return null;
    }

    // ==================== parsePostResult ====================

    /**
     * 解析发帖结果（完全对齐官方 parsePostResult 逻辑顺序）
     *
     * 官方逻辑顺序：
     *   1. .alert_error → 失败
     *   2. .alert_right → 成功，从 a[href*=thread] 提取tid和url
     *   3. 正则匹配 location.href 跳转URL → 成功
     *   4. 正则匹配 var tid = parseInt(...) → 成功，构建 thread URL
     *   5. link[rel=canonical][href*=thread-] → 成功
     *   6. a[href*=thread-].s.xst → 成功
     *   7. .alert_info → 失败
     *   8. #messagetext → 失败
     *   9. 兜底: "发帖失败，请稍后重试"
     *
     * @param html 发帖提交后的响应HTML
     * @return PostResult
     */
    public static PostResult parsePostResult(String html) {
        if (TextUtils.isEmpty(html)) {
            return new PostResult(false, "发帖失败，请稍后重试", null, null);
        }

        try {
            Document doc = Jsoup.parse(html);

            // 1. 先查 .alert_error → 有则失败
            Element alertError = doc.selectFirst(".alert_error");
            if (alertError != null) {
                String text = alertError.text().trim();
                if (!TextUtils.isEmpty(text)) {
                    return new PostResult(false, text, null, null);
                }
            }

            // 2. 查 .alert_right → 有则成功
            Element alertRight = doc.selectFirst(".alert_right");
            if (alertRight != null) {
                String text = alertRight.text().trim();
                String tid = null;
                String redirectUrl = null;

                // 从 a[href*="thread"] 提取tid和url（对齐官方）
                Element threadLink = doc.selectFirst("a[href*=thread]");
                if (threadLink != null) {
                    String href = threadLink.attr("href");
                    redirectUrl = href;
                    tid = extractTidFromUrl(href);
                }

                String message = "发帖成功";
                if (!TextUtils.isEmpty(text)) {
                    message = text;
                }

                return new PostResult(true, message, tid, redirectUrl);
            }

            // 3. 无 .alert_right 时，用正则匹配 location.href 跳转URL（对齐官方）
            String pageHtml = doc.html();
            Matcher urlMatcher = Pattern.compile(
                    "location\\.href\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(pageHtml);
            if (urlMatcher.find()) {
                String redirectUrl = urlMatcher.group(1);
                String tid = extractTidFromUrl(redirectUrl);
                return new PostResult(true, "发帖成功", tid, redirectUrl);
            }

            // 4. 用正则匹配 var tid = parseInt('123456')（对齐官方）
            Matcher tidMatcher = Pattern.compile(
                    "var\\s+tid\\s*=\\s*parseInt\\s*\\(\\s*['\"](\\d+)['\"]\\s*\\)").matcher(pageHtml);
            if (tidMatcher.find()) {
                String tid = tidMatcher.group(1);
                // 构建thread URL（对齐官方: "thread-" + tid + "-1-1.html"）
                String redirectUrl = "thread-" + tid + "-1-1.html";

                // 从标题元素提取（对齐官方: h1.ts, span#thread_subject, #thread_subject）
                String title = extractResultTitle(doc);
                String message = "发帖成功";
                if (!TextUtils.isEmpty(title)) {
                    message = "发帖成功：" + title;
                }

                return new PostResult(true, message, tid, redirectUrl);
            }

            // 5. 从 link[rel=canonical][href*=thread-] 提取（对齐官方）
            Element canonical = doc.selectFirst("link[rel=canonical][href*=thread-]");
            if (canonical != null) {
                String href = canonical.attr("href");
                String tid = extractTidFromUrl(href);

                String title = extractResultTitle(doc);
                String message = "发帖成功";
                if (!TextUtils.isEmpty(title)) {
                    message = "发帖成功：" + title;
                }

                return new PostResult(true, message, tid, href);
            }

            // 6. 从 a[href*=thread-].s.xst 提取（对齐官方）
            Element threadLink = doc.selectFirst("a[href*=thread-].s.xst");
            if (threadLink != null) {
                String href = threadLink.attr("href");
                String tid = extractTidFromUrl(href);
                String title = extractTitleText(threadLink);

                String message = "发帖成功";
                if (!TextUtils.isEmpty(title)) {
                    message = "发帖成功：" + title;
                }

                return new PostResult(true, message, tid, href);
            }

            // 7. 检查 .alert_info（对齐官方）
            Element alertInfo = doc.selectFirst(".alert_info");
            if (alertInfo != null) {
                String text = alertInfo.text().trim();
                if (!TextUtils.isEmpty(text)) {
                    return new PostResult(false, text, null, null);
                }
            }

            // 8. 检查 #messagetext（对齐官方）
            Element messageText = doc.selectFirst("#messagetext");
            if (messageText != null) {
                String text = messageText.text().trim();
                if (!TextUtils.isEmpty(text)) {
                    return new PostResult(false, text, null, null);
                }
            }

            // 9. 兜底（对齐官方: "发帖失败，请稍后重试"）
            return new PostResult(false, "发帖失败，请稍后重试", null, null);

        } catch (Exception e) {
            return new PostResult(false, "发帖失败，请稍后重试", null, null);
        }
    }

    // ==================== extractTidFromUrl ====================

    /**
     * 从URL中提取tid（对齐官方 extractTidFromUrl）
     * 支持: tid=(\d+) 和 thread-(\d+)
     *
     * @param url URL字符串
     * @return tid，未找到返回null
     */
    public static String extractTidFromUrl(String url) {
        if (TextUtils.isEmpty(url)) return null;

        // 尝试 tid=(\d+)
        Matcher m = Pattern.compile("tid=(\\d+)").matcher(url);
        if (m.find()) return m.group(1);

        // 尝试 thread-(\d+)
        m = Pattern.compile("thread-(\\d+)").matcher(url);
        if (m.find()) return m.group(1);

        return null;
    }

    // ==================== 辅助方法 ====================

    /**
     * 从元素提取标题文本（对齐官方 HomeParserUtils.extractTitleText）
     * 取元素的 ownText，如果为空则取 text()
     */
    private static String extractTitleText(Element el) {
        if (el == null) return null;
        String text = el.ownText().trim();
        if (TextUtils.isEmpty(text)) {
            text = el.text().trim();
        }
        return TextUtils.isEmpty(text) ? null : text;
    }

    /**
     * 从结果页面提取标题（对齐官方: h1.ts, span#thread_subject, #thread_subject）
     */
    private static String extractResultTitle(Document doc) {
        if (doc == null) return null;

        Element el = doc.selectFirst("h1.ts");
        if (el != null) {
            String text = extractTitleText(el);
            if (!TextUtils.isEmpty(text)) return text;
        }

        el = doc.selectFirst("span#thread_subject");
        if (el != null) {
            String text = extractTitleText(el);
            if (!TextUtils.isEmpty(text)) return text;
        }

        el = doc.selectFirst("#thread_subject");
        if (el != null) {
            String text = extractTitleText(el);
            if (!TextUtils.isEmpty(text)) return text;
        }

        return null;
    }
}
