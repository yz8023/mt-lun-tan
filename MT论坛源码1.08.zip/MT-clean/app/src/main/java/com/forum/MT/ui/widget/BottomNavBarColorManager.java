package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/**
 * 底部导航栏自定义颜色管理。
 *
 * 用户可在主题设置页为底部导航栏选择背景颜色、选中文字/图标颜色、未选中颜色。
 * 颜色为 0 时表示使用默认样式（默认白底 / 主色高亮 / 灰色未选中）。
 *
 * 偏好键：
 *   nav_bar_bg_color       (int, 0 表示默认白色)
 *   nav_bar_active_color   (int, 0 表示默认主色 #FF4081)
 *   nav_bar_inactive_color (int, 0 表示默认灰色 #757575)
 *   nav_post_bg_color      (int, 0 表示默认主色 #FF4081)
 *   nav_post_icon_color    (int, 0 表示默认白色)
 */
public final class BottomNavBarColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_BG = "nav_bar_bg_color";
    public static final String KEY_ACTIVE = "nav_bar_active_color";
    public static final String KEY_INACTIVE = "nav_bar_inactive_color";
    public static final String KEY_POST_BG = "nav_post_bg_color";
    public static final String KEY_POST_ICON = "nav_post_icon_color";

    /** 默认背景色（蓝紫） */
    public static final int DEFAULT_BG = 0xFF575996;
    /** 默认选中色（橙色） */
    public static final int DEFAULT_ACTIVE = 0xFFFF9800;
    /** 默认未选中色 */
    public static final int DEFAULT_INACTIVE = Color.rgb(117, 117, 117);
    /** 默认发帖按钮背景色（橙色） */
    public static final int DEFAULT_POST_BG = 0xFFFF9800;
    /** 默认发帖按钮 "+" 图标色 */
    public static final int DEFAULT_POST_ICON = Color.WHITE;

    private static volatile int bgColor = 0;
    private static volatile int activeColor = 0;
    private static volatile int inactiveColor = 0;
    private static volatile int postBgColor = 0;
    private static volatile int postIconColor = 0;

    private BottomNavBarColorManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        bgColor = prefs.getInt(KEY_BG, 0);
        activeColor = prefs.getInt(KEY_ACTIVE, 0);
        inactiveColor = prefs.getInt(KEY_INACTIVE, 0);
        postBgColor = prefs.getInt(KEY_POST_BG, 0);
        postIconColor = prefs.getInt(KEY_POST_ICON, 0);
    }

    public static int getBgColor() { return bgColor; }
    public static int getActiveColor() { return activeColor; }
    public static int getInactiveColor() { return inactiveColor; }
    public static int getPostBgColor() { return postBgColor; }
    public static int getPostIconColor() { return postIconColor; }

    /** 设置背景颜色，0 表示恢复默认。持久化 + 回调刷新。 */
    public static void setBgColor(Context context, int color) {
        bgColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_BG, color).apply();
        }
        notifyChanged();
    }

    public static void setActiveColor(Context context, int color) {
        activeColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_ACTIVE, color).apply();
        }
        notifyChanged();
    }

    public static void setInactiveColor(Context context, int color) {
        inactiveColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_INACTIVE, color).apply();
        }
        notifyChanged();
    }

    /** 设置发帖按钮背景色，0 表示恢复默认（主色）。持久化 + 回调刷新。 */
    public static void setPostBgColor(Context context, int color) {
        postBgColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_POST_BG, color).apply();
        }
        notifyChanged();
    }

    /** 设置发帖按钮 "+" 图标色，0 表示恢复默认（白色）。持久化 + 回调刷新。 */
    public static void setPostIconColor(Context context, int color) {
        postIconColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_POST_ICON, color).apply();
        }
        notifyChanged();
    }

    /** 当前应使用的导航栏背景色。 */
    public static int resolveBgColor() {
        return bgColor != 0 ? bgColor : DEFAULT_BG;
    }

    /** 当前选中颜色。 */
    public static int resolveActiveColor() {
        return activeColor != 0 ? activeColor : DEFAULT_ACTIVE;
    }

    /** 当前未选中颜色。 */
    public static int resolveInactiveColor() {
        return inactiveColor != 0 ? inactiveColor : DEFAULT_INACTIVE;
    }

    /** 当前发帖按钮背景色。 */
    public static int resolvePostBgColor() {
        return postBgColor != 0 ? postBgColor : DEFAULT_POST_BG;
    }

    /** 当前发帖按钮 "+" 图标色。 */
    public static int resolvePostIconColor() {
        return postIconColor != 0 ? postIconColor : DEFAULT_POST_ICON;
    }

    /** 判断发帖按钮背景是否为深色（深色背景时 "+" 图标宜用白色）。 */
    public static boolean isPostBgDark() {
        int color = resolvePostBgColor();
        if (color == Color.TRANSPARENT) return false;
        double r = Color.red(color) / 255.0;
        double g = Color.green(color) / 255.0;
        double b = Color.blue(color) / 255.0;
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance < 0.45;
    }

    /** 判断选中色是否为浅色（用于选择对比文字色时参考）。 */
    public static boolean isActiveLight() {
        int color = resolveActiveColor();
        double r = Color.red(color) / 255.0;
        double g = Color.green(color) / 255.0;
        double b = Color.blue(color) / 255.0;
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.5;
    }

    /** 判断背景是否为深色（导航栏背景深色时，未选中文字/图标宜用浅色）。 */
    public static boolean isBgDark() {
        int color = resolveBgColor();
        if (color == Color.TRANSPARENT) return false;
        double r = Color.red(color) / 255.0;
        double g = Color.green(color) / 255.0;
        double b = Color.blue(color) / 255.0;
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance < 0.45;
    }

    /** 变更回调（MainActivity 注册用于实时刷新导航栏）。 */
    public interface OnColorChangedListener {
        void onNavColorsChanged();
    }

    private static volatile OnColorChangedListener listener;

    /** 注册导航栏颜色变更回调。 */
    public static void setListener(OnColorChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnColorChangedListener l = listener;
        if (l != null) l.onNavColorsChanged();
    }
}