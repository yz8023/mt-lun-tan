package com.forum.MT.ui.detail;
import com.forum.MT.ui.BaseActivity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.os.Bundle;
    import android.graphics.ColorFilter;
    import android.graphics.PixelFormat;
    import android.graphics.drawable.Drawable;
    import android.graphics.Rect;
    import android.text.Html;
    import android.text.Spannable;
    import android.text.SpannableString;
    import android.text.TextUtils;
    import android.text.util.Linkify;
    import android.text.method.LinkMovementMethod;
    import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.view.View;
    import android.util.DisplayMetrics;
    import android.util.Log;
    import android.view.Gravity;
    import android.view.LayoutInflater;
    import android.view.MotionEvent;
    import android.view.View;
    import android.view.ViewGroup;
import android.view.ViewTreeObserver;
    import android.media.MediaPlayer;
    import android.widget.HorizontalScrollView;
import android.widget.FrameLayout;
import android.widget.ImageView;
    import android.widget.LinearLayout;
    import android.widget.TextView;
    import android.widget.Toast;
    import android.app.AlertDialog;
    import android.app.Dialog;
    import android.widget.Spinner;
    import android.widget.Switch;
    import android.text.Editable;
    import android.widget.EditText;
    import android.widget.ArrayAdapter;
    import android.widget.Button;
import android.content.Intent;
    import android.content.SharedPreferences;
    import android.content.Context;
import android.database.Cursor;
import android.provider.OpenableColumns;
    import android.net.Uri;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;

    import androidx.activity.result.ActivityResultLauncher;
    import androidx.activity.result.PickVisualMediaRequest;
    import androidx.activity.result.contract.ActivityResultContracts;
    import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.request.transition.Transition;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.forum.MT.R;
import com.forum.MT.databinding.ThreadDetailActivityBinding;
import com.forum.MT.model.BrowseHistory;
import com.forum.MT.model.PostDetail;
import com.forum.MT.model.Poll;
import com.forum.MT.model.ReplyItem;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.session.FollowStateManager;
import com.forum.MT.session.UserSessionManager;
import com.forum.MT.storage.HistoryStore;

import com.forum.MT.ui.post.EditPostActivity;
import com.forum.MT.ui.space.UserProfileActivity;
import com.forum.MT.ui.widget.ReplyBlacklistManager;
import com.forum.MT.ui.widget.AutoLoadMoreManager;
import com.forum.MT.ui.widget.LoadAllRepliesManager;
import com.forum.MT.ui.widget.NestedScrollRepliesManager;
import com.forum.MT.ui.widget.SwipeCommentManager;
import com.forum.MT.ui.widget.SwipeCommentHelper;
    import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import com.forum.MT.ui.widget.HomeBarColorManager;
import com.forum.MT.ui.widget.PollBarColorManager;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 帖子详情 Activity（原生版）
 * 完全移除 WebView，使用原生组件 + 数据驱动架构
 */
public class ThreadDetailActivity extends BaseActivity {

    private ThreadDetailActivityBinding binding;
    private HttpClient httpClient;
    private String tid;
    private String targetPid;      // 通知点击跳转时，定位到具体回复楼层
    private PostDetail postDetail;

    // ==================== 配色变更自动重渲染缓存 ====================
    private String cachedContentHtml;            // 正文 HTML（含占位符，已分离图片/引用/代码/表格）
    private List<TableData> cachedMainTables = new ArrayList<>();
    private List<String> cachedImageUrls = new ArrayList<>();
    private List<QuoteCardRef> cachedQuoteCards = new ArrayList<>();
    private List<CodeCardRef> cachedCodeCards = new ArrayList<>();
    private List<HiddenCardRef> cachedHiddenCards = new ArrayList<>();
    private int cachedThemeFingerprint = Integer.MIN_VALUE;
    // 预提取的附件卡片列表（在 bindData 中提取，renderContentWithInlineTables 复用）
    private List<AttachmentCardRef> mPreExtractedAttachmentCards = null;
    // 预提取的内联大图URL列表（在 bindData 中提取，renderContentWithInlineTables 渲染为独立 ImageView）
    private List<String> mInlineImageUrls = new ArrayList<>();
    // ★ 记录已加载失败的内联图片URL，避免返回页面时 Glide 恢复请求导致闪烁旧缓存图
    private final java.util.Set<String> mFailedImageUrls = java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<>());
    private ReplyAdapter replyAdapter;
    // 评论区筛选与排序：默认按时间倒序（最新在前）。
    private boolean onlyOpReplies = false;
    private boolean repliesDescending;
    /** 置顶请求单飞标记：避免重复点击打出多组互相覆盖的 stickreply 请求。 */
    private boolean mReplyPinInProgress = false;
    private List<ReplyItem> displayedReplies = new ArrayList<>();
    private boolean isLiked = false;
    private int likeCount = 0;
    private boolean isFavorited = false;
    private int favoriteCount = 0;
    private Uri pendingImageUri = null;
    // 已成功上传、但尚未随回复提交确认的附件。回复支持连续插入多张图片。
    private final List<String> pendingUploadAids = new ArrayList<>();
    private boolean imageUploadInProgress = false;
    // 从通知携带 pid 进入时，先完成目标楼层定位；本次会话内先抑制自动加载更多/自动加载全部，
    // 避免定位到目标页后又从后续页继续自动追加，导致页数错乱。
    private boolean mSuppressAutoReplyLoadingForTarget = false;

    // ==================== 滑动切换评论区 ====================
    private boolean swipeCommentMode = false;
    private boolean isCommentPageVisible = false;
    private View commentSectionView = null;
    private ViewGroup commentSectionParent = null;
    private int commentSectionIndex = 0;
    // 自定义滑动控制器
    private SwipeCommentHelper swipeHelper = null;
    private android.view.ActionMode currentActionMode = null;

    // 底部输入框点击后弹出的"回复/评论"弹窗（仿官方安装包交互）
    private Dialog mThreadReplyDialog;
    private EditText mThreadDialogReplyInput;

    // 图片选择器
    private final ActivityResultLauncher<PickVisualMediaRequest> pickMedia =
            registerForActivityResult(new ActivityResultContracts.PickVisualMedia(), uri -> {
                if (uri != null) {
                    pendingImageUri = uri;
                    // 上传图片并嵌入回复
                    uploadAndAttachImage(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ThreadDetailActivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        httpClient = HttpClient.getInstance();

        // 读取评论默认排序设置（时间倒序/正序）
        repliesDescending = getSharedPreferences("reply_order_pref", MODE_PRIVATE)
                .getBoolean("replies_descending_default", true);

        // 获取传入的 tid
        tid = getIntent().getStringExtra("tid");
        if (tid == null) {
            finish();
            return;
        }
        targetPid = getIntent().getStringExtra("pid");
        mSuppressAutoReplyLoadingForTarget = !TextUtils.isEmpty(targetPid);

        // Toolbar 返回（★ 移除箭头图标，仅保留点击功能）
        binding.toolbar.setNavigationIcon(null);
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        // 设置下拉刷新
        binding.swipeRefresh.setOnRefreshListener(this::refreshPostDetail);

        // 初始化回复列表
        setupRecyclerView();

        // 滑动切换评论区模式
        setupSwipeCommentMode();

        // 评论边框/背景颜色变更时刷新评论列表
        com.forum.MT.ui.widget.CommentBorderDrawable.setListener(() -> {
            if (isFinishing() || isDestroyed()) return;
            runOnUiThread(() -> {
                if (replyAdapter != null) replyAdapter.notifyDataSetChanged();
            });
        });


        // 帖子详情页自定义背景颜色变更时刷新页面
        com.forum.MT.ui.widget.HomeBarColorManager.setListener(() -> {
            if (isFinishing() || isDestroyed()) return;
            runOnUiThread(() -> applyThreadPageColors());
        });
        applyThreadPageColors();

        // 输入框回车发送：改为点击输入框弹出"回复/评论"弹窗
        binding.etReply.setOnClickListener(v -> showThreadReplyDialog());
        // 底部输入框为只读展示，点击弹出弹窗，不唤起软键盘
        binding.etReply.setShowSoftInputOnFocus(false);

        // 底部输入框不再直接聚焦输入（改为弹窗），回车发送逻辑保留供弹窗使用
        binding.etReply.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                attemptReply();
                return true;
            }
            return false;
        });

        // 表情按钮（弹出表情面板；未打开弹窗时先弹出弹窗）
        // （底部快捷栏已去除表情/图片按钮，表情与图片操作统一在回复弹窗内完成）

        // 图片选择按钮（未打开弹窗时先弹出弹窗）

        // 评论按钮滚动到评论区
        binding.btnComments.setOnClickListener(v -> smoothScrollToComments());
        binding.btnLike.setOnClickListener(v -> toggleLike());

        // 收藏按钮
        binding.btnFavorite.setOnClickListener(v -> toggleFavorite());

        // 分享按钮
        binding.btnShare.setOnClickListener(v -> shareThread());

        // 查看隐藏内容：弹出回复输入框（回复后即可查看）
        binding.btnViewHidden.setOnClickListener(v -> showThreadReplyDialog());

        // 加载更多回复
        binding.btnLoadMore.setOnClickListener(v -> {
            // 用户手动点击“加载更多”后，解除通知定位阶段的自动加载抑制，
            // 后续是否继续加载完全交给用户显式操作控制。
            mSuppressAutoReplyLoadingForTarget = false;
            // 如果正在加载全部回复，点击则取消
            if (mCancelLoadAll == false && !binding.btnLoadMore.isEnabled()) {
                mCancelLoadAll = true;
                binding.btnLoadMore.setText("取消中…");
                return;
            }
            loadMoreReplies();
        });

        // 自动加载更多回复：滑动到回复底部时自动触发
        setupAutoLoadMore();

        // 评论区筛选：只看楼主
        binding.btnOnlyOp.setOnClickListener(v -> {
            onlyOpReplies = !onlyOpReplies;
            updateReplyFilterAndOrder();
        });

        // 评论区排序：默认倒序，切换后按新的 order 参数重新请求服务端。
        binding.btnReplyOrder.setOnClickListener(v -> {
            repliesDescending = !repliesDescending;
            // 不能只反转当前内存列表；必须从第1页按新排序重新加载，
            // 这样跨页评论也会使用同一套服务端排序规则。
            refreshPostDetail();
        });

        // 评论区黑名单管理
        binding.btnReplyBlacklist.setOnClickListener(v -> showBlacklistDialog());

        // 赞赏按钮
    binding.btnReward.setOnClickListener(v -> showRewardDialog(null));

    // 踢帖按钮
    binding.btnKick.setOnClickListener(v -> performKick());

    // 加载帖子详情
        loadPostDetail();
    }

        // 右上角不显示任何功能菜单。

    // ==================== 初始化 ====================

    private void setupRecyclerView() {
        replyAdapter = new ReplyAdapter(new ArrayList<>());
        replyAdapter.setOnReplyClickListener((item, position) -> {
            // 点击回复按钮：弹窗回复该楼层（仿官方安装包交互，不再预填"回复 xx："到输入框）
            if (item != null && !TextUtils.isEmpty(item.getPid())) {
                showReplyCommentDialog(item);
            } else {
                // 兜底：没有 pid 时退化为普通回复栏
                binding.etReply.setText("");
                binding.etReply.requestFocus();
                binding.nestedScroll.smoothScrollBy(0, binding.layoutReply.getHeight() + 200);
            }
        });
        replyAdapter.setOnUserClickListener((item, position) -> {
            String uid = item.getAuthorUid();
            if (!TextUtils.isEmpty(uid)) {
                Intent intent = new Intent(ThreadDetailActivity.this, UserProfileActivity.class);
                intent.putExtra("uid", uid);
                intent.putExtra("username", item.getAuthor());
                startActivity(intent);
            }
        });
        // 评论打赏：复用 showRewardDialog，传入该 ReplyItem 作为打赏目标。
        replyAdapter.setOnRewardClickListener((item, position) -> showRewardDialog(item));
        // 评论举报：弹窗选择原因后提交 Discuz 举报接口。
        replyAdapter.setOnReportClickListener((item, position) -> showReplyReportDialog(item));
        // 评论编辑：仅自己的楼层显示入口，进入编辑页拉取原文后修改。
        replyAdapter.setOnEditClickListener((item, position) -> startEditReply(item));
        // 评论置顶：仅自己的楼层显示，走 Discuz topicadmin stickreply 接口。
        replyAdapter.setOnPinClickListener((item, position) -> toggleReplyPin(item));
        replyAdapter.setCurrentUid(UserSessionManager.getInstance().getUid(this));
        binding.recyclerReplies.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerReplies.setAdapter(replyAdapter);
    }

    // ==================== 滑动切换评论区 ====================

    /**
     * 初始化滑动切换评论区模式（类似小黑盒）。
     * 评论区作为全屏覆盖层从右侧滑入，跟随手指实时平移。
     */
    private void setupSwipeCommentMode() {
        swipeCommentMode = SwipeCommentManager.isEnabled(this);
        if (!swipeCommentMode) return;

        // 1. 找到评论区视图
        commentSectionView = binding.layoutCommentSection;
        commentSectionParent = (ViewGroup) commentSectionView.getParent();
        commentSectionIndex = commentSectionParent.indexOfChild(commentSectionView);
        commentSectionParent.removeView(commentSectionView);

        // 2. 找到 SwipeRefreshLayout（正文页）的父容器
        ViewGroup contentFrame = (ViewGroup) binding.swipeRefresh.getParent();
        contentFrame.removeView(binding.swipeRefresh);

        // 3. 把正文页和评论区叠放在 overlay 容器（FrameLayout）
        FrameLayout overlay = binding.frameCommentOverlay;
        overlay.removeAllViews();
        overlay.setVisibility(View.VISIBLE);

        int screenW = getResources().getDisplayMetrics().widthPixels;

        // 正文页：占满 overlay（底层）
        FrameLayout.LayoutParams contentLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        overlay.addView(binding.swipeRefresh, contentLp);

        // 评论区：占满 overlay（上层，初始在屏幕右侧外）
        FrameLayout.LayoutParams commentLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        overlay.addView(commentSectionView, commentLp);

        // 4. RecyclerView 填满评论区剩余高度，关闭嵌套滚动（不再有 NestedScrollView 作为父容器）
        // ★ 必须用 height=0 + weight=1 而不是 MATCH_PARENT：
        //   layout_comment_section 是竖向 LinearLayout，MATCH_PARENT 会吃掉标题栏之外的
        //   全部剩余高度，把下方的 btn_load_more / tv_empty_replies 挤出可视区，
        //   导致右滑评论区看不到“加载更多回复”按钮。
        binding.recyclerReplies.setNestedScrollingEnabled(false);
        ViewGroup.LayoutParams rp = binding.recyclerReplies.getLayoutParams();
        if (rp instanceof LinearLayout.LayoutParams) {
            LinearLayout.LayoutParams llp = (LinearLayout.LayoutParams) rp;
            llp.height = 0;
            llp.weight = 1f;
            binding.recyclerReplies.setLayoutParams(llp);
        } else {
            rp.height = ViewGroup.LayoutParams.MATCH_PARENT;
            binding.recyclerReplies.setLayoutParams(rp);
        }

        // 5. 显示 Toolbar 中的"评论"小标题
        binding.tvTitleComment.setVisibility(View.VISIBLE);

        // 6. 标题点击切换
        binding.tvTitleThread.setOnClickListener(v -> showMainPage());
        binding.tvTitleComment.setOnClickListener(v -> showCommentPage());

        // 7. 滑动手势控制器
        swipeHelper = new SwipeCommentHelper(this, binding.swipeRefresh,
                commentSectionView, overlay,
                () -> isCommentPageVisible,
                (visible) -> {
                    isCommentPageVisible = visible;
                    updateTitleState();
                });

        // 8. 插入半透明遮罩（正文页之上，评论区之下）
        swipeHelper.setupScrim();

        // 初始状态：正文页（确保评论区在屏幕右侧外且不可见）
        isCommentPageVisible = false;
        updateTitleState();
        commentSectionView.setTranslationX(getResources().getDisplayMetrics().widthPixels);
        commentSectionView.setVisibility(View.INVISIBLE);
    }

    /**
     * 更新 Toolbar 标题状态：切换时"帖子详情"和"评论"交换大小/位置
     */
    private void updateTitleState() {
        if (!swipeCommentMode) return;
        if (isCommentPageVisible) {
            binding.tvTitleThread.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13);
            binding.tvTitleThread.setTextColor(getResources().getColor(R.color.text_secondary));
            binding.tvTitleThread.setTypeface(null, android.graphics.Typeface.NORMAL);
            binding.tvTitleComment.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18);
            binding.tvTitleComment.setTextColor(getResources().getColor(R.color.text_primary));
            binding.tvTitleComment.setTypeface(null, android.graphics.Typeface.BOLD);
        } else {
            binding.tvTitleThread.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18);
            binding.tvTitleThread.setTextColor(getResources().getColor(R.color.text_primary));
            binding.tvTitleThread.setTypeface(null, android.graphics.Typeface.BOLD);
            binding.tvTitleComment.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13);
            binding.tvTitleComment.setTextColor(getResources().getColor(R.color.text_secondary));
            binding.tvTitleComment.setTypeface(null, android.graphics.Typeface.NORMAL);
        }
    }

    /**
     * 按适配器实际条数同步"暂无回复"空状态与列表可见性。
     *
     * <p>为什么需要独立成一个方法：过滤结果为空时 {@code applyFilterResult} 会把
     * {@code recyclerReplies} 置为 GONE、{@code tvEmptyReplies} 置为 VISIBLE。
     * 但当"加载全部评论"开启时，后续页由 {@link #loadAllReplies()} 通过
     * {@code replyAdapter.appendItems()} 增量追加，那条路径只发
     * {@code notifyItemRangeInserted}，既不重新过滤也不触碰可见性
     * （见 loadAllReplies 收尾处"不再重复过滤，只更新按钮状态"的注释）。
     * 于是出现过：黑名单把第 1 页全部命中 → 列表被隐藏 → 后续页数据已进适配器，
     * 但界面仍停在"暂无回复"（例：thread-172019，黑名单 177 词、共 2 页）。
     *
     * <p>以 {@code replyAdapter.getItemCount()} 为唯一判据，两条路径共用，
     * 避免可见性状态和适配器内容脱节。必须在主线程调用。
     */
    private void syncRepliesEmptyState() {
        if (binding == null || replyAdapter == null) return;
        boolean hasReplies = replyAdapter.getItemCount() > 0;
        binding.recyclerReplies.setVisibility(hasReplies ? View.VISIBLE : View.GONE);
        binding.tvEmptyReplies.setVisibility(hasReplies ? View.GONE : View.VISIBLE);
    }

    /**
     * 滑动到评论区页
     */
    private void showCommentPage() {
        if (!swipeCommentMode) return;
        if (isCommentPageVisible) return;
        isCommentPageVisible = true;
        updateTitleState();
        if (com.forum.MT.util.Dbg.ON) Log.e("MT_SWIPE", "showCommentPage: calling openCommentPage, swipeHelper=" + (swipeHelper != null));
        if (swipeHelper != null) swipeHelper.openCommentPage();
    }

    /**
     * 回到正文页
     */
    private void hideCommentPage() {
        if (!swipeCommentMode) return;
        if (!isCommentPageVisible) return;
        isCommentPageVisible = false;
        updateTitleState();
        if (swipeHelper != null) swipeHelper.closeCommentPage();
    }

    /** showMainPage = hideCommentPage 的别名，供 Tab 点击调用 */
    private void showMainPage() {
        hideCommentPage();
    }

    /**
     * 滑动切换模式：在 dispatchTouchEvent 中拦截水平滑动
     */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (swipeCommentMode && swipeHelper != null) {
            if (ev.getActionMasked() == MotionEvent.ACTION_MOVE && currentActionMode != null) {
                finishCurrentActionMode();
            }
            if (swipeHelper.handleDispatchTouchEvent(ev)) {
                return true;
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onActionModeStarted(android.view.ActionMode mode) {
        super.onActionModeStarted(mode);
        currentActionMode = mode;
    }

    @Override
    public void onActionModeFinished(android.view.ActionMode mode) {
        super.onActionModeFinished(mode);
        if (currentActionMode == mode) {
            currentActionMode = null;
        }
    }

    /**
     * 关闭当前文字选择 ActionMode（复制浮动栏）
     */
    public void finishCurrentActionMode() {
        if (currentActionMode != null) {
            currentActionMode.finish();
            currentActionMode = null;
        }
    }

    // ==================== 数据加载 ====================

    /**
     * 首次加载帖子详情
     * ★ 优化：只发 1 个主 HTTP 请求，附加数据（好文头像/打赏/收藏状态）异步后台加载
     */
    private void loadPostDetail() {
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.swipeRefresh.setEnabled(false);

        new Thread(() -> {
            try {
                String detailUrl = ForumParser.getThreadDetailUrl(tid, getReplyOrder());
                httpClient.syncFromCookieManager();
                String html = httpClient.get(detailUrl);
                if (TextUtils.isEmpty(html)) {
                    throw new IllegalStateException("服务器返回空页面，请检查网络后重试");
                }
                PostDetail detail = ForumParser.parseThreadDetail(html);
                if (detail == null) {
                    throw new IllegalStateException("帖子内容解析失败");
                }
                if (!TextUtils.isEmpty(detail.getAuthorUid())) {
                    detail.setFollowed(FollowStateManager.resolve(ThreadDetailActivity.this,
                            detail.getAuthorUid(), detail.isFollowed()));
                }

                runOnUiThread(() -> {
                    // ★ 崩溃守卫：若用户在请求完成前退出了详情页，Activity 已销毁，
                    // Glide.with(this) 会抛 "You cannot start a load for a destroyed activity"。
                    if (isFinishing() || isDestroyed()) return;
                    bindData(detail);
                    // ★ 附加数据（好文头像/打赏/收藏状态）异步加载，加载完成后增量更新 UI
                    loadExtraDetailData(detail);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    binding.progressBar.setVisibility(View.GONE);
                    binding.swipeRefresh.setEnabled(true);
                    String message = TextUtils.isEmpty(e.getMessage())
                            ? "网络异常，请下拉刷新重试" : e.getMessage();
                    Toast.makeText(ThreadDetailActivity.this,
                            "加载失败: " + message, Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    /**
     * 生成当前排序下的详情页 URL。
     * 关键点：切换排序时必须清理旧的 currentPage/已加载列表，
     * 由服务端从第1页返回新的顺序。
     */
    private String getReplyOrderUrl() {
        return ForumParser.getThreadDetailUrl(tid, getReplyOrder());
    }

    /**
     * 下拉刷新
     * ★ 优化：只发 1 个主 HTTP 请求，附加数据异步加载
     */
    private void refreshPostDetail() {
        new Thread(() -> {
            try {
                String detailUrl = ForumParser.getThreadDetailUrl(tid, getReplyOrder());
                httpClient.syncFromCookieManager();
                String html = httpClient.get(detailUrl);
                if (TextUtils.isEmpty(html)) {
                    throw new IllegalStateException("服务器返回空页面，请检查网络后重试");
                }
                PostDetail detail = ForumParser.parseThreadDetail(html);
                 if (detail == null) {
                     throw new IllegalStateException("帖子内容解析失败");
                 }
                if (!TextUtils.isEmpty(detail.getAuthorUid())) {
                    detail.setFollowed(FollowStateManager.resolve(ThreadDetailActivity.this,
                            detail.getAuthorUid(), detail.isFollowed()));
                }

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    binding.swipeRefresh.setRefreshing(false);
                    // ★ 刷新后恢复点赞/收藏的本地状态，避免被重置
                    applyServerActionState(detail);
                    likeCount = Math.max(0, detail.getLikeCount());
                    favoriteCount = Math.max(0, detail.getFavoriteCount());
                    updateLikeIcon();
                    updateFavoriteIcon();
                    updateCountBadge(binding.tvFavoriteBadge, favoriteCount);
                    bindData(detail);
                    // ★ 附加数据异步加载
                    loadExtraDetailData(detail);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    binding.swipeRefresh.setRefreshing(false);
                    String message = TextUtils.isEmpty(e.getMessage())
                            ? "网络异常，请稍后重试" : e.getMessage();
                    Toast.makeText(ThreadDetailActivity.this,
                            "刷新失败: " + message, Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    // ==================== 数据绑定 ====================

    /**
     * ★ 优化：附加数据异步加载
     * 主请求 bindData 完成后再后台加载：好文头像 / 打赏金币 / 收藏状态。
     * 加载完成后 runOnUiThread 增量更新 UI，不重新 bind、不打断阅读。
     */
    private void loadExtraDetailData(final PostDetail detail) {
        if (detail == null) return;
        new Thread(() -> {
            final boolean[] changed = {false};
            try {
                if (detail.getGoodReviewCount() > 0) {
                    String desktopHtml = httpClient.getDesktop(ForumParser.getThreadDesktopDetailUrl(tid));
                    List<String> avatars = ForumParser.parseGoodReviewAvatarUrls(desktopHtml);
                    if (avatars != null && !avatars.isEmpty()) {
                        detail.setGoodReviewUserAvatars(avatars);
                        changed[0] = true;
                    }
                }
            } catch (Exception ignored) {
            }
            try {
                if (!TextUtils.isEmpty(detail.getRewardDetailUrl())) {
                    String rewardHtml = httpClient.get(detail.getRewardDetailUrl());
                    detail.setRewardCoins(ForumParser.parseRewardCoins(rewardHtml));
                    changed[0] = true;
                }
            } catch (Exception ignored) {
            }
            // 收藏状态异步同步（仅登录用户）
            final boolean favLoaded = syncFavoriteStateFromServer(detail);
            if (favLoaded) changed[0] = true;

            final boolean needsUpdate = changed[0];
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (needsUpdate) {
                    updateRewardReviewSection(detail);
                    updateFavoriteIcon();
                    updateCountBadge(binding.tvFavoriteBadge, favoriteCount);
                }
            });
        }).start();
    }

    /**
     * 增量更新“赞赏/好评”区域（不重新 bindData）
     */
    private void updateRewardReviewSection(PostDetail detail) {
        if (detail == null || !httpClient.isLoggedIn() || isDestroyed() || isFinishing()) return;
        int rewardCount = detail.getRewardCount();
        int goodReviewCount = detail.getGoodReviewCount();
        int rewardCoins = detail.getRewardCoins();
        List<String> rewardAvatars = detail.getRewardUserAvatars();
        List<String> goodReviewAvatars = detail.getGoodReviewUserAvatars();
        boolean hasData = rewardCount > 0 || goodReviewCount > 0
                || (rewardAvatars != null && !rewardAvatars.isEmpty())
                || (goodReviewAvatars != null && !goodReviewAvatars.isEmpty());
        if (hasData) {
            binding.layoutRewardReviewStats.setVisibility(View.VISIBLE);
            binding.tvRewardCount.setText(String.valueOf(rewardCount));
            binding.tvRewardCoins.setText("共计 " + rewardCoins + " 金币");
            binding.tvGoodReviewCount.setText(String.valueOf(goodReviewCount));
            bindAvatarStrip(binding.llRewardAvatars, rewardAvatars);
            bindAvatarStrip(binding.llGoodReviewAvatars, goodReviewAvatars);
        }
    }

    // ==================== 数据绑定 ====================

    /**
     * 将解析后的 PostDetail 绑定到所有原生视图
     */
    private void dbgFile(String tag, String msg) {
        try {
            java.io.File f = new java.io.File(getCacheDir(), "mt_render_debug.txt");
            java.io.FileWriter fw = new java.io.FileWriter(f, true);
            fw.write(tag + ": " + msg + "\n");
            fw.close();
        } catch (Exception ignored) {}
    }

    private void bindData(PostDetail detail) {
        dbgFile("bindData", "START tid=" + tid);
        if (detail == null) {
            dbgFile("bindData", "detail is NULL!");
            binding.progressBar.setVisibility(View.GONE);
            binding.swipeRefresh.setEnabled(true);
            Toast.makeText(this, "帖子内容为空，请下拉刷新重试", Toast.LENGTH_SHORT).show();
            return;
        }
        this.postDetail = detail;
        binding.progressBar.setVisibility(View.GONE);
        binding.swipeRefresh.setEnabled(true);
        // 顶栏编辑入口与评论区编辑按钮的可见性都依赖当前登录 uid，
        // 必须在拿到帖子作者后再同步一次。
        updateThreadEditEntry(detail);

        // 隐藏内容卡片列表（提升到方法级作用域，供正文块外判断是否使用了新机制）
        List<HiddenCardRef> hiddenCards = new ArrayList<>();

        // ---- 版块名称 ----
        if (!TextUtils.isEmpty(detail.getForumName())) {
            binding.tvForumName.setVisibility(View.VISIBLE);
            binding.tvForumName.setText(detail.getForumName());
        } else {
            binding.tvForumName.setVisibility(View.GONE);
        }

        // ---- 帖子标题 ----
        binding.tvThreadTitle.setText(
                !TextUtils.isEmpty(detail.getTitle()) ? detail.getTitle() : "");

        // ---- 作者信息栏 ----
        // 头像（Glide + CircleCrop）
        String avatarUrl = detail.getAvatarUrl();
        if (!TextUtils.isEmpty(avatarUrl)) {
            Glide.with(this)
                    .load(avatarUrl)
                    .transform(new CircleCrop())
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .into(binding.ivAuthorAvatar);
        } else {
            binding.ivAuthorAvatar.setImageResource(R.drawable.ic_account);
        }

        // 用户名
        binding.tvAuthorName.setText(
                !TextUtils.isEmpty(detail.getAuthor()) ? detail.getAuthor() : "匿名");

        // 记录浏览历史
        try {
            new HistoryStore(this).add(new BrowseHistory(
                    tid,
                    detail.getTitle(),
                    detail.getAuthor(),
                    detail.getAuthorUid(),
                    detail.getAvatarUrl(),
                    detail.getForumName(),
                    System.currentTimeMillis()
            ));
        } catch (Exception ignored) { }

        // ★ 新增：作者头像点击 → 原生用户资料页
        final String authorUid = detail.getAuthorUid();
        if (!TextUtils.isEmpty(authorUid)) {
            binding.ivAuthorAvatar.setOnClickListener(v -> {
                Intent intent = new Intent(ThreadDetailActivity.this, UserProfileActivity.class);
                intent.putExtra("uid", authorUid);
                intent.putExtra("username", detail.getAuthor());
                startActivity(intent);
            });
            binding.tvAuthorName.setOnClickListener(v -> {
                Intent intent = new Intent(ThreadDetailActivity.this, UserProfileActivity.class);
                intent.putExtra("uid", authorUid);
                intent.putExtra("username", detail.getAuthor());
                startActivity(intent);
            });
        }

        // 等级
        if (!TextUtils.isEmpty(detail.getAuthorLevel())) {
            binding.tvAuthorLevel.setVisibility(View.VISIBLE);
            binding.tvAuthorLevel.setText(detail.getAuthorLevel());
        } else {
            binding.tvAuthorLevel.setVisibility(View.GONE);
        }

        // 发布时间
        binding.tvPublishTime.setText(
                !TextUtils.isEmpty(detail.getPublishTime()) ? detail.getPublishTime() : "");

        // 帖子头部只保留发布时间。地点信息可能已经包含在时间文本中，隐藏重复的第二个地点标签。
        binding.tvLocation.setVisibility(View.GONE);

        // 关注 / 编辑按钮共用作者栏右侧位置，二者互斥：
        // 自己的帖子显示"编辑"（不能关注自己），别人的帖子显示"关注"。
        boolean isOwnThread = isSelfThread(detail);
        if (isOwnThread) {
            binding.btnFollow.setVisibility(View.GONE);
            binding.btnFollow.setOnClickListener(null);
        } else if (httpClient.isLoggedIn() && !TextUtils.isEmpty(detail.getAuthor())) {
            binding.btnFollow.setVisibility(View.VISIBLE);
            binding.btnFollow.setText(detail.isFollowed()
                    ? getString(R.string.action_followed) : getString(R.string.action_follow));
            binding.btnFollow.setOnClickListener(v -> toggleFollow());
        } else {
            binding.btnFollow.setVisibility(View.GONE);
        }

        // ---- 帖子正文（文本-图片分离渲染） ----
        // 1) 将Discuz! BBCode([attach]/[attachimg])转为img标签
        // 2) 提取HTML中的图片URL，3) 清理HTML文本，4) 渲染文本到tv_content，5) 图片动态加载到ll_images_container
        String rawHtml = detail.getContentHtml();
        dbgFile("rawHtml", "null=" + (rawHtml==null) + " length=" + (rawHtml==null?0:rawHtml.length()));
        if (rawHtml != null) {
            dbgFile("rawHtml_snippet", rawHtml.substring(0, Math.min(300, rawHtml.length())));
        }
        if (!TextUtils.isEmpty(rawHtml)) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[bindData] rawHtml length=" + rawHtml.length() + " snippet=" + rawHtml.substring(0, Math.min(200, rawHtml.length())));
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[bindData] rawHtml contains quote=" + rawHtml.contains("[quote]") + " blockquote=" + rawHtml.contains("blockquote") + " comiis_quote=" + rawHtml.contains("comiis_quote"));
            // ★ 关键修复：将 [attach]N[/attach] 和 [attachimg]N[/attachimg] 转换为真实 <img> 标签
            rawHtml = convertAttachBBCodeToImg(rawHtml);
            // 将 Discuz! 的文字链接 BBCode 转为 HTML 链接，避免原生 TextView 把它当普通文本。
            rawHtml = convertTextLinkBBCode(rawHtml);
            // ★ 修复：服务端返回的<a>显示文本可能被截断(...)，用href替换显示文本
            rawHtml = fixTruncatedLinkTexts(rawHtml);
            binding.tvContent.setVisibility(View.VISIBLE);
            List<String> imageUrls = new ArrayList<>();
            // ★ 关键修复：在引用/隐藏/代码块提取之前先提取附件链接，因为附件链接
            // 可能位于引用块或隐藏块内部，后提取会被提前带走而丢失。
            List<AttachmentCardRef> attachmentCards = new ArrayList<>();
            rawHtml = extractAttachmentLinks(rawHtml, attachmentCards);
            mPreExtractedAttachmentCards = attachmentCards;
            if (com.forum.MT.util.Dbg.ON) Log.d("MT_ATTACH", "[bindData] pre-extracted attachmentCards count=" + attachmentCards.size());
            // ★ 关键修复：先提取隐藏内容块（解析端已标记 data-sqapp-hidden，兜底兼容
            // 未标记的提示框），为 <!--HIDDEN_CARD_N--> 占位符——必须在提取引用块之前，
            // 因为隐藏块可能保留 comiis_quote 类，后提取不会被引用逻辑误吞。
            String htmlWithHiddenCards = extractHiddenBlocks(rawHtml, hiddenCards);
            // ★ 再提取引用块（避免 Jsoup 清理误删）
            List<QuoteCardRef> quoteCards = new ArrayList<>();
            String htmlWithQuoteCards = extractQuoteBlocks(htmlWithHiddenCards, quoteCards);
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ATTACH", "[bindData] after extractQuoteBlocks: ATTACH_CARD=" + htmlWithQuoteCards.contains("ATTACH_CARD"));
            // ★ 提取代码块（[code]/<pre>/div.blockcode）为 <!--CODE_CARD_N--> 占位符
            List<CodeCardRef> codeCards = new ArrayList<>();
            htmlWithQuoteCards = extractCodeBlocks(htmlWithQuoteCards, codeCards);
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[bindData] extracted " + quoteCards.size() + " quote cards, " + hiddenCards.size() + " hidden cards and " + codeCards.size() + " code cards");
            String cleanHtml = extractAndSeparateImages(htmlWithQuoteCards, imageUrls);
            dbgFile("cleanHtml", "length=" + cleanHtml.length() + " imageUrls=" + imageUrls.size());
            dbgFile("cleanHtml_snippet", cleanHtml.substring(0, Math.min(300, cleanHtml.length())));
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[bindData] after extractAndSeparateImages: contains QUOTE_CARD=" + cleanHtml.contains("QUOTE_CARD") + " ATTACH_CARD=" + cleanHtml.contains("ATTACH_CARD"));
            // ★ 将 <table> 转换为表格占位标记，渲染为可横滑的真实表格视图，内联在正文对应位置
            List<TableData> mainTables = new ArrayList<>();
            String contentHtml = convertHtmlTables(cleanHtml, mainTables);
            dbgFile("contentHtml", "length=" + contentHtml.length() + " tables=" + mainTables.size());
            dbgFile("contentHtml_snippet", contentHtml.substring(0, Math.min(300, contentHtml.length())));
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[bindData] after convertHtmlTables: contains QUOTE_CARD=" + contentHtml.contains("QUOTE_CARD") + " ATTACH_CARD=" + contentHtml.contains("ATTACH_CARD"));
            // ★ 补充：合并 ForumParser 从附件/懒加载中提取的图片（JS动态渲染的图片）
            // 只添加那些不在内联 HTML 中的图片（已在原文内联显示的图片不重复添加到底部）
            List<String> attachUrls = detail.getImageUrls();
            if (attachUrls != null && !attachUrls.isEmpty()) {
                for (String url : attachUrls) {
                    if (!imageUrls.contains(url)
                            && !contentHtml.contains(url)
                            && !contentHtml.contains(url.replace("&", "&amp;"))) {
                        imageUrls.add(url);
                    }
                }
            }
            // ★ 预加载表情图到缓存，然后渲染主帖
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_DEBUG", "[bindData] calling preloadMainContentSmileys, contentHtml length=" + contentHtml.length() + " imageUrls=" + imageUrls.size());
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_DEBUG", "[bindData] contentHtml preview: " + contentHtml.substring(0, Math.min(300, contentHtml.length())));
            preloadMainContentSmileys(contentHtml, mainTables, binding.frameContent,
                    binding.tvContent, imageUrls, quoteCards, codeCards, hiddenCards);

            // ★ 缓存本次渲染数据，供 onResume 检测配色变更后重渲染
            cachedContentHtml = contentHtml;
            cachedMainTables = new ArrayList<>(mainTables);
            cachedImageUrls = new ArrayList<>(imageUrls);
            cachedQuoteCards = new ArrayList<>(quoteCards);
            cachedCodeCards = new ArrayList<>(codeCards);
            cachedHiddenCards = new ArrayList<>(hiddenCards);
            cachedThemeFingerprint = com.forum.MT.ui.widget.ThemeVersionManager.fingerprint(this);

            // 加载图片到独立容器
            if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_IMG_DBG", "[bindData] imageUrls size=" + imageUrls.size() + " urls=" + imageUrls);
            if (!imageUrls.isEmpty()) {
                binding.llImagesContainer.removeAllViews();
                binding.llImagesContainer.setVisibility(View.VISIBLE);
                for (int i = 0; i < imageUrls.size(); i++) {
                    String imgUrl = imageUrls.get(i);
                    if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_IMG_DBG", "[bindData] adding image[" + i + "]=" + imgUrl);
                    ImageView imageView = new ImageView(this);
                    imageView.setLayoutParams(new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT));
                    imageView.setAdjustViewBounds(true);
                    imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    imageView.setBackgroundColor(0xFFF0F0F0);
                    imageView.setOnClickListener(v -> openImagePreview(imgUrl));
                    Glide.with(this)
                            .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(imgUrl))
                            .placeholder(new ColorDrawable(0xFFF0F0F0))
                            .timeout(15000)
                            .error(createFailedImageDrawable())
                            .into(imageView);
                    binding.llImagesContainer.addView(imageView);
                }
            } else {
                binding.llImagesContainer.setVisibility(View.GONE);
            }

            } else {
            binding.tvContent.setVisibility(View.GONE);
            binding.llImagesContainer.setVisibility(View.GONE);
            // ★ 显示占位提示，避免用户看到空白区域
            binding.tvContent.setVisibility(View.VISIBLE);
            binding.tvContent.setText("[内容加载中，请刷新重试]");
            binding.tvContent.setTextColor(0xFF9E9E9E);
            binding.tvContent.setTextSize(14);
            binding.tvContent.setGravity(android.view.Gravity.CENTER);
        }

        // ---- 隐藏内容区域 ----
        // ★ 新机制（对齐开源sqapp）：隐藏内容已在正文原位置内联渲染为
        // "隐藏内容"卡片（橙色+查看按钮）。仅当正文没有提取到隐藏卡片
        // （历史数据 / 解析异常兜底）时才显示旧的独立提示区块。
        if (detail.isHasHiddenContent() && hiddenCards.isEmpty()) {
            binding.layoutHiddenContent.setVisibility(View.VISIBLE);
            binding.tvHiddenContentHint.setVisibility(View.VISIBLE);
            binding.btnViewHidden.setVisibility(View.VISIBLE);
            binding.tvHiddenContent.setVisibility(View.GONE);
        } else {
            binding.layoutHiddenContent.setVisibility(View.GONE);
        }

        // ---- 投票区域 ----
        renderPoll(detail.getPoll());

        // ---- 点赞状态：网页端可确认时优先使用网页端，否则才回退到旧本地值 ----
        if (detail.isLikedStateKnown()) {
            isLiked = detail.isLiked();
            saveLikedState(isLiked);
        } else {
            isLiked = restoreLikedState();
        }
        likeCount = Math.max(0, detail.getLikeCount());
        updateLikeIcon();
        updateCountBadge(binding.tvCommentsBadge, detail.getReplyCount());
        updateCountBadge(binding.tvLikeBadge, likeCount);

        // ---- 收藏状态：网页端可确认时优先使用网页端，否则才回退到旧本地值 ----
        if (detail.isFavoritedStateKnown()) {
            isFavorited = detail.isFavorited();
            saveFavoritedState(isFavorited);
        } else {
            isFavorited = restoreFavoritedState();
        }
        favoriteCount = Math.max(0, detail.getFavoriteCount());
        updateFavoriteIcon();
        updateCountBadge(binding.tvFavoriteBadge, favoriteCount);

        // ---- 回复列表 ----
        List<ReplyItem> replies = detail.getReplies();
        if (replies == null) replies = new ArrayList<>();
        displayedReplies = new ArrayList<>(replies);
        updateReplyFilterAndOrder();

        // ---- 回复计数 ----
        int replyCount = detail.getReplyCount();
        if (replyCount > 0) {
            binding.tvReplyCount.setVisibility(View.VISIBLE);
            binding.tvReplyCount.setText("(" + replyCount + ")");
        } else {
            binding.tvReplyCount.setVisibility(View.GONE);
        }

        // ---- 加载更多按钮：有回复且有分页可能时显示 ----
        boolean hasMore = (replies != null && !replies.isEmpty())
                && (detail.getCurrentPage() < detail.getTotalPages()
                    || !TextUtils.isEmpty(detail.getNextPageUrl()));
        // 如果总回复数 > 当前页回复数，也有更多
        if (replyCount > (replies != null ? replies.size() : 0)) {
            hasMore = true;
        }
        binding.btnLoadMore.setVisibility(hasMore ? View.VISIBLE : View.GONE);

        // 点进帖子加载全部评论
        if (hasMore && LoadAllRepliesManager.isEnabled(this) && !shouldSuppressAutoReplyLoading()) {
            loadAllReplies();
        }

        // ---- 底部回复栏（仅登录用户可见） ----
        binding.layoutReply.setVisibility(
                httpClient.isLoggedIn() ? View.VISIBLE : View.GONE);

        // ---- 帖子操作按钮（赞赏 + 踢帖，仅登录用户可见） ----
        binding.layoutThreadActions.setVisibility(
                httpClient.isLoggedIn() ? View.VISIBLE : View.GONE);

        // ---- 赞赏和好评详情模块（仅登录用户可见且有数据时显示） ----
        int rewardCount = detail.getRewardCount();
        int goodReviewCount = detail.getGoodReviewCount();
        int rewardCoins = detail.getRewardCoins();
        List<String> rewardAvatars = detail.getRewardUserAvatars();
        List<String> goodReviewAvatars = detail.getGoodReviewUserAvatars();
        boolean hasRewardReviewData = rewardCount > 0 || goodReviewCount > 0
                || (rewardAvatars != null && !rewardAvatars.isEmpty())
                || (goodReviewAvatars != null && !goodReviewAvatars.isEmpty());
        if (httpClient.isLoggedIn() && hasRewardReviewData) {
            binding.layoutRewardReviewStats.setVisibility(View.VISIBLE);
            binding.tvRewardCount.setText(String.valueOf(rewardCount));
            binding.tvRewardCoins.setText("共计 " + rewardCoins + " 金币");
            binding.tvGoodReviewCount.setText(String.valueOf(goodReviewCount));
            bindAvatarStrip(binding.llRewardAvatars, rewardAvatars);
            bindAvatarStrip(binding.llGoodReviewAvatars, goodReviewAvatars);
        } else {
            binding.layoutRewardReviewStats.setVisibility(View.GONE);
        }

        // 如果有目标 pid，跳转到对应回复楼层（支持跨页查找）
        if (targetPid != null && !targetPid.isEmpty() && replies != null) {
            if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "bindData: checking targetPid=" + targetPid
                    + " replies.size=" + replies.size()
                    + " totalPages=" + (postDetail != null ? postDetail.getTotalPages() : 0));
            for (int i = 0; i < replies.size(); i++) {
                ReplyItem r = replies.get(i);
                if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "  reply[" + i + "] pid=" + (r != null ? r.getPid() : "null"));
            }
            boolean found = false;
            int foundPos = -1;
            for (int i = 0; i < replies.size(); i++) {
                ReplyItem r = replies.get(i);
                if (r != null && targetPid.equals(r.getPid())) {
                    found = true;
                    foundPos = i;
                    break;
                }
            }
            if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "bindData: targetPid found=" + found + " pos=" + foundPos);
            if (found) {
                replyAdapter.setHighlightedPid(targetPid);
                int adapterPos = replyAdapter.findPositionByPid(targetPid);
                if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "bindData: foundPos=" + foundPos + " adapterPos=" + adapterPos);
                if (adapterPos >= 0) {
                    scrollToReply(adapterPos);
                } else {
                    scrollToTargetPidWhenReady(6, foundPos);
                }
                releaseAutoReplySuppressionForTarget();
            } else if (postDetail != null && postDetail.getTotalPages() > 1) {
                replyAdapter.setHighlightedPid(targetPid);
                binding.tvLocatingMessage.setVisibility(View.VISIBLE);
                jumpToTargetPage(postDetail.getTotalPages());
            } else {
                replyAdapter.setHighlightedPid(null);
                binding.nestedScroll.scrollTo(0, 0);
            }
        } else {
            replyAdapter.setHighlightedPid(null);
            binding.tvLocatingMessage.setVisibility(View.GONE);
            binding.nestedScroll.scrollTo(0, 0);
        }
    }

    /**
     * 底部“快速定位评论区”滚动。
     * ★ 修复：帖子正文图片是 Glide 异步加载的，点击时图片可能尚未加载完成，
     *   getTop() 得到的是图片未撑开前的旧坐标，导致多图（≥2张）时定位偏移/错误。
     *   这里等布局稳定（getTop() 连续两次一致）后再滚动，确保定位到评论区顶部。
     */
    private void smoothScrollToComments() {
        // 滑动切换模式：直接切换到评论区页
        if (swipeCommentMode) {
            showCommentPage();
            return;
        }
        binding.recyclerReplies.setVisibility(View.VISIBLE);
        // 等待布局稳定后再滚动（图片异步加载会多次改变内容高度）
        final long[] lastTop = {Long.MIN_VALUE};
        final int[] stableCount = {0};
        final ViewTreeObserver.OnGlobalLayoutListener[] listenerRef = new ViewTreeObserver.OnGlobalLayoutListener[1];
        listenerRef[0] = () -> {
            int top = getCommentSectionY();
            if (top == lastTop[0]) {
                stableCount[0]++;
            } else {
                stableCount[0] = 0;
                lastTop[0] = top;
            }
            // 连续两次布局一致（或图片加载完成后）即认为稳定
            if (stableCount[0] >= 2) {
                if (listenerRef[0] != null) {
                    binding.nestedScroll.getViewTreeObserver().removeOnGlobalLayoutListener(listenerRef[0]);
                }
                binding.nestedScroll.smoothScrollTo(0, getCommentSectionY());
            }
        };
        binding.nestedScroll.getViewTreeObserver().addOnGlobalLayoutListener(listenerRef[0]);

        // 兜底：1.5 秒后仍不稳定则直接滚动到当前最新位置
        binding.nestedScroll.postDelayed(() -> {
            if (listenerRef[0] != null) {
                binding.nestedScroll.getViewTreeObserver().removeOnGlobalLayoutListener(listenerRef[0]);
            }
            binding.nestedScroll.smoothScrollTo(0, getCommentSectionY());
        }, 1500);
    }

    /**
     * 计算某个 View 在 NestedScrollView 内容坐标系中的 Y 值。
     * ★ 关键修复：recycler_replies 的父容器是 layout_comment_section（再上层还有
     * layout_thread_header），直接用 recyclerReplies.getTop() 只是相对评论区容器的
     * 偏移，会丢掉整个帖子正文的高度，导致定位偏差（表现为“差一页”）。
     */
    private int computeYInNestedScroll(View view) {
        if (view == null || binding == null) return 0;
        int y = 0;
        View v = view;
        while (v != null && v != binding.nestedScroll) {
            y += v.getTop();
            android.view.ViewParent parent = v.getParent();
            if (!(parent instanceof View)) break;
            v = (View) parent;
        }
        return y;
    }

    /** 评论区在 NestedScrollView 内容中的绝对 Y。 */
    private int getCommentSectionY() {
        if (binding == null) return 0;
        View section = binding.layoutCommentSection;
        if (section != null && section.getParent() != null) {
            return computeYInNestedScroll(section);
        }
        return computeYInNestedScroll(binding.recyclerReplies);
    }

    /**
     * 立即（无动画、不等布局稳定）把外层 NestedScrollView 滚到评论区顶部。
     * 用于消息定位场景：此时用户已经在等待，不能再花 1.5s 等图片撑高。
     */
    private void jumpToCommentSectionNow() {
        if (binding == null) return;
        binding.nestedScroll.scrollTo(0, Math.max(getCommentSectionY(), 0));
    }

    /** 隐藏“消息定位中…”提示。定位滚动真正完成后才隐藏，避免文字先消失、画面还没动。 */
    private void hideLocatingMessage() {
        if (binding == null) return;
        binding.tvLocatingMessage.setVisibility(View.GONE);
    }

    private void scrollToReply(int pos) {
        // 滑动切换模式：立即切到评论区页并同步定位。
        // ★ 评论区面板此时是 INVISIBLE + translationX，但仍参与测量/布局，
        //   所以不必等 300ms 滑动动画结束才滚动（旧实现固定等 350ms，
        //   叠加 adapter 刷新与校正后就变成“文字消失后还要等几秒”）。
        if (swipeCommentMode) {
            if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "swipeCommentMode=true, pos=" + pos + ", showCommentPage + immediate scroll");
            showCommentPage();
            scrollToReplyInRecyclerView(pos, 0);
            return;
        }
        // 非滑动模式：直接用 RecyclerView 滚动定位
        scrollToReplyInRecyclerView(pos, 0);
    }

    /**
     * 在 RecyclerView 中滚动定位到指定位置。
     * 使用 post 等待布局完成后滚动，并重试确保定位成功。
     */
    private void scrollToReplyInRecyclerView(int pos, int retryCount) {
        binding.recyclerReplies.setVisibility(View.VISIBLE);
        if (pos < 0) pos = 0;
        final int targetPos = pos;
        if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "scrollToReplyInRecyclerView pos=" + targetPos + " retry=" + retryCount
                + " nestedScrolling=" + binding.recyclerReplies.isNestedScrollingEnabled()
                + " childCount=" + binding.recyclerReplies.getChildCount()
                + " adapterCount=" + (binding.recyclerReplies.getAdapter() != null ? binding.recyclerReplies.getAdapter().getItemCount() : 0));

        binding.recyclerReplies.post(() -> {
            androidx.recyclerview.widget.RecyclerView.LayoutManager lm = binding.recyclerReplies.getLayoutManager();
            if (!(lm instanceof LinearLayoutManager)) {
                if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "lm not LinearLayoutManager, fallback");
                smoothScrollToComments();
                binding.recyclerReplies.scrollToPosition(targetPos);
                hideLocatingMessage();
                return;
            }
            LinearLayoutManager linearLayoutManager = (LinearLayoutManager) lm;

            // 模式0：滑动切换评论区模式 —— RecyclerView 已从 NestedScrollView 移到 overlay，
            // 它自己就是唯一的滚动容器，直接内部定位（绝不能再去滚 nestedScroll）。
            if (swipeCommentMode) {
                if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode0(swipe): scrollToPositionWithOffset pos=" + targetPos);
                linearLayoutManager.scrollToPositionWithOffset(targetPos, 0);
                binding.recyclerReplies.post(() -> {
                    linearLayoutManager.scrollToPositionWithOffset(targetPos, 0);
                    hideLocatingMessage();
                });
                // 图片异步加载会改变项高，延迟再校正一次
                binding.recyclerReplies.postDelayed(() -> {
                    androidx.recyclerview.widget.RecyclerView.ViewHolder vh =
                            binding.recyclerReplies.findViewHolderForAdapterPosition(targetPos);
                    if (vh == null || Math.abs(vh.itemView.getTop()) > 50) {
                        if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode0(swipe): correction pos=" + targetPos);
                        linearLayoutManager.scrollToPositionWithOffset(targetPos, 0);
                    }
                }, 250);
                return;
            }

            // 模式1：回复区独立滚动（RecyclerView 自己滚）
            if (binding.recyclerReplies.isNestedScrollingEnabled()) {
                if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode1: independent scroll, scrollToPositionWithOffset pos=" + targetPos);
                // ★ 修复“要等 1-2 秒才滑下去”：定位场景不能用 smoothScrollToComments()，
                //   它要等布局稳定（正文图片异步加载导致高度反复变化，几乎等不到），
                //   最终总是走 1500ms 兜底。这里直接瞬移到评论区顶部并做一次校正。
                jumpToCommentSectionNow();
                linearLayoutManager.scrollToPositionWithOffset(targetPos, 0);
                // 二次确认
                binding.recyclerReplies.post(() -> {
                    if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode1: second scrollToPositionWithOffset pos=" + targetPos);
                    jumpToCommentSectionNow();
                    linearLayoutManager.scrollToPositionWithOffset(targetPos, 0);
                    hideLocatingMessage();
                });
                // 图片撑高后再校正一次评论区顶部位置
                binding.recyclerReplies.postDelayed(() -> {
                    jumpToCommentSectionNow();
                    linearLayoutManager.scrollToPositionWithOffset(targetPos, 0);
                }, 250);
                return;
            }

            // 模式2：原版整体页面滚动（外层 NestedScrollView 滚）
            // ★ 修复：wrap_content 模式下 RecyclerView 测量全部 127 条会导致 ANR，
            // 且 smoothScrollTo 对超大距离（如 38627px）不可靠。
            // 改为：先 scrollToPositionWithOffset 让 RecyclerView 内部定位，
            // 再用 scrollTo（瞬移）而非 smoothScrollTo 定位到目标 y。
            if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode2: nested scroll, scrollToPositionWithOffset pos=" + targetPos);
            linearLayoutManager.scrollToPositionWithOffset(targetPos, 0);
            binding.recyclerReplies.post(() -> {
                androidx.recyclerview.widget.RecyclerView.ViewHolder vh =
                        binding.recyclerReplies.findViewHolderForAdapterPosition(targetPos);
                if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode2: vh=" + (vh != null ? "found" : "null") + " pos=" + targetPos);
                if (vh != null) {
                    int y = computeYInNestedScroll(binding.recyclerReplies) + vh.itemView.getTop();
                    if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode2: scrollTo nestedScroll y=" + y);
                    // ★ 大距离用 scrollTo 瞬移，小距离用 smoothScrollTo 平滑
                    int currentScroll = binding.nestedScroll.getScrollY();
                    int distance = Math.abs(y - currentScroll);
                    if (distance > 3000) {
                        binding.nestedScroll.scrollTo(0, Math.max(y, 0));
                    } else {
                        binding.nestedScroll.smoothScrollTo(0, Math.max(y, 0));
                    }
                    hideLocatingMessage();
                    // 二次确认：图片加载可能导致位置偏移
                    binding.recyclerReplies.postDelayed(() -> {
                        androidx.recyclerview.widget.RecyclerView.ViewHolder vh2 =
                                binding.recyclerReplies.findViewHolderForAdapterPosition(targetPos);
                        if (vh2 != null) {
                            int y2 = computeYInNestedScroll(binding.recyclerReplies) + vh2.itemView.getTop();
                            int cur2 = binding.nestedScroll.getScrollY();
                            if (Math.abs(y2 - cur2) > 50) {
                                if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode2: correction scrollTo y2=" + y2);
                                binding.nestedScroll.scrollTo(0, Math.max(y2, 0));
                            }
                        }
                    }, 300);
                } else {
                    // 兜底：先滚到评论区顶部，再次尝试定位
                    if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode2: vh null, fallback + retry");
                    linearLayoutManager.scrollToPositionWithOffset(targetPos, 0);
                    binding.recyclerReplies.postDelayed(() -> {
                        androidx.recyclerview.widget.RecyclerView.ViewHolder vh2 =
                                binding.recyclerReplies.findViewHolderForAdapterPosition(targetPos);
                        if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode2: retry vh2=" + (vh2 != null ? "found" : "null"));
                        if (vh2 != null) {
                            int y2 = computeYInNestedScroll(binding.recyclerReplies) + vh2.itemView.getTop();
                            if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "mode2: retry scrollTo y2=" + y2);
                            binding.nestedScroll.scrollTo(0, Math.max(y2, 0));
                        }
                        hideLocatingMessage();
                    }, 150);
                }
            });
        });
    }

    /**
     * 按官方逻辑跳转到目标 pid 所在页。
     * 官方 APK 的做法：
     * 1) 调用 findpost 重定向接口获取目标页码（始终是正序页码）
     * 2) 用该页码加载帖子（不传 ordertype，即正序）
     * 3) 在该页中定位 targetPid
     * 如果 findpost 失败，则从第 2 页开始顺序扫描到最后一页。
     */
    private void jumpToTargetPage(final int totalPages) {
        final String replyOrder = getReplyOrder();
        new Thread(() -> {
            try {
                // 第一步：调用 findpost 获取目标页码（论坛返回的是正序页码）
                String pageStr = httpClient.resolveFindPostPage(tid, targetPid);
                if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "findpost result: tid=" + tid + " pid=" + targetPid + " pageStr=" + pageStr);
                int ascTargetPage = -1;
                if (pageStr != null) {
                    try {
                        ascTargetPage = Integer.parseInt(pageStr);
                    } catch (NumberFormatException ignored) {
                    }
                }
                int targetPage = mapFindPostPageToCurrentOrder(ascTargetPage, totalPages, replyOrder);
                if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "findpost resolved ascTargetPage=" + ascTargetPage
                        + " targetPage=" + targetPage + " order=" + replyOrder
                        + " totalPages=" + totalPages);

                // ★ 修复“定位差一页”：findpost 返回的是正序页码，而倒序（ordertype=1）分页
                // 边界与正序并不是简单镜像（正序首页含楼主，倒序首页含最新评论），
                // totalPages-ascPage+1 常常偏移一页。因此先试映射页，再试相邻页，
                // 最后才做全量扫描。
                java.util.LinkedHashSet<Integer> candidates = new java.util.LinkedHashSet<>();
                if (targetPage >= 1 && targetPage <= totalPages) {
                    candidates.add(targetPage);
                    if (targetPage - 1 >= 1) candidates.add(targetPage - 1);
                    if (targetPage + 1 <= totalPages) candidates.add(targetPage + 1);
                }
                for (Integer candidate : candidates) {
                    if (loadAndLocatePageScan(candidate, totalPages, replyOrder)) {
                        if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "found targetPid on page " + candidate
                                + " order=" + replyOrder + " (mapped=" + targetPage + ")");
                        return;
                    }
                    if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "targetPid not found on candidate page " + candidate);
                }

                // 兜底：按“当前评论排序”从第 1 页开始顺序扫描，保持与界面显示一致
                for (int p = 1; p <= totalPages; p++) {
                    if (candidates.contains(p)) continue;
                    if (loadAndLocatePageScan(p, totalPages, replyOrder)) {
                        if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "found targetPid on page " + p + " (scan, order=" + replyOrder + ")");
                        return;
                    }
                }

                // 全部扫描失败，隐藏提示
                if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "targetPid not found on any page");
                runOnUiThread(() -> {
                    binding.tvLocatingMessage.setVisibility(View.GONE);
                    binding.nestedScroll.scrollTo(0, 0);
                    releaseAutoReplySuppressionForTarget();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    binding.tvLocatingMessage.setVisibility(View.GONE);
                    binding.nestedScroll.scrollTo(0, 0);
                    releaseAutoReplySuppressionForTarget();
                });
            }
        }).start();
    }

    /**
     * 加载当前评论排序下的指定页，解析后定位 targetPid。
     * findpost 返回的是“正序页码”，调用方会先换算成当前排序对应的页码，
     * 这里始终按当前评论排序加载，避免通知定位后出现正序/倒序混排。
     *
     * ★ 修复：找到目标页后，从当前排序的第 1 页加载到目标页并合并，
     *   确保用户看到的是与当前排序一致的连续回复内容。
     *   同时将 currentPage 更新为目标页，后续"加载更多"能从正确位置继续。
     *
     * @return true 如果在该页找到了 targetPid
     */
    private int mapFindPostPageToCurrentOrder(int ascPage, int totalPages, String replyOrder) {
        if (ascPage < 1 || totalPages < 1) return -1;
        if ("desc".equalsIgnoreCase(replyOrder)) {
            return totalPages - ascPage + 1;
        }
        return ascPage;
    }

    private void preProcessRepliesInBackground(List<ReplyItem> replies) {
        if (replies == null || replies.isEmpty()) return;
        for (ReplyItem r : replies) {
            try {
                ReplyAdapter.preProcessReply(r);
            } catch (Exception ignored) {
            }
        }
    }

    private List<ReplyItem> getCachedPageOneRepliesForLocate() {
        if (postDetail == null || postDetail.getCurrentPage() != 1) return null;
        List<ReplyItem> replies = postDetail.getReplies();
        if (replies == null || replies.isEmpty()) return null;
        return new ArrayList<>(replies);
    }

    private List<ReplyItem> fetchRepliesPageForLocate(int page, String replyOrder) throws Exception {
        String pageUrl = ForumParser.getThreadDetailUrl(tid, page, replyOrder);
        if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "scan: loading page " + page + " url=" + pageUrl);
        String html = httpClient.get(pageUrl);
        PostDetail pageDetail = ForumParser.parseThreadDetail(html);
        List<ReplyItem> pageReplies = pageDetail != null ? pageDetail.getReplies() : null;
        if (pageReplies == null) pageReplies = new ArrayList<>();
        preProcessRepliesInBackground(pageReplies);
        return pageReplies;
    }

    private int findReplyPositionByPid(List<ReplyItem> replies, String pid) {
        if (replies == null || replies.isEmpty() || TextUtils.isEmpty(pid)) return -1;
        for (int i = 0; i < replies.size(); i++) {
            ReplyItem r = replies.get(i);
            if (r != null && pid.equals(r.getPid())) {
                return i;
            }
        }
        return -1;
    }

    private List<ReplyItem> buildRepliesUpToTargetPageFast(int targetPage,
                                                           String replyOrder,
                                                           List<ReplyItem> targetPageReplies) throws Exception {
        java.util.concurrent.ConcurrentHashMap<Integer, List<ReplyItem>> pageReplyMap =
                new java.util.concurrent.ConcurrentHashMap<>();

        if (targetPageReplies != null && !targetPageReplies.isEmpty()) {
            pageReplyMap.put(targetPage, new ArrayList<>(targetPageReplies));
        }

        List<ReplyItem> cachedPageOneReplies = getCachedPageOneRepliesForLocate();
        if (cachedPageOneReplies != null && !cachedPageOneReplies.isEmpty()) {
            preProcessRepliesInBackground(cachedPageOneReplies);
            pageReplyMap.put(1, cachedPageOneReplies);
        }

        List<Integer> missingPages = new ArrayList<>();
        for (int p = 1; p <= targetPage; p++) {
            if (!pageReplyMap.containsKey(p)) {
                missingPages.add(p);
            }
        }

        if (!missingPages.isEmpty()) {
            int poolSize = Math.min(4, missingPages.size());
            java.util.concurrent.ExecutorService pool =
                    java.util.concurrent.Executors.newFixedThreadPool(poolSize);
            java.util.concurrent.CountDownLatch latch =
                    new java.util.concurrent.CountDownLatch(missingPages.size());
            java.util.concurrent.ConcurrentLinkedQueue<Integer> failedPages =
                    new java.util.concurrent.ConcurrentLinkedQueue<>();

            for (Integer pageNum : missingPages) {
                final int fetchPage = pageNum;
                pool.execute(() -> {
                    try {
                        List<ReplyItem> replies = fetchRepliesPageForLocate(fetchPage, replyOrder);
                        pageReplyMap.put(fetchPage, replies);
                    } catch (Exception e) {
                        Log.w("ThreadDetail", "parallel locate fetch failed, page=" + fetchPage, e);
                        failedPages.add(fetchPage);
                    } finally {
                        latch.countDown();
                    }
                });
            }

            latch.await();
            pool.shutdown();

            if (!failedPages.isEmpty()) {
                for (Integer failedPage : failedPages) {
                    List<ReplyItem> replies = fetchRepliesPageForLocate(failedPage, replyOrder);
                    pageReplyMap.put(failedPage, replies);
                }
            }
        }

        List<ReplyItem> allReplies = new ArrayList<>();
        for (int p = 1; p <= targetPage; p++) {
            List<ReplyItem> replies = pageReplyMap.get(p);
            if (replies != null && !replies.isEmpty()) {
                allReplies.addAll(replies);
            }
        }
        return allReplies;
    }

    private boolean loadAndLocatePageScan(int page, int totalPages, String replyOrder) {
        try {
            List<ReplyItem> pageReplies;
            if (page == 1) {
                List<ReplyItem> cachedPageOneReplies = getCachedPageOneRepliesForLocate();
                if (cachedPageOneReplies != null && !cachedPageOneReplies.isEmpty()) {
                    if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "scan: reuse cached page 1 replies, size=" + cachedPageOneReplies.size());
                    preProcessRepliesInBackground(cachedPageOneReplies);
                    pageReplies = cachedPageOneReplies;
                } else {
                    pageReplies = fetchRepliesPageForLocate(page, replyOrder);
                }
            } else {
                pageReplies = fetchRepliesPageForLocate(page, replyOrder);
            }

            if (pageReplies == null || pageReplies.isEmpty()) {
                if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "scan: page " + page + " has no replies");
                return false;
            }

            if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "scan: page " + page + " has " + pageReplies.size() + " replies");
            int foundPos = findReplyPositionByPid(pageReplies, targetPid);
            if (foundPos < 0) {
                return false;
            }

            final int targetPage = page;
            List<ReplyItem> mergedReplies = buildRepliesUpToTargetPageFast(targetPage, replyOrder, pageReplies);
            if (mergedReplies == null || mergedReplies.isEmpty()) {
                mergedReplies = new ArrayList<>(pageReplies);
            }
            final List<ReplyItem> replies = new ArrayList<>(mergedReplies);
            final int targetPosInMerged = findReplyPositionByPid(replies, targetPid);

            runOnUiThread(() -> {
                if (postDetail != null) {
                    postDetail.setReplies(replies);
                    postDetail.setCurrentPage(targetPage);
                }
                displayedReplies = new ArrayList<>(replies);
                updateReplyFilterAndOrder();
                replyAdapter.setHighlightedPid(targetPid);
                boolean hasMore = targetPage < totalPages;
                binding.btnLoadMore.setVisibility(hasMore ? View.VISIBLE : View.GONE);
                binding.btnLoadMore.setEnabled(true);
                binding.btnLoadMore.setText(R.string.load_more_replies);

                int filteredPos = replyAdapter.findPositionByPid(targetPid);
                final int scrollToPos = filteredPos >= 0 ? filteredPos
                        : (targetPosInMerged >= 0 ? targetPosInMerged : foundPos);
                if (filteredPos >= 0) {
                    scrollToReply(scrollToPos);
                } else {
                    // 黑名单过滤走后台线程，adapter 此刻可能还没拿到数据。
                    // 用按 pid 重查的方式等 adapter 就绪后再定位，避免滚到错误楼层。
                    scrollToTargetPidWhenReady(6, scrollToPos);
                }

                releaseAutoReplySuppressionForTarget();
            });

            return true;
        } catch (Exception e) {
            Log.w("ThreadDetail", "loadAndLocatePageScan failed, page=" + page, e);
            return false;
        }
    }

    /** 当前评论排序对应的 Discuz! order 参数。 */
    private String getReplyOrder() {
        return repliesDescending ? "desc" : "asc";
    }

    /**
     * 等 adapter 数据就绪后按 pid 定位。适配器数据可能来自后台过滤线程，
     * 立即 findPositionByPid 会返回 -1，此时重试而不是滚到过时的位置。
     */
    private void scrollToTargetPidWhenReady(int retriesLeft, int fallbackPos) {
        if (isFinishing() || isDestroyed() || replyAdapter == null) return;
        int pos = replyAdapter.findPositionByPid(targetPid);
        if (pos >= 0) {
            if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "scrollToTargetPidWhenReady: resolved pos=" + pos);
            scrollToReply(pos);
            return;
        }
        if (retriesLeft <= 0) {
            if (com.forum.MT.util.Dbg.ON) Log.e("MT_ScrollReply", "scrollToTargetPidWhenReady: give up, fallbackPos=" + fallbackPos);
            if (fallbackPos >= 0) scrollToReply(fallbackPos);
            else hideLocatingMessage();
            return;
        }
        binding.recyclerReplies.postDelayed(
                () -> scrollToTargetPidWhenReady(retriesLeft - 1, fallbackPos), 120);
    }

    /**
     * 应用评论筛选。
     * 评论顺序已经由服务端通过 order=asc/desc 决定，客户端这里只做楼主筛选，
     * 不再反转当前已加载列表，避免把分页边界内的局部排序误当成全帖排序。
     */
    private void updateReplyFilterAndOrder() {
        if (postDetail == null) return;
        // ★ 修复并发崩溃：必须在主线程对 displayedReplies 做快照。
        // 后台过滤线程若直接遍历 displayedReplies 本身，而 loadAllReplies
        // 每批又在主线程 displayedReplies.addAll(...)，会抛
        // ConcurrentModificationException 被 catch 吞掉，导致 applyFilterResult
        // 永远不执行、界面停在旧状态（表现为"卡住"）。
        final List<ReplyItem> source = displayedReplies == null
                ? new ArrayList<>() : new ArrayList<>(displayedReplies);
        final String opUid = postDetail.getAuthorUid();
        final String opName = postDetail.getAuthor();
        final ReplyBlacklistManager blacklist = ReplyBlacklistManager.getInstance(this);
        final boolean blacklistActive = blacklist.isEnabled() && blacklist.size() > 0;
        // 屏蔽AI回复（模板化灌水）
        final boolean aiFilterActive =
                com.forum.MT.ui.widget.AiReplyFilterManager.isEnabled(this);
        final String threadTitle = postDetail.getTitle();

        // 无黑名单过滤时，直接在主线程处理（轻量级）
        if (!blacklistActive) {
            List<ReplyItem> result = new ArrayList<>();
            for (ReplyItem item : source) {
                if (item == null) continue;
                boolean isTargetReply = !TextUtils.isEmpty(targetPid) && targetPid.equals(item.getPid());
                if (!isTargetReply && onlyOpReplies) {
                    boolean isOp = item.isOP();
                    if (!isOp && !TextUtils.isEmpty(opUid)) isOp = opUid.equals(item.getAuthorUid());
                    if (!isOp && !TextUtils.isEmpty(opName)) isOp = opName.equals(item.getAuthor());
                    if (!isOp) continue;
                }
                // 屏蔽AI回复：仅受"屏蔽灌水回复"开关控制，与黑名单独立。
                if (aiFilterActive && !isTargetReply
                        && shouldAiReplyFilter(item) && isAiSpam(item, threadTitle)) {
                    continue;
                }
                result.add(item);
            }
            applyFilterResult(result, blacklist, true);
            return;
        }

        // 开启黑名单时，过滤操作在后台线程执行，避免卡顿
        new Thread(() -> {
            try {
                List<ReplyItem> result = new ArrayList<>();
                for (ReplyItem item : source) {
                    if (item == null) continue;
                    boolean isTargetReply = !TextUtils.isEmpty(targetPid) && targetPid.equals(item.getPid());
                    if (!isTargetReply && onlyOpReplies) {
                        boolean isOp = item.isOP();
                        if (!isOp && !TextUtils.isEmpty(opUid)) isOp = opUid.equals(item.getAuthorUid());
                        if (!isOp && !TextUtils.isEmpty(opName)) isOp = opName.equals(item.getAuthor());
                        if (!isOp) continue;
                    }
                    // ★ 通知定位目标回复永远保留，避免被黑名单/只看楼主过滤掉导致 adapterCount 很小
                    if (isTargetReply) {
                        result.add(item);
                        continue;
                    }
                    // 黑名单只检查当前回复正文；引用块属于上下文，不能作为绕过条件。
                    if (!shouldBlacklistFilter(item)) {
                        result.add(item);
                        continue;
                    }
                    String contentText = item.getContentText();
                    if (contentText == null || contentText.isEmpty()) {
                        contentText = android.text.Html.fromHtml(
                                item.getContentHtml() != null ? item.getContentHtml() : "",
                                android.text.Html.FROM_HTML_MODE_COMPACT).toString();
                    }
                    // 模板灌水检测仅受"屏蔽灌水回复"开关控制，与黑名单独立。
                    if (aiFilterActive
                            && com.forum.MT.ui.widget.AiReplyFilterManager
                                    .isAiSpamReply(contentText, threadTitle)) {
                        continue;
                    }
                    if (blacklist.isBlocked(contentText)) {
                        continue;
                    }
                    result.add(item);
                }
                runOnUiThread(() -> applyFilterResult(result, blacklist, false));
            } catch (Exception e) {
                // ★ 不再静默吞掉：过滤失败会导致列表停在旧状态，必须能查到原因，
                // 并且要兜底同步一次空状态，避免界面永久停留在"加载中"观感。
                android.util.Log.e("MT_ALL_REPLIES", "updateReplyFilterAndOrder filter failed", e);
                runOnUiThread(() -> {
                    if (isDestroyed() || isFinishing()) return;
                    syncRepliesEmptyState();
                });
            }
        }).start();
    }

    /**
     * ★ 判断回复是否应参与黑名单过滤。
     * 豁免规则：带图片的回复不过滤；引用块只作为显示上下文，不参与正文匹配。
     * @return true=应过滤，false=豁免不过滤
     */
    private boolean shouldBlacklistFilter(ReplyItem item) {
        if (item == null) return true;
        // 只有真实内容图片才豁免；论坛表情、小图标不能让模板回复绕过过滤。
        return !hasSubstantiveReplyImage(item.getContentHtml());
    }

    /**
     * AI 灌水过滤沿用正文文本判定；带引用的回复只要正文是模板句仍应被过滤。
     * 仅真实内容图片豁免，表情图片和界面小图标仍参与模板过滤。
     */
    private boolean shouldAiReplyFilter(ReplyItem item) {
        if (item == null) return false;
        return !hasSubstantiveReplyImage(item.getContentHtml());
    }

    /**
     * 判断回复中是否存在应当保留该回复的真实内容图片。
     * Discuz 会把表情也输出成 img 标签，不能仅凭“包含 img”就豁免整条回复。
     */
    private boolean hasSubstantiveReplyImage(String html) {
        if (TextUtils.isEmpty(html)) return false;

        String lowerHtml = html.toLowerCase(java.util.Locale.ROOT);
        if (lowerHtml.contains("[attachimg]") || lowerHtml.contains("[img]")) {
            return true;
        }

        org.jsoup.nodes.Document imageDoc = org.jsoup.Jsoup.parseBodyFragment(html);
        for (org.jsoup.nodes.Element img : imageDoc.select("img")) {
            String tag = img.outerHtml().toLowerCase(java.util.Locale.ROOT);
            String src = img.hasAttr("file") ? img.attr("file") : img.attr("src");
            if (TextUtils.isEmpty(src)) src = img.attr("data-original");
            if (TextUtils.isEmpty(src)) src = img.attr("data-src");
            if (TextUtils.isEmpty(src)) src = img.attr("zoomfile");
            String lowerUrl = src == null ? "" : src.toLowerCase(java.util.Locale.ROOT);

            boolean smileyOrIcon = tag.contains("smilieid")
                    || lowerUrl.contains("smiley")
                    || lowerUrl.contains("emoticon")
                    || lowerUrl.contains("/static/image/")
                    || lowerUrl.contains("face")
                    || lowerUrl.contains("stamp")
                    || lowerUrl.contains("magic")
                    || lowerUrl.contains("mini")
                    || lowerUrl.contains("icon")
                    || lowerUrl.contains("none.gif")
                    || lowerUrl.contains("common_");
            if (!smileyOrIcon) return true;
        }
        return false;
    }

    /**
     * 判断回复是否为AI模板灌水（仅当开启屏蔽AI回复时调用）。
     * 豁免：带图回复由 shouldAiReplyFilter 决定，此处只做正文内容检测。
     */
    private boolean isAiSpam(ReplyItem item, String threadTitle) {
        if (item == null) return false;
        String contentText = item.getContentText();
        if (contentText == null || contentText.isEmpty()) {
            contentText = android.text.Html.fromHtml(
                    item.getContentHtml() != null ? item.getContentHtml() : "",
                    android.text.Html.FROM_HTML_MODE_COMPACT).toString();
        }
        return com.forum.MT.ui.widget.AiReplyFilterManager
                .isAiSpamReply(contentText, threadTitle);
    }

    private void applyFilterResult(List<ReplyItem> result, ReplyBlacklistManager blacklist, boolean skipAutoLoadCheck) {
        // 服务端置顶的评论排到当前列表前部，与网页端表现一致。
        // List.sort 是稳定排序（TimSort），未置顶评论之间的服务端分页顺序不受影响。
        // 只在确实存在置顶评论时才排序，避免每次过滤都为绝大多数无置顶的帖子做无用功。
        if (result != null && result.size() > 1) {
            boolean hasPinned = false;
            for (ReplyItem item : result) {
                if (item != null && item.isPinned()) { hasPinned = true; break; }
            }
            if (hasPinned) {
                result.sort((left, right) -> Boolean.compare(
                        right != null && right.isPinned(),
                        left != null && left.isPinned()));
            }
        }

        // ★ 修复：NestedScrollView.onSizeChanged 中 isWithinDeltaOfScreen
        // 在子 View 被移除时会抛出 IllegalArgumentException。
        // 清除焦点避免 NestedScrollView 持有已移除子 View 的引用。
        // 不再 scrollTo(0,0)，避免添加关键词时页面跳回顶部。
        View focused = getCurrentFocus();
        if (focused != null) focused.clearFocus();
        if (binding != null) binding.recyclerReplies.clearFocus();
        // 更新适配器
        replyAdapter.updateData(result);
        updateReplyCountWithFilteredCount();
        if (!TextUtils.isEmpty(targetPid)) {
            int targetPos = replyAdapter.findPositionByPid(targetPid);
            if (com.forum.MT.util.Dbg.ON) Log.e("ThreadDetail", "applyFilterResult: targetPid=" + targetPid
                    + " result.size=" + result.size()
                    + " adapterTargetPos=" + targetPos
                    + " onlyOpReplies=" + onlyOpReplies
                    + " blacklistEnabled=" + (blacklist != null && blacklist.isEnabled())
                    + " blacklistSize=" + (blacklist != null ? blacklist.size() : 0));
        }

        // 黑名单过滤后结果为空且有更多页时，自动加载更多
        // ★ 必须排除 mLoadingAllReplies：loadAllReplies() 已经在翻页，
        // 若这里再起一个线程，两条线程会同时 postDetail.setCurrentPage(...)
        // 互相覆盖页码，导致同一批页反复抓取、"加载全部 x/y" 计数不动。
        if (!skipAutoLoadCheck && !mAutoLoadSkipping && !mLoadingAllReplies
                && !shouldSuppressAutoReplyLoading()
                && blacklist.isEnabled() && blacklist.size() > 0 && result.isEmpty()
                && postDetail != null && postDetail.getCurrentPage() < postDetail.getTotalPages()) {
            mAutoLoadSkipping = true;
            binding.btnLoadMore.setEnabled(false);
            binding.btnLoadMore.setText(R.string.loading);
            new Thread(() -> {
                try {
                    int page = postDetail.getCurrentPage() + 1;
                    int totalPages = postDetail.getTotalPages();
                    int targetCount = 10;
                    List<ReplyItem> allNewReplies = new ArrayList<>();
                    int visibleCount = 0;

                    while (visibleCount < targetCount && page <= totalPages) {
                        String pageUrl = ForumParser.getThreadDetailUrl(tid, page, getReplyOrder());
                        String html = httpClient.get(pageUrl);
                        PostDetail pageDetail = ForumParser.parseThreadDetail(html);
                        List<ReplyItem> pageReplies = pageDetail.getReplies();
                        if (pageReplies != null && !pageReplies.isEmpty()) {
                            for (ReplyItem r : pageReplies) {
                                allNewReplies.add(r);
                                // ★ 带图回复豁免；引用块不影响当前正文的过滤判定。
                                if (shouldBlacklistFilter(r)) {
                                    String contentText = r.getContentText();
                                    if (contentText == null || contentText.isEmpty()) {
                                        contentText = android.text.Html.fromHtml(
                                                r.getContentHtml() != null ? r.getContentHtml() : "",
                                                android.text.Html.FROM_HTML_MODE_COMPACT).toString();
                                    }
                                    if (!(com.forum.MT.ui.widget.AiReplyFilterManager.isEnabled(this)
                                            && com.forum.MT.ui.widget.AiReplyFilterManager
                                                    .isAiSpamReply(contentText, postDetail.getTitle())
                                            || blacklist.isBlocked(contentText))) {
                                        visibleCount++;
                                    }
                                } else {
                                    visibleCount++;
                                }
                            }
                        }
                        if (pageDetail.getTotalPages() > totalPages) {
                            totalPages = pageDetail.getTotalPages();
                            postDetail.setTotalPages(totalPages);
                        }
                        page++;
                    }
                    postDetail.setCurrentPage(page - 1);

                    runOnUiThread(() -> {
                        mAutoLoadSkipping = false;
                        binding.btnLoadMore.setEnabled(true);
                        binding.btnLoadMore.setText(R.string.load_more_replies);
                        if (!allNewReplies.isEmpty()) {
                            List<ReplyItem> merged = new ArrayList<>(postDetail.getReplies());
                            merged.addAll(allNewReplies);
                            postDetail.setReplies(merged);
                            displayedReplies = new ArrayList<>(merged);
                            updateReplyFilterAndOrder();
                        } else {
                            binding.btnLoadMore.setVisibility(View.GONE);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        mAutoLoadSkipping = false;
                        binding.btnLoadMore.setEnabled(true);
                        binding.btnLoadMore.setText(R.string.load_more_replies);
                    });
                }
            }).start();
        }

        // 排序由服务端分页结果保证，这里只保留楼主筛选后的原始顺序。
        binding.btnOnlyOp.setText(onlyOpReplies
                ? R.string.reply_all_users : R.string.reply_only_op);
        binding.btnOnlyOp.setTextColor(getColor(onlyOpReplies
                ? R.color.primary : R.color.text_secondary));
        binding.btnReplyOrder.setText(repliesDescending
                ? R.string.reply_order_desc : R.string.reply_order_asc);
        binding.btnReplyOrder.setTextColor(getColor(repliesDescending
                ? R.color.primary : R.color.text_secondary));

        // 更新黑名单按钮状态：只显示开关，不显示关键词数量
        ReplyBlacklistManager blMgr = ReplyBlacklistManager.getInstance(this);
        if (blMgr.isEnabled()) {
            binding.btnReplyBlacklist.setText(R.string.reply_blacklist_on);
            binding.btnReplyBlacklist.setTextColor(getColor(R.color.primary));
        } else {
            binding.btnReplyBlacklist.setText(R.string.reply_blacklist_off);
            binding.btnReplyBlacklist.setTextColor(getColor(R.color.text_secondary));
        }

        // 空状态以适配器实际条数为准，不直接用 result：
        // loadAllReplies 会在此之后继续 appendItems 增量追加，
        // 那条路径不会重新走过滤，必须共用同一个复位入口。
        syncRepliesEmptyState();

        // ★ 动态调整 RecyclerView 高度：回复少时用 wrap_content（内联显示），
        // 回复多时用固定高度（只测量可见项，防止 ANR）
        // 仅在"回复区独立滚动"开关开启时生效
        // ★ 竞态修复：loadAllReplies 执行期间强制保持固定高度，
        // 避免 applyFilterResult 把高度改回 wrap_content 后，
        // notifyItemRangeInserted 在 NestedScrollView 中测量全部 item 导致 ANR
        if (swipeCommentMode) {
            // 滑动切换模式：RecyclerView 始终填满 overlay 容器
            binding.recyclerReplies.setNestedScrollingEnabled(true);
            ViewGroup.LayoutParams rp = binding.recyclerReplies.getLayoutParams();
            if (rp.height != ViewGroup.LayoutParams.MATCH_PARENT) {
                rp.height = ViewGroup.LayoutParams.MATCH_PARENT;
                binding.recyclerReplies.setLayoutParams(rp);
            }
        } else if (NestedScrollRepliesManager.isEnabled(this)
                && (mLoadingAllReplies || result.size() >= 1)) {
            binding.recyclerReplies.setNestedScrollingEnabled(true);
            ViewGroup.LayoutParams rp = binding.recyclerReplies.getLayoutParams();
            int twoThirdsScreen = (int)(getResources().getDisplayMetrics().heightPixels * 0.66);
            if (rp.height != twoThirdsScreen) {
                rp.height = twoThirdsScreen;
                binding.recyclerReplies.setLayoutParams(rp);
            }
        } else {
            // 回复少或开关关闭：wrap_content + 关闭嵌套滚动（整体页面滚动）
            binding.recyclerReplies.setNestedScrollingEnabled(false);
            ViewGroup.LayoutParams rp = binding.recyclerReplies.getLayoutParams();
            if (rp.height != ViewGroup.LayoutParams.WRAP_CONTENT) {
                rp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                binding.recyclerReplies.setLayoutParams(rp);
            }
        }
    }

    /** 更新评论总数及当前已过滤数量。 */
    private void updateReplyCountWithFilteredCount() {
        if (binding == null || postDetail == null || replyAdapter == null) return;
        int totalCount = Math.max(0, postDetail.getReplyCount());
        int loadedCount = displayedReplies == null ? 0 : displayedReplies.size();
        int visibleCount = replyAdapter.getItemCount();
        int filteredCount = Math.max(0, loadedCount - visibleCount);
        if (totalCount > 0 || filteredCount > 0) {
            binding.tvReplyCount.setVisibility(View.VISIBLE);
            if (filteredCount > 0) {
                binding.tvReplyCount.setText("(" + totalCount + "，过滤 " + filteredCount + " 条)");
            } else {
                binding.tvReplyCount.setText("(" + totalCount + ")");
            }
        } else {
            binding.tvReplyCount.setVisibility(View.GONE);
        }
    }

    // ==================== 评论黑名单管理 ====================

    private AlertDialog mBlacklistDialog;

    private void showBlacklistDialog() {
        ReplyBlacklistManager mgr = ReplyBlacklistManager.getInstance(this);
        android.view.LayoutInflater inflater = android.view.LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_reply_blacklist, null);

        // 开关
        android.widget.Switch switchEnable = dialogView.findViewById(R.id.switch_blacklist_enable);
        switchEnable.setChecked(mgr.isEnabled());

        // 统计文字
        TextView tvStats = dialogView.findViewById(R.id.tv_blacklist_stats);
        // 清空按钮
        View btnClearAll = dialogView.findViewById(R.id.btn_blacklist_clear_all);
        // 关键词列表 RecyclerView
        androidx.recyclerview.widget.RecyclerView rvKeywords = dialogView.findViewById(R.id.rv_blacklist_keywords);
        rvKeywords.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(this));
        // 空状态
        View llEmpty = dialogView.findViewById(R.id.ll_blacklist_empty);

        // 刷新列表的回调
        Runnable refreshUI = new Runnable() {
            @Override
            public void run() {
                refreshBlacklistUI(rvKeywords, llEmpty, btnClearAll, tvStats, mgr, inflater, this);
            }
        };
        refreshUI.run();

        // 开关监听
        switchEnable.setOnCheckedChangeListener((button, isChecked) -> {
            mgr.setEnabled(isChecked);
            updateReplyFilterAndOrder();
        });

        // 添加关键词 — 点击 + 按钮
        EditText etInput = dialogView.findViewById(R.id.et_blacklist_input);
        View btnAdd = dialogView.findViewById(R.id.btn_blacklist_add);
        View.OnClickListener addListener = v -> {
            String text = etInput.getText().toString().trim();
            if (text.isEmpty()) {
                return;
            }
            boolean added = mgr.addKeyword(text);
            if (!added) {
                android.widget.Toast.makeText(this, "关键词已存在", android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            etInput.setText("");
            etInput.requestFocus();
            refreshUI.run();
            updateReplyFilterAndOrder();
        };
        btnAdd.setOnClickListener(addListener);

        // 回车也可添加
        etInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                addListener.onClick(v);
                return true;
            }
            return false;
        });

        // 清空全部
        btnClearAll.setOnClickListener(v -> {
            if (mgr.size() == 0) return;
            new AlertDialog.Builder(this)
                    .setTitle("清空黑名单")
                    .setMessage("确认清空所有关键词？")
                    .setPositiveButton("清空", (d, w) -> {
                        mgr.clear();
                        refreshUI.run();
                        updateReplyFilterAndOrder();
                    })
                    .setNegativeButton(R.string.blacklist_cancel, null)
                    .show();
        });

        // 导出过滤
        View btnExport = dialogView.findViewById(R.id.btn_blacklist_export);
        btnExport.setOnClickListener(v -> {
            try {
                java.util.List<String> keywords = mgr.getKeywords();
                if (keywords.isEmpty()) {
                    Toast.makeText(this, "暂无关键词可导出", Toast.LENGTH_SHORT).show();
                    return;
                }
                String fileName = "MT_blacklist_" +
                        java.text.SimpleDateFormat.getDateInstance().format(new java.util.Date())
                                .replace("/", "_").replace(" ", "_") + ".txt";
                java.io.File outputFile = writeBlacklistToFile(keywords, fileName);
                if (outputFile != null) {
                    Toast.makeText(this, "已导出 " + keywords.size() + " 个关键词", Toast.LENGTH_SHORT).show();
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    android.net.Uri contentUri = androidx.core.content.FileProvider.getUriForFile(
                            this, getPackageName() + ".fileprovider", outputFile);
                    shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "MT论坛黑名单过滤");
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(shareIntent, "分享黑名单过滤"));
                } else {
                    Toast.makeText(this, "导出失败", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "导出失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // 导入过滤
        View btnImport = dialogView.findViewById(R.id.btn_blacklist_import);
        btnImport.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/plain");
            startActivityForResult(intent, 1001);
        });

        mBlacklistDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.blacklist_manage)
                .setView(dialogView)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void refreshBlacklistUI(androidx.recyclerview.widget.RecyclerView rvKeywords,
                                    View llEmpty, View btnClearAll, TextView tvStats,
                                    ReplyBlacklistManager mgr,
                                    android.view.LayoutInflater inflater,
                                    Runnable refreshCallback) {
        java.util.List<String> keywords = mgr.getKeywords();

        if (keywords.isEmpty()) {
            llEmpty.setVisibility(View.VISIBLE);
            rvKeywords.setVisibility(View.GONE);
            btnClearAll.setVisibility(View.GONE);
            tvStats.setVisibility(View.GONE);
        } else {
            llEmpty.setVisibility(View.GONE);
            rvKeywords.setVisibility(View.VISIBLE);
            btnClearAll.setVisibility(View.VISIBLE);

            // 黑名单管理区域不再显示关键词数量。
            tvStats.setVisibility(View.GONE);

            // 使用 Adapter 高效渲染，避免上千条一次性 inflate
            BlacklistKeywordAdapter adapter = new BlacklistKeywordAdapter(keywords, keyword -> {
                mgr.removeKeyword(keyword);
                refreshCallback.run();
                updateReplyFilterAndOrder();
            });
            rvKeywords.setAdapter(adapter);
        }
    }

    /** 黑名单关键词列表 Adapter — RecyclerView 高效渲染 */
    private static class BlacklistKeywordAdapter
            extends androidx.recyclerview.widget.RecyclerView.Adapter<BlacklistKeywordAdapter.VH> {

        private final java.util.List<String> keywords;
        private final java.util.function.Consumer<String> onDelete;

        BlacklistKeywordAdapter(java.util.List<String> keywords,
                                java.util.function.Consumer<String> onDelete) {
            this.keywords = keywords;
            this.onDelete = onDelete;
        }

        @Override
        public VH onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            View v = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_blacklist_keyword, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            String kw = keywords.get(position);
            holder.tvKeyword.setText(kw);
            holder.btnDelete.setOnClickListener(v -> {
                if (onDelete != null) onDelete.accept(kw);
            });
        }

        @Override
        public int getItemCount() {
            return keywords.size();
        }

        static class VH extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            TextView tvKeyword;
            View btnDelete;

            VH(View v) {
                super(v);
                tvKeyword = v.findViewById(R.id.tv_keyword);
                btnDelete = v.findViewById(R.id.btn_delete_keyword);
            }
        }
    }

    // ==================== 附加统计 ====================
    private void bindAvatarStrip(LinearLayout container, List<String> avatarUrls) {
        if (container == null || isDestroyed() || isFinishing()) return;
        container.removeAllViews();
        if (avatarUrls == null || avatarUrls.isEmpty()) return;

        int maxVisible = Math.min(6, avatarUrls.size());
        int size = dpToPx(32);
        int overlap = dpToPx(8);
        for (int i = 0; i < maxVisible; i++) {
            ImageView avatar = new ImageView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            if (i > 0) params.leftMargin = -overlap;
            avatar.setLayoutParams(params);
            avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
            avatar.setPadding(dpToPx(1), dpToPx(1), dpToPx(1), dpToPx(1));
            avatar.setBackgroundResource(R.drawable.circle_avatar_bg);
            String url = avatarUrls.get(i);
            Glide.with(this)
                    .load(url)
                    .transform(new CircleCrop())
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .into(avatar);
            container.addView(avatar);
        }

        // 超过6个时保留第6个头像并追加“+N”，可继续横向滑动查看已加载列表。
        if (avatarUrls.size() > 6) {
            TextView more = new TextView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    dpToPx(32), dpToPx(32));
            params.leftMargin = -overlap;
            more.setLayoutParams(params);
            more.setGravity(Gravity.CENTER);
            more.setText("+" + (avatarUrls.size() - 6));
            more.setTextSize(10);
            more.setTextColor(Color.WHITE);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(0x99000000);
            bg.setStroke(dpToPx(1), Color.WHITE);
            more.setBackground(bg);
            container.addView(more);
        }
    }

    // ==================== 回复 ====================

    private void attemptReply() {
        // 登录可能来自 WebView；仅当原生 CookieJar 尚未登录时再同步，
        // 避免旧 WebView Cookie 覆盖当前有效会话。
        if (!httpClient.isLoggedIn()) {
            httpClient.syncFromCookieManager();
        }
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }
        if (imageUploadInProgress) {
            Toast.makeText(this, "图片仍在上传，请完成后再发送", Toast.LENGTH_SHORT).show();
            return;
        }

        // 主回复弹窗打开时从弹窗输入框读取内容
        String replyText;
        if (mThreadDialogReplyInput != null && mThreadReplyDialog != null && mThreadReplyDialog.isShowing()) {
            replyText = mThreadDialogReplyInput.getText() == null ? ""
                    : mThreadDialogReplyInput.getText().toString().trim();
        } else {
            replyText = binding.etReply.getText().toString().trim();
        }
        if (TextUtils.isEmpty(replyText)) {
            if (mThreadDialogReplyInput != null && mThreadReplyDialog != null && mThreadReplyDialog.isShowing()) {
                Toast.makeText(this, getString(R.string.reply_hint_empty), Toast.LENGTH_SHORT).show();
            } else {
                binding.tilReply.setError(getString(R.string.reply_hint_empty));
            }
            return;
        }
        if (mThreadDialogReplyInput != null && mThreadReplyDialog != null && mThreadReplyDialog.isShowing()) {
            // 弹窗模式不显示底部输入框错误
        } else {
            binding.tilReply.setError(null);
        }

        submitReplyText(replyText);
    }

    /**
     * 统一的主回复提交链路：底部输入框与"评论/回复"弹窗共用。
     * 弹窗模式成功后自动关闭弹窗并清空底部输入框。
     */
    private void submitReplyText(final String replyText) {
        // 取快照，防止网络线程提交期间 UI 又完成另一张图片上传而漏绑或误绑附件。
        final List<String> uploadAids;
        synchronized (pendingUploadAids) {
            uploadAids = new ArrayList<>(pendingUploadAids);
        }
        final String formhash = postDetail != null ? postDetail.getFormhash() : null;

        // 弹窗模式：同时禁用弹窗发送按钮防止重复提交
        if (mThreadReplyDialog != null && mThreadReplyDialog.isShowing()) {
            try {
                View dv = mThreadReplyDialog.findViewById(R.id.btn_dialog_send);
                if (dv != null) dv.setEnabled(false);
            } catch (Exception ignored) {
            }
        }
        new Thread(() -> {
            try {
                String fh = formhash;
                if (TextUtils.isEmpty(fh)) {
                    String html = httpClient.get(ForumParser.getThreadDetailUrl(tid));
                    fh = ForumParser.parseFormhash(html);
                }
                if (TextUtils.isEmpty(fh)) {
                    showReplyFailure("获取回复验证失败，请刷新页面后重试");
                    return;
                }

                Map<String, String> params = new HashMap<>();
                params.put("formhash", fh);
                params.put("message", replyText);
                params.put("replysubmit", "yes");
                params.put("posttime", String.valueOf(System.currentTimeMillis() / 1000));

                // swfupload 只会暂存附件。必须使用 attachnew[aid][description]
                // 才会在回复发布时将图片正式关联；attach[] 会造成“上传成功但帖子无图”。
                for (String aid : uploadAids) {
                    if (!TextUtils.isEmpty(aid) && aid.matches("\\d+")) {
                        params.put("attachnew[" + aid + "][description]", "");
                    }
                }

                String replyUrl = HttpClient.BASE_URL
                        + "forum.php?mod=post&action=reply&tid="
                        + tid + "&extra=&replysubmit=yes&mobile=2";
                String result = httpClient.post(replyUrl, params);
                boolean responseReportsSuccess = isReplyResponseSuccessful(result);
                // Discuz!/Comiis 的成功响应并不固定：有些主题会返回 XML/脚本，甚至会在
                // 成功页面的公共脚本中带有“formhash错误”字样。响应无法明确识别时，
                // 以重新读取服务端帖子后的实际内容作为最终依据，避免“已发布却提示失败”。
                if (!responseReportsSuccess
                        && !wasReplyPublished(replyText, uploadAids)) {
                    showReplyFailure(extractReplyError(result));
                    return;
                }

                completeReplyPublished(uploadAids);
            } catch (Exception e) {
                showReplyFailure("回复失败：" + (TextUtils.isEmpty(e.getMessage())
                        ? "网络异常，请稍后重试" : e.getMessage()));
            }
        }).start();
    }

    /**
     * 弹窗发送：把弹窗输入内容同步到底部输入框后走统一提交链路，
     * 成功后关闭弹窗。
     */
    private void submitReplyFromDialog(String text) {
        // 直接走统一提交链路；发送失败时 showReplyFailure 会保留弹窗内容
        // （弹窗不自动关闭，用户可修改后重试）。
        submitReplyText(text);
    }

    /**
     * 当接口未返回统一的成功格式时，到服务端最后一页核验刚发布的内容。
     * 只在响应无法确认时调用，避免把网络超时直接误报为成功。
     */
    private boolean wasReplyPublished(String replyText, List<String> uploadAids) {
        try {
            String currentUid = UserSessionManager.getInstance().getUid(getApplicationContext());
            if (TextUtils.isEmpty(currentUid)) return false;

            // 记录发送前已有的 pid 集合，用于检测“出现新楼层”。
            Set<String> knownPids = new HashSet<>();
            if (postDetail != null && postDetail.getReplies() != null) {
                for (ReplyItem it : postDetail.getReplies()) {
                    if (it != null && !TextUtils.isEmpty(it.getPid())) {
                        knownPids.add(it.getPid());
                    }
                }
            }

            int lastPage = postDetail != null ? Math.max(1, postDetail.getTotalPages()) : 1;
            String url = ForumParser.getThreadDetailUrl(tid) + "&page=" + lastPage
                    + "&_reply_check=" + System.currentTimeMillis();
            PostDetail latest = ForumParser.parseThreadDetail(httpClient.get(url));
            if (latest == null || latest.getReplies() == null) return false;

            String expectedText = normalizeReplyText(replyText);
            for (int i = latest.getReplies().size() - 1; i >= 0; i--) {
                ReplyItem item = latest.getReplies().get(i);
                if (item == null || !currentUid.equals(item.getAuthorUid())) continue;

                // ① 出现一个发送前不存在的自己的新楼层 pid —— 说明发布成功。
                // 纯表情/含表情消息被服务器渲染成 <img> 后，文本无法精确匹配，必须靠此兜底。
                if (!TextUtils.isEmpty(item.getPid()) && !knownPids.contains(item.getPid())) {
                    return true;
                }

                // ② 纯文本/带文字消息：仍保留内容校验作为第二道依据。
                if (!TextUtils.isEmpty(expectedText)
                        && normalizeReplyText(item.getContentText()).contains(expectedText)) {
                    return true;
                }
                // 纯图片评论在解析后可能没有可比对的正文；此时核验该楼层是否带有本次附件 aid。
                if (TextUtils.isEmpty(expectedText) && uploadAids != null && !uploadAids.isEmpty()) {
                    String html = item.getContentHtml();
                    boolean allPresent = !TextUtils.isEmpty(html);
                    for (String aid : uploadAids) {
                        if (TextUtils.isEmpty(aid) || !html.contains(aid)) {
                            allPresent = false;
                            break;
                        }
                    }
                    if (allPresent) return true;
                }
            }
        } catch (Exception ignored) {
            // 核验失败时仍保留原输入和附件，用户可以安全地决定是否重试。
        }
        return false;
    }

    private String normalizeReplyText(String text) {
        if (TextUtils.isEmpty(text)) return "";
        return text.replaceAll("(?is)\\[attach(?:img)?\\]\\d+\\[/attach(?:img)?\\]", "")
                .replaceAll("\\s+", " ").trim();
    }

    private void completeReplyPublished(List<String> uploadAids) {
        runOnUiThread(() -> {
            binding.etReply.setText("");
            binding.tilReply.setError(null);
            synchronized (pendingUploadAids) {
                pendingUploadAids.removeAll(uploadAids);
            }
            // 弹窗模式：发送成功后自动关闭弹窗（先清空弹窗输入框，避免 dismiss 监听回填残留文字）
            if (mThreadReplyDialog != null && mThreadReplyDialog.isShowing()) {
                if (mThreadDialogReplyInput != null) {
                    mThreadDialogReplyInput.setText("");
                }
                mThreadReplyDialog.dismiss();
            }
            Toast.makeText(ThreadDetailActivity.this,
                    R.string.reply_success, Toast.LENGTH_SHORT).show();
            refreshRepliesAfterPublished();
        });
    }

    /**
     * 回复发布成功后只同步包含最新回复的页面，并按 pid 合并到当前列表。
     * 不再重新 bindData，避免清空“加载全部评论”已经加载的内容。
     */
    private void refreshRepliesAfterPublished() {
        new Thread(() -> {
            try {
                httpClient.syncFromCookieManager();

                // 倒序时第一页包含最新回复；正序时先读第一页取得最新总页数，
                // 再读取最后一页，兼容本次回复导致新增分页的情况。
                String firstUrl = ForumParser.getThreadDetailUrl(tid, 1, getReplyOrder());
                PostDetail firstDetail = ForumParser.parseThreadDetail(httpClient.get(firstUrl));
                if (firstDetail == null) {
                    throw new IllegalStateException("评论同步失败");
                }

                PostDetail latestDetail = firstDetail;
                int latestTotalPages = Math.max(1, firstDetail.getTotalPages());
                if (!repliesDescending && latestTotalPages > 1) {
                    String lastUrl = ForumParser.getThreadDetailUrl(
                            tid, latestTotalPages, getReplyOrder());
                    PostDetail lastDetail = ForumParser.parseThreadDetail(httpClient.get(lastUrl));
                    if (lastDetail != null) {
                        latestDetail = lastDetail;
                        latestTotalPages = Math.max(latestTotalPages,
                                lastDetail.getTotalPages());
                    }
                }

                final PostDetail syncedDetail = latestDetail;
                final int syncedTotalPages = latestTotalPages;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed() || postDetail == null) return;

                    List<ReplyItem> merged = displayedReplies == null
                            ? new ArrayList<>() : new ArrayList<>(displayedReplies);
                    Set<String> knownPids = new HashSet<>();
                    for (ReplyItem item : merged) {
                        if (item != null && !TextUtils.isEmpty(item.getPid())) {
                            knownPids.add(item.getPid());
                        }
                    }

                    List<ReplyItem> latestReplies = syncedDetail.getReplies();
                    List<ReplyItem> newReplies = new ArrayList<>();
                    if (latestReplies != null) {
                        for (ReplyItem item : latestReplies) {
                            if (item == null) continue;
                            String pid = item.getPid();
                            if (!TextUtils.isEmpty(pid) && knownPids.contains(pid)) continue;
                            newReplies.add(item);
                            if (!TextUtils.isEmpty(pid)) knownPids.add(pid);
                        }
                    }
                    // 整批合并，保留服务端返回的新回复顺序。
                    // 倒序时加到列表头部，正序时追加到列表尾部。
                    if (repliesDescending) {
                        merged.addAll(0, newReplies);
                    } else {
                        merged.addAll(newReplies);
                    }

                    displayedReplies = merged;
                    postDetail.setReplies(new ArrayList<>(merged));
                    postDetail.setReplyCount(Math.max(postDetail.getReplyCount(),
                            syncedDetail.getReplyCount()));
                    postDetail.setTotalPages(Math.max(postDetail.getTotalPages(),
                            syncedTotalPages));
                    if (!TextUtils.isEmpty(syncedDetail.getFormhash())) {
                        postDetail.setFormhash(syncedDetail.getFormhash());
                    }

                    updateReplyFilterAndOrder();
                    boolean hasMore = postDetail.getCurrentPage() < postDetail.getTotalPages();
                    binding.btnLoadMore.setVisibility(hasMore ? View.VISIBLE : View.GONE);
                    binding.btnLoadMore.setEnabled(true);
                    binding.btnLoadMore.setText(R.string.load_more_replies);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(ThreadDetailActivity.this,
                        "回复已发布，最新评论同步失败，可稍后手动刷新",
                        Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private boolean isReplyResponseSuccessful(String response) {
        if (TextUtils.isEmpty(response) || ForumParser.isLoginPage(response)) return false;
        String lower = response.toLowerCase(java.util.Locale.ROOT);
        // Discuz 标准 Ajax/XML 成功标记，以及 Comiis 的成功提示。
        // 必须先检测成功标记：Comiis 成功页的公共脚本中也常含“formhash错误”等字样，
        // 若先检测失败短语会把“已发布成功”误判为“验证失效”。
        if (lower.contains("succeedhandle_reply") || lower.contains("succeedhandle_post")
                || lower.contains("reply_success") || lower.contains("回复发布成功")
                || lower.contains("发布成功") || lower.contains("succeedhandle")) {
            return true;
        }
        if (containsAny(response, "请先登录", "formhash错误", "非法操作", "没有权限",
                "回复失败", "附件上传失败", "附件不存在", "上传图片失败")) {
            return false;
        }
        return Pattern.compile("[?&](?:tid|pid)=\\d+", Pattern.CASE_INSENSITIVE)
                .matcher(response).find();
    }

    private String extractReplyError(String response) {
        if (TextUtils.isEmpty(response)) return "回复失败，服务器未返回结果";
        if (ForumParser.isLoginPage(response) || containsAny(response, "请先登录")) {
            return "登录状态已失效，请重新登录";
        }
        if (containsAny(response, "formhash错误", "非法操作")) {
            return "验证已失效，请刷新页面后重试";
        }
        if (containsAny(response, "附件上传失败", "附件不存在", "上传图片失败")) {
            return "图片附件关联失败，请重新上传后再发送";
        }
        return "回复发布失败，请稍后重试";
    }

    private void showReplyFailure(String message) {
        runOnUiThread(() -> {
            // 弹窗模式：恢复弹窗发送按钮，便于用户修改后重试
            if (mThreadReplyDialog != null && mThreadReplyDialog.isShowing()) {
                try {
                    View dv = mThreadReplyDialog.findViewById(R.id.btn_dialog_send);
                    if (dv != null) dv.setEnabled(true);
                } catch (Exception ignored) {
                }
            }
            Toast.makeText(ThreadDetailActivity.this, message, Toast.LENGTH_SHORT).show();
        });
    }

    // ==================== 帖子主回复弹窗（仿"回复评论"弹窗交互） ====================

    /**
     * 如果主回复弹窗尚未打开则弹出并返回 true，已打开则返回 false。
     */
    private boolean showThreadReplyDialogIfNeeded() {
        if (mThreadReplyDialog != null && mThreadReplyDialog.isShowing()) {
            return false;
        }
        showThreadReplyDialog();
        return true;
    }

    /**
     * 帖子底部输入框改为弹窗输入：点击底部"说点什么吧..."输入框时，
     * 弹出与"回复评论"同款的弹窗（dialog_reply_comment.xml），
     * 标题为"评论"，输入框为空由用户输入，发送后走原有 attemptReply 的提交链路。
     */
    private void showThreadReplyDialog() {
        if (!httpClient.isLoggedIn()) {
            httpClient.syncFromCookieManager();
        }
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }

        View dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_reply_comment, null);
        TextView tvTitle = dialogView.findViewById(R.id.tv_dialog_title);
        TextView btnCancel = dialogView.findViewById(R.id.btn_dialog_cancel);
        TextView btnSend = dialogView.findViewById(R.id.btn_dialog_send);
        EditText etDialogReply = dialogView.findViewById(R.id.et_dialog_reply);

        // ===== 应用回复弹窗自定义颜色 =====
        int dlgTextColor = com.forum.MT.ui.widget.ReplyDialogColorManager.resolveTextColor(this);
        int dlgBgColor = com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBgColor(this);
        int dlgBorderColor = com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBorderColor(this);
        int dlgBtnColor = com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBtnColor(this);

        // 弹窗背景：圆角 + 边框
        android.graphics.drawable.GradientDrawable dlgBg = new android.graphics.drawable.GradientDrawable();
        dlgBg.setColor(dlgBgColor);
        dlgBg.setCornerRadius(dpToPx(16));
        dlgBg.setStroke(dpToPx(1), dlgBorderColor);
        dialogView.setBackground(dlgBg);

        // 标题文字色
        tvTitle.setTextColor(dlgTextColor);

        // 输入框文字色
        etDialogReply.setTextColor(dlgTextColor);
        etDialogReply.setHintTextColor(dlgTextColor);

        // 输入框边框色（TextInputLayout 的 boxStrokeColor）
        com.google.android.material.textfield.TextInputLayout tilDialogReply =
                dialogView.findViewById(R.id.til_dialog_reply);
        if (tilDialogReply != null) {
            tilDialogReply.setBoxStrokeColorStateList(android.content.res.ColorStateList.valueOf(dlgBorderColor));
        }

        // 发送按钮：无边框，使用按钮色
        android.graphics.drawable.GradientDrawable sendBg = new android.graphics.drawable.GradientDrawable();
        sendBg.setColor(dlgBtnColor);
        sendBg.setCornerRadius(dpToPx(20));
        btnSend.setBackground(sendBg);
        btnSend.setTextColor(android.graphics.Color.WHITE);

        // 取消按钮：和发送一样的按键样式，共用设置
        android.graphics.drawable.GradientDrawable cancelBg = new android.graphics.drawable.GradientDrawable();
        cancelBg.setColor(dlgBtnColor);
        cancelBg.setCornerRadius(dpToPx(20));
        btnCancel.setBackground(cancelBg);
        btnCancel.setTextColor(android.graphics.Color.WHITE);
        btnCancel.setTextSize(15);
        btnCancel.setTypeface(null, android.graphics.Typeface.BOLD);
        btnCancel.setPadding(dpToPx(24), dpToPx(10), dpToPx(24), dpToPx(10));
        // 弹窗底部操作：表情 / 图片
        View btnDialogEmoji = dialogView.findViewById(R.id.btn_dialog_emoji);
        View btnDialogImage = dialogView.findViewById(R.id.btn_dialog_image);
        if (btnDialogEmoji != null) {
            btnDialogEmoji.setOnClickListener(v -> showEmojiPanel());
        }
        if (btnDialogImage != null) {
            btnDialogImage.setOnClickListener(v -> {
                if (imageUploadInProgress) {
                    Toast.makeText(this, "图片仍在上传，请稍候", Toast.LENGTH_SHORT).show();
                    return;
                }
                pickImage();
            });
        }
        // 工具箱按钮：展开/收起扩展功能面板（加粗/链接/引用/代码）
        View btnDialogToolbox = dialogView.findViewById(R.id.btn_dialog_toolbox);
        View llFunctionPanel = dialogView.findViewById(R.id.ll_dialog_function_panel);
        if (btnDialogToolbox != null && llFunctionPanel != null) {
            btnDialogToolbox.setOnClickListener(v -> {
                boolean shouldShow = llFunctionPanel.getVisibility() != View.VISIBLE;
                if (shouldShow) {
                    llFunctionPanel.setVisibility(View.VISIBLE);
                    llFunctionPanel.setAlpha(0f);
                    llFunctionPanel.setScaleX(0.86f);
                    llFunctionPanel.setScaleY(0.86f);
                    llFunctionPanel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).start();
                } else {
                    llFunctionPanel.animate().alpha(0f).scaleX(0.86f).scaleY(0.86f).setDuration(140L)
                            .withEndAction(() -> { llFunctionPanel.setVisibility(View.GONE); llFunctionPanel.setAlpha(1f); llFunctionPanel.setScaleX(1f); llFunctionPanel.setScaleY(1f); }).start();
                }
            });
        }
        // 扩展功能按钮
        View btnBold = dialogView.findViewById(R.id.btn_dialog_bold);
        View btnLink = dialogView.findViewById(R.id.btn_dialog_link);
        View btnQuote = dialogView.findViewById(R.id.btn_dialog_quote);
        View btnCode = dialogView.findViewById(R.id.btn_dialog_code);
        if (btnBold != null) btnBold.setOnClickListener(v -> {
            insertDialogReplyTags(etDialogReply, "[b]", "[/b]");
            if (llFunctionPanel != null) llFunctionPanel.setVisibility(View.GONE);
        });
        if (btnLink != null) btnLink.setOnClickListener(v -> {
            showDialogReplyLinkDialog(etDialogReply);
            if (llFunctionPanel != null) llFunctionPanel.setVisibility(View.GONE);
        });
        if (btnQuote != null) btnQuote.setOnClickListener(v -> {
            showDialogReplyQuoteDialog(etDialogReply);
            if (llFunctionPanel != null) llFunctionPanel.setVisibility(View.GONE);
        });
        if (btnCode != null) btnCode.setOnClickListener(v -> {
            showDialogReplyCodeDialog(etDialogReply);
            if (llFunctionPanel != null) llFunctionPanel.setVisibility(View.GONE);
        });

        tvTitle.setText("评论");

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(dialogView);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            android.view.WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.9f);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setAttributes(lp);
            dialog.getWindow().setSoftInputMode(
                    android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }

        mThreadReplyDialog = dialog;
        mThreadDialogReplyInput = etDialogReply;
        // 保留用户之前输入的内容（若上次弹窗未发送且未关闭）
        String prev = binding.etReply.getText() == null ? "" : binding.etReply.getText().toString().trim();
        if (!TextUtils.isEmpty(prev)) {
            etDialogReply.setText(prev);
            etDialogReply.setSelection(etDialogReply.getText().length());
        }

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnSend.setOnClickListener(v -> {
            String text = etDialogReply.getText() == null ? "" : etDialogReply.getText().toString().trim();
            if (TextUtils.isEmpty(text)) {
                Toast.makeText(ThreadDetailActivity.this,
                        R.string.reply_hint_empty, Toast.LENGTH_SHORT).show();
                return;
            }
            btnSend.setEnabled(false);
            submitReplyFromDialog(text);
        });
        // 软键盘回车直接发送
        etDialogReply.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                btnSend.performClick();
                return true;
            }
            return false;
        });

        dialog.setOnShowListener(d -> etDialogReply.requestFocus());
        dialog.setOnDismissListener(d -> {
            // 弹窗关闭时把未发送内容回填到底部输入框便于下次打开继续
            if (mThreadDialogReplyInput != null) {
                String text = mThreadDialogReplyInput.getText() == null ? "" : mThreadDialogReplyInput.getText().toString();
                binding.etReply.setText(text);
            }
            mThreadReplyDialog = null;
            mThreadDialogReplyInput = null;
        });
        dialog.show();
    }

    /** 弹窗内插入成对 BBCode 标签到 EditText */
    private void insertDialogReplyTags(EditText et, String openTag, String closeTag) {
        if (et == null) return;
        Editable editable = et.getText();
        if (editable == null) return;
        int length = editable.length();
        int start = et.getSelectionStart();
        int end = et.getSelectionEnd();
        if (start < 0) start = length;
        if (end < 0) end = start;
        start = Math.min(start, length);
        end = Math.min(end, length);
        if (start > end) { int t = start; start = end; end = t; }
        editable.replace(start, end, openTag + editable.subSequence(start, end) + closeTag);
        int cursor = (end == start) ? start + openTag.length()
                : start + openTag.length() + (end - start) + closeTag.length();
        et.setSelection(Math.min(cursor, editable.length()));
        et.requestFocus();
    }

    /** 弹窗内插入带内容的 BBCode 标签 */
    private void insertDialogReplyContent(EditText et, String openTag, String closeTag, String content) {
        if (et == null) return;
        Editable editable = et.getText();
        if (editable == null) return;
        int length = editable.length();
        int start = et.getSelectionStart();
        int end = et.getSelectionEnd();
        if (start < 0) start = length;
        if (end < 0) end = start;
        start = Math.min(start, length);
        end = Math.min(end, length);
        if (start > end) { int t = start; start = end; end = t; }
        String value = openTag + content + closeTag;
        editable.replace(start, end, value);
        et.setSelection(Math.min(start + value.length(), editable.length()));
        et.requestFocus();
    }

    private String getDialogSelectedText(EditText et) {
        if (et == null) return "";
        Editable editable = et.getText();
        if (editable == null) return "";
        int start = Math.max(0, et.getSelectionStart());
        int end = Math.max(0, et.getSelectionEnd());
        if (start > end) { int t = start; start = end; end = t; }
        start = Math.min(start, editable.length());
        end = Math.min(end, editable.length());
        return editable.subSequence(start, end).toString();
    }

    private void showDialogReplyLinkDialog(EditText et) {
        if (et == null) return;
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_reply_link);
        dialog.setCancelable(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        EditText inputUrl = dialog.findViewById(R.id.et_reply_link_url);
        EditText inputText = dialog.findViewById(R.id.et_reply_link_text);
        View cancel = dialog.findViewById(R.id.btn_cancel_link);
        View confirm = dialog.findViewById(R.id.btn_confirm_link);
        if (cancel != null) cancel.setOnClickListener(v -> dialog.dismiss());
        if (confirm != null) confirm.setOnClickListener(v -> {
            String url = inputUrl == null ? "" : inputUrl.getText().toString().trim();
            String linkText = inputText == null ? "" : inputText.getText().toString().trim();
            if (url.isEmpty()) { if (inputUrl != null) inputUrl.setError("请输入链接地址"); return; }
            String selected = getDialogSelectedText(et);
            String title = TextUtils.isEmpty(linkText) ? selected : linkText;
            if (TextUtils.isEmpty(title)) {
                insertDialogReplyContent(et, "[url]", "[/url]", url);
            } else {
                insertDialogReplyContent(et, "[url=" + url + "]", "[/url]", title);
            }
            dialog.dismiss();
        });
        dialog.show();
    }

    private void showDialogReplyQuoteDialog(EditText et) {
        if (et == null) return;
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_reply_quote);
        dialog.setCancelable(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        EditText input = dialog.findViewById(R.id.et_reply_quote);
        View cancel = dialog.findViewById(R.id.btn_cancel_quote);
        View confirm = dialog.findViewById(R.id.btn_confirm_quote);
        String selected = getDialogSelectedText(et);
        if (!TextUtils.isEmpty(selected) && input != null) input.setText(selected);
        if (cancel != null) cancel.setOnClickListener(v -> dialog.dismiss());
        if (confirm != null) confirm.setOnClickListener(v -> {
            String value = input == null ? "" : input.getText().toString().trim();
            if (TextUtils.isEmpty(value)) { if (input != null) input.setError("请输入引用内容"); return; }
            insertDialogReplyContent(et, "[quote]", "[/quote]", value);
            dialog.dismiss();
        });
        dialog.show();
    }

    private void showDialogReplyCodeDialog(EditText et) {
        if (et == null) return;
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_reply_code);
        dialog.setCancelable(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        EditText input = dialog.findViewById(R.id.et_reply_code);
        View cancel = dialog.findViewById(R.id.btn_cancel_code);
        View confirm = dialog.findViewById(R.id.btn_confirm_code);
        String selected = getDialogSelectedText(et);
        if (!TextUtils.isEmpty(selected) && input != null) input.setText(selected);
        if (cancel != null) cancel.setOnClickListener(v -> dialog.dismiss());
        if (confirm != null) confirm.setOnClickListener(v -> {
            String value = input == null ? "" : input.getText().toString().trim();
            if (TextUtils.isEmpty(value)) { if (input != null) input.setError("请输入代码内容"); return; }
            insertDialogReplyContent(et, "[code]", "[/code]", value);
            dialog.dismiss();
        });
        dialog.show();
    }

    // ==================== 回复评论弹窗（仿官方安装包交互） ====================

    /**
     * 仿官方"回复评论"弹窗：点击楼层回复按钮时弹出对话框，
     * 标题显示"回复 {用户名}"，输入框为空，不再往底部输入框预填内容。
     */
    private void showReplyCommentDialog(ReplyItem item) {
        if (item == null) return;
        final String targetPid = item.getPid();
        if (TextUtils.isEmpty(targetPid)) return;

        String username = item.getAuthor();
        if (TextUtils.isEmpty(username) || username.trim().isEmpty()) {
            username = "匿名用户";
        } else {
            username = username.trim();
        }
        final String targetAuthor = username;
        String itemTime = item.getTime() == null ? "" : item.getTime().trim();
        final String targetTime = itemTime;
        // 目标楼层原文（有内容时提交时附带引用，仿官方 repquote 逻辑）
        String contentText = item.getContentText() == null ? "" : item.getContentText().trim();
        final String targetContent = contentText;

        View dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_reply_comment, null);
        TextView tvTitle = dialogView.findViewById(R.id.tv_dialog_title);
        TextView btnCancel = dialogView.findViewById(R.id.btn_dialog_cancel);
        TextView btnSend = dialogView.findViewById(R.id.btn_dialog_send);
        EditText etReply = dialogView.findViewById(R.id.et_dialog_reply);

        // ===== 应用回复弹窗自定义颜色 =====
        int dlgTextColor = com.forum.MT.ui.widget.ReplyDialogColorManager.resolveTextColor(this);
        int dlgBgColor = com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBgColor(this);
        int dlgBorderColor = com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBorderColor(this);
        int dlgBtnColor = com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBtnColor(this);

        // 弹窗背景：圆角 + 边框
        android.graphics.drawable.GradientDrawable dlgBg = new android.graphics.drawable.GradientDrawable();
        dlgBg.setColor(dlgBgColor);
        dlgBg.setCornerRadius(dpToPx(16));
        dlgBg.setStroke(dpToPx(1), dlgBorderColor);
        dialogView.setBackground(dlgBg);

        // 标题文字色
        tvTitle.setTextColor(dlgTextColor);

        // 输入框文字色
        etReply.setTextColor(dlgTextColor);
        etReply.setHintTextColor(dlgTextColor);

        // 输入框边框色（TextInputLayout 的 boxStrokeColor）
        com.google.android.material.textfield.TextInputLayout tilReply =
                dialogView.findViewById(R.id.til_dialog_reply);
        if (tilReply != null) {
            tilReply.setBoxStrokeColorStateList(android.content.res.ColorStateList.valueOf(dlgBorderColor));
        }

        // 发送按钮：无边框，使用按钮色
        android.graphics.drawable.GradientDrawable sendBg = new android.graphics.drawable.GradientDrawable();
        sendBg.setColor(dlgBtnColor);
        sendBg.setCornerRadius(dpToPx(20));
        btnSend.setBackground(sendBg);
        btnSend.setTextColor(android.graphics.Color.WHITE);

        // 取消按钮：和发送一样的按键样式，共用设置
        android.graphics.drawable.GradientDrawable cancelBg = new android.graphics.drawable.GradientDrawable();
        cancelBg.setColor(dlgBtnColor);
        cancelBg.setCornerRadius(dpToPx(20));
        btnCancel.setBackground(cancelBg);
        btnCancel.setTextColor(android.graphics.Color.WHITE);
        btnCancel.setTextSize(15);
        btnCancel.setTypeface(null, android.graphics.Typeface.BOLD);
        btnCancel.setPadding(dpToPx(24), dpToPx(10), dpToPx(24), dpToPx(10));
        // 弹窗底部操作：表情 / 图片
        View btnDialogEmoji = dialogView.findViewById(R.id.btn_dialog_emoji);
        View btnDialogImage = dialogView.findViewById(R.id.btn_dialog_image);
        if (btnDialogEmoji != null) {
            btnDialogEmoji.setOnClickListener(v -> showEmojiPanel());
        }
        if (btnDialogImage != null) {
            btnDialogImage.setOnClickListener(v -> {
                if (imageUploadInProgress) {
                    Toast.makeText(this, "图片仍在上传，请稍候", Toast.LENGTH_SHORT).show();
                    return;
                }
                pickImage();
            });
        }

        tvTitle.setText("回复 " + targetAuthor);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(dialogView);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            android.view.WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.9f);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setAttributes(lp);
            dialog.getWindow().setSoftInputMode(
                    android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnSend.setOnClickListener(v -> {
            String text = etReply.getText() == null ? "" : etReply.getText().toString().trim();
            if (TextUtils.isEmpty(text)) {
                Toast.makeText(ThreadDetailActivity.this,
                        R.string.reply_hint_empty, Toast.LENGTH_SHORT).show();
                return;
            }
            btnSend.setEnabled(false);
            dialog.dismiss();
            submitReplyToComment(targetPid, targetAuthor, targetTime, targetContent, text);
        });
        // 软键盘回车直接发送
        etReply.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                btnSend.performClick();
                return true;
            }
            return false;
        });

        dialog.setOnShowListener(d -> etReply.requestFocus());
        mThreadReplyDialog = dialog;
        mThreadDialogReplyInput = etReply;
        dialog.setOnDismissListener(d -> {
            // 回复评论弹窗关闭后清理引用（不回填底部输入框，保持官方交互）
            mThreadReplyDialog = null;
            mThreadDialogReplyInput = null;
        });
        dialog.show();
    }

    /**
     * 提交"回复评论"，严格仿官方安装包 CommentManager.submitReplyToComment：
     * - URL（i.d + i.b）：forum.php?mod=post&action=reply&fid=<fid>&tid=<tid>
     *        &repquote=<pid>&page=<page>  [&handlekey=fastpost&loc=1&inajax=1]
     *   （pid 为空时去掉 &repquote=<pid>；url 含 ? 时 handlekey 前用 &）
     * - POST 参数（i.c 评论回复分支）：formhash / message / replysubmit=yes /
     *        noticetrimstr（引用块，通知被回复人）/ noticeauthormsg（原文前100字符）
     */
    private void submitReplyToComment(String targetPid, String targetAuthor,
                                      String targetTime, String targetContent,
                                      String replyText) {
        if (!httpClient.isLoggedIn()) {
            httpClient.syncFromCookieManager();
        }
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }
        final String finalText = replyText;
        final String formhash = postDetail != null ? postDetail.getFormhash() : null;
        final String fid = postDetail != null ? postDetail.getForumFid() : null;
        final String timeText = targetTime == null ? "" : targetTime;
        final String authorText = (targetAuthor == null || targetAuthor.trim().isEmpty())
                ? "匿名用户" : targetAuthor.trim();
        final String contentText = targetContent == null ? "" : targetContent;

        new Thread(() -> {
            try {
                String fh = formhash;
                if (TextUtils.isEmpty(fh)) {
                    String html = httpClient.get(ForumParser.getThreadDetailUrl(tid));
                    fh = ForumParser.parseFormhash(html);
                }
                if (TextUtils.isEmpty(fh)) {
                    showReplyFailure("获取回复验证失败，请刷新页面后重试");
                    return;
                }

                // 清理 message：HTML 实体反转义、去标签、空白归一、截 200（官方 i.c 处理）
                String msg = cleanReplyMessage(finalText);

                Map<String, String> params = new HashMap<>();
                params.put("formhash", fh);
                params.put("message", msg);
                params.put("replysubmit", "yes");

                // 评论回复（对已有评论回复）：带引用通知字段（官方 noticetrimstr / noticeauthormsg）
                if (!TextUtils.isEmpty(targetPid)) {
                    String findPost = "forum.php?mod=redirect&goto=findpost&pid="
                            + targetPid + "&ptid=" + tid;
                    String quote;
                    if (!TextUtils.isEmpty(contentText)) {
                        quote = "[quote][size=2][url=" + findPost
                                + "][color=#999999]" + authorText + " 发表于 " + timeText
                                + "][/color][/url][/size]\n" + cleanReplyMessage(contentText)
                                + "[/quote]";
                    } else {
                        quote = "[quote][size=2][url=" + findPost
                                + "][color=#999999]" + authorText
                                + "][/color][/url][/size]\n" + cleanReplyMessage(msg)
                                + "[/quote]";
                    }
                    params.put("noticetrimstr", quote);
                    params.put("noticeauthormsg", takeChars(msg, 100));
                }

                // URL：forum.php?mod=post&action=reply&fid=<fid>&tid=<tid>
                //       [&repquote=<pid>]&page=1
                StringBuilder url = new StringBuilder(HttpClient.BASE_URL)
                        .append("forum.php?mod=post&action=reply&fid=")
                        .append(fid == null ? "" : fid)
                        .append("&tid=").append(tid)
                        .append("&page=1");
                if (!TextUtils.isEmpty(targetPid)) {
                    url.append("&repquote=").append(targetPid);
                }
                url.append("&handlekey=fastpost&loc=1&inajax=1");
                String commentUrl = url.toString();
                String referer = ForumParser.getThreadDetailUrl(tid);
                String result = httpClient.postWithReferer(commentUrl, params, referer);
                boolean responseReportsSuccess = isCommentSuccess(result);
                if (!responseReportsSuccess) {
                    showReplyFailure(extractCommentError(result));
                    return;
                }
                runOnUiThread(() -> {
                    Toast.makeText(ThreadDetailActivity.this,
                            "评论回复发布成功", Toast.LENGTH_SHORT).show();
                    refreshRepliesAfterPublished();
                });
            } catch (Exception e) {
                showReplyFailure("回复失败：" + (TextUtils.isEmpty(e.getMessage())
                        ? "网络异常，请稍后重试" : e.getMessage()));
            }
        }).start();
    }

    /**
     * 仿官方 i.c() 的 message 清理：HTML 实体反转义 → 去 HTML 标签 → 空白归一 → 截 200。
     * 注意：不能再把 [ → 【、] → 】。QQ/贴吧/狗头表情的 code（如 [呵呵]、[doge]）依赖 []
     * 括号被服务器识别，若转成【】会变成普通文本导致表情无法渲染。
     */
    private String cleanReplyMessage(String input) {
        if (input == null) return "";
        String s = input;
        s = s.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
                .replace("&apos;", "'").replace("\u00a0", " ");
        s = s.replaceAll("<[^>]+>", "");
        s = s.replaceAll("\\s+", " ").trim();
        s = takeChars(s, 200);
        return s;
    }

    private String takeChars(String s, int n) {
        if (s == null) return "";
        if (s.length() <= n) return s;
        return s.substring(0, n);
    }

    /**
     * 评论回复成功判定，与官方 i.f()/i.e() 判定一致：
     * succeedhandle_fastpost / succeedhandle / post_reply_succeed / 回复成功 / 发表回复成功
     */
    private boolean isCommentSuccess(String response) {
        if (TextUtils.isEmpty(response) || ForumParser.isLoginPage(response)) return false;
        // 成功标记优先：Comiis 成功页公共脚本中也常含“formhash错误”等字样，
        // 先检测成功标记可避免把“已发布成功”误判为“验证失效”。
        String lower = response.toLowerCase(java.util.Locale.ROOT);
        if (lower.contains("succeedhandle")
                || lower.contains("post_reply_succeed")
                || containsAny(response, "回复成功", "发表回复成功", "发布成功", "点评成功")) {
            return true;
        }
        if (containsAny(response, "请先登录", "formhash错误", "非法操作", "没有权限",
                "回复失败", "评论失败", "点评失败")) {
            return false;
        }
        return false;
    }

    private String extractCommentError(String response) {
        if (TextUtils.isEmpty(response)) return "评论回复失败，服务器未返回结果";
        if (ForumParser.isLoginPage(response) || containsAny(response, "请先登录")) {
            return "登录状态已失效，请重新登录";
        }
        if (containsAny(response, "formhash错误", "非法操作")) {
            return "验证已失效，请刷新页面后重试";
        }
        // 仿官方 i.g() 提取服务端具体错误（Discuz inajax 返回 <error>...</error> 或明文提示）
        String clean = response.replaceAll("\\s+", " ").trim();
        if (containsAny(clean, "内容不能为空")) {
            return "评论内容不能为空";
        }
        if (containsAny(clean, "发帖过于频繁", "频繁")) {
            return "发帖过于频繁，请稍后再试";
        }
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("<error>(.*?)</error>", java.util.regex.Pattern.DOTALL)
                .matcher(clean);
        if (m.find()) {
            String err = m.group(1).replaceAll("<[^>]+>", "").trim();
            if (!TextUtils.isEmpty(err)) {
                return err.length() > 100 ? err.substring(0, 100) : err;
            }
        }
        return "评论回复发布失败，请稍后重试";
    }

    // ==================== 点赞（持久化 + 真实网络同步） ====================

    private static final String PREF_LIKE_FAV = "thread_like_fav_state";
    private static final String KEY_LIKED_PREFIX = "liked_";
    private static final String KEY_FAVORITED_PREFIX = "fav_";

    private boolean restoreLikedState() {
        if (TextUtils.isEmpty(tid)) return false;
        SharedPreferences prefs = getSharedPreferences(PREF_LIKE_FAV, MODE_PRIVATE);
        return prefs.getBoolean(KEY_LIKED_PREFIX + tid, false);
    }

    private void saveLikedState(boolean liked) {
        if (TextUtils.isEmpty(tid)) return;
        getSharedPreferences(PREF_LIKE_FAV, MODE_PRIVATE)
                .edit().putBoolean(KEY_LIKED_PREFIX + tid, liked).apply();
    }

    private boolean restoreFavoritedState() {
        if (TextUtils.isEmpty(tid)) return false;
        SharedPreferences prefs = getSharedPreferences(PREF_LIKE_FAV, MODE_PRIVATE);
        return prefs.getBoolean(KEY_FAVORITED_PREFIX + tid, false);
    }

    private void saveFavoritedState(boolean favorited) {
        if (TextUtils.isEmpty(tid)) return;
        getSharedPreferences(PREF_LIKE_FAV, MODE_PRIVATE)
                .edit().putBoolean(KEY_FAVORITED_PREFIX + tid, favorited).apply();
    }
    private void toggleLike() {
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(tid) || binding.btnLike.isEnabled() == false) return;

        // ★ 不能给自己的帖子点赞：直接拦截，避免发起网络请求后提示“网页端未确认点赞状态已更新”
        String currentUid = UserSessionManager.getInstance().getUid(getApplicationContext());
        String authorUid = postDetail != null ? postDetail.getAuthorUid() : null;
        if (!TextUtils.isEmpty(currentUid) && !TextUtils.isEmpty(authorUid)
                && currentUid.equals(authorUid)) {
            Toast.makeText(this, "不能点赞自己的帖子", Toast.LENGTH_SHORT).show();
            return;
        }

        final boolean targetState = !isLiked;
        final boolean oldState = isLiked;
        final int oldCount = likeCount;
        isLiked = targetState;
        likeCount = Math.max(0, likeCount + (targetState ? 1 : -1));
        updateLikeIcon();
        binding.btnLike.setEnabled(false);

        new Thread(() -> {
            boolean success = false;
            String errorMessage = null;
            try {
                // 点赞必须严格复用 Comiis 网页端的链接：
                // forum.php?mod=misc&action=recommend&handlekey=recommend_add&do=add...
                // 取消点赞不是 do=sub，而是先请求同一个 recommend_add，再由网页插件 re_recommend 取消。
                httpClient.syncFromCookieManager();
                String pageHtml = httpClient.getDesktop(ForumParser.getThreadDetailUrl(tid)
                        + "&_action_refresh=" + System.currentTimeMillis());
                String formhash = postDetail != null ? postDetail.getFormhash() : null;
                if (TextUtils.isEmpty(formhash)) formhash = ForumParser.parseFormhash(pageHtml);

                String recommendUrl = extractRecommendActionUrl(pageHtml);
                if (TextUtils.isEmpty(recommendUrl)) {
                    if (TextUtils.isEmpty(formhash)) throw new IllegalStateException("无法获取formhash");
                    recommendUrl = HttpClient.BASE_URL + "forum.php?mod=misc&action=recommend"
                            + "&handlekey=recommend_add&do=add&tid=" + tid
                            + "&hash=" + formhash;
                }
                recommendUrl = appendQuery(recommendUrl, "inajax=1");
                String result = httpClient.get(recommendUrl);

                if (targetState) {
                    // 添加成功时网页响应会包含 recommendv/recommendc 或成功提示。
                    success = isLikeAddResponseSuccessful(result);
                } else {
                    // Comiis 网页端的取消流程：add 接口返回“已评价”后调用插件 re_recommend。
                    boolean alreadyLiked = containsAny(result,
                            "您已评价过本主题", "您已经评价过本主题", "已经评价过本主题");
                    if (alreadyLiked || isLikeAddResponseSuccessful(result)) {
                        String cancelUrl = HttpClient.BASE_URL
                                + "plugin.php?id=comiis_app&comiis=re_recommend&tid=" + tid
                                + "&inajax=1";
                        String cancelResult = httpClient.get(cancelUrl);
                        success = !ForumParser.isLoginPage(cancelResult)
                                && !containsAny(cancelResult, "没有权限", "操作失败", "非法操作", "请先登录");
                    }
                }

                // 以重新读取详情页得到的网页状态作为最终结果，避免仅凭提示文本误判。
                Boolean serverState = queryServerLikeState();
                if (serverState != null) success = serverState == targetState;
                if (!success) errorMessage = "网页端未确认点赞状态已更新";
            } catch (Exception e) {
                errorMessage = e.getMessage();
            }

            final boolean finalSuccess = success;
            final String finalError = errorMessage;
            runOnUiThread(() -> {
                binding.btnLike.setEnabled(true);
                if (finalSuccess) {
                    saveLikedState(targetState);
                    if (postDetail != null) {
                        postDetail.setLiked(targetState);
                        postDetail.setLikedStateKnown(true);
                    }
                    Toast.makeText(ThreadDetailActivity.this,
                            targetState ? "已点赞" : "已取消点赞", Toast.LENGTH_SHORT).show();
                } else {
                    isLiked = oldState;
                    likeCount = oldCount;
                    updateLikeIcon();
                    Toast.makeText(ThreadDetailActivity.this,
                            TextUtils.isEmpty(finalError) ? "点赞操作失败，请稍后重试" : finalError,
                            Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    private String extractRecommendActionUrl(String html) {
        if (TextUtils.isEmpty(html)) return null;
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parse(html);
            org.jsoup.nodes.Element link = doc.select(
                    "a.comiis_recommend_addkey, a.comiis_recommend_new").first();
            if (link == null) return null;
            String href = link.attr("href");
            if (TextUtils.isEmpty(href) || href.startsWith("javascript:")) return null;
            if (href.startsWith("/")) return HttpClient.BASE_URL + href.substring(1);
            if (href.startsWith("http://") || href.startsWith("https://")) return href;
            return HttpClient.BASE_URL + href;
        } catch (Exception ignored) {
            return null;
        }
    }

    private String appendQuery(String url, String query) {
        if (TextUtils.isEmpty(url)) return url;
        if (url.contains("inajax=")) return url;
        return url + (url.contains("?") ? "&" : "?") + query;
    }

    private boolean containsAny(String text, String... values) {
        if (TextUtils.isEmpty(text) || values == null) return false;
        for (String value : values) {
            if (!TextUtils.isEmpty(value) && text.contains(value)) return true;
        }
        return false;
    }

    private boolean isLikeAddResponseSuccessful(String result) {
        if (TextUtils.isEmpty(result) || ForumParser.isLoginPage(result)) return false;
        if (containsAny(result, "没有点赞权限", "不能点赞", "今日评价机会已用完",
                "关闭的主题无法执行", "请先登录", "formhash错误", "非法操作")) return false;
        return containsAny(result, "recommendv", "recommendc", "点赞成功", "推荐成功",
                "succeedhandle_recommend", "评价成功");
    }

    private Boolean queryServerLikeState() {
        try {
            String html = httpClient.get(ForumParser.getThreadDetailUrl(tid)
                    + "&_action_refresh=" + System.currentTimeMillis());
            PostDetail server = ForumParser.parseThreadDetail(html);
            if (server != null && server.isLikedStateKnown()) return server.isLiked();
        } catch (Exception ignored) {}
        return null;
    }


    private void updateLikeIcon() {
        binding.btnLike.setImageResource(isLiked
                ? R.drawable.forum_like_on
                : R.drawable.forum_like_off);
        updateCountBadge(binding.tvLikeBadge, Math.max(0, likeCount));
    }

    private void updateFavoriteIcon() {
        binding.btnFavorite.setImageResource(isFavorited
                ? R.drawable.forum_favorite_on
                : R.drawable.forum_favorite_off);
    }

    private void updateCountBadge(TextView badge, int count) {
        if (badge == null) return;
        if (count > 0) {
            badge.setText(count > 99 ? "99+" : String.valueOf(count));
            badge.setVisibility(View.VISIBLE);
        } else {
            badge.setVisibility(View.GONE);
        }
    }

    private void insertAtMention() {
        int start = Math.max(0, binding.etReply.getSelectionStart());
        String text = binding.etReply.getText() == null ? "" : binding.etReply.getText().toString();
        String insert = "@";
        binding.etReply.setText(text.substring(0, Math.min(start, text.length())) + insert
                + text.substring(Math.min(start, text.length())));
        binding.etReply.setSelection(Math.min(start, text.length()) + insert.length());
        binding.etReply.requestFocus();
    }

    // ==================== 关注 ====================

    private void toggleFollow() {
        if (postDetail == null || TextUtils.isEmpty(postDetail.getAuthorUid())) return;
        if (!FollowStateManager.isLoggedIn(this)) {
            Toast.makeText(this, "请先登录后再关注", Toast.LENGTH_SHORT).show();
            return;
        }
        final boolean targetState = !postDetail.isFollowed();
        binding.btnFollow.setEnabled(false);
        new Thread(() -> {
            boolean success = FollowStateManager.syncFollow(ThreadDetailActivity.this,
                    postDetail.getAuthorUid(), targetState);
            runOnUiThread(() -> {
                binding.btnFollow.setEnabled(true);
                if (success) {
                    postDetail.setFollowed(targetState);
                    binding.btnFollow.setText(targetState
                            ? R.string.action_followed : R.string.action_follow);
                    Toast.makeText(this, targetState
                            ? R.string.action_follow_success
                            : R.string.action_unfollow_success,
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "关注操作失败，请稍后重试", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    // ==================== 收藏 ====================
    /**
     * 收藏/取消收藏：严格复用 Comiis 详情页按钮 href。
     * 网页端不是普通表单 POST：点击 .dialog 后由 common_u.js 发 GET + inajax=1，
     * 服务端返回 succeedhandle_favorite_add/del 脚本，再由页面更新图标。
     */
    private void toggleFavorite() {
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(tid) || !binding.btnFavorite.isEnabled()) return;

        final boolean targetState = !isFavorited;
        final boolean oldState = isFavorited;
        binding.btnFavorite.setEnabled(false);

        new Thread(() -> {
            boolean success = false;
            String errorMessage = null;
            try {
                httpClient.syncFromCookieManager();
                if (targetState) {
                    // 添加收藏：Comiis 必须先 GET 打开确认表单，再 POST 提交表单。
                    String pageHtml = httpClient.get(ForumParser.getThreadDetailUrl(tid)
                            + "&_favorite_refresh=" + System.currentTimeMillis());
                    String actionUrl = extractFavoriteActionUrl(pageHtml);
                    if (TextUtils.isEmpty(actionUrl)) {
                        throw new IllegalStateException("无法获取收藏操作地址");
                    }

                    String result = httpClient.get(appendQuery(actionUrl, "inajax=1"));
                    if (!ForumParser.isLoginPage(result)
                            && !containsAny(result, "请先登录", "没有权限", "非法操作", "formhash错误")) {
                        String favoritePostUrl = extractFavoriteFormAction(result, actionUrl);
                        if (!TextUtils.isEmpty(favoritePostUrl)) {
                            Map<String, String> formParams = extractFavoriteFormParams(result);
                            formParams.put("favoritesubmit", "true");
                            formParams.put("favoritesubmit_btn", "确定");
                            if (!formParams.containsKey("description")) {
                                formParams.put("description", "手机收藏");
                            }
                            String postResult = httpClient.post(favoritePostUrl, formParams);
                            success = isFavoriteMutationResponseSuccessful(postResult, true);
                        } else {
                            // 已收藏时服务端可能直接返回重复收藏提示；最终状态校验仍是依据。
                            success = isFavoriteMutationResponseSuccessful(result, true);
                        }
                    }
                } else {
                    // 取消收藏不是详情页按钮的反向 POST，而是收藏列表中的 favid 删除接口。
                    success = requestRemoveFavoriteFromServer();
                }

                // 操作接口返回成功后，服务器状态更新可能比请求响应晚几十到几百毫秒。
                // 先校验帖子详情页图标，再校验收藏列表，并允许短暂重试，避免误报“未确认”。
                Boolean serverState = queryServerFavoriteStateWithRetry(targetState);
                if (serverState != null) {
                    success = serverState == targetState;
                }
                if (!success) errorMessage = "网页端未确认收藏状态已更新";
            } catch (Exception e) {
                errorMessage = e.getMessage();
            }

            final boolean finalSuccess = success;
            final String finalError = errorMessage;
            runOnUiThread(() -> {
                binding.btnFavorite.setEnabled(true);
                if (finalSuccess) {
                    isFavorited = targetState;
                    favoriteCount = Math.max(0, favoriteCount + (targetState ? 1 : -1));
                    saveFavoritedState(targetState);
                    if (postDetail != null) {
                        postDetail.setFavorited(targetState);
                        postDetail.setFavoritedStateKnown(true);
                    }
                    updateFavoriteIcon();
                    updateCountBadge(binding.tvFavoriteBadge, favoriteCount);
                    Toast.makeText(ThreadDetailActivity.this,
                            targetState ? "已收藏" : "已取消收藏", Toast.LENGTH_SHORT).show();
                } else {
                    isFavorited = oldState;
                    updateFavoriteIcon();
                    Toast.makeText(ThreadDetailActivity.this,
                            TextUtils.isEmpty(finalError) ? "收藏操作失败，请稍后重试" : finalError,
                            Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    private String extractFavoriteActionUrl(String html) {
        if (TextUtils.isEmpty(html)) return null;
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parse(html);
            org.jsoup.nodes.Element link = doc.select("#comiis_favorite_a").first();
            if (link == null) return null;
            String href = link.attr("href");
            if (TextUtils.isEmpty(href) || href.startsWith("javascript:")) return null;
            if (href.startsWith("/")) return HttpClient.BASE_URL + href.substring(1);
            if (href.startsWith("http://") || href.startsWith("https://")) return href;
            return HttpClient.BASE_URL + href;
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * 收藏状态最终校验：优先读取帖子详情页中的收藏图标，
     * 再读取收藏列表。操作接口返回后服务器页面存在短暂缓存/延迟，
     * 因此最多重试数次，避免刚收藏成功就被误判为失败。
     */
    private String extractFavoriteFormAction(String response, String fallbackUrl) {
        if (TextUtils.isEmpty(response)) return null;
        try {
            String html = extractCdata(response);
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parse(html);
            org.jsoup.nodes.Element form = doc.select("form[id^=favoriteform], form[name^=favoriteform]").first();
            if (form == null) return null;
            String action = form.attr("action");
            if (TextUtils.isEmpty(action)) action = fallbackUrl;
            return normalizeForumUrl(action);
        } catch (Exception ignored) {
            return null;
        }
    }

    private Map<String, String> extractFavoriteFormParams(String response) {
        Map<String, String> params = new HashMap<>();
        if (TextUtils.isEmpty(response)) return params;
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parse(extractCdata(response));
            org.jsoup.nodes.Element form = doc.select("form[id^=favoriteform], form[name^=favoriteform]").first();
            if (form == null) return params;
            for (org.jsoup.nodes.Element input : form.select("input[name], textarea[name], select[name]")) {
                String name = input.attr("name");
                if (TextUtils.isEmpty(name)) continue;
                String value = input.tagName().equalsIgnoreCase("textarea")
                        ? input.text() : input.attr("value");
                params.put(name, value == null ? "" : value);
            }
        } catch (Exception ignored) {}
        return params;
    }

    private String extractCdata(String response) {
        if (TextUtils.isEmpty(response)) return "";
        int start = response.indexOf("<![CDATA[");
        if (start < 0) start = response.indexOf("<![cdata[");
        if (start < 0) return response;
        start += 9;
        int end = response.indexOf("]]>", start);
        return end >= 0 ? response.substring(start, end) : response.substring(start);
    }

    private String normalizeForumUrl(String url) {
        if (TextUtils.isEmpty(url)) return url;
        if (url.startsWith("http://") || url.startsWith("https://")) return url;
        if (url.startsWith("/")) return HttpClient.BASE_URL + url.substring(1);
        return HttpClient.BASE_URL + url;
    }

    private boolean isFavoriteMutationResponseSuccessful(String response, boolean targetState) {
        if (TextUtils.isEmpty(response) || ForumParser.isLoginPage(response)) return false;
        if (containsAny(response, "请先登录", "没有权限", "非法操作", "formhash错误",
                "收藏失败", "取消收藏失败")) return false;
        if (targetState) {
            return containsAny(response, "succeedhandle_favorite_add",
                    "succeedhandle_favorite_thread", "收藏成功", "信息收藏成功",
                    "已收藏", "重复收藏");
        }
        return containsAny(response, "succeedhandle_favorite_del",
                "succeedhandle_favorite_thread", "取消收藏成功", "已取消收藏",
                "删除成功", "取消成功");
    }
    /**
     * 通过收藏列表中的 favid 调用 Comiis/Discuz! 删除接口。
     * 详情页收藏按钮本身没有取消收藏接口，重复 GET 只会返回“已收藏”。
     */
    private boolean requestRemoveFavoriteFromServer() throws Exception {
        String listUrl = HttpClient.BASE_URL
                + "home.php?mod=space&do=favorite&type=all&mobile=2";
        String page = httpClient.get(listUrl + "&_favorite_remove=" + System.currentTimeMillis());
        if (ForumParser.isLoginPage(page)) return false;

        String favid = "";
        List<com.forum.MT.model.Thread> favorites =
                ForumParser.parseFavoriteList(page);
        if (favorites != null) {
            for (com.forum.MT.model.Thread item : favorites) {
                if (item != null && tid.equals(item.getTid())) {
                    favid = item.getFavid();
                    break;
                }
            }
        }
        if (TextUtils.isEmpty(favid)) {
            // 某些模板不会把 favid 放在标题链接上，直接从同一条目附近的删除链接提取。
            Matcher matcher = Pattern.compile(
                    "(?:favid|fav_id)=(\\d+)[^<>]{0,300}(?:tid=" + Pattern.quote(tid)
                            + "|thread-" + Pattern.quote(tid) + "-)",
                    Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(page);
            if (matcher.find()) favid = matcher.group(1);
            if (TextUtils.isEmpty(favid)) {
                matcher = Pattern.compile(
                        "(?:tid=" + Pattern.quote(tid) + "|thread-" + Pattern.quote(tid) + "-)[^<>]{0,300}"
                                + "(?:favid|fav_id)=(\\d+)",
                        Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(page);
                if (matcher.find()) favid = matcher.group(1);
            }
        }
        if (TextUtils.isEmpty(favid)) return false;

        String formhash = ForumParser.parseFormhash(page);
        if (TextUtils.isEmpty(formhash)) {
            String detailHtml = httpClient.get(ForumParser.getThreadDetailUrl(tid)
                    + "&_favorite_remove_hash=" + System.currentTimeMillis());
            formhash = ForumParser.parseFormhash(detailHtml);
        }

        String deleteUrl = HttpClient.BASE_URL + "home.php?mod=spacecp&ac=favorite&op=delete"
                + "&favid=" + favid + "&type=all&mobile=2";
        Map<String, String> params = new HashMap<>();
        params.put("referer", listUrl);
        params.put("deletesubmit", "true");
        if (!TextUtils.isEmpty(formhash)) params.put("formhash", formhash);
        params.put("handlekey", "comiis");

        String response = httpClient.post(deleteUrl, params);
        String verifyHtml = httpClient.get(listUrl + "&_favorite_remove_verify="
                + System.currentTimeMillis());
        boolean stillExists = containsFavoriteTid(verifyHtml, tid);
        return !stillExists || containsAny(response, "succeedhandle_favorite_del",
                "删除成功", "取消收藏成功", "取消成功");
    }

    private boolean containsFavoriteTid(String html, String targetTid) {
        if (TextUtils.isEmpty(html) || TextUtils.isEmpty(targetTid)) return false;
        List<com.forum.MT.model.Thread> favorites =
                ForumParser.parseFavoriteList(html);
        if (favorites != null) {
            for (com.forum.MT.model.Thread item : favorites) {
                if (item != null && targetTid.equals(item.getTid())) return true;
            }
        }
        return Pattern.compile("(?:[?&]tid=" + Pattern.quote(targetTid)
                        + "(?:&|\\\"|')|thread-" + Pattern.quote(targetTid) + "(?:-|\\.))",
                Pattern.CASE_INSENSITIVE).matcher(html).find();
    }
private Boolean queryServerFavoriteStateWithRetry(boolean targetState) {
        Boolean lastState = null;
        long[] delays = new long[]{0L, 250L, 600L, 1200L, 2000L};
        for (long delay : delays) {
            if (delay > 0L) {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }

            // 详情页的 #comiis_favorite_a 图标是网页端当前用户状态，
            // 比收藏列表的条目解析更直接，优先作为最终依据。
            Boolean detailState = queryServerFavoriteDetailState();
            if (detailState != null) {
                lastState = detailState;
                if (detailState == targetState) return detailState;
            }

            Boolean listState = queryServerFavoriteListState();
            if (listState != null) {
                lastState = listState;
                if (listState == targetState) return listState;
            }
        }
        return lastState;
    }

    private Boolean queryServerFavoriteDetailState() {
        try {
            String html = httpClient.get(ForumParser.getThreadDetailUrl(tid)
                    + "&_favorite_verify=" + System.currentTimeMillis());
            if (ForumParser.isLoginPage(html)) return null;
            PostDetail server = ForumParser.parseThreadDetail(html);
            if (server != null && server.isFavoritedStateKnown()) {
                return server.isFavorited();
            }
        } catch (Exception ignored) {}
        return null;
    }

    private Boolean queryServerFavoriteListState() {
        try {
            String html = httpClient.get(HttpClient.BASE_URL
                    + "home.php?mod=space&do=favorite&type=all&mobile=2&_favorite_verify="
                    + System.currentTimeMillis());
            if (ForumParser.isLoginPage(html)) return null;

            // 先使用结构化解析；若模板只返回标题链接但解析不到 title，
            // 再直接按 thread-{tid}- 格式从原始 HTML 兜底判断。
            List<com.forum.MT.model.Thread> favorites =
                    ForumParser.parseFavoriteList(html);
            if (favorites != null) {
                for (com.forum.MT.model.Thread item : favorites) {
                    if (item != null && tid.equals(item.getTid())) return true;
                }
            }
            return !TextUtils.isEmpty(tid)
                    && Pattern.compile("thread-" + Pattern.quote(tid) + "(?:-|\\\\.)",
                    Pattern.CASE_INSENSITIVE).matcher(html).find();
        } catch (Exception ignored) {
            return null;
        }
    }

    private Boolean queryServerFavoriteState() {
        return queryServerFavoriteListState();
    }


    // ==================== 隐藏内容 ====================

    private void viewHiddenContent() {
        if (postDetail == null || !postDetail.isHasHiddenContent()) return;

        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }

        // 隐藏提示文字与按钮，显示隐藏内容
        binding.tvHiddenContentHint.setVisibility(View.GONE);
        binding.btnViewHidden.setVisibility(View.GONE);

        if (!TextUtils.isEmpty(postDetail.getHiddenContentHtml())) {
            binding.tvHiddenContent.setVisibility(View.VISIBLE);
            // 使用文本-图片分离方案渲染隐藏内容（表格内联为可横滑视图）
            List<String> hiddenImageUrls = new ArrayList<>();
            String cleanHiddenHtml = extractAndSeparateImages(postDetail.getHiddenContentHtml(), hiddenImageUrls);
            // ★ 修复：将 <table> 转换为表格占位标记（放在图片提取之后）
            List<TableData> hiddenTables = new ArrayList<>();
            String hiddenContentHtml = convertHtmlTables(cleanHiddenHtml, hiddenTables);
            binding.tvHiddenContent.setVisibility(View.VISIBLE);
            renderContentWithInlineTables(hiddenContentHtml, hiddenTables, binding.layoutHiddenContent,
                    binding.tvHiddenContent,
                    (int) com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(this,
                            com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_HIDDEN),
                    com.forum.MT.R.color.text_primary, 0f, 1.4f);
            setupClickableLinks(binding.tvHiddenContent);
            // 隐藏内容中的图片追加到ll_images_container
            for (String imgUrl : hiddenImageUrls) {
                ImageView imageView = new ImageView(this);
                imageView.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                imageView.setAdjustViewBounds(true);
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setBackgroundColor(0xFFF0F0F0);
                imageView.setOnClickListener(v -> openImagePreview(imgUrl));
                Glide.with(this)
                        .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(imgUrl))
                        .placeholder(new ColorDrawable(0xFFF0F0F0))
                        .error(createFailedImageDrawable())
                        .into(imageView);
                binding.llImagesContainer.addView(imageView);
            }
        } else {
            // 无缓存内容，提示用户先回复
            Toast.makeText(this, R.string.hidden_content_prompt, Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== 分页加载更多回复 ====================

    private boolean mAutoLoading = false; // 防止重复触发
    private boolean mAutoLoadSkipping = false; // 防止黑名单自动加载递归
    private volatile boolean mCancelLoadAll = false; // 取消加载全部回复
    private volatile boolean mLoadingAllReplies = false; // 防止重复执行

    private boolean shouldSuppressAutoReplyLoading() {
        return mSuppressAutoReplyLoadingForTarget && !TextUtils.isEmpty(targetPid);
    }

    /** 定位完成后解除自动加载抑制，并触发自动加载全部（如果已启用）。 */
    private void releaseAutoReplySuppressionForTarget() {
        mSuppressAutoReplyLoadingForTarget = false;
        // 解除抑制后，如果已启用"自动加载更多回复"，且还有更多页，触发自动加载
        if (postDetail != null && LoadAllRepliesManager.isEnabled(this)
                && !mLoadingAllReplies && !mAutoLoading
                && postDetail.getCurrentPage() < postDetail.getTotalPages()) {
            loadAllReplies();
        }
    }

    private void setupAutoLoadMore() {
        // 1) 监听 NestedScrollView 滚动（回复区 wrap_content 模式下生效）
        binding.nestedScroll.setOnScrollChangeListener(
                new androidx.core.widget.NestedScrollView.OnScrollChangeListener() {
                    @Override
                    public void onScrollChange(androidx.core.widget.NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                        if (!AutoLoadMoreManager.isEnabled(ThreadDetailActivity.this)) return;
                        if (shouldSuppressAutoReplyLoading()) return;
                        if (mAutoLoading) return;
                        if (binding.btnLoadMore.getVisibility() != View.VISIBLE) return;
                        if (!binding.btnLoadMore.isEnabled()) return;

                        // 检查是否滚动到接近底部
                        View contentView = v.getChildAt(0);
                        if (contentView == null) return;
                        int totalHeight = contentView.getHeight();
                        int remain = totalHeight - (scrollY + v.getHeight());
                        if (remain < 300) {
                            mAutoLoading = true;
                            loadMoreReplies();
                        }
                    }
                });

        // 2) 监听 RecyclerView 滚动（回复区固定高度 + 嵌套滚动模式下生效）
        binding.recyclerReplies.addOnScrollListener(
                new androidx.recyclerview.widget.RecyclerView.OnScrollListener() {
                    @Override
                    public void onScrolled(@NonNull androidx.recyclerview.widget.RecyclerView rv, int dx, int dy) {
                        if (!AutoLoadMoreManager.isEnabled(ThreadDetailActivity.this)) return;
                        if (shouldSuppressAutoReplyLoading()) return;
                        if (mAutoLoading) return;
                        if (binding.btnLoadMore.getVisibility() != View.VISIBLE) return;
                        if (!binding.btnLoadMore.isEnabled()) return;
                        if (dy <= 0) return; // 仅下滑时触发

                        androidx.recyclerview.widget.LinearLayoutManager lm =
                                (androidx.recyclerview.widget.LinearLayoutManager) rv.getLayoutManager();
                        if (lm == null) return;
                        int total = lm.getItemCount();
                        int lastVisible = lm.findLastVisibleItemPosition();
                        // 还剩不到3条就到底了，自动加载
                        if (total - lastVisible <= 3) {
                            mAutoLoading = true;
                            loadMoreReplies();
                        }
                    }
                });
    }

    /**
     * 点进帖子时自动加载全部评论：循环请求所有页，直到拉完或达到上限。
     */
    private void loadAllReplies() {
        if (postDetail == null) return;
        if (shouldSuppressAutoReplyLoading()) return;
        if (postDetail.getCurrentPage() >= postDetail.getTotalPages()) return;

        if (mLoadingAllReplies) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.w("MT_ALL_REPLIES", "already running, skipping");
            return;
        }
        mLoadingAllReplies = true;
        mCancelLoadAll = false;
        binding.btnLoadMore.setEnabled(false);
        binding.btnLoadMore.setText(R.string.loading);

        // ★ 确保 RecyclerView 使用固定高度 + 嵌套滚动模式，
        // 避免在 NestedScrollView 内 wrap_content 测量全部子项导致 ANR
        // 仅在"回复区独立滚动"开关开启时生效
        if (swipeCommentMode) {
            binding.recyclerReplies.setNestedScrollingEnabled(true);
            ViewGroup.LayoutParams rp = binding.recyclerReplies.getLayoutParams();
            if (rp.height != ViewGroup.LayoutParams.MATCH_PARENT) {
                rp.height = ViewGroup.LayoutParams.MATCH_PARENT;
                binding.recyclerReplies.setLayoutParams(rp);
            }
        } else if (NestedScrollRepliesManager.isEnabled(this)) {
            binding.recyclerReplies.setNestedScrollingEnabled(true);
            ViewGroup.LayoutParams rp = binding.recyclerReplies.getLayoutParams();
            int twoThirdsScreen = (int)(getResources().getDisplayMetrics().heightPixels * 0.66);
            if (rp.height != twoThirdsScreen) {
                rp.height = twoThirdsScreen;
                binding.recyclerReplies.setLayoutParams(rp);
            }
        }

        // ★ 不再限制最大页数：RecyclerView 已改为固定高度只测量可见项，
        // 不会因为加载全部回复导致 ANR
        final int BATCH_SIZE = 5; // 每批加载5页就更新一次UI，避免OOM

        // ★ 获取黑名单状态，每批追加时就过滤，不用等全部加载完
        final ReplyBlacklistManager blacklist = ReplyBlacklistManager.getInstance(this);
        final boolean blacklistActive = blacklist.isEnabled() && blacklist.size() > 0;
        // ★ 屏蔽AI回复：每批追加时也过滤，避免后续页灌水回复绕过过滤器
        final boolean aiFilterActive =
                com.forum.MT.ui.widget.AiReplyFilterManager.isEnabled(this);
        final String threadTitle = postDetail.getTitle();

        new Thread(() -> {
            try {
                int startPage = postDetail.getCurrentPage() + 1;
                int totalPages = postDetail.getTotalPages();
                int endPage = totalPages; // 加载全部页，不限制
                final int totalBatches = (endPage - startPage + BATCH_SIZE - 1) / BATCH_SIZE;
                if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ALL_REPLIES", "loadAllReplies: startPage=" + startPage + " endPage=" + endPage + " totalPages=" + totalPages + " batches=" + totalBatches);

                int batchNum = 0;

                for (int batchStart = startPage; batchStart <= endPage; batchStart += BATCH_SIZE) {
                    if (mCancelLoadAll) {
                        if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ALL_REPLIES", "cancelled at batch " + batchNum);
                        break;
                    }
                    if (isDestroyed() || isFinishing()) {
                        if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ALL_REPLIES", "activity destroyed at batch " + batchNum);
                        return;
                    }

                    int batchEnd = Math.min(batchStart + BATCH_SIZE - 1, endPage);
                    java.util.List<ReplyItem> batchReplies = new ArrayList<>();

                    for (int page = batchStart; page <= batchEnd; page++) {
                        if (mCancelLoadAll) break;
                        if (isDestroyed() || isFinishing()) return;

                        try {
                            String pageUrl = ForumParser.getThreadDetailUrl(tid, page, getReplyOrder());
                            String html = httpClient.get(pageUrl);
                            if (isDestroyed() || isFinishing()) return;

                            PostDetail pageDetail = ForumParser.parseThreadDetail(html);
                            List<ReplyItem> pageReplies = pageDetail.getReplies();
                            if (pageReplies != null && !pageReplies.isEmpty()) {
                                batchReplies.addAll(pageReplies);
                            }
                            if (pageDetail.getTotalPages() > totalPages) {
                                totalPages = pageDetail.getTotalPages();
                                endPage = totalPages; // 加载全部页，不限制
                            }
                        } catch (Exception e) {
                            android.util.Log.e("MT_ALL_REPLIES", "load page " + page + " failed", e);
                        }
                    }

                    batchNum++;
                    final int currentBatch = batchNum;
                    final int currentTotal = totalBatches;

                    if (!batchReplies.isEmpty()) {
                        // ★ 在后台线程预处理每条回复的 HTML（Jsoup/正则转换），
                        // 避免主线程 onBindViewHolder 时逐条处理导致 ANR
                        for (ReplyItem r : batchReplies) {
                            try {
                                ReplyAdapter.preProcessReply(r);
                            } catch (Exception e) {
                                // 预处理失败不阻塞，bind 时会走慢速路径
                            }
                        }
                        // ★ 每批追加时就做黑名单+AI过滤，只把未被过滤的回复加入列表，
                        // 避免全部加载完才过滤导致用户等待。
                        final List<ReplyItem> batchToShow = new ArrayList<>();
                        for (ReplyItem r : batchReplies) {
                            // 带图回复豁免；引用块不影响当前正文的过滤判定。
                            if (!shouldBlacklistFilter(r)) {
                                batchToShow.add(r);
                                continue;
                            }
                            String contentText = r.getContentText();
                            if (contentText == null || contentText.isEmpty()) {
                                contentText = android.text.Html.fromHtml(
                                        r.getContentHtml() != null ? r.getContentHtml() : "",
                                        android.text.Html.FROM_HTML_MODE_COMPACT).toString();
                            }
                            // 模板灌水检测仅受"屏蔽灌水回复"开关控制，与黑名单独立。
                            if (aiFilterActive
                                    && com.forum.MT.ui.widget.AiReplyFilterManager
                                            .isAiSpamReply(contentText, threadTitle)) {
                                continue;
                            }
                            // 黑名单过滤
                            if (blacklistActive && blacklist.isBlocked(contentText)) {
                                continue;
                            }
                            batchToShow.add(r);
                        }
                        // 增量更新：每批加载完就立即更新UI，释放内存
                        // ★ 使用 appendItems + notifyItemRangeInserted 避免 notifyDataSetChanged
                        // 导致 RecyclerView 重新绑定所有可见项（回复越多越慢，最终 ANR）。
                        runOnUiThread(() -> {
                            if (isDestroyed() || isFinishing()) return;
                            binding.btnLoadMore.setText("加载全部 " + currentBatch + "/" + currentTotal);
                            postDetail.getReplies().addAll(batchReplies);
                            displayedReplies.addAll(batchReplies);
                            if (!batchToShow.isEmpty()) {
                                replyAdapter.appendItems(batchToShow);
                                // 首页被黑名单全部命中时列表处于 GONE，
                                // 这里必须复位，否则数据进来了却仍显示"暂无回复"。
                                syncRepliesEmptyState();
                            }
                            // 每批原始评论加入 displayedReplies、可见评论加入适配器后立即刷新，
                            // 即使本批全部被过滤，也能实时更新“过滤 N 条”。
                            updateReplyCountWithFilteredCount();
                            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ALL_REPLIES", "batch " + currentBatch + " done, totalReplies=" + displayedReplies.size());
                        });
                    } else {
                        runOnUiThread(() -> {
                            binding.btnLoadMore.setText("加载全部 " + currentBatch + "/" + currentTotal);
                        });
                    }
                }

                if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ALL_REPLIES", "loadAllReplies finished: batches=" + batchNum);

                if (mCancelLoadAll || isDestroyed() || isFinishing()) {
                    if (!isDestroyed() && !isFinishing()) {
                        runOnUiThread(() -> {
                            binding.btnLoadMore.setEnabled(true);
                            binding.btnLoadMore.setText(R.string.load_more_replies);
                        });
                    }
                    mLoadingAllReplies = false;
                    return;
                }

                postDetail.setCurrentPage(endPage);
                final boolean hasMore = endPage < totalPages;
                final int finalTotalPages = totalPages;
                final int finalEndPage = endPage;

                runOnUiThread(() -> {
                    if (isDestroyed() || isFinishing()) {
                        mLoadingAllReplies = false;
                        return;
                    }
                    // ★ 每批追加时已做黑名单过滤，全部加载完后不再重复过滤。
                    // 只更新按钮状态（黑名单/楼主/排序）与空状态。
                    syncRepliesEmptyState();
                    ReplyBlacklistManager blMgr = ReplyBlacklistManager.getInstance(this);
                    if (blMgr.isEnabled()) {
                        binding.btnReplyBlacklist.setText(R.string.reply_blacklist_on);
                        binding.btnReplyBlacklist.setTextColor(getColor(R.color.primary));
                    } else {
                        binding.btnReplyBlacklist.setText(R.string.reply_blacklist_off);
                        binding.btnReplyBlacklist.setTextColor(getColor(R.color.text_secondary));
                    }
                    updateReplyCountWithFilteredCount();
                    binding.btnOnlyOp.setText(onlyOpReplies
                            ? R.string.reply_all_users : R.string.reply_only_op);
                    binding.btnOnlyOp.setTextColor(getColor(onlyOpReplies
                            ? R.color.primary : R.color.text_secondary));
                    binding.btnLoadMore.setEnabled(true);
                    if (hasMore) {
                        binding.btnLoadMore.setText("加载更多回复（剩余" + (finalTotalPages - finalEndPage) + "页）");
                        binding.btnLoadMore.setVisibility(View.VISIBLE);
                    } else {
                        binding.btnLoadMore.setVisibility(View.GONE);
                    }
                    mLoadingAllReplies = false;
                });
            } catch (Exception e) {
                android.util.Log.e("MT_ALL_REPLIES", "loadAllReplies exception", e);
                if (!isDestroyed() && !isFinishing()) {
                    runOnUiThread(() -> {
                        binding.btnLoadMore.setEnabled(true);
                        binding.btnLoadMore.setText(R.string.load_more_replies);
                    });
                }
                mLoadingAllReplies = false;
            }
        }).start();
    }

    private void loadMoreReplies() {
        if (postDetail == null) return;

        binding.btnLoadMore.setEnabled(false);
        binding.btnLoadMore.setText(R.string.loading);

        // ★ 每次"加载更多"后回复数可能持续累积，超过一定数量时同样切换为
        // 固定高度 + 嵌套滚动，避免 wrap_content 测量全部子项导致 ANR
        // 仅在"回复区独立滚动"开关开启时生效
        if (NestedScrollRepliesManager.isEnabled(this)) {
            final int currentCount = displayedReplies == null ? 0 : displayedReplies.size();
            if (currentCount >= 1) {
                binding.recyclerReplies.setNestedScrollingEnabled(true);
                ViewGroup.LayoutParams rp = binding.recyclerReplies.getLayoutParams();
                int twoThirdsScreen = (int)(getResources().getDisplayMetrics().heightPixels * 0.66);
                if (rp.height != twoThirdsScreen) {
                    rp.height = twoThirdsScreen;
                    binding.recyclerReplies.setLayoutParams(rp);
                }
            }
        }

        new Thread(() -> {
            try {
                int page = postDetail.getCurrentPage() + 1;
                int totalPages = postDetail.getTotalPages();
                int targetCount = 10; // 每次最多加载10条
                List<ReplyItem> allNewReplies = new ArrayList<>();

                // 持续拉取多页，直到凑够 targetCount 条（未被屏蔽的）或拉完所有页
                ReplyBlacklistManager blacklist = ReplyBlacklistManager.getInstance(ThreadDetailActivity.this);
                boolean blacklistEnabled = blacklist.isEnabled() && blacklist.size() > 0;
                int visibleCount = 0; // 已收集的未被屏蔽的回复数

                while (visibleCount < targetCount && page <= totalPages) {
                    String pageUrl = ForumParser.getThreadDetailUrl(tid, page, getReplyOrder());
                    String html = httpClient.get(pageUrl);
                    PostDetail pageDetail = ForumParser.parseThreadDetail(html);
                    List<ReplyItem> pageReplies = pageDetail.getReplies();
                    if (pageReplies != null && !pageReplies.isEmpty()) {
                        for (ReplyItem r : pageReplies) {
                            // ★ 全部回复都加入列表，保留原始数据
                            allNewReplies.add(r);
                            // 只有未被屏蔽的才计入 visibleCount
                            if (blacklistEnabled) {
                                String contentText = r.getContentText();
                                if (contentText == null || contentText.isEmpty()) {
                                    contentText = android.text.Html.fromHtml(
                                            r.getContentHtml() != null ? r.getContentHtml() : "",
                                            android.text.Html.FROM_HTML_MODE_COMPACT).toString();
                                }
                                if (!blacklist.isBlocked(contentText)) {
                                    visibleCount++;
                                }
                            } else {
                                visibleCount++;
                            }
                        }
                    }
                    // ★ 修复：不要在循环内调用 postDetail.setCurrentPage()，因为后续页面的
                    // HTML 可能没有 input[name=page]，导致 pageDetail.getCurrentPage() 总是返回 1，
                    // 从而把已加载到的正确页码重置为 1，下次点击"加载更多"会重复加载同一批页面。
                    // 改为在循环结束后用 page - 1 设置正确的当前页码。
                    if (pageDetail.getTotalPages() > totalPages) {
                        totalPages = pageDetail.getTotalPages();
                        postDetail.setTotalPages(totalPages);
                    }
                    page++;
                }
                // ★ 循环结束后设置正确的当前页码（page 已自增，所以最后成功加载的页是 page - 1）
                postDetail.setCurrentPage(page - 1);

                // ★ 在后台线程预处理每条回复的 HTML，避免主线程 ANR
                if (!allNewReplies.isEmpty()) {
                    for (ReplyItem r : allNewReplies) {
                        try {
                            ReplyAdapter.preProcessReply(r);
                        } catch (Exception e) {
                            // 预处理失败不阻塞
                        }
                    }
                }

                final int finalTotalPages = totalPages;

                runOnUiThread(() -> {
                    mAutoLoading = false;
                    binding.btnLoadMore.setEnabled(true);
                    binding.btnLoadMore.setText(R.string.load_more_replies);

                    if (!allNewReplies.isEmpty()) {
                        // 追加到现有回复列表
                        List<ReplyItem> merged = new ArrayList<>(postDetail.getReplies());
                        merged.addAll(allNewReplies);
                        postDetail.setReplies(merged);
                        displayedReplies = new ArrayList<>(merged);
                        // updateReplyFilterAndOrder 统一处理黑名单过滤，确保开关切换后数据完整
                        updateReplyFilterAndOrder();

                        // 判断是否还有更多
                        boolean hasMore = postDetail.getCurrentPage() < finalTotalPages;
                        if (!hasMore) {
                            binding.btnLoadMore.setVisibility(View.GONE);
                        }
                    } else {
                        binding.btnLoadMore.setVisibility(View.GONE);
                        Toast.makeText(ThreadDetailActivity.this,
                                R.string.no_more_replies, Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    mAutoLoading = false;
                    binding.btnLoadMore.setEnabled(true);
                    binding.btnLoadMore.setText(R.string.load_more_replies);
                    Toast.makeText(ThreadDetailActivity.this,
                                    "加载失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    // ==================== BBCode→img转换 + 文本-图片分离工具 ====================
    /**
     * 支持 Discuz! 的“插入文字链接”功能：
     * [url=https://example.com]点我下载[/url]
     * [url]https://example.com[/url]
     *
     * Discuz! 正常渲染后会生成 <a href="...">文字</a>，这里同时保留
     * 原始 BBCode 兼容性，避免原生客户端把链接文字显示成不可点击的普通文本。
     */
    private static String convertTextLinkBBCode(String html) {
        if (TextUtils.isEmpty(html)) return "";
        String result = html;
        result = result.replaceAll("(?is)\\[url\\s*=\\s*([^\\]\\s]+)\\]([^\\[]*?)\\[/url\\]",
                "<a href=\"$1\">$2</a>");
        result = result.replaceAll("(?is)\\[url\\]([^\\[]+?)\\[/url\\]",
                "<a href=\"$1\">$1</a>");
        return result;
    }

    /**
     * ★ 修复：服务端返回的<a>显示文本可能被截断（包含...），
     * 用 href 完整URL替换显示文本，保持<a>标签样式
     */
    private static String fixTruncatedLinkTexts(String html) {
        if (TextUtils.isEmpty(html)) return html;
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parse(html);
            doc.outputSettings().prettyPrint(false);
            org.jsoup.select.Elements links = doc.select("a[href]");
            for (org.jsoup.nodes.Element link : links) {
                String text = link.text();
                String href = link.attr("href");
                if (TextUtils.isEmpty(href)) continue;
                // 如果显示文本包含...且href比文本长，用href替换显示文本
                if (text.contains("...") || text.contains("…") || text.contains("..")) {
                    link.text(href);
                }
            }
            String result = doc.body().html();
            // 只解码 &amp; 和 &quot;；不解码 &lt; &gt;——否则会把正文里作为文字
            // 讨论的 "&lt;pre&gt;" 变成真实 <pre> 标签，导致误渲染为代码块。
            // &lt; &gt; 交给 Html.fromHtml 自动解码显示为 < > 字符即可。
            // 原样保留 HTML 实体，由最终 Html.fromHtml 统一解码一次
            // （避免双重编码 &amp;lt; 被提前拆成 &lt; 甚至 < 造成误判为标签）
            return result;
        } catch (Exception e) {
            return html;
        }
    }

    /**
     /**
     * 将 HTML <table> 转换为内联表格占位。
     * <p>
     * 从 HTML 中提取每个 <table> 的数据（行/列单元格文本），
     * 替换为 &lt;img src="table://N"&gt; 占位符，供 ImageGetter 渲染为
     * 带边框的表格位图，内联插入正文的原始位置（而非追加到页面底部）。
     *
     * @param html 原始HTML
     * @param outTables 输出的表格数据列表（调用者传入）
     * @return 替换后的HTML（<table> 换成 table://N 占位符）
     */
    private static String convertHtmlTables(String html, List<TableData> outTables) {
        if (TextUtils.isEmpty(html)) return html;
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parseBodyFragment(html);
            org.jsoup.select.Elements tables = doc.select("table");
            if (tables.isEmpty()) return html;

            int index = 0;
            for (org.jsoup.nodes.Element table : tables) {
                List<List<String>> rows = new ArrayList<>();
                org.jsoup.select.Elements trs = table.select("tr");
                for (org.jsoup.nodes.Element tr : trs) {
                    List<String> cells = new ArrayList<>();
                    org.jsoup.select.Elements tds = tr.select("th, td");
                    for (org.jsoup.nodes.Element td : tds) {
                        cells.add(td.text().trim());
                    }
                    if (!cells.isEmpty()) {
                        rows.add(cells);
                    }
                }
                if (rows.isEmpty()) {
                    table.remove();
                    continue;
                }
                if (outTables != null) {
                    outTables.add(new TableData(rows));
                }
                // 替换为占位符，保留内联位置
                table.before("<img src=\"table://" + index + "\" />");
                table.remove();
                index++;
            }

            String result = doc.body().html();
            // 还原 Jsoup 转义
            // 原样保留 HTML 实体，由最终 Html.fromHtml 统一解码一次
            // （避免双重编码 &amp;lt; 被提前拆成 &lt; 甚至 < 造成误判为标签）
            return result;
        } catch (Exception e) {
            return html;
        }
    }

    /** 表格数据：行列表 */
    private static class TableData {
        final List<List<String>> rows;

        TableData(List<List<String>> rows) {
            this.rows = rows;
        }

        List<List<String>> getRows() {
            return rows;
        }
    }

    /** 引用卡片数据：存储引用块的原始HTML */
    private static class QuoteCardRef {
        final String html;
        QuoteCardRef(String html) {
            this.html = html;
        }
    }

    private static class CodeCardRef {
        final String html;
        CodeCardRef(String html) {
            this.html = html;
        }
    }

    /** 隐藏内容卡片数据：内容HTML（空=未解锁/需回复）+ 是否可展开 */
    private static class HiddenCardRef {
        final String html;   // 真实隐藏内容（已解锁时非空）
        final boolean unlocked; // 是否已解锁（游客态=false）
        HiddenCardRef(String html) {
            this.html = html;
            this.unlocked = !TextUtils.isEmpty(html);
        }
    }

    /** 附件卡片数据：附件链接 + 显示文件名 */
    private static class AttachmentCardRef {
        final String url;
        final String label;
        AttachmentCardRef(String url, String label) {
            this.url = url;
            String l = label != null ? label.trim() : "";
            // 清理常见无效显示文本（如链接自身URL、纯数字aid等，无帮助）保留原名
            if (l.isEmpty() || l.matches("^附件\\s*\\d*$") || l.equals(url)) {
                l = extractFileNameFromUrl(url);
            }
            this.label = l.isEmpty() ? "打开附件" : l;
        }
    }

    /**
     * 将表格数据绘制为 Bitmap（带边框、表头底色）。
     * 由 ImageGetter 调用，生成可内联显示的表格位图。
     */
    private android.graphics.Bitmap renderTableToBitmap(TableData table, int maxWidthPx) {
        try {
            float density = getResources().getDisplayMetrics().density;
            return TableBitmapRenderer.renderTable(density, maxWidthPx, table.getRows(),
                    com.forum.MT.ui.widget.TableColorManager.resolveColors(this));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 渲染引用卡片内部的表格为 Drawable（应用表格配色）。
     * 供 buildQuoteCard 的 ImageGetter 使用，宽度限制在卡片可用宽度内。
     */
    private android.graphics.drawable.Drawable renderQuoteTableToDrawable(TableData table) {
        try {
            int maxWidth = getScrollTableMaxWidth();
            android.graphics.Bitmap bmp = renderTableToBitmap(table, maxWidth);
            if (bmp == null) return null;
            return new android.graphics.drawable.BitmapDrawable(getResources(), bmp);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 将 HTML 按 table:// 占位符拆分渲染为：文本段 + 可横滑表格段交替显示。
     * <p>
     * 表格段使用 HorizontalScrollView 包裹自然宽度的表格位图 ImageView，
     * 支持左右滑动查看完整表格；表格的位置与正文中的原始位置一致（内联）。
     *
     * @param html   已由 convertHtmlTables 处理过的 HTML（含 &lt;img src="table://N"&gt; 占位符）
     * @param tables 表格数据列表（与占位符索引对应）
     * @param root   目标垂直 LinearLayout（frame_content），其第 0 个子视图应为 tv_content
     */
    /**
     * ★ 预加载主帖 HTML 中的表情图到缓存，然后渲染。
     * 与 ReplyAdapter.preloadSmileysAndRender 同理：先后台下载表情，再主线程渲染。
     */
    private void preloadMainContentSmileys(String html, List<TableData> tables,
                                           LinearLayout root, TextView tvContent,
                                           List<String> bigImageUrls,
                                           List<QuoteCardRef> quoteCards,
                                           List<CodeCardRef> codeCards,
                                           List<HiddenCardRef> hiddenCards) {
        long t0 = System.currentTimeMillis();
        if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_PRELOAD", "START htmlLen=" + (html != null ? html.length() : 0));

        // ★ 性能优化：从 HTML 中提取大图，替换为 @@IMGCARDN@@ 标记
        // 这样 Html.fromHtml 只渲染文字+表情（快速），大图由 renderContentWithInlineTables
        // 作为独立 ImageView 渲染（Glide 异步加载），消除二次渲染。
        mInlineImageUrls.clear();
        String htmlForRender = extractInlineImagesFromHtml(html, mInlineImageUrls);

        // 收集需要预加载的表情URL（小图标，保持内联渲染）
        java.util.Set<String> smileyUrls = new java.util.LinkedHashSet<>();
        if (!TextUtils.isEmpty(htmlForRender)) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                    "<img\\s+[^>]*src=\"([^\"]+)\"", java.util.regex.Pattern.CASE_INSENSITIVE)
                    .matcher(htmlForRender);
            while (m.find()) {
                String src = m.group(1);
                if (src != null && (src.contains("smiley") || src.contains("emoticon")
                        || src.contains("/static/image/"))) {
                    String fullUrl = src;
                    if (fullUrl.startsWith("//")) fullUrl = "https:" + fullUrl;
                    else if (fullUrl.startsWith("/")) fullUrl = HttpClient.BASE_URL + fullUrl.substring(1);
                    smileyUrls.add(fullUrl);
                }
            }
        }

        java.util.List<String> toDownload = new java.util.ArrayList<>();
        for (String url : smileyUrls) {
            if (!ReplyAdapter.getSmileyCache().containsKey(url)) {
                toDownload.add(url);
            }
        }

        // ★ 第一次渲染：文字 + 表情占位 + 表格 + 卡片（大图已被替换为 ImageView）
        Runnable renderTask = () -> {
            long t1 = System.currentTimeMillis();
            renderContentWithInlineTables(htmlForRender, tables, root, quoteCards, codeCards, hiddenCards);
            setupClickableLinks(tvContent);
            applyEditTimeColor(tvContent);
            tvContent.setVisibility(View.VISIBLE);
            long t2 = System.currentTimeMillis();
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_PRELOAD", "render done in " + (t2 - t1) + "ms");
        };
        renderTask.run();

        // 后台并行下载表情图（小图标），全部完成后回主线程重渲染一次（无大图，渲染很快）
        if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_PRELOAD", "toDownload=" + toDownload.size());
        if (!toDownload.isEmpty()) {
            java.util.concurrent.ExecutorService pool =
                    java.util.concurrent.Executors.newFixedThreadPool(Math.min(4, Math.max(2, toDownload.size())));
            java.util.concurrent.CountDownLatch latch =
                    new java.util.concurrent.CountDownLatch(toDownload.size());
            for (String url : toDownload) {
                pool.submit(() -> {
                    try {
                        android.graphics.drawable.Drawable drawable = Glide.with(ThreadDetailActivity.this)
                                .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(url))
                                .submit()
                                .get();
                        if (drawable != null) {
                            int maxSize = dpToPx(24);
                            int w = drawable.getIntrinsicWidth();
                            int h = drawable.getIntrinsicHeight();
                            if (w > maxSize || h > maxSize) {
                                float ratio = (float) maxSize / Math.max(w, h);
                                w = (int) (w * ratio);
                                h = (int) (h * ratio);
                            } else {
                                w = Math.max(w, 16);
                                h = Math.max(h, 16);
                            }
                            drawable.setBounds(0, 0, w, h);
                            String saveKey = url == null ? null : url.replace("&amp;", "&");
                            if (saveKey != null) {
                                ReplyAdapter.getSmileyCache().put(saveKey, drawable);
                            }
                            if (url != null && !url.equals(saveKey)) {
                                ReplyAdapter.getSmileyCache().put(url, drawable);
                            }
                            // ★ 如果是 GIF，额外缓存原始字节（用于 ImageGetter 创建独立实例）
                            if (isGifDrawable(drawable) && saveKey != null) {
                                preloadGifBytesMainThread(saveKey);
                            }
                        }
                    } catch (Exception e) {
                        android.util.Log.w("MT_PRELOAD", "smiley download failed: " + url, e);
                    } finally {
                        latch.countDown();
                    }
                });
            }
            pool.shutdown();
            new Thread(() -> {
                try {
                    latch.await();
                } catch (InterruptedException ignored) {
                }
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        long tR2 = System.currentTimeMillis();
                        // 表情下载完成后的单次重渲染（已无大图，速度快）
                        renderContentWithInlineTables(htmlForRender, tables, root,
                                quoteCards, codeCards, hiddenCards);
                        setupClickableLinks(tvContent);
                        applyEditTimeColor(tvContent);
                        tvContent.setVisibility(View.VISIBLE);
                        long tR3 = System.currentTimeMillis();
                        if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_PRELOAD", "smiley re-render done in " + (tR3 - tR2) + "ms");
                    }
                });
            }).start();
        }
        long tEnd = System.currentTimeMillis();
        if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_PRELOAD", "END total=" + (tEnd - t0) + "ms");
    }

    private void renderContentWithInlineTables(String html, List<TableData> tables,
                                               LinearLayout root) {
        renderContentWithInlineTables(html, tables, root, binding.tvContent,
                (int) com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(ThreadDetailActivity.this),
                com.forum.MT.R.color.text_primary, 0f, 1.4f, null, null);
    }

    private void renderContentWithInlineTables(String html, List<TableData> tables,
                                               LinearLayout root,
                                               List<QuoteCardRef> quoteCards,
                                               List<CodeCardRef> codeCards) {
        renderContentWithInlineTables(html, tables, root, binding.tvContent,
                (int) com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(ThreadDetailActivity.this),
                com.forum.MT.R.color.text_primary, 0f, 1.4f, quoteCards, codeCards);
    }

    private void renderContentWithInlineTables(String html, List<TableData> tables,
                                               LinearLayout root,
                                               List<QuoteCardRef> quoteCards,
                                               List<CodeCardRef> codeCards,
                                               List<HiddenCardRef> hiddenCards) {
        renderContentWithInlineTables(html, tables, root, binding.tvContent,
                (int) com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(ThreadDetailActivity.this),
                com.forum.MT.R.color.text_primary, 0f, 1.4f, quoteCards, codeCards, hiddenCards);
    }

    /**
     * 将 HTML 按 table:// 占位符拆分渲染为：文本段 + 可横滑表格段交替显示。
     * <p>
     * 表格段使用 HorizontalScrollView 包裹自然宽度的表格位图 ImageView，
     * 支持左右滑动查看完整表格；表格的位置与正文中的原始位置一致（内联）。
     *
     * @param html     已由 convertHtmlTables 处理过的 HTML（含 &lt;img src="table://N"&gt; 占位符）
     * @param tables   表格数据列表（与占位符索引对应）
     * @param root     目标垂直 LinearLayout（frame_content），其第 0 个子视图应为 mainText
     * @param mainText 主文本 TextView（root 中已定义样式的首个文本容器）
     * @param textSize 动态创建的额外 TextView 的字体大小(sp)
     * @param textColorRes 动态创建的额外 TextView 的文字颜色资源
     * @param lineSpacingExtra 额外行距(dp)
     * @param lineSpacingMulti 行距倍数
     */
    private void renderContentWithInlineTables(String html, List<TableData> tables,
                                               LinearLayout root,
                                               TextView mainText, int textSize, int textColorRes,
                                               float lineSpacingExtra, float lineSpacingMulti) {
        renderContentWithInlineTables(html, tables, root, mainText, textSize, textColorRes,
                lineSpacingExtra, lineSpacingMulti, null, null);
    }

    private void renderContentWithInlineTables(String html, List<TableData> tables,
                                               LinearLayout root,
                                               TextView mainText, int textSize, int textColorRes,
                                               float lineSpacingExtra, float lineSpacingMulti,
                                               List<QuoteCardRef> preExtractedQuoteCards,
                                               List<CodeCardRef> preExtractedCodeCards) {
        renderContentWithInlineTables(html, tables, root, mainText, textSize, textColorRes,
                lineSpacingExtra, lineSpacingMulti, preExtractedQuoteCards, preExtractedCodeCards, null);
    }

    private void renderContentWithInlineTables(String html, List<TableData> tables,
                                               LinearLayout root,
                                               TextView mainText, int textSize, int textColorRes,
                                               float lineSpacingExtra, float lineSpacingMulti,
                                               List<QuoteCardRef> preExtractedQuoteCards,
                                               List<CodeCardRef> preExtractedCodeCards,
                                               List<HiddenCardRef> preExtractedHiddenCards) {
        if (root == null) return;
        // ★ 清空 root 中之前渲染的卡片/图片视图（保留 mainText）
        // 先收集要删除的视图（跳过 mainText）
        for (int i = root.getChildCount() - 1; i >= 0; i--) {
            View child = root.getChildAt(i);
            if (child != mainText) {
                root.removeViewAt(i);
            }
        }
        dbgFile("render", "root!=null htmlLen=" + (html==null?-1:html.length()));
        TextView mainContent = (mainText != null) ? mainText : binding.tvContent;
        mainContent.setText("");
        // ★ 应用"显示大小"设置：主文本字号跟随调用方传入的 textSize（正文/隐藏内容各自独立）
        mainContent.setTextSize(textSize);

        if (TextUtils.isEmpty(html)) {
            dbgFile("render", "html is EMPTY!");
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_DEBUG", "[renderContentWithInlineTables] html is empty, setting VISIBLE and returning");
            mainContent.setVisibility(View.VISIBLE);
            return;
        }

        // 第一步：提取引用块（[quote] BBCode、<blockquote>、div.comiis_quote 等）

        // 第一步：提取引用块（[quote] BBCode、<blockquote>、div.comiis_quote 等）
        // 替换为 <!--QUOTE_CARD_N--> 占位符，供后续拆分渲染
        List<QuoteCardRef> quoteCards = preExtractedQuoteCards != null ? preExtractedQuoteCards : new ArrayList<>();
        List<CodeCardRef> codeCards = preExtractedCodeCards != null ? preExtractedCodeCards : new ArrayList<>();
        List<HiddenCardRef> hiddenCards = preExtractedHiddenCards != null ? preExtractedHiddenCards : new ArrayList<>();
        String htmlWithCards;
        if (preExtractedQuoteCards != null) {
            // 已在 bindData 中提前提取，HTML 中已含 <!--QUOTE_CARD_N--> 占位符
            htmlWithCards = html;
            if (com.forum.MT.util.Dbg.ON) Log.d("MT_QUOTE", "[renderContentWithInlineTables] using pre-extracted " + quoteCards.size() + " quote cards");
        } else {
            if (com.forum.MT.util.Dbg.ON) Log.d("MT_QUOTE", "[renderContentWithInlineTables] input html length=" + html.length() + " snippet=" + html.substring(0, Math.min(200, html.length())));
            htmlWithCards = extractQuoteBlocks(html, quoteCards);
            if (com.forum.MT.util.Dbg.ON) Log.d("MT_QUOTE", "[renderContentWithInlineTables] quoteCards count=" + quoteCards.size() + " htmlWithCards length=" + htmlWithCards.length());
        }
        // ★ 提取隐藏内容块（解析端已在 HTML 中标记 data-sqapp-hidden；兜底兼容未标记的提示框）
        if (preExtractedHiddenCards == null) {
            htmlWithCards = extractHiddenBlocks(htmlWithCards, hiddenCards);
            if (com.forum.MT.util.Dbg.ON) Log.d("MT_HIDDEN", "[renderContentWithInlineTables] hiddenCards count=" + hiddenCards.size());
        }
        // ★ 提取代码块（如果尚未在 bindData 中提取）
        if (preExtractedCodeCards == null) {
            htmlWithCards = extractCodeBlocks(htmlWithCards, codeCards);
            if (com.forum.MT.util.Dbg.ON) Log.d("MT_QUOTE", "[renderContentWithInlineTables] codeCards count=" + codeCards.size());
        }
        // ★ 提取附件链接为附件卡片占位符（参考开源 sqapp 的 addAttachmentCard）
        List<AttachmentCardRef> attachmentCards;
        if (mPreExtractedAttachmentCards != null && !mPreExtractedAttachmentCards.isEmpty()) {
            // 已在 bindData 中提前提取，HTML 中已含 ATTACH_CARD_N 占位符
            attachmentCards = mPreExtractedAttachmentCards;
            if (com.forum.MT.util.Dbg.ON) Log.d("MT_ATTACH", "[renderContentWithInlineTables] using pre-extracted " + attachmentCards.size() + " attachment cards");
        } else {
            attachmentCards = new ArrayList<>();
            htmlWithCards = extractAttachmentLinks(htmlWithCards, attachmentCards);
        }
        if (!attachmentCards.isEmpty()) {
            if (com.forum.MT.util.Dbg.ON) Log.d("MT_ATTACH", "[renderContentWithInlineTables] attachmentCards count=" + attachmentCards.size());
        }

        // 第二步：按 table://N 占位符、QUOTE_CARD_N、CODE_CARD_N、HIDDEN_CARD_N、ATTACH_CARD_N 和 IMGCARD_N 标记拆分 HTML
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(
                "<img\\s+src=\"table://(\\d+)\"[^>]*>|<!--QUOTE_CARD_(\\d+)-->|<!--CODE_CARD_(\\d+)-->|<!--HIDDEN_CARD_(\\d+)-->|<!--ATTACH_CARD_(\\d+)-->|@@IMGCARD(\\d+)@@",
                java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Matcher matcher = pattern.matcher(htmlWithCards);

        // 收集分段：文本段（String），表格索引（Integer，>=0），
        // 引用卡索引（Integer，<0，存 -index-1），代码卡索引（Integer，存 -index-1001），
        // 隐藏卡索引（Integer，存 -index-2001），附件卡索引（Integer，存 -index-3001）
        List<Object> segments = new ArrayList<>();
        int lastEnd = 0;
        while (matcher.find()) {
            if (matcher.start() > lastEnd) {
                segments.add(htmlWithCards.substring(lastEnd, matcher.start()));
            }
            if (matcher.group(1) != null) {
                // 表格段
                segments.add(Integer.parseInt(matcher.group(1)));
            } else if (matcher.group(2) != null) {
                // 引用卡片段：用负数编码，-(idx+1) 避免与表格索引冲突
                segments.add(-(Integer.parseInt(matcher.group(2)) + 1));
            } else if (matcher.group(3) != null) {
                // 代码卡片段：用负数编码，-(idx+1001) 避免与引用卡索引冲突
                segments.add(-(Integer.parseInt(matcher.group(3)) + 1001));
            } else if (matcher.group(4) != null) {
                // 隐藏卡片段：用负数编码，-(idx+2001) 与引用/代码卡索引区分
                segments.add(-(Integer.parseInt(matcher.group(4)) + 2001));
            } else if (matcher.group(5) != null) {
                // 附件卡片段：用负数编码，-(idx+3001) 与其它卡片索引区分
                segments.add(-(Integer.parseInt(matcher.group(5)) + 3001));
            } else {
                // 图片片段：用负数编码，-(idx+4001) 与其它卡片索引区分
                segments.add(-(Integer.parseInt(matcher.group(6)) + 4001));
            }
            lastEnd = matcher.end();
        }
        if (lastEnd < htmlWithCards.length()) {
            segments.add(htmlWithCards.substring(lastEnd));
        }

        for (Object s : segments) {
            if (s instanceof Integer) {
            } else {
            }
        }
        if (segments.isEmpty()) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_DEBUG", "[renderContent] segments empty, rendering full html directly");
            mainContent.setText(fromForumHtml(htmlWithCards,
                    createInlineImageGetter(mainContent)));
            mainContent.setVisibility(View.VISIBLE);
            return;
        }
        if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_DEBUG", "[renderContent] segments count=" + segments.size());

        // 移除 mainContent 之后残留的动态子视图（表格段/额外文本段），再重新渲染。
        // 保留 mainContent 之前（提示文字/按钮等静态控件）。
        int mainIndex = -1;
        for (int i = 0; i < root.getChildCount(); i++) {
            if (root.getChildAt(i) == mainContent) {
                mainIndex = i;
                break;
            }
        }
        if (mainIndex < 0) {
            // mainContent 不在 root 中，直接加入末尾
            root.addView(mainContent);
            mainIndex = root.getChildCount() - 1;
        }
        for (int i = root.getChildCount() - 1; i > mainIndex; i--) {
            root.removeViewAt(i);
        }

        boolean firstText = true;
        int segIdx = 0;
        for (Object seg : segments) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_DEBUG", "[renderContent] processing segment " + segIdx + " type=" + (seg instanceof Integer ? "card/table" : "text") + " textLen=" + (seg instanceof String ? ((String)seg).length() : 0));
            segIdx++;
            if (seg instanceof Integer) {
                int idx = (Integer) seg;
                if (idx >= 0) {
                    // 表格段
                    if (tables != null && idx < tables.size()) {
                        TableData t = tables.get(idx);
                        int maxWidth = getScrollTableMaxWidth();
                        android.graphics.Bitmap bmp = renderTableToBitmap(t, maxWidth);
                        if (bmp != null) {
                            root.addView(buildScrollableTable(bmp));
                        } else {
                            root.addView(buildEmptySpacer());
                        }
                    }
                } else {
                    // 引用卡片段：还原索引
                    int quoteIdx = -idx - 1;
                    if (quoteCards != null && quoteIdx >= 0 && quoteIdx < quoteCards.size()) {
                        root.addView(buildQuoteCard(quoteCards.get(quoteIdx).html));
                    } else if (idx <= -1000 && idx >= -2000) {
                        // 代码卡片段：索引范围 -(idx+1001)
                        int codeIdx = -idx - 1001;
                        if (codeCards != null && codeIdx >= 0 && codeIdx < codeCards.size()) {
                            root.addView(buildCodeCard(codeCards.get(codeIdx).html));
                        }
                    } else if (idx < -2000 && idx >= -3000) {
                        // 隐藏卡片段：索引范围 -(idx+2001)
                        int hiddenIdx = -idx - 2001;
                        if (hiddenCards != null && hiddenIdx >= 0 && hiddenIdx < hiddenCards.size()) {
                            root.addView(buildHiddenCard(hiddenCards.get(hiddenIdx)));
                        }
                    } else if (idx < -3000 && idx >= -4000) {
                        // 附件卡片段：索引范围 -(idx+3001)
                        int attachIdx = -idx - 3001;
                        if (attachmentCards != null && attachIdx >= 0 && attachIdx < attachmentCards.size()) {
                            root.addView(buildAttachmentCard(attachmentCards.get(attachIdx)));
                        }
                    } else if (idx < -4000) {
                        // ★ 图片片段：索引范围 -(idx+4001)
                        int imgIdx = -idx - 4001;
                        if (mInlineImageUrls != null && imgIdx >= 0 && imgIdx < mInlineImageUrls.size()) {
                            root.addView(buildInlineImageView(mInlineImageUrls.get(imgIdx)));
                        }
                    }
                }
            } else {
                String textPart = (String) seg;
                if (textPart.trim().isEmpty()) continue;
                CharSequence rendered = fromForumHtml(textPart,
                        createInlineImageGetter(mainContent));
                if (firstText) {
                    dbgFile("render_seg", "firstText: rendered=" + (rendered==null?"null":rendered.toString().substring(0, Math.min(100, rendered.toString().length()))));
                    mainContent.setText(rendered);
                    mainContent.setVisibility(View.VISIBLE);
                    firstText = false;
                } else {
                    TextView extra = new TextView(this);
                    extra.setTextSize(textSize);
                    extra.setTextColor(getResources().getColor(textColorRes, getTheme()));
                    extra.setIncludeFontPadding(true);
                    extra.setText(rendered, TextView.BufferType.SPANNABLE);
                    // ★ 修复：extra 动态 TextView 也必须设置链接可点击，
                    // 否则引用块/代码块/表格之后的文本段中的链接无法点击。
                    setupClickableLinks(extra);
                    root.addView(extra, new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT));
                }
            }
        }
        if (firstText) {
            // 全是表格/引用卡无文本
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_DEBUG", "[renderContent] no text segments found, setting GONE");
            mainContent.setVisibility(View.GONE);
        } else {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_DEBUG", "[renderContent] rendering done, mainContent has text");
        }
    }

    /**
     * 构建一个可横向滑动的表格视图（HorizontalScrollView + ImageView）
     */
    private View buildScrollableTable(android.graphics.Bitmap bmp) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(true);
        // 不启用 fillViewport：保持位图自然尺寸，避免窄表格被拉伸变形；
        // 超宽表格保持自然宽度，可左右滑动查看全部内容。
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        ImageView imageView = new ImageView(this);
        imageView.setImageBitmap(bmp);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        // 保持位图自然宽度（横向可滑动）；高度按位图高度自适应
        imageView.setLayoutParams(new HorizontalScrollView.LayoutParams(
                HorizontalScrollView.LayoutParams.WRAP_CONTENT,
                HorizontalScrollView.LayoutParams.WRAP_CONTENT));
        // 顶部留白与下划线分隔
        scroll.addView(imageView);
        return scroll;
    }

    /** 表格位图最大宽度：屏幕宽 - 页边距 */
    private int getScrollTableMaxWidth() {
        return getResources().getDisplayMetrics().widthPixels - dpToPx(48);
    }

    private View buildEmptySpacer() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(8)));
        return v;
    }

    /**
     * ★ 性能优化：构建独立 ImageView 渲染内联大图。
     * 用 Glide 异步加载，不阻塞主线程，加载完成后自动显示。
     */
    private View buildInlineImageView(String imageUrl) {
        int maxImgWidth = getResources().getDisplayMetrics().widthPixels - dpToPx(32);
        ImageView imageView = new ImageView(this);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        imageView.setMaxWidth(maxImgWidth);
        imageView.setMaxHeight(dpToPx(400));
        imageView.setMinimumHeight(dpToPx(120));
        imageView.setOnClickListener(v -> {
            if (imageUrl != null && !imageUrl.isEmpty()) {
                openImagePreview(imageUrl);
            }
        });

        // 失败时显示占位图，但允许页面重新绑定时再次尝试，避免一次网络抖动永久阻断图片。

        if (!isFinishing() && !isDestroyed()) {
            Glide.with(this)
                    .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(imageUrl))
                    .placeholder(new android.graphics.drawable.ColorDrawable(0xFFF0F0F0))
                    .timeout(15000)
                    .error(createFailedImageDrawable())
                    .override(maxImgWidth, dpToPx(400))
                    .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                        @Override
                        public boolean onLoadFailed(@androidx.annotation.Nullable com.bumptech.glide.load.engine.GlideException e,
                                                    Object model,
                                                    com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                                    boolean isFirstResource) {
                            if (imageUrl != null) {
                                mFailedImageUrls.add(imageUrl);
                            }
                            // ★ 关键：延迟清除 Glide 请求，让 error drawable 先显示，
                            //   然后清除请求使该 Target 不再受 Activity 生命周期恢复影响，
                            //   避免从预览页返回时 Glide resumeRequests 重试导致闪烁。
                            final ImageView iv = imageView;
                            iv.post(() -> {
                                try {
                                    Glide.with(ThreadDetailActivity.this).clear(iv);
                                } catch (Exception ignored) {}
                                iv.setImageDrawable(createFailedImageDrawable());
                            });
                            // 返回 true 表示已自行处理 error drawable
                            return true;
                        }
                        @Override
                        public boolean onResourceReady(android.graphics.drawable.Drawable resource,
                                                       Object model,
                                                       com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                                                       com.bumptech.glide.load.DataSource dataSource,
                                                       boolean isFirstResource) {
                            return false;
                        }
                    })
                    .into(imageView);
        }
        return imageView;
    }

    /**
     * 构建引用内容卡片（MaterialCardView），显示在正文引用块位置。
     * 样式参考 sqapp 开源版：浅绿色背景、圆角、标题"引用内容"。
     */
    private View buildQuoteCard(String quoteHtml) {
        com.google.android.material.card.MaterialCardView card =
                new com.google.android.material.card.MaterialCardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dpToPx(6), 0, dpToPx(6));
        card.setLayoutParams(params);
        card.setRadius(dpToPx(12));
        card.setCardBackgroundColor(com.forum.MT.ui.widget.QuoteBgColorManager.resolveBgColor(this));
        card.setStrokeWidth(dpToPx(1));
        card.setStrokeColor(com.forum.MT.ui.widget.QuoteBgColorManager.resolveBorderColor(this));
        card.setCardElevation(0f);
        card.setContentPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        // 标题行
        TextView titleView = new TextView(this);
        titleView.setText("引用内容");
        titleView.setTextColor(com.forum.MT.ui.widget.QuoteBgColorManager.resolveTitleColor(this));
        titleView.setTextSize(13);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        body.addView(titleView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // 分隔线
        View divider = new View(this);
        int borderColor = com.forum.MT.ui.widget.QuoteBgColorManager.resolveBorderColor(this);
        divider.setBackgroundColor(borderColor);
        divider.setAlpha(0.3f);
        LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1));
        divParams.setMargins(0, dpToPx(6), 0, dpToPx(6));
        body.addView(divider, divParams);

        // 引用内容正文
        TextView contentView = new TextView(this);
        contentView.setTextSize(14);
        contentView.setTextColor(com.forum.MT.ui.widget.QuoteBgColorManager.resolveTextColor(this));
        contentView.setLineSpacing(0f, 1.4f);

        // 提取引用内容中的 <table> 为表格占位符，供 ImageGetter 渲染为位图表格（应用表格配色）
        List<TableData> quoteTables = new ArrayList<>();
        String quoteHtmlWithTablePlaceholders = convertHtmlTables(quoteHtml, quoteTables);
        final TableData[] quoteTableArr = quoteTables.toArray(new TableData[0]);

        android.text.Html.ImageGetter ig = source -> {
            if (source != null && source.startsWith("table://")) {
                try {
                    int idx = Integer.parseInt(source.substring("table://".length()));
                    if (idx >= 0 && idx < quoteTableArr.length) {
                        return renderQuoteTableToDrawable(quoteTableArr[idx]);
                    }
                } catch (Exception ignored) {}
            }
            return null;
        };

        CharSequence rendered = fromForumHtml(quoteHtmlWithTablePlaceholders, ig);
        // 应用用户自定义的加粗值
        int boldWeight = com.forum.MT.ui.widget.QuoteBoldWeightManager.getWeight(this);
        if (boldWeight != 700 && rendered instanceof android.text.Spannable) {
            android.text.Spannable sp = (android.text.Spannable) rendered;
            android.text.style.StyleSpan[] spans = sp.getSpans(0, sp.length(), android.text.style.StyleSpan.class);
            for (android.text.style.StyleSpan span : spans) {
                if (span.getStyle() == android.graphics.Typeface.BOLD) {
                    int s = sp.getSpanStart(span);
                    int e = sp.getSpanEnd(span);
                    int f = sp.getSpanFlags(span);
                    sp.removeSpan(span);
                    android.graphics.Typeface customTf = android.graphics.Typeface.create(
                            android.graphics.Typeface.DEFAULT, boldWeight, false);
                    sp.setSpan(new android.text.style.TypefaceSpan(customTf), s, e, f);
                }
            }
        }
        contentView.setText(rendered);
        setupClickableLinks(contentView);
        body.addView(contentView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        card.addView(body);
        return card;
    }

    /**
     * 构建 📎 附件卡片（浅蓝背景、圆角 10dp，点击打开附件链接）。
     * 移植自开源 sqapp 项目的 addAttachmentCard。
     */
    private View buildAttachmentCard(final AttachmentCardRef ref) {
        if (ref == null) return buildEmptySpacer();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.START);
        row.setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10));
        android.graphics.drawable.GradientDrawable background =
                new android.graphics.drawable.GradientDrawable();
        background.setColor(0xFFF3F6FA);
        background.setCornerRadius(dpToPx(10));
        background.setStroke(dpToPx(1), 0xFFD1DDF0);
        row.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dpToPx(6), 0, dpToPx(6));
        row.setLayoutParams(params);

        TextView icon = new TextView(this);
        icon.setText("📎");
        icon.setTextSize(20);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                dpToPx(36), LinearLayout.LayoutParams.WRAP_CONTENT);
        iconParams.gravity = android.view.Gravity.CENTER_VERTICAL;
        row.addView(icon, iconParams);

        // 右侧信息容器（垂直排列）
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        row.addView(info, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // 解析 label：格式如 "文件名.txt 前天 20:05上传 11.92 KB , 下载次数: 11, 下载积分: 金币 -1"
        String label = ref.label;
        String fileName = label;
        String uploadTime = "";
        String fileSize = "";
        String downloadCount = "";

        // 尝试提取文件名（到第一个时间/上传之前）
        java.util.regex.Matcher nameM = java.util.regex.Pattern.compile(
                "^(.+?)\\s+(?=\\S+\\s*\\d+[日时:]|\\S+\\s+\\d{1,2}[:：])").matcher(label);
        // 简单方案：按关键词分段
        // 1. 提取大小
        java.util.regex.Matcher sizeM = java.util.regex.Pattern.compile(
                "(\\d+(?:\\.\\d+)?\\s*(?:KB|MB|GB|kb|mb|gb))").matcher(label);
        if (sizeM.find()) {
            fileSize = sizeM.group(1);
        }
        // 2. 提取下载次数
        java.util.regex.Matcher dlM = java.util.regex.Pattern.compile(
                "下载次数[:：]\\s*(\\d+)").matcher(label);
        if (dlM.find()) {
            downloadCount = dlM.group(1);
        }
        // 2b. 提取下载积分
        String downloadScore = "";
        java.util.regex.Matcher scoreM = java.util.regex.Pattern.compile(
                "下载积分[:：]\\s*(.+?)(?:$|\\s*$)").matcher(label);
        if (scoreM.find()) {
            downloadScore = scoreM.group(1).trim();
        }
        // 3. 提取上传时间（XX XX:XX上传 或 XX XX:XX:XX上传）
        java.util.regex.Matcher timeM = java.util.regex.Pattern.compile(
                "(前天|昨天|今天|\\d{1,2}月\\d{1,2}日|\\d{4}-\\d{1,2}-\\d{1,2})\\s*\\d{1,2}[:：]\\d{1,2}(?:[:：]\\d{1,2})?\\s*上传").matcher(label);
        if (timeM.find()) {
            uploadTime = timeM.group();
        }
        // 4. 文件名 = 从开头到上传时间之前
        if (!uploadTime.isEmpty()) {
            int idx = label.indexOf(uploadTime);
            if (idx > 0) {
                fileName = label.substring(0, idx).trim();
            }
        } else {
            // 兜底：取到大小之前
            if (!fileSize.isEmpty()) {
                int idx = label.indexOf(fileSize);
                if (idx > 0) {
                    fileName = label.substring(0, idx).trim();
                }
            }
        }

        // 第一行：文件名
        TextView name = new TextView(this);
        name.setText(fileName);
        name.setTextSize(14);
        name.setTextColor(0xFF1565C0);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        info.addView(name);

        // 第二行：时间 + 大小 + 下载次数
        StringBuilder meta = new StringBuilder();
        if (!uploadTime.isEmpty()) {
            meta.append(uploadTime);
        }
        if (!fileSize.isEmpty()) {
            if (meta.length() > 0) meta.append("  ");
            meta.append("大小: ").append(fileSize);
        }
        if (!downloadCount.isEmpty()) {
            if (meta.length() > 0) meta.append("  ");
            meta.append("下载: ").append(downloadCount);
        }
        if (!downloadScore.isEmpty()) {
            if (meta.length() > 0) meta.append("  ");
            meta.append("积分: ").append(downloadScore);
        }
        if (meta.length() > 0) {
            TextView metaTv = new TextView(this);
            metaTv.setText(meta.toString());
            metaTv.setTextSize(12);
            metaTv.setTextColor(0xFF888888);
            info.addView(metaTv);
        }

        row.setOnClickListener(v -> openContentLink(ref.url));
        return row;
    }

    /**
     * 构建"隐藏内容"卡片（MaterialCardView，橙色主题）。
     * 样式对齐开源 sqapp：浅橙背景、橙色描边、标题"隐藏内容" + 查看按钮。
     * <p>
     * 已解锁（unlocked=true）时点击"查看"直接原地展开真实内容；
     * 未解锁时点击"查看"走 viewHiddenContent 的老逻辑（登录/回复校验后加载）。
     */
    private View buildHiddenCard(final HiddenCardRef ref) {
        com.google.android.material.card.MaterialCardView card =
                new com.google.android.material.card.MaterialCardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dpToPx(6), 0, dpToPx(6));
        card.setLayoutParams(params);
        card.setRadius(dpToPx(12));
        card.setCardBackgroundColor(0xFFFEF3E2);
        card.setStrokeWidth(dpToPx(1));
        card.setStrokeColor(0xFFF59E0B);
        card.setCardElevation(0f);
        card.setContentPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        // 标题行：🔒 隐藏内容（右侧查看按钮）
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText("隐藏内容");
        titleView.setTextColor(0xFFB45309);
        titleView.setTextSize(14);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        titleRow.addView(titleView, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView btnView = new TextView(this);
        btnView.setText("查看");
        btnView.setTextColor(0xFFF59E0B);
        btnView.setTextSize(13);
        btnView.setTypeface(null, android.graphics.Typeface.BOLD);
        btnView.setGravity(android.view.Gravity.CENTER);
        btnView.setPadding(dpToPx(12), dpToPx(4), dpToPx(12), dpToPx(4));
        // 查看按钮描边
        android.graphics.drawable.GradientDrawable btnBg = new android.graphics.drawable.GradientDrawable();
        btnBg.setColor(0xFFFFF7ED);
        btnBg.setCornerRadius(dpToPx(16));
        btnBg.setStroke(dpToPx(1), 0xFFF59E0B);
        btnView.setBackground(btnBg);
        titleRow.addView(btnView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        body.addView(titleRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // 底部提示 / 展开区
        final LinearLayout contentArea = new LinearLayout(this);
        contentArea.setOrientation(LinearLayout.VERTICAL);
        contentArea.setVisibility(View.GONE);
        body.addView(contentArea, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        card.addView(body);

        final boolean unlocked = ref != null && ref.unlocked;
        final String hiddenHtml = ref != null ? ref.html : "";
        // 记录当前是否已展开（用于收起切换）
        final boolean[] expanded = {false};
        btnView.setOnClickListener(v -> {
            if (unlocked && !TextUtils.isEmpty(hiddenHtml)) {
                if (expanded[0]) {
                    // 已展开 → 收起
                    contentArea.setVisibility(View.GONE);
                    btnView.setText("查看");
                    expanded[0] = false;
                    return;
                }
                // 未展开 → 展开
                if (contentArea.getChildCount() == 0) {
                    // 提取隐藏内容中的图片 + 表格，渲染到 contentArea
                    java.util.List<String> hiddenImageUrls = new java.util.ArrayList<>();
                    // ★ 关键修复：隐藏内容图片必须保留在原文内联位置（keepAllInline=true），
                    // 不能分离到底部——否则图片会全部跑到隐藏内容最后面
                    String cleanHiddenHtml = extractAndSeparateImages(hiddenHtml, hiddenImageUrls, true);
                    // ★ 检查 cleanHiddenHtml 中是否还有 <img> 标签（内联保留的图片）
                    int inlineImgCount = 0;
                    java.util.regex.Matcher inlineImgM = java.util.regex.Pattern.compile("<img\\b", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(cleanHiddenHtml);
                    while (inlineImgM.find()) inlineImgCount++;
                    java.util.List<TableData> hiddenTables = new java.util.ArrayList<>();
                    String hiddenContentHtmlStr = convertHtmlTables(cleanHiddenHtml, hiddenTables);
                    // ★ 收集隐藏内容中的图片URL，后台预加载到缓存
                    java.util.List<String> hiddenImgToLoad = new java.util.ArrayList<>();
                    java.util.regex.Matcher hm2 = java.util.regex.Pattern.compile(
                            "<img\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(hiddenContentHtmlStr);
                    while (hm2.find()) {
                        java.util.regex.Matcher sm2 = java.util.regex.Pattern.compile(
                                "\\bsrc\\s*=\\s*\"([^\"]+)\"").matcher(hm2.group());
                        if (sm2.find()) {
                            String rawUrl2 = sm2.group(1);
                            String fullUrl2 = normalizeImageUrl(rawUrl2);
                            if (fullUrl2 != null) {
                                fullUrl2 = fullUrl2.replace("&amp;", "&");
                                if (!hiddenImgToLoad.contains(fullUrl2)) hiddenImgToLoad.add(fullUrl2);
                            }
                        }
                    }
                    final String finalHiddenHtml = hiddenContentHtmlStr;
                    final java.util.List<TableData> finalHiddenTables = hiddenTables;
                    final int finalTextSize = (int) com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(this,
                            com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_HIDDEN);
                    final java.util.List<String> finalImgToLoad = hiddenImgToLoad;
                    // ★ 先渲染文字（立即可见），再后台预加载图片
                    TextView inner = new TextView(this);
                    inner.setTextSize(finalTextSize);
                    inner.setTextColor(getResources().getColor(com.forum.MT.R.color.text_primary, getTheme()));
                    inner.setLineSpacing(0f, 1.4f);
                    contentArea.addView(inner, new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT));
                    renderContentWithInlineTables(finalHiddenHtml, finalHiddenTables, contentArea,
                            inner, finalTextSize,
                            com.forum.MT.R.color.text_primary, 0f, 1.4f, null, null);
                    setupClickableLinks(inner);
                    {
                        CharSequence innerText = inner.getText();
                        int spanCount = 0;
                        if (innerText instanceof android.text.Spannable) {
                            android.text.style.ClickableSpan[] spans = ((android.text.Spannable) innerText)
                                    .getSpans(0, innerText.length(), android.text.style.ClickableSpan.class);
                            spanCount = spans.length;
                            for (android.text.style.ClickableSpan s : spans) {
                                int ss = ((android.text.Spannable) innerText).getSpanStart(s);
                                int se = ((android.text.Spannable) innerText).getSpanEnd(s);
                            }
                        }
                    }

                    // ★ 修复：拦截隐藏内容中的"回复"链接，改为弹出回复弹窗而非刷新页面
                    try {
                        CharSequence hiddenText = inner.getText();
                        if (hiddenText instanceof android.text.Spannable) {
                            android.text.Spannable hiddenSpannable = (android.text.Spannable) hiddenText;
                            android.text.style.ClickableSpan[] hiddenSpans = hiddenSpannable.getSpans(
                                    0, hiddenSpannable.length(), android.text.style.ClickableSpan.class);
                            for (android.text.style.ClickableSpan span : hiddenSpans) {
                                int s = hiddenSpannable.getSpanStart(span);
                                int e = hiddenSpannable.getSpanEnd(span);
                                if (s >= 0 && e > s) {
                                    CharSequence linkText = hiddenSpannable.subSequence(s, e);
                                    if (linkText != null && linkText.toString().contains("回复")) {
                                        hiddenSpannable.removeSpan(span);
                                        hiddenSpannable.setSpan(new android.text.style.ClickableSpan() {
                                            @Override
                                            public void onClick(View widget) {
                                                showThreadReplyDialog();
                                            }
                                            @Override
                                            public void updateDrawState(android.text.TextPaint ds) {
                                                ds.setColor(ds.linkColor != 0 ? ds.linkColor : 0xFF1976D2);
                                                ds.setUnderlineText(true);
                                            }
                                        }, s, e, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                                    }
                                }
                            }
                        }
                    } catch (Exception ignored) {
                        // 安全兜底，不中断渲染
                    }

                    // ★ 后台预加载图片到缓存，完成后重新渲染使图片显示
                    if (!finalImgToLoad.isEmpty()) {
                        new Thread(() -> {
                            for (String url : finalImgToLoad) {
                                try {
                                    android.graphics.drawable.Drawable drawable = Glide.with(ThreadDetailActivity.this)
                                            .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(url)).submit().get();
                                    if (drawable != null) {
                                        int maxW = dpToPx(300);
                                        int w = drawable.getIntrinsicWidth();
                                        int h = drawable.getIntrinsicHeight();
                                        if (w > maxW) {
                                            float ratio = (float) maxW / w;
                                            w = (int) (w * ratio);
                                            h = (int) (h * ratio);
                                        }
                                        drawable.setBounds(0, 0, w, h);
                                        ReplyAdapter.sReplyImageCache.put(url, drawable);
                                    } else {
                                        // ★ 加载失败：放入"图片已失效"占位图
                                        ReplyAdapter.sReplyImageCache.put(url, createFailedImageDrawable());
                                    }
                                } catch (Exception e) {
                                    // ★ 加载异常：同样放入"图片已失效"占位图
                                    ReplyAdapter.sReplyImageCache.put(url, createFailedImageDrawable());
                                }
                            }
                            runOnUiThread(() -> {
                                renderContentWithInlineTables(finalHiddenHtml, finalHiddenTables, contentArea,
                                        inner, finalTextSize,
                                        com.forum.MT.R.color.text_primary, 0f, 1.4f, null, null);
                                setupClickableLinks(inner);
                            });
                        }).start();
                    }
                }
                contentArea.setVisibility(View.VISIBLE);
                btnView.setText("收起");
                expanded[0] = true;
            } else {
                // 未解锁：弹出回复输入框，让用户回复后即可查看隐藏内容
                showThreadReplyDialog();
            }
        });
        return card;
    }

    /**
     * 创建"图片已失效"占位 Drawable（浅灰背景 + 提示文字）。
     * 用于飞书网盘等临时链接过期或图片加载失败时显示。
     */
    private android.graphics.drawable.Drawable createFailedImageDrawable() {
        int w = dpToPx(160);
        int h = dpToPx(48);
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(w, h,
                android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(bmp);
        // 浅灰背景
        android.graphics.Paint bgPaint = new android.graphics.Paint();
        bgPaint.setColor(0xFFF0F0F0);
        canvas.drawRect(0, 0, w, h, bgPaint);
        // 边框
        android.graphics.Paint borderPaint = new android.graphics.Paint();
        borderPaint.setColor(0xFFCCCCCC);
        borderPaint.setStyle(android.graphics.Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1);
        canvas.drawRect(0, 0, w - 1, h - 1, borderPaint);
        // 提示文字
        android.graphics.Paint textPaint = new android.graphics.Paint();
        textPaint.setColor(0xFF999999);
        textPaint.setTextSize(dpToPx(13));
        textPaint.setAntiAlias(true);
        textPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        float baseline = h / 2f - (textPaint.descent() + textPaint.ascent()) / 2;
        canvas.drawText("图片已失效", w / 2f, baseline, textPaint);
        android.graphics.drawable.BitmapDrawable drawable =
                new android.graphics.drawable.BitmapDrawable(getResources(), bmp);
        drawable.setBounds(0, 0, w, h);
        return drawable;
    }

    /**
     * 渲染代码块为 MaterialCardView（深色背景、等宽字体、可横向滚动、复制按钮）。
     * 支持 [code] BBCode、<pre>、<code>、div.blockcode、div.comiis_blockcode 等格式。
     */
        private View buildCodeCard(String codeHtml) {
        int bgColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveBgColor(this);
        int borderColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveBorderColor(this);
        int textColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveTextColor(this);
        int titleBgColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveTitleBgColor(this);
        int titleTextColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveTitleTextColor(this);

        com.google.android.material.card.MaterialCardView card =
                new com.google.android.material.card.MaterialCardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dpToPx(6), 0, dpToPx(6));
        card.setLayoutParams(params);
        card.setRadius(dpToPx(12));
        card.setCardBackgroundColor(bgColor);
        card.setStrokeWidth(dpToPx(1));
        card.setStrokeColor(borderColor);
        card.setCardElevation(0f);
        card.setContentPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        // 标题行：代码内容 + 复制按钮（尺寸对齐"隐藏内容"卡片）
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText("代码内容");
        titleView.setTextColor(titleTextColor);
        titleView.setTextSize(14);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        titleRow.addView(titleView, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // —— 查看/收起 按钮 ——（用 TextView 对齐隐藏内容卡片，避免 Button 默认 minHeight=48dp 导致更高）
        TextView viewBtn = new TextView(this);
        viewBtn.setText("查看");
        viewBtn.setTextSize(13);
        viewBtn.setTextColor(textColor);
        viewBtn.setTypeface(null, android.graphics.Typeface.BOLD);
        viewBtn.setGravity(android.view.Gravity.CENTER);
        android.graphics.drawable.GradientDrawable viewGd = new android.graphics.drawable.GradientDrawable();
        viewGd.setColor(titleBgColor);
        viewGd.setCornerRadius(dpToPx(16));
        viewGd.setStroke(dpToPx(1), textColor);
        viewBtn.setBackground(viewGd);
        android.widget.LinearLayout.LayoutParams viewBtnParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        viewBtnParams.setMargins(0, 0, dpToPx(6), 0);
        viewBtn.setLayoutParams(viewBtnParams);
        viewBtn.setPadding(dpToPx(12), dpToPx(4), dpToPx(12), dpToPx(4));

        // —— 复制按钮 ——（用 TextView 对齐隐藏内容卡片）
        TextView copyBtn = new TextView(this);
        copyBtn.setText("复制");
        copyBtn.setTextSize(13);
        copyBtn.setTextColor(textColor);
        copyBtn.setTypeface(null, android.graphics.Typeface.BOLD);
        copyBtn.setGravity(android.view.Gravity.CENTER);
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(titleBgColor);
        gd.setCornerRadius(dpToPx(16));
        gd.setStroke(dpToPx(1), textColor);
        copyBtn.setBackground(gd);
        android.widget.LinearLayout.LayoutParams btnParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        btnParams.setMargins(0, 0, 0, 0);
        copyBtn.setLayoutParams(btnParams);
        copyBtn.setPadding(dpToPx(12), dpToPx(4), dpToPx(12), dpToPx(4));
        copyBtn.setOnClickListener(v -> {
            String plainText = android.text.Html.fromHtml(codeHtml,
                    android.text.Html.FROM_HTML_MODE_COMPACT).toString();
            android.content.ClipboardManager clm = (android.content.ClipboardManager)
                    getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            clm.setPrimaryClip(android.content.ClipData.newPlainText("code", plainText));
            android.widget.Toast.makeText(this, "代码已复制", android.widget.Toast.LENGTH_SHORT).show();
        });

        titleRow.addView(viewBtn);
        titleRow.addView(copyBtn);

        body.addView(titleRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // 代码区容器（默认折叠，点"查看"展开，点"收起"折叠）
        final LinearLayout codeArea = new LinearLayout(this);
        codeArea.setOrientation(LinearLayout.VERTICAL);
        codeArea.setVisibility(View.GONE);

        // 分隔线
        View divider = new View(this);
        divider.setBackgroundColor(borderColor);
        divider.setAlpha(0.3f);
        LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1));
        divParams.setMargins(0, dpToPx(6), 0, dpToPx(6));
        codeArea.addView(divider, divParams);

        // 清洗代码文本：解码 HTML 实体 → 去标签（<br>→换行）→ 规范化空白 → 纯文本
        String raw = codeHtml
                .replace("&lt;", "<").replace("&gt;", ">")
                .replace("&amp;", "&").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&apos;", "'")
                .replace("&nbsp;", " ").replace("&#160;", " ")
                .replace("&#10;", "\n").replace("&#x0A;", "\n")
                .replace("&#13;", "\n").replace("&#9;", "\t");
        raw = raw.replaceAll("(?i)<br\\s*/?>", "\n");
        raw = raw.replaceAll("(?i)<[^>]+>", "");
        StringBuilder codeSb = new StringBuilder();
        for (String line : raw.split("\n")) {
            line = line.trim().replaceAll("[ \\t]+", " ");
            if (line.isEmpty()) continue;
            codeSb.append(line).append('\n');
        }
        String codeText = codeSb.toString();

        // 用等宽字体渲染，横向滚动查看长行（长行不换行 → 高度=真实行数，上下紧凑）
        android.widget.HorizontalScrollView scrollView = new android.widget.HorizontalScrollView(this);
        scrollView.setHorizontalScrollBarEnabled(true);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        // ★ 防误触刷新 + 防晃动：方向一旦判定为「横向」，整个手势内锁定 disallow，
        // 不再每次 MOVE 来回切换（来回切换会让父容器反复抢手势 → 上下晃动）。
        final float[] downXY = {0f, 0f};
        final boolean[] lockedHorizontal = {false};
        scrollView.setOnTouchListener((v, ev) -> {
            switch (ev.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    downXY[0] = ev.getX();
                    downXY[1] = ev.getY();
                    lockedHorizontal[0] = false;
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    break;
                case android.view.MotionEvent.ACTION_MOVE:
                    if (!lockedHorizontal[0]) {
                        float dx = Math.abs(ev.getX() - downXY[0]);
                        float dy = Math.abs(ev.getY() - downXY[1]);
                        // 水平优先且超过阈值 → 锁定为横向手势，禁止父容器拦截，直到手势结束
                        if (dx > dy && dx > dpToPx(8)) {
                            lockedHorizontal[0] = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                    }
                    break;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    lockedHorizontal[0] = false;
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    break;
            }
            return false;
        });

        TextView codeView = new TextView(this);
        codeView.setTextSize(12);
        codeView.setTextColor(textColor);
        codeView.setTypeface(android.graphics.Typeface.MONOSPACE);
        codeView.setLineSpacing(0f, 1.25f);
        codeView.setPadding(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4));
        codeView.setBackgroundColor(bgColor);
        codeView.setHorizontallyScrolling(true);
        codeView.setText(codeText);
        // ★ 链接可点击：统一复用 setupClickableLinks（URL 识别 + 点击跳转浏览器）
        setupClickableLinks(codeView);
        codeView.setLinkTextColor(0xFF4FC3F7);
        scrollView.addView(codeView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        codeArea.addView(scrollView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // 查看/收起 切换
        final boolean[] expandedCode = {false};
        viewBtn.setOnClickListener(v -> {
            if (expandedCode[0]) {
                codeArea.setVisibility(View.GONE);
                viewBtn.setText("查看");
            } else {
                codeArea.setVisibility(View.VISIBLE);
                viewBtn.setText("收起");
            }
            expandedCode[0] = !expandedCode[0];
        });

        body.addView(codeArea, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        card.addView(body);
        return card;
    }

    /**
     * 构建"隐藏内容"卡片（MaterialCardView，橙色主题）。
     * 样式对齐开源 sqapp：浅橙背景、橙色描边、标题"隐藏内容" + 查看按钮。
     * <p>
     * 已解锁（unlocked=true）时点击"查看"直接原地展开真实内容；
     * 未解锁时点击"查看"走 viewHiddenContent 的老逻辑（登录/回复校验后加载）。
     */

    /**
     * 将 Discuz! 的 [attachimg]/[attach]/[img] BBCode 转换为 HTML 标签。
     * <p>
     * 注意：
     * - [attachimg] 是图片附件 → 转为 <img>，由图片管线加载
     * - [attach] 是通用文件附件（zip/pdf/doc等）→ 转为附件链接，
     *   由后续的附件卡片渲染为 📎 卡片（参考开源 sqapp 项目）
     */
    private static String convertAttachBBCodeToImg(String html) {
        if (TextUtils.isEmpty(html)) return "";
        String result = html;
        result = result.replaceAll("(?i)\\[attachimg\\]([0-9]+)\\[/attachimg\\]",
                "<img data-mt-inline=\"true\" src=\"https://bbs.binmt.cc/forum.php?mod=image&aid=$1&size=300x300&key=&nocache=1\">");
        // [attach] 是文件附件：转为附件链接（保留 aid），由附件卡片渲染
        result = result.replaceAll("(?i)\\[attach\\]([0-9]+)\\[/attach\\]",
                "<a data-sqapp-attachment=\"true\" href=\"https://bbs.binmt.cc/forum.php?mod=attachment&aid=$1\">附件 $1</a>");
        result = result.replaceAll("\\[img(?:=[^\\]]*)?\\]\\s*([^\\[\\]]+?)\\s*\\[/img\\]",
                "<img src=\"$1\">");
        return result;
    }

    /**
     * 提取正文中的附件链接（<a href="...mod=attachment..."> 等），替换为
     * &lt;!--ATTACH_CARD_N--&gt; 占位符，供分段渲染构建 📎 附件卡片。
     * 参考开源 sqapp 项目的 isAttachmentLink / addAttachmentCard。
     *
     * @param html 已转换、清理完成的 HTML
     * @param out  输出附件卡片列表（顺序与占位符索引对应）
     * @return 替换后的 HTML
     */
    private String extractAttachmentLinks(String html, List<AttachmentCardRef> out) {
        if (TextUtils.isEmpty(html)) return html;
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parseBodyFragment(html);
            doc.outputSettings().prettyPrint(false);
            org.jsoup.select.Elements links = doc.select("a[href]");
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ATTACH", "[extractAttachmentLinks] total a[href] links=" + links.size() + ", html length=" + html.length());
            // ★ 诊断：在传入的html中搜索附件标记
            String htmlLower = html.toLowerCase(java.util.Locale.ROOT);
            if (htmlLower.contains("mod=attachment") || htmlLower.contains("[attach") || htmlLower.contains("aid=")) {
                if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ATTACH", "[extractAttachmentLinks] ATTACH FOUND IN RAW HTML but not in a[href]! snippet="
                        + html.substring(Math.max(0, htmlLower.indexOf("mod=attachment") - 50), Math.min(html.length(), htmlLower.indexOf("mod=attachment") + 200)).replace('\n', ' '));
            }
            // 倒序遍历，便于原地替换为占位符（后续节点不受前面替换影响）
            for (int i = links.size() - 1; i >= 0; i--) {
                org.jsoup.nodes.Element a = links.get(i);
                String sfx = ""; // 链接后的补充文本（如换行/空格）由原 HTML 保留
                String href = a.attr("href");
                if (TextUtils.isEmpty(href)) continue;
                String lower = href.toLowerCase(java.util.Locale.ROOT);
                boolean isAttachment = lower.contains("mod=attachment")
                        || lower.contains("/attachment/")
                        || lower.contains("attachment.php")
                        || lower.contains("aid=");
                if (isAttachment) {
                    if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ATTACH", "[extractAttachmentLinks] FOUND attachment link href=" + href + " text=" + a.text() + " html=" + a.outerHtml().substring(0, Math.min(300, a.outerHtml().length())));
                }
                if (!isAttachment) continue;
                String fullUrl = normalizeLinkUrl(href);
                if (TextUtils.isEmpty(fullUrl)) continue;
                String label = a.text();
                if (TextUtils.isEmpty(label)) {
                    // 兜底：从 URL 提取文件名
                    String fn = extractFileNameFromUrl(fullUrl);
                    label = TextUtils.isEmpty(fn) ? "打开附件" : fn;
                }
                out.add(0, new AttachmentCardRef(fullUrl, label));
                // 替换该 a 标签为占位符
                int idx = out.size() - 1;
                a.before("<!--ATTACH_CARD_" + idx + "-->");
                a.remove();
            }
            String result = doc.body().html();
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ATTACH", "[extractAttachmentLinks] result contains ATTACH_CARD=" + result.contains("ATTACH_CARD") + " length=" + result.length());
            return result;
        } catch (Exception e) {
            android.util.Log.w("MT_ATTACH", "extractAttachmentLinks failed", e);
            return html;
        }
    }

    /** 从附件 URL 末尾提取文件名（去掉查询参数与路径前缀） */
    private static String extractFileNameFromUrl(String url) {
        if (TextUtils.isEmpty(url)) return "";
        String u = url;
        int q = u.indexOf('?');
        if (q >= 0) u = u.substring(0, q);
        int slash = u.lastIndexOf('/');
        if (slash >= 0) u = u.substring(slash + 1);
        return u.trim();
    }

    /**
     * 将正文中的引用块（[quote] BBCode、&lt;blockquote&gt;、div.comiis_quote 等）
     * 提取为卡片占位符，供 renderContentWithInlineTables 渲染为 MaterialCardView。
     *
     * @param html     原始HTML（可能含 BBCode 或 HTML 引用标签）
     * @param outQuotes 输出的引用卡片数据列表
     * @return 替换后的HTML（引用块替换为 &lt;!--QUOTE_CARD_N--&gt; 占位符）
     */
    private static String extractQuoteBlocks(String html, List<QuoteCardRef> outQuotes) {
        if (TextUtils.isEmpty(html)) return html;
        // 第一步：将 [quote] BBCode 转换为 <blockquote> HTML 标签
        String before = html;
        String result = html.replaceAll("(?is)\\[quote(?:=[^\\]]*)?\\](.*?)\\[/quote\\]",
                "<blockquote>$1</blockquote>");
        if (!result.equals(before)) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[extractQuoteBlocks] BBCode [quote] replaced, length " + before.length() + " -> " + result.length());
        } else {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[extractQuoteBlocks] no [quote] BBCode found");
        }
        // 第二步：用 Jsoup 解析，查找所有引用块元素
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parseBodyFragment(result);
            doc.outputSettings().prettyPrint(false);
            org.jsoup.select.Elements all = doc.select(
                    "blockquote, div.comiis_quote, .quote, [class*=comiis_quote]");
            // 只保留最外层匹配元素（避免父 div.comiis_quote 和子 blockquote 重复处理）
            org.jsoup.select.Elements quoteBlocks = new org.jsoup.select.Elements();
            for (org.jsoup.nodes.Element el : all) {
                // ★ 排除隐藏内容提示框：Comiis 隐藏内容提示（"游客，如果您要查看本帖
                // 隐藏内容请回复"）与引用块共用 comiis_quote 类，但它们不是引用。
                // 判断依据：文本包含"隐藏内容"或"游客"（隐藏提示标准文案），
                // 且内部没有真正的 <blockquote> 引用结构。
                String elText = el.text();
                boolean hiddenHint = elText.contains("隐藏内容")
                        || elText.contains("游客，如果您要查看")
                        || (elText.contains("隐藏") && elText.contains("回复"));
                boolean hasRealBlockquote = !el.select("blockquote").isEmpty();
                boolean isHiddenHintBox = hiddenHint && !hasRealBlockquote;
                if (isHiddenHintBox) {
                    if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[extractQuoteBlocks] skip hidden-content hint box: text="
                            + (elText.length() > 60 ? elText.substring(0, 60) : elText));
                    continue;
                }
                boolean hasParentInList = false;
                for (org.jsoup.nodes.Element parent : el.parents()) {
                    if (parent != el && all.contains(parent)) {
                        hasParentInList = true;
                        break;
                    }
                }
                if (!hasParentInList) {
                    quoteBlocks.add(el);
                }
            }
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[extractQuoteBlocks] Jsoup found " + all.size() + " raw, filtered to " + quoteBlocks.size() + " outermost");
            int index = 0;
            for (org.jsoup.nodes.Element qb : quoteBlocks) {
                String tagName = qb.tagName();
                String cls = qb.className();
                String rawHtml = qb.html();
                // 剥离内部 <blockquote> 和 </blockquote> 标签，避免 Html.fromHtml 渲染竖线
                String cleanHtml = rawHtml.replaceAll("(?i)</?blockquote[^>]*>", "");
                // 剥离 <ul>、<ol>、<li> 标签（消除小圆点），并将 <li> 内容换行处理
                cleanHtml = cleanHtml.replaceAll("(?i)</?ul[^>]*>", "");
                cleanHtml = cleanHtml.replaceAll("(?i)</?ol[^>]*>", "");
                cleanHtml = cleanHtml.replaceAll("(?i)<li[^>]*>", "<br>");
                cleanHtml = cleanHtml.replaceAll("(?i)</li>", "");
                // 清理多余的 <br><br> 或 <br>•<br> 等
                cleanHtml = cleanHtml.replaceAll("(?:<br\\s*/?>\\s*){3,}", "<br><br>");
                String htmlSnippet = cleanHtml.length() > 80 ? cleanHtml.substring(0, 80) + "..." : cleanHtml;
                if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[extractQuoteBlocks] quote[" + index + "] tag=" + tagName + " class=" + cls + " html=" + htmlSnippet);
                if (outQuotes != null) {
                    outQuotes.add(new QuoteCardRef(cleanHtml));
                }
                qb.before("<!--QUOTE_CARD_" + index + "-->");
                qb.remove();
                index++;
            }
            result = doc.body().html();
            // 原样保留 HTML 实体，由最终 Html.fromHtml 统一解码一次
        } catch (Exception e) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_QUOTE", "[extractQuoteBlocks] Jsoup error: " + e.getMessage());
            return html;
        }
        return result;
    }

    /**
     * 提取隐藏内容块（解析端已标记 data-sqapp-hidden）为 <!--HIDDEN_CARD_N--> 占位符，
     * 供 renderContentWithInlineTables 在正文原位置渲染"隐藏内容"卡片。
     * <p>
     * 兼容两类输入：
     * <ul>
     *   <li>已由 ForumParser 标记 data-sqapp-hidden 的节点（新解析流程）</li>
     *   <li>未标记但含隐藏提示语（游客…回复/本帖隐藏的内容）的 comiis_quote（兜底）</li>
     * </ul>
     */
    private static String extractHiddenBlocks(String html, java.util.List<HiddenCardRef> outHidden) {
        if (TextUtils.isEmpty(html)) return html;
        if (outHidden == null) return html;
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parseBodyFragment(html);
            doc.outputSettings().prettyPrint(false);
            org.jsoup.select.Elements all = doc.select(
                    "[data-sqapp-hidden], div.comiis_quote.locked, .sqapp-hidden-content, div.locked");
            // 兜底：额外扫描携带隐藏语义的 comiis_quote（游客…回复/本帖隐藏的内容）
            for (org.jsoup.nodes.Element el : doc.select("div.comiis_quote")) {
                if (el.hasAttr("data-sqapp-hidden")) continue;
                String t = el.text();
                if ((t.contains("隐藏内容") && (t.contains("回复") || t.contains("游客")))
                        || t.contains("游客，如果您要查看")
                        || t.contains("本帖隐藏的内容")) {
                    // 排除内部还包含真正的 <blockquote> 的引用块
                    boolean hasRealBlockquote = !el.select("blockquote").isEmpty();
                    if (!hasRealBlockquote) all.add(el);
                }
            }
            // 只保留最外层
            org.jsoup.select.Elements blocks = new org.jsoup.select.Elements();
            for (org.jsoup.nodes.Element el : all) {
                boolean hasParentInList = false;
                for (org.jsoup.nodes.Element parent : el.parents()) {
                    if (parent != el && all.contains(parent)) {
                        hasParentInList = true;
                        break;
                    }
                }
                if (!hasParentInList) blocks.add(el);
            }
            int index = 0;
            for (org.jsoup.nodes.Element b : blocks) {
                // 已解锁时节点内部就是真实内容（ForumParser 已写回）
                String contentHtml = b.html();
                boolean unlocked = !TextUtils.isEmpty(contentHtml)
                        && !(b.text().contains("隐藏内容") && b.text().contains("回复")
                        && b.select("a[href*=action=reply], a[href*=mod=post]").isEmpty());
                if (!unlocked) {
                    // 游客提示态：仍然展示卡片，点击后让 viewHiddenContent 自行访问接口
                    contentHtml = "";
                }
                outHidden.add(new HiddenCardRef(unlocked ? contentHtml : ""));
                b.before("<!--HIDDEN_CARD_" + index + "-->");
                b.remove();
                index++;
            }
            String result = doc.body().html();
            // 原样保留 HTML 实体，由最终 Html.fromHtml 统一解码一次
            // （避免双重编码 &amp;lt; 被提前拆成 &lt; 甚至 < 造成误判为标签）
            return result;
        } catch (Exception e) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_HIDDEN", "[extractHiddenBlocks] error: " + e.getMessage());
            return html;
        }
    }

    /**
     * 提取代码块（[code]、<pre>、<code>、div.blockcode、div.comiis_blockcode）为 <!--CODE_CARD_N--> 占位符，
     * 供 renderContentWithInlineTables 渲染为深色代码卡片。
     */
    private static String extractCodeBlocks(String html, java.util.List<CodeCardRef> outCodes) {
        if (TextUtils.isEmpty(html)) return html;
        String result = html;
        // 第一步：将 [code] BBCode 转换为带标记的 <div>，避免与正文里被解码出的裸 <pre> 混淆
        result = result.replaceAll("(?is)\\[code(?:=[^\\]]*)?\\](.*?)\\[/code\\]",
                "<div data-mt-code=\"true\">$1</div>");
        // 第二步：用 Jsoup 解析，查找所有代码块元素
        try {
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parseBodyFragment(result);
            doc.outputSettings().prettyPrint(false);
            // 只选真正的代码块容器，不选裸 <pre>（避免 &lt;pre&gt; 文字被解码后误判）
            org.jsoup.select.Elements all = new org.jsoup.select.Elements();
            all.addAll(doc.select("div.blockcode, div.comiis_blockcode"));
            all.addAll(doc.select("pre.blockcode, pre.comiis_blockcode"));
            all.addAll(doc.select("div[data-mt-code=true]"));
            // 词边界匹配 blockcode/codeblock 类名（排除 blockcode_icon、quote_blockcode 等）
            for (org.jsoup.nodes.Element el : doc.select("[class]")) {
                String cls = el.className();
                if (cls.matches("(?i).*(?:^|\\s)(?:blockcode|codeblock|comiis_blockcode)(?:\\s|$).*")) {
                    if (!all.contains(el)) all.add(el);
                }
            }
            // 只保留最外层匹配元素（避免 <pre><code> 重复处理）
            org.jsoup.select.Elements codeBlocks = new org.jsoup.select.Elements();
            for (org.jsoup.nodes.Element el : all) {
                boolean hasParentInList = false;
                for (org.jsoup.nodes.Element parent : el.parents()) {
                    if (parent != el && all.contains(parent)) {
                        hasParentInList = true;
                        break;
                    }
                }
                if (!hasParentInList) {
                    codeBlocks.add(el);
                }
            }
            int index = 0;
            for (org.jsoup.nodes.Element cb : codeBlocks) {
                String rawHtml = cb.html();
                // 如果内部有 <code>，只取 <code> 的内容
                org.jsoup.select.Elements innerCode = cb.select("code");
                if (!innerCode.isEmpty()) {
                    rawHtml = innerCode.get(0).html();
                }
                if (outCodes != null) {
                    outCodes.add(new CodeCardRef(rawHtml));
                }
                cb.before("<!--CODE_CARD_" + index + "-->");
                cb.remove();
                index++;
            }
            result = doc.body().html();
            // 原样保留 HTML 实体，由最终 Html.fromHtml 统一解码一次
        } catch (Exception e) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_QUOTE", "[extractCodeBlocks] Jsoup error: " + e.getMessage());
            return html;
        }
        return result;
    }


    private String extractAndSeparateImages(String html, List<String> imageUrls) {
        return extractAndSeparateImages(html, imageUrls, false);
    }

    /**
     * 处理 HTML 中的图片：分类为内联保留/底部列表。
     *
     * @param html           原始 HTML
     * @param imageUrls      收集"网页端插入图片"（非内联）的列表
     * @param keepAllInline  true 时所有图片都保留在原文内联位置（用于隐藏内容等需要保持原位的场景）
     */
    private String extractAndSeparateImages(String html, List<String> imageUrls, boolean keepAllInline) {
        if (TextUtils.isEmpty(html)) return "";
        try {
            // ★ 保护所有占位符注释：Jsoup.parse 会丢弃 HTML 注释，
            // 在解析前先把 <!--XXX_CARD_N--> 替换为文本标记，最后再恢复
            html = html.replaceAll("<!--ATTACH_CARD_(\\d+)-->", "@@ATTACHCARD$1@@");
            html = html.replaceAll("<!--HIDDEN_CARD_(\\d+)-->", "@@HIDDENCARD$1@@");
            html = html.replaceAll("<!--QUOTE_CARD_(\\d+)-->", "@@QUOTECARD$1@@");
            html = html.replaceAll("<!--CODE_CARD_(\\d+)-->", "@@CODECARD$1@@");
            // 使用 Jsoup 解析
            org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parse(html);
            
            // ★ 移除所有 <script> 和 <style> 标签（防止JS代码暴露为乱码）
            doc.select("script").remove();
            doc.select("style").remove();
            
            // ★ 移除 Discuz! 特有的 <ignore_js_op> 包裹标签（内部含 JS 操作占位）
            // 注意：含附件链接（<a href="...mod=attachment...">）的 ignore_js_op 要保留，
            // 否则通用文件附件（zip/pdf等）会在渲染前被删除导致"嵌入的文件不显示"。
            int keptIgnoreOps = 0;
            for (org.jsoup.nodes.Element ignoreOp : doc.select("ignore_js_op").toArray(new org.jsoup.nodes.Element[0])) {
                org.jsoup.select.Elements attachLinks = ignoreOp.select("a[href*=mod=attachment], a[href*=attachment.php], a[href*=aid=]");
                boolean hasAttachmentLink = !attachLinks.isEmpty();
                if (!hasAttachmentLink) {
                    ignoreOp.remove();
                } else {
                    keptIgnoreOps++;
                    if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ATTACH", "[extractAndSeparateImages] KEEP ignore_js_op with attachment: " + attachLinks.first().outerHtml().substring(0, Math.min(200, attachLinks.first().outerHtml().length())));
                }
            }
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_ATTACH", "[extractAndSeparateImages] ignore_js_op total=" + doc.select("ignore_js_op").size() + " kept with attachments=" + keptIgnoreOps);
            
            // ★ 移除所有元素中仅含 "border=" 等残留属性文字的标签（Discuz! 遗留的畸形属性文本）
            // 注意：Jsoup CSS选择器不支持正则中的 ["'] 字符类，需用Java迭代代替
            for (org.jsoup.nodes.Element el : doc.select("*").toArray(new org.jsoup.nodes.Element[0])) {
                String ownText = el.ownText();
                if (ownText.matches("^border\\s*=\\s*[\"']?\\d.*")) {
                    el.remove();
                }
            }
            
            // ★ 智能处理图片：与 ReplyAdapter.extractImagesFromHtml 逻辑一致
            // - 表情/小图标 → 保留在原文内联位置（不提取到底部列表）
            // - [attachimg] 转换的图片（带 data-mt-inline 标记）→ 保留在原文内联位置
            // - 真实图片文件（.jpg/.png/.gif/.webp 或路径含 data/attachment/ /forum/）→ 保留在原文内联位置
            // - 网页端插入的图片（非以上类型）→ 从正文移除，显示在底部图片列表
            // ★ 必须用 toArray() 遍历，否则在循环中修改 DOM 会影响迭代器
            org.jsoup.nodes.Element[] imgs = doc.select("img").toArray(new org.jsoup.nodes.Element[0]);
            for (org.jsoup.nodes.Element img : imgs) {
                // 按优先级获取图片URL：file > comiis_loadimages > data-original > data-src > src
                String realUrl = null;
                if (img.hasAttr("file") && !TextUtils.isEmpty(img.attr("file")))
                    realUrl = img.attr("file");
                else if (img.hasAttr("comiis_loadimages") && !TextUtils.isEmpty(img.attr("comiis_loadimages")))
                    realUrl = img.attr("comiis_loadimages");
                else if (img.hasAttr("data-original") && !TextUtils.isEmpty(img.attr("data-original")))
                    realUrl = img.attr("data-original");
                else if (img.hasAttr("data-src") && !TextUtils.isEmpty(img.attr("data-src")))
                    realUrl = img.attr("data-src");
                else if (img.hasAttr("data-file") && !TextUtils.isEmpty(img.attr("data-file")))
                    realUrl = img.attr("data-file");
                else if (img.hasAttr("src") && !TextUtils.isEmpty(img.attr("src")))
                    realUrl = img.attr("src");
                
                if (realUrl == null || realUrl.isEmpty()) {
                    img.remove();
                    continue;
                }
                String fullUrl = normalizeImageUrl(realUrl);
                if (fullUrl == null) {
                    img.remove();
                    continue;
                }
                String lowerUrl = fullUrl.toLowerCase(java.util.Locale.ROOT);

                // 判断是否为表情/小图标
                boolean inlineImage = lowerUrl.contains("smiley") || lowerUrl.contains("emoticon")
                        || lowerUrl.contains("face") || lowerUrl.contains("/static/image/smiley")
                        || lowerUrl.contains("stamp") || lowerUrl.contains("magic")
                        || lowerUrl.contains("mini") || lowerUrl.contains("icon")
                        || lowerUrl.contains("none.gif") || lowerUrl.contains("common_");

                // ★ 优先检查 data-mt-inline 标记（[attachimg] 转换的图片）
                boolean mtInline = img.hasAttr("data-mt-inline");

                // ★ 判断是否为真实图片文件 URL
                boolean realImageFile = !inlineImage
                        && (lowerUrl.matches(".*\\.(jpe?g|png|gif|webp|bmp)(\\?.*)?$")
                        || lowerUrl.contains("data/attachment/")
                        || lowerUrl.contains("/forum/"));

                // ★ 网页端插入的图片（非内联、非真实图片文件）→ 从正文移除到底部列表
                boolean webUploaded = !mtInline && !realImageFile;

                if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_IMG_DBG", "[extractAndSeparateImages] img url=" + fullUrl
                    + " inlineImage=" + inlineImage + " mtInline=" + mtInline
                    + " realImageFile=" + realImageFile + " webUploaded=" + webUploaded
                    + " modImage=" + lowerUrl.contains("mod=image"));

                if (inlineImage) {
                    // 表情/小图标 → 保留在原文，统一 src
                    img.attr("src", fullUrl);
                    // 移除懒加载属性
                    img.removeAttr("file");
                    img.removeAttr("zoomfile");
                    img.removeAttr("comiis_loadimages");
                    img.removeAttr("data-original");
                    img.removeAttr("data-src");
                    img.removeAttr("data-file");
                } else if (mtInline || lowerUrl.contains("mod=image") || realImageFile) {
                    // ★ 内联图片 / 附件图 / 真实图片文件 → 保留在原文内联位置
                    // 统一 src，移除懒加载属性
                    img.attr("src", fullUrl.replace("&", "&amp;"));
                    img.removeAttr("file");
                    img.removeAttr("zoomfile");
                    img.removeAttr("comiis_loadimages");
                    img.removeAttr("data-original");
                    img.removeAttr("data-src");
                    img.removeAttr("data-file");
                    img.removeAttr("data-mt-inline");
                    // 包 <a> 便于点击放大
                    String hrefEscaped = fullUrl.replace("&", "&amp;");
                    org.jsoup.nodes.Element parent = img.parent();
                    if (parent != null && parent.tagName().equals("a")) {
                        // 已在 <a> 中，不重复包裹
                    } else {
                        org.jsoup.nodes.Element anchor = doc.createElement("a");
                        anchor.attr("href", hrefEscaped);
                        img.replaceWith(anchor);
                        anchor.appendChild(img);
                    }
                } else if (webUploaded) {
                    // ★ 网页端插入的图片（飞书网盘、外部图床等无扩展名URL）→ 保留在原文内联位置
                    //   不再移到底部图片列表，避免图片脱离上下文
                    img.attr("src", fullUrl.replace("&", "&amp;"));
                    img.removeAttr("file");
                    img.removeAttr("zoomfile");
                    img.removeAttr("comiis_loadimages");
                    img.removeAttr("data-original");
                    img.removeAttr("data-src");
                    img.removeAttr("data-file");
                    String hrefEscaped = fullUrl.replace("&", "&amp;");
                    org.jsoup.nodes.Element parent = img.parent();
                    if (parent != null && parent.tagName().equals("a")) {
                        // 已在 <a> 中，不重复包裹
                    } else {
                        org.jsoup.nodes.Element anchor = doc.createElement("a");
                        anchor.attr("href", hrefEscaped);
                        img.replaceWith(anchor);
                        anchor.appendChild(img);
                    }
                } else {
                    // 兜底：保留在原文（避免丢失）
                    img.attr("src", fullUrl.replace("&", "&amp;"));
                }
            }
            
            // ★ 二次清理：用正则移除任何暴露为纯文本的 replyload JS 片段
            String cleanedText = doc.body().html();
            // 保护 ATTACH_CARD / HIDDEN_CARD / QUOTE_CARD / CODE_CARD 占位符：
            // Jsoup 二次解析会丢失 HTML 注释，先替换为文本标记
            java.util.List<String> savedAttachPlaceholders = new java.util.ArrayList<>();
            java.util.regex.Matcher attachPm = java.util.regex.Pattern.compile("<!--ATTACH_CARD_(\\d+)-->").matcher(cleanedText);
            int attachPmIdx = 0;
            while (attachPm.find()) {
                savedAttachPlaceholders.add(attachPm.group(0));
                cleanedText = cleanedText.replace(attachPm.group(0), "@@ATTACHCARD" + attachPm.group(1) + "@@");
                attachPmIdx++;
            }
            // 同样保护 HIDDEN_CARD 占位符
            java.util.List<String> savedHiddenPlaceholders = new java.util.ArrayList<>();
            java.util.regex.Matcher hiddenPm = java.util.regex.Pattern.compile("<!--HIDDEN_CARD_(\\d+)-->").matcher(cleanedText);
            int hiddenPmIdx = 0;
            while (hiddenPm.find()) {
                savedHiddenPlaceholders.add(hiddenPm.group(0));
                cleanedText = cleanedText.replace(hiddenPm.group(0), "@@HIDDENCARD" + hiddenPm.group(1) + "@@");
                hiddenPmIdx++;
            }
            // 同样保护 QUOTE_CARD 占位符
            java.util.List<String> savedQuotePlaceholders = new java.util.ArrayList<>();
            java.util.regex.Matcher quotePm = java.util.regex.Pattern.compile("<!--QUOTE_CARD_(\\d+)-->").matcher(cleanedText);
            int quotePmIdx = 0;
            while (quotePm.find()) {
                savedQuotePlaceholders.add(quotePm.group(0));
                cleanedText = cleanedText.replace(quotePm.group(0), "@@QUOTECARD" + quotePm.group(1) + "@@");
                quotePmIdx++;
            }
            // 同样保护 CODE_CARD 占位符
            java.util.List<String> savedCodePlaceholders = new java.util.ArrayList<>();
            java.util.regex.Matcher codePm = java.util.regex.Pattern.compile("<!--CODE_CARD_(\\d+)-->").matcher(cleanedText);
            int codePmIdx = 0;
            while (codePm.find()) {
                savedCodePlaceholders.add(codePm.group(0));
                cleanedText = cleanedText.replace(codePm.group(0), "@@CODECARD" + codePm.group(1) + "@@");
                codePmIdx++;
            }
            cleanedText = cleanedText.replaceAll("(?i)replyload\\s*\\+?\\s*=\\s*'[^']*'", "");
            cleanedText = cleanedText.replaceAll("(?i)replyload\\s*\\+?\\s*=\\s*\"[^\"]*\"", "");
            cleanedText = cleanedText.replaceAll("(?i)replyload\\s*\\+?\\s*=\\s*[^;\\s<]+", "");
            // 清理单个 border="0" alt="" 等孤立属性字符串
            cleanedText = cleanedText.replaceAll("\\s+border\\s*=\\s*[\"'][^\"']*[\"']", "");
            cleanedText = cleanedText.replaceAll("\\s+alt\\s*=\\s*[\"'][^\"']*[\"']", "");
            // ★ 修复：Jsoup 1.17.2 的 :empty 伪类有 bug（div:empty 错误匹配有子元素的 div）
            // 改用 childNodes().isEmpty() 手动迭代检查，避免误删内容
            org.jsoup.nodes.Document cleanDoc = org.jsoup.Jsoup.parse(cleanedText);
            cleanDoc.outputSettings().prettyPrint(false);
            boolean changed;
            do {
                changed = false;
                for (org.jsoup.nodes.Element el : cleanDoc.select("b, i, u, s, font, span, div, p").toArray(new org.jsoup.nodes.Element[0])) {
                    if (el.childNodes().isEmpty()) {
                        el.remove();
                        changed = true;
                    }
                }
            } while (changed);
            cleanedText = cleanDoc.body().html();
            // 恢复所有占位符
            java.util.regex.Matcher restorePm = java.util.regex.Pattern.compile("@@ATTACHCARD(\\d+)@@").matcher(cleanedText);
            java.lang.StringBuffer sb = new java.lang.StringBuffer();
            while (restorePm.find()) {
                restorePm.appendReplacement(sb, "<!--ATTACH_CARD_" + restorePm.group(1) + "-->");
            }
            restorePm.appendTail(sb);
            cleanedText = sb.toString();
            // 恢复 HIDDEN_CARD
            cleanedText = cleanedText.replaceAll("@@HIDDENCARD(\\d+)@@", "<!--HIDDEN_CARD_$1-->");
            // 恢复 QUOTE_CARD
            cleanedText = cleanedText.replaceAll("@@QUOTECARD(\\d+)@@", "<!--QUOTE_CARD_$1-->");
            // 恢复 CODE_CARD
            cleanedText = cleanedText.replaceAll("@@CODECARD(\\d+)@@", "<!--CODE_CARD_$1-->");
            // 只解码 &amp; 和 &quot;；不解码 &lt; &gt;——否则会把正文里作为文字
            // 讨论的 "&lt;pre&gt;" 变成真实 <pre> 标签，导致误渲染为代码块。
            // &lt; &gt; 交给 Html.fromHtml 自动解码显示为 < > 字符即可。
            // 原样保留 HTML 实体，由最终 Html.fromHtml 统一解码一次
            return cleanedText;
        } catch (Exception e) {
            // Jsoup 解析失败时回退到原来方案
            return fallbackExtractImages(html, imageUrls);
        }
    }

    /**
     * 备用方案：当 Jsoup 解析失败时使用正则处理
     */
    private String fallbackExtractImages(String html, List<String> imageUrls) {
        // 先移除 <script>...</script> 和 <style>...</style>
        String cleaned = html.replaceAll("(?i)<script[^>]*>.*?</script>", "");
        cleaned = cleaned.replaceAll("(?i)<style[^>]*>.*?</style>", "");
        
        // 匹配所有含 file/comiis_loadimages/data-original/data-src/data-file/src 属性的 img 标签
        Pattern imgPattern = Pattern.compile(
                "<img[^>]*(?:file|comiis_loadimages|data-original|data-src|data-file|src)=[\"']([^\"']+)[\"']",
                Pattern.CASE_INSENSITIVE);
        Matcher matcher = imgPattern.matcher(cleaned);
        while (matcher.find()) {
            String url = matcher.group(1);
            String fullUrl = normalizeImageUrl(url);
            if (fullUrl != null && !fullUrl.contains("smiley") && !fullUrl.contains("face")
                    && !fullUrl.contains("emoticon") && !fullUrl.contains("icon")
                    && !fullUrl.contains("none.gif") && !fullUrl.contains("common_")) {
                if (!imageUrls.contains(fullUrl)) imageUrls.add(fullUrl);
            }
        }
        
        // 移除所有 img 标签
        cleaned = cleaned.replaceAll("(?i)<img[^>]*>", "");
        return cleaned;
    }

    /**
     * 统一图片URL补全：处理 // / ./ 和纯相对路径
     */
    private static String normalizeImageUrl(String url) {
        if (TextUtils.isEmpty(url)) return null;
        if (url.startsWith("//")) return "https:" + url;
        if (url.startsWith("/")) return HttpClient.BASE_URL + url.substring(1);
        if (url.startsWith("./")) return HttpClient.BASE_URL + url.substring(2);
        if (url.startsWith("http://") || url.startsWith("https://")) return url;
        // 纯相对路径如 "data/attachment/..."
        return HttpClient.BASE_URL + url;
    }

    /**
     * ★ 性能优化：从 HTML 中提取大图（非表情），替换为 @@IMGCARDN@@ 文本标记。
     * 这样 Html.fromHtml 只渲染文字+表情（快速），大图由 renderContentWithInlineTables
     * 作为独立 ImageView 渲染（Glide 异步加载），消除二次渲染。
     *
     * @param html            原始 HTML（已经过 extractAndSeparateImages 处理）
     * @param inlineImageUrls 收集大图URL的列表（按出现顺序）
     * @return 处理后的 HTML（大图被替换为 @@IMGCARDN@@ 标记）
     */
    private String extractInlineImagesFromHtml(String html, List<String> inlineImageUrls) {
        if (TextUtils.isEmpty(html)) return html;
        inlineImageUrls.clear();
        java.util.regex.Pattern imgPattern = java.util.regex.Pattern.compile(
                "<img\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Matcher m = imgPattern.matcher(html);
        java.util.regex.Pattern srcPattern = java.util.regex.Pattern.compile(
                "\\bsrc\\s*=\\s*\"([^\"]+)\"", java.util.regex.Pattern.CASE_INSENSITIVE);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String imgTag = m.group();
            // 提取 src
            java.util.regex.Matcher sm = srcPattern.matcher(imgTag);
            if (!sm.find()) {
                m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(imgTag));
                continue;
            }
            String rawUrl = sm.group(1);
            // 跳过表格占位符
            if (rawUrl != null && rawUrl.startsWith("table://")) {
                m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(imgTag));
                continue;
            }
            String fullUrl = normalizeImageUrl(rawUrl);
            if (fullUrl == null) {
                m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(imgTag));
                continue;
            }
            String urlLower = fullUrl.toLowerCase(java.util.Locale.ROOT);
            // 跳过表情/小图标（保持内联渲染）
            boolean isSmiley = urlLower.contains("smiley") || urlLower.contains("emoticon")
                    || urlLower.contains("/static/image/");
            if (isSmiley) {
                m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(imgTag));
                continue;
            }
            // 大图：替换为文本标记，由 renderContentWithInlineTables 渲染为独立 ImageView
            int idx = inlineImageUrls.size();
            inlineImageUrls.add(fullUrl.replace("&amp;", "&"));
            m.appendReplacement(sb, "@@IMGCARD" + idx + "@@");
        }
        m.appendTail(sb);
        String result = sb.toString();
        if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_PRELOAD", "[extractInlineImages] extracted " + inlineImageUrls.size()
                + " inline images, htmlLen " + html.length() + " -> " + result.length());
        return result;
    }
    /**
     * 为 TextView 设置可点击链接。
     * 增强链接识别能力，同时保留文本长按复制功能。
     */
    /**
     * 为帖子内容中的"编辑时间"文字（"本帖最后由…编辑"）应用自定义颜色。
     * 在 setupClickableLinks 之后调用。
     */
    private void applyEditTimeColor(TextView textView) {
        if (textView == null) return;
        int editTimeColor = com.forum.MT.ui.widget.HomeBarColorManager.getEditTimeColor();
        try {
            CharSequence text = textView.getText();
            if (!(text instanceof Spannable)) return;
            Spannable spannable = (Spannable) text;
            String fullText = spannable.toString();
            // 匹配 "本帖最后由" 后到 "编辑" 之间的内容
            int startIdx = fullText.indexOf("本帖最后由");
            if (startIdx < 0) return;
            // 找到从 startIdx 开始第一个 "编辑" 的位置来算结束
            int endIdx = fullText.indexOf("编辑", startIdx);
            if (endIdx < 0) return;
            endIdx += "编辑".length(); // 包含"编辑"两字
            // ★ 应用"显示大小-编辑时间"字号（默认 0 = 跟随容器不覆盖）
            float editTimeSize = com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(this,
                    com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_EDIT_TIME);
            if (editTimeSize > 0) {
                android.text.style.AbsoluteSizeSpan[] sizeSpans = spannable.getSpans(
                        startIdx, endIdx, android.text.style.AbsoluteSizeSpan.class);
                for (android.text.style.AbsoluteSizeSpan old : sizeSpans) {
                    spannable.removeSpan(old);
                }
                spannable.setSpan(new android.text.style.AbsoluteSizeSpan(
                                (int) (editTimeSize * getResources().getDisplayMetrics().scaledDensity)),
                        startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            // 清除已有的前景色span
            if (editTimeColor != 0) {
                android.text.style.ForegroundColorSpan[] oldSpans = spannable.getSpans(
                        startIdx, endIdx, android.text.style.ForegroundColorSpan.class);
                for (android.text.style.ForegroundColorSpan old : oldSpans) {
                    spannable.removeSpan(old);
                }
                spannable.setSpan(new android.text.style.ForegroundColorSpan(editTimeColor),
                        startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        } catch (Exception ignored) {
            // 安全兜底
        }
    }

    private void setupClickableLinks(TextView textView) {
        if (textView == null) return;
        
        // ★ 启用文本选择（允许长按复制），与自定义 LinkMovementMethod 配合使用
        textView.setTextIsSelectable(true);
        textView.setFocusable(true);
        textView.setClickable(true);
        textView.setLongClickable(true);
        textView.setHighlightColor(0x332196F3);

        CharSequence value = textView.getText();
        Spannable spannable;
        if (value instanceof Spannable) {
            spannable = (Spannable) value;
        } else {
            spannable = new SpannableString(value == null ? "" : value);
            textView.setText(spannable, TextView.BufferType.SPANNABLE);
        }

        // ★ 修复：更精确的URL正则，避免匹配到URL后面的中文/标点
        // 协议前缀 + 域名部分（字母数字.-） + 路径部分
        // 修复点1：Android 的 \w 默认匹配 Unicode 字母（含中文），导致 (?<![\w]) 在中文字符后阻止 URL 匹配。
        //          改用 [a-zA-Z0-9_] 显式 ASCII 字符集。
        // 修复点2：原正则域名部分使用 [\w\-.]++ 后又重复要求 (?:\.[\w\-]++)+，
        //          导致含有多个点的域名（如 bbs.binmt.cc）整体匹配失败，链接无法渲染。
        Pattern urlPattern = Pattern.compile(
            "(?<![a-zA-Z0-9_])" +                          // 前面不是ASCII单词字符（Android \w含中文，改用显式ASCII）
            "(?:" +
                "https?://" +                               // http:// 或 https://
                "[a-zA-Z0-9.\\-]+" +                       // 域名（ASCII字母数字、中划线、点）
                "(?::\\d+)?" +                              // 可选端口 :8080
                "(?:/[a-zA-Z0-9\\-._/?=&%#@+~:]*)" +        // 可选路径
                "|" +
                "https?://" +                               // http:// 或 https://（无路径时）
                "[a-zA-Z0-9.\\-]+" +
                "(?::\\d+)?" +
                "|" +
                "www\\." +                                  // www. 开头（无协议时）
                "[a-zA-Z0-9.\\-]+" +
                "(?::\\d+)?" +
                "(?:/[a-zA-Z0-9\\-._/?=&%#@+~:]*)" +
                "|" +
                "www\\." +                                  // www. 开头（无路径时）
                "[a-zA-Z0-9.\\-]+" +
                "(?::\\d+)?" +
            ")" +
            "(?![a-zA-Z0-9_/])" +                           // 后面不是ASCII单词字符或斜杠
            "(?<![,.;:!?)\\]>'\u201d\u201c])",      // 后面不是标点/引号
            Pattern.CASE_INSENSITIVE
        );
        
        FixNestedScrollLinkMovementMethod.matcherLinkify(
            spannable, 
            urlPattern, 
            url -> normalizeLinkUrl(url),  // URL处理器：规范化URL
            url -> openContentLink(url)    // 点击处理器：打开链接
        );
        {
            android.text.style.ClickableSpan[] spans = spannable.getSpans(0, spannable.length(), android.text.style.ClickableSpan.class);
        }

        // Html.fromHtml() 产生 URLSpan；统一替换为应用自己的 ClickableSpan。
        // ★ 修复：当 <a> 标签文本包含非 URL 前缀（如"成品链接：https://..."）时，
        //   URLSpan 覆盖整个文本，直接替换会导致前缀也变成链接。
        //   解决：在 URLSpan 范围内用正则定位真实 URL，只对 URL 部分添加 ClickableSpan。
        URLSpan[] urlSpans = spannable.getSpans(0, spannable.length(), URLSpan.class);
        for (URLSpan oldSpan : urlSpans) {
            final String targetUrl = normalizeLinkUrl(oldSpan.getURL());
            int start = spannable.getSpanStart(oldSpan);
            int end = spannable.getSpanEnd(oldSpan);
            int flags = spannable.getSpanFlags(oldSpan);
            spannable.removeSpan(oldSpan);
            if (start >= 0 && end > start && !TextUtils.isEmpty(targetUrl)) {
                // 在 URLSpan 文本范围内查找真实 URL 的位置
                String spanText = spannable.subSequence(start, end).toString();
                java.util.regex.Matcher urlMatcher = urlPattern.matcher(spanText);
                if (urlMatcher.find()) {
                    // URL 在 spanText 中的位置
                    int urlStartInSpan = urlMatcher.start();
                    int urlEndInSpan = urlMatcher.end();
                    // 只对 URL 部分添加 ClickableSpan
                    spannable.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(View widget) {
                            openContentLink(targetUrl);
                        }
                    }, start + urlStartInSpan, start + urlEndInSpan, flags);
                } else {
                    // spanText 不含可识别 URL（如纯文字链接文本），整段添加
                    spannable.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(View widget) {
                            openContentLink(targetUrl);
                        }
                    }, start, end, flags);
                }
            }
        }

        // 使用自定义LinkMovementMethod解决NestedScrollView兼容性问题
        textView.setMovementMethod(new FixNestedScrollLinkMovementMethod());
        textView.setAutoLinkMask(0);
        // ★ 启动内联 GIF 动画（setText 已完成，callback 已设置）
        // 与 ReplyAdapter.setupClickableLinks 保持一致，修复主帖动态表情不播放的问题
        startGifAnimationsInTextView(textView);
    }


    /**
     * ★ 复制 Drawable（通过 ConstantState.newDrawable），避免多个 ImageSpan 共享同一 GifDrawable 实例。
     */
    private static android.graphics.drawable.Drawable copyDrawable(android.graphics.drawable.Drawable src) {
        if (src == null) return null;
        android.graphics.drawable.Drawable.ConstantState cs = src.getConstantState();
        if (cs != null) {
            android.graphics.drawable.Drawable copy = cs.newDrawable();
            copy.setBounds(src.getBounds());
            return copy;
        }
        return src;
    }

    /**
     * ★ 判断 Drawable 是否为 Glide 的 GifDrawable
     */
    private static boolean isGifDrawable(android.graphics.drawable.Drawable d) {
        if (d == null) return false;
        String name = d.getClass().getName();
        return name != null && name.contains("GifDrawable");
    }

    /**
     * 用原始 GIF 字节解码真正独立的动画 Drawable。
     * 优先使用 Android 原生 ImageDecoder（AnimatedImageDrawable），失败时再退回 Glide.asGif + 唯一 signature。
     */
    private android.graphics.drawable.Drawable decodeIndependentGifDrawable(String cacheKey, byte[] gifBytes, TextView textView) {
        if (gifBytes == null || gifBytes.length == 0) return null;
        int maxSize = dpToPx(24);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            try {
                byte[] localBytes = java.util.Arrays.copyOf(gifBytes, gifBytes.length);
                android.graphics.ImageDecoder.Source src = android.graphics.ImageDecoder.createSource(
                        java.nio.ByteBuffer.wrap(localBytes));
                android.graphics.drawable.Drawable decoded = android.graphics.ImageDecoder.decodeDrawable(src,
                        (decoder, info, source) -> {
                            android.util.Size size = info.getSize();
                            int w = Math.max(1, size.getWidth());
                            int h = Math.max(1, size.getHeight());
                            int tw;
                            int th;
                            if (w > maxSize || h > maxSize) {
                                float ratio = (float) maxSize / Math.max(w, h);
                                tw = Math.max(1, Math.round(w * ratio));
                                th = Math.max(1, Math.round(h * ratio));
                            } else {
                                tw = Math.max(w, 16);
                                th = Math.max(h, 16);
                            }
                            decoder.setTargetSize(tw, th);
                        });
                if (decoded != null) {
                    int w = Math.max(decoded.getIntrinsicWidth(), 16);
                    int h = Math.max(decoded.getIntrinsicHeight(), 16);
                    decoded.setBounds(0, 0, w, h);

                    return decoded;
                }
            } catch (Exception e) {
                android.util.Log.e("MT_MAIN_GIF", "ImageDecoder GIF failed: " + cacheKey, e);
            }
        }

        try {
            byte[] localBytes = java.util.Arrays.copyOf(gifBytes, gifBytes.length);
            android.graphics.drawable.Drawable fresh = com.bumptech.glide.Glide.with(this)
                    .asGif()
                    .load(localBytes)
                    .skipMemoryCache(true)
                    .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                    .signature(new com.bumptech.glide.signature.ObjectKey(cacheKey + "#" + System.nanoTime()))
                    .submit()
                    .get();
            if (fresh != null) {
                int w = fresh.getIntrinsicWidth();
                int h = fresh.getIntrinsicHeight();
                if (w > maxSize || h > maxSize) {
                    float ratio = (float) maxSize / Math.max(w, h);
                    w = Math.max(1, Math.round(w * ratio));
                    h = Math.max(1, Math.round(h * ratio));
                } else {
                    w = Math.max(w, 16);
                    h = Math.max(h, 16);
                }
                fresh.setBounds(0, 0, w, h);
                return fresh;
            }
        } catch (Exception e) {
            android.util.Log.e("MT_MAIN_GIF", "Glide GIF decode failed: " + cacheKey, e);
        }
        return null;
    }

    /**
     * ★ 为 GIF 表情获取完全独立的动画 Drawable。
     * 先从字节缓存读取；未命中则同步下载文件字节并缓存，再独立解码。
     */
    private android.graphics.drawable.Drawable getIndependentGifDrawable(String url, TextView textView) {
        String normUrl = url == null ? null : url.replace("&amp;", "&");
        if (TextUtils.isEmpty(normUrl)) return null;

        byte[] gifBytes = com.forum.MT.ui.detail.ReplyAdapter.sGifBytesCache.get(normUrl);
        if (gifBytes == null && !normUrl.equals(url)) {
            gifBytes = com.forum.MT.ui.detail.ReplyAdapter.sGifBytesCache.get(url);
        }
        if (gifBytes == null) {
            try {
                java.io.File gifFile = com.bumptech.glide.Glide.with(this)
                        .asFile()
                        .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(normUrl))
                        .submit()
                        .get();
                if (gifFile != null && gifFile.exists()) {
                    gifBytes = java.nio.file.Files.readAllBytes(gifFile.toPath());
                    if (gifBytes != null && gifBytes.length > 0) {
                        com.forum.MT.ui.detail.ReplyAdapter.sGifBytesCache.put(normUrl, gifBytes);
                        if (!normUrl.equals(url)) {
                            com.forum.MT.ui.detail.ReplyAdapter.sGifBytesCache.put(url, gifBytes);
                        }

                    }
                }
            } catch (Exception e) {
                android.util.Log.e("MT_MAIN_GIF", "load GIF bytes on demand failed: " + normUrl, e);
            }
        }
        return decodeIndependentGifDrawable(normUrl, gifBytes, textView);
    }

    /**
     * ★ 如果 drawable 是 Glide 的 GifDrawable，调用 start() 启动动画。
     * GifDrawable 通过 newDrawable() 复制后默认不自动播放，必须显式 start()。
     * 同时需要 setVisible(true) 让 GifDrawable 的帧回调生效。
     */
    private static void startGifIfNeeded(android.graphics.drawable.Drawable drawable) {
        if (drawable == null) return;
        startGifDrawableInternal(drawable, null);
    }

    /**
     * ★ 遍历 TextView 文本中的所有 ImageSpan，找到 GifDrawable 并启动动画。
     * 必须在 setText() 之后调用——此时 TextView 已为 drawable 设置了 callback，
     * GifDrawable 的帧调度才能通过 invalidateSelf() → callback.invalidateDrawable() 触发重绘。
     */
    private static void startGifAnimationsInTextView(TextView textView) {
        if (textView == null) return;
        CharSequence text = textView.getText();
        if (!(text instanceof android.text.Spannable)) return;
        android.text.Spannable spannable = (android.text.Spannable) text;
        android.text.style.ImageSpan[] imageSpans = spannable.getSpans(0, spannable.length(),
                android.text.style.ImageSpan.class);
        for (android.text.style.ImageSpan span : imageSpans) {
            android.graphics.drawable.Drawable d = span.getDrawable();
            startGifDrawableInternal(d, textView);
        }
    }

    /**
     * 内部方法：检测 GifDrawable 并启动动画，设置 callback。
     * ★ 关键修复：TextView 的 verifyDrawable() 只检查 compound drawable，
     *   不检查 ImageSpan 的 drawable，所以 GifDrawable.invalidateSelf() 调用
     *   callback.invalidateDrawable() 时 TextView 不会重绘。
     *   解决方案：用自定义 Callback 包装，直接调用 textView.invalidate()。
     * @param drawable 要检测的 drawable
     * @param callback 宿主 TextView（为 null 时不设置 callback，仅 start）
     */
    private static void startGifDrawableInternal(android.graphics.drawable.Drawable drawable,
                                                   TextView callback) {
        if (drawable == null) return;
        String className = drawable.getClass().getName();
        boolean isGlideGif = className != null && className.contains("GifDrawable");
        boolean isAnimatedImage = drawable instanceof android.graphics.drawable.Animatable
                && className != null && className.contains("AnimatedImageDrawable");
        if (!isGlideGif && !isAnimatedImage) return;
        try {
            // ★ 关键：设置自定义 callback，绕过 TextView.verifyDrawable() 的限制
            if (callback != null) {
                drawable.setCallback(new android.graphics.drawable.Drawable.Callback() {
                    @Override
                    public void invalidateDrawable(android.graphics.drawable.Drawable who) {
                        callback.invalidate();
                    }
                    @Override
                    public void scheduleDrawable(android.graphics.drawable.Drawable who, Runnable what, long when) {
                        long delay = Math.max(0L, when - android.os.SystemClock.uptimeMillis());
                        callback.postDelayed(what, delay);
                    }
                    @Override
                    public void unscheduleDrawable(android.graphics.drawable.Drawable who, Runnable what) {
                        callback.removeCallbacks(what);
                    }
                });
            }
            try {
                java.lang.reflect.Method setVisible = drawable.getClass().getMethod("setVisible", boolean.class, boolean.class);
                setVisible.invoke(drawable, true, false);
            } catch (Exception ignore) {
            }
            if (drawable instanceof android.graphics.drawable.Animatable) {
                ((android.graphics.drawable.Animatable) drawable).start();
            } else {
                java.lang.reflect.Method start = drawable.getClass().getMethod("start");
                start.invoke(drawable);
            }
        } catch (Exception e) {
            android.util.Log.e("MT_MAIN_GIF", "Failed to start animated drawable", e);
        }
    }

    /**
     * ★ 在后台线程下载 GIF 文件并缓存原始字节（主帖表情预加载时调用）。
     * @param url GIF 图片 URL
     */
    private void preloadGifBytesMainThread(String url) {
        if (com.forum.MT.ui.detail.ReplyAdapter.sGifBytesCache.containsKey(url)) return;
        try {
            java.io.File gifFile = com.bumptech.glide.Glide.with(this)
                    .asFile()
                    .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(url))
                    .submit()
                    .get();
            if (gifFile != null && gifFile.exists()) {
                byte[] bytes = java.nio.file.Files.readAllBytes(gifFile.toPath());
                if (bytes != null && bytes.length > 0) {
                    com.forum.MT.ui.detail.ReplyAdapter.sGifBytesCache.put(url, bytes);

                }
            }
        } catch (Exception e) {
            android.util.Log.e("MT_MAIN_GIF", "preloadGifBytes failed: " + url, e);
        }
    }

    private String normalizeLinkUrl(String url) {
        if (TextUtils.isEmpty(url)) return url;
        if (url.startsWith("//")) return "https:" + url;
        if (url.startsWith("/")) return HttpClient.BASE_URL + url.substring(1);
        if (url.startsWith("./")) return HttpClient.BASE_URL + url.substring(2);
        if (url.startsWith("http://") || url.startsWith("https://")) return url;
        if (url.startsWith("www.")) return "http://" + url;
        return HttpClient.BASE_URL + url;
    }

    private void openContentLink(String url) {
        if (TextUtils.isEmpty(url)) return;
        try {
            // 论坛内部链接：应用内跳转，不打开浏览器
            // 1. 用户主页: home.php?mod=space&uid=xxx 或 space-uid-xxx.html
            java.util.regex.Matcher uidMatcher = java.util.regex.Pattern.compile(
                "(?:mod=space&uid=|space-uid-)(\\d+)").matcher(url);
            if (uidMatcher.find()) {
                String uid = uidMatcher.group(1);
                Intent intent = new Intent(this, com.forum.MT.ui.space.UserProfileActivity.class);
                intent.putExtra("uid", uid);
                startActivity(intent);
                return;
            }
            // 2. 帖子链接: thread-xxx-1-1.html 或 forum.php?mod=viewthread&tid=xxx
            java.util.regex.Matcher tidMatcher = java.util.regex.Pattern.compile(
                "(?:thread-(\\d+)|tid=(\\d+))").matcher(url);
            if (tidMatcher.find()) {
                String tid = tidMatcher.group(1) != null ? tidMatcher.group(1) : tidMatcher.group(2);
                Intent intent = new Intent(this, ThreadDetailActivity.class);
                intent.putExtra("tid", tid);
                startActivity(intent);
                return;
            }
            // 3. 其他链接：用浏览器打开
            Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(browser);
        } catch (Exception e) {
            Toast.makeText(this, "没有可用的浏览器", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidUploadUid(String uid) {
        if (TextUtils.isEmpty(uid)) return false;
        try {
            return Long.parseLong(uid) > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void applyServerActionState(PostDetail detail) {
        if (detail == null) return;
        if (detail.isLikedStateKnown()) {
            isLiked = detail.isLiked();
            saveLikedState(isLiked);
        } else {
            isLiked = restoreLikedState();
        }
        if (detail.isFavoritedStateKnown()) {
            isFavorited = detail.isFavorited();
            saveFavoritedState(isFavorited);
        } else {
            isFavorited = restoreFavoritedState();
        }
    }

    private boolean syncFavoriteStateFromServer(PostDetail detail) {
        if (detail == null || TextUtils.isEmpty(tid) || !httpClient.isLoggedIn()) return false;
        try {
            String html = httpClient.get(HttpClient.BASE_URL
                    + "home.php?mod=space&do=favorite&mobile=2&_refresh="
                    + System.currentTimeMillis());
            if (ForumParser.isLoginPage(html)) return false;
            List<com.forum.MT.model.Thread> favorites =
                    ForumParser.parseFavoriteList(html);
            boolean found = false;
            if (favorites != null) {
                for (com.forum.MT.model.Thread item : favorites) {
                    if (item != null && tid.equals(item.getTid())) {
                        found = true;
                        break;
                    }
                }
            }
            detail.setFavorited(found);
            detail.setFavoritedStateKnown(true);
            return true;
        } catch (Exception ignored) {
            // 收藏页请求失败时保留详情页解析结果/本地回退值
            return false;
        }
    }

    // ==================== 图片相关 ====================

    /**
     * 打开图片预览大图
     */
    private void openImagePreview(String url) {
        if (TextUtils.isEmpty(url)) return;
        // ★ 修复：使用内置 ImagePreviewActivity 全屏预览（支持缩放），不再跳转浏览器
        Intent intent = new Intent(this, ImagePreviewActivity.class);
        intent.putExtra("image_url", url);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "无法打开图片", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 图片选择
     */
    private void pickImage() {
        pickMedia.launch(new PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                .build());
    }

    private String getDisplayNameFromUri(Uri uri) {
        if (uri == null) return null;
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri,
                    new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (column >= 0) return cursor.getString(column);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String path = uri.getLastPathSegment();
        return TextUtils.isEmpty(path) ? null : path;
    }

    private String buildUploadFileName(String sourceName, String mimeType) {
        String name = TextUtils.isEmpty(sourceName) ? "" : sourceName
                .replaceAll("[\\\\/:*?\"<>|]", "_");
        // Content URI 的最后一段常是无扩展名的数字 ID。此时根据真实 MIME 补全扩展名。
        if (name.isEmpty() || !name.matches("(?i).*\\.[a-z0-9]{2,5}$")) {
            String extension = extensionFromMimeType(mimeType);
            name = "reply_" + System.currentTimeMillis() + extension;
        }
        return name;
    }

    private String extensionFromMimeType(String mimeType) {
        if ("image/png".equalsIgnoreCase(mimeType)) return ".png";
        if ("image/gif".equalsIgnoreCase(mimeType)) return ".gif";
        if ("image/webp".equalsIgnoreCase(mimeType)) return ".webp";
        if ("image/bmp".equalsIgnoreCase(mimeType)) return ".bmp";
        if ("image/heic".equalsIgnoreCase(mimeType) || "image/heif".equalsIgnoreCase(mimeType)) {
            return ".heic";
        }
        return ".jpg";
    }

    /**
     * 上传并附加图片到回复
     */
    /**
     * 控制回复弹窗内图片按钮的启用状态（底部快捷栏已移除图片按钮）。
     */
    private void setDialogImageButtonEnabled(boolean enabled) {
        runOnUiThread(() -> {
            if (mThreadReplyDialog == null || !mThreadReplyDialog.isShowing()) return;
            View ib = mThreadReplyDialog.findViewById(R.id.btn_dialog_image);
            if (ib != null) ib.setEnabled(enabled);
            ib = mThreadReplyDialog.findViewById(R.id.btn_dialog_send);
            if (ib != null) ib.setEnabled(enabled);
        });
    }

    private void uploadAndAttachImage(Uri imageUri) {
        if (imageUploadInProgress) {
            Toast.makeText(this, "已有图片正在上传，请稍候", Toast.LENGTH_SHORT).show();
            return;
        }
        pendingImageUri = imageUri;
        imageUploadInProgress = true;
        setDialogImageButtonEnabled(false);
        Toast.makeText(this, "正在上传图片...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            File file = null;
            try {
                // 登录可能来自网页容器；上传前仅在本地 Cookie 缺失时同步，避免覆盖有效会话。
                if (!httpClient.isLoggedIn()) httpClient.syncFromCookieManager();
                if (!httpClient.isLoggedIn()) {
                    showUploadError("登录状态已失效，请重新登录");
                    return;
                }

                // 论坛的 swfupload 是老旧服务端：它会按文件头、扩展名、尺寸和大小联合校验。
                // 直接上传相册原始文件即使 MIME 正确，也会因 HEIC/AVIF/特殊 WebP、透明 PNG、
                // 超高分辨率或厂商私有编码而被拒绝。统一解码为尺寸受控的标准 JPEG，
                // 可使原生上传行为稳定地落在该接口支持范围内。
                file = transcodeReplyImageToJpeg(imageUri);
                if (file == null || !file.exists() || file.length() == 0) {
                    showUploadError("无法读取或转换图片文件");
                    return;
                }
                String mimeType = "image/jpeg";

                // 上传令牌只在桌面版发帖页中稳定存在；详情页移动版通常没有 hash。
                String detailHtml = httpClient.getDesktop(ForumParser.getThreadDetailUrl(tid));
                String uid = extractUploadValue(detailHtml, "discuz_uid");
                String hash = extractUploadValue(detailHtml, "hash");
                if (!isValidUploadUid(uid)) uid = null;
                if (TextUtils.isEmpty(uid) || TextUtils.isEmpty(hash)) {
                    String fid = extractForumFid(detailHtml);
                    if (TextUtils.isEmpty(fid)) fid = "39";
                    String postHtml = httpClient.getDesktop(HttpClient.BASE_URL
                            + "forum.php?mod=post&action=newthread&fid=" + fid);
                    if (TextUtils.isEmpty(uid)) uid = extractUploadValue(postHtml, "discuz_uid");
                    if (!isValidUploadUid(uid)) uid = null;
                    if (TextUtils.isEmpty(hash)) hash = extractUploadValue(postHtml, "hash");
                }
                if (!isValidUploadUid(uid) || TextUtils.isEmpty(hash)) {
                    showUploadError("获取图片上传授权失败，请重新登录后重试");
                    return;
                }

                Map<String, String> extra = new HashMap<>();
                extra.put("uid", uid);
                extra.put("hash", hash);
                String url = HttpClient.BASE_URL + "misc.php?mod=swfupload&operation=upload"
                        + "&type=image&inajax=yes&infloat=yes&simple=2";
                String result = httpClient.uploadFileWithUserAgent(url, file, "Filedata", extra,
                        HttpClient.DESKTOP_USER_AGENT, mimeType);
                String aid = parseUploadAid(result);
                if (TextUtils.isEmpty(aid)) {
                    showUploadError(extractUploadError(result));
                    return;
                }

                final String finalAid = aid;
                synchronized (pendingUploadAids) {
                    if (!pendingUploadAids.contains(finalAid)) pendingUploadAids.add(finalAid);
                }
                runOnUiThread(() -> {
                    EditText activeEdit = getActiveReplyEdit();
                    if (activeEdit != null) {
                        String cur = activeEdit.getText() == null ? "" : activeEdit.getText().toString();
                        if (cur.endsWith("\n")) {
                            cur = cur.substring(0, cur.length() - 1);
                        }
                        if (cur.isEmpty()) {
                            activeEdit.append("[attachimg]" + finalAid + "[/attachimg]");
                        } else {
                            activeEdit.append("\n[attachimg]" + finalAid + "[/attachimg]");
                        }
                    } else {
                        binding.etReply.append("\n[attachimg]" + finalAid + "[/attachimg]");
                    }
                    Toast.makeText(this, "图片已上传，发送评论后才会正式关联", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                showUploadError("图片上传失败：" + (TextUtils.isEmpty(e.getMessage())
                        ? "网络异常，请稍后重试" : e.getMessage()));
            } finally {
                if (file != null) file.delete();
                runOnUiThread(() -> {
                    imageUploadInProgress = false;
                    setDialogImageButtonEnabled(true);
                });
            }
        }).start();
    }

    private String extractUploadError(String response) {
        if (TextUtils.isEmpty(response)) return "图片上传失败，服务器未返回结果";
        if (ForumParser.isLoginPage(response) || containsAny(response, "请先登录", "登录")) {
            return "登录状态已失效，请重新登录";
        }
        String text = response.replaceAll("(?s)<[^>]+>", " ").trim();
        if (text.startsWith("DISCUZUPLOAD|")) {
            String[] parts = text.split("\\|", -1);
            if (parts.length > 3) {
                String error = parts[parts.length - 1].trim();
                if (!TextUtils.isEmpty(error) && !error.matches("\\d+")) {
                    return "图片上传失败：" + error;
                }
            }
        }
        return "图片上传失败，请检查图片格式、大小和登录状态";
    }

    private void showUploadError(String message) {
        runOnUiThread(() -> Toast.makeText(ThreadDetailActivity.this,
                message, Toast.LENGTH_SHORT).show());
    }

    private String extractForumFid(String html) {
        if (TextUtils.isEmpty(html)) return null;
        Matcher m = Pattern.compile("(?:forum-|[?&]fid=)(\\d+)").matcher(html);
        return m.find() ? m.group(1) : null;
    }

    private String extractUploadValue(String html, String key) {
        if (TextUtils.isEmpty(html)) return null;
        String quotedKey = Pattern.quote(key);

        // 兼容 JS 变量和对象属性：discuz_uid='123'、hash = "..."、hash:"..."。
        Matcher m = Pattern.compile("(?:var\\s+|\\b)" + quotedKey
                + "\\s*(?:=|:)\\s*['\"]([^'\"]+)['\"]",
                Pattern.CASE_INSENSITIVE).matcher(html);
        if (m.find()) return m.group(1);

        // JSON 风格：\"hash\":\"...\"
        m = Pattern.compile("\\\"" + quotedKey + "\\\"\\s*:\\s*['\"]([^'\"]+)['\"]",
                Pattern.CASE_INSENSITIVE).matcher(html);
        if (m.find()) return m.group(1);

        // Discuz 桌面发帖页通常把 hash 放在隐藏 input 中。
        m = Pattern.compile("<input[^>]+name\\s*=\\s*['\"]" + quotedKey
                + "['\"][^>]+value\\s*=\\s*['\"]([^'\"]+)['\"]",
                Pattern.CASE_INSENSITIVE).matcher(html);
        if (m.find()) return m.group(1);

        m = Pattern.compile("<input[^>]+value\\s*=\\s*['\"]([^'\"]+)['\"][^>]+name\\s*=\\s*['\"]"
                + quotedKey + "['\"]", Pattern.CASE_INSENSITIVE).matcher(html);
        if (m.find()) return m.group(1);

        // 兜底：直接查找形如 ?uid=123&hash=xxx 的参数片段
        m = Pattern.compile("[?&]" + quotedKey + "=([^&\"'<>\\s]+)", Pattern.CASE_INSENSITIVE).matcher(html);
        return m.find() ? m.group(1) : null;
    }

    private String parseUploadAid(String response) {
        if (TextUtils.isEmpty(response)) return null;

        String text = response.trim();
        if (text.isEmpty()) return null;

        // 去掉可能的 HTML 标签（部分场景返回 script/html 混合）
        text = text.replaceAll("(?s)<[^>]+>", "").trim();

        if (text.toUpperCase(java.util.Locale.ROOT).startsWith("DISCUZUPLOAD|")) {
            // 兼容多种返回位次：
            // 1) DISCUZUPLOAD|xxx|0|aid|...（官方注释）
            // 2) DISCUZUPLOAD|0|aid|...（某些站点可能省略一段）
            String[] parts = text.split("\\|", -1);
            if (parts.length >= 4) {
                if ("0".equals(parts[2]) && parts[3].matches("\\d+")) return parts[3];
            }
            if (parts.length >= 3) {
                if ("0".equals(parts[1]) && parts[2].matches("\\d+")) return parts[2];
            }

            Matcher mPipe = Pattern.compile("(?i)DISCUZUPLOAD\\|[^|]*\\|0\\|([^|]+)").matcher(text);
            if (mPipe.find() && mPipe.group(1).matches("\\d+")) return mPipe.group(1);
        }

        // 常见兜底：直接提取 aid/attach 等数值
        Matcher m = Pattern.compile("(?:aid|attach)(?:Id)?[\\s:='\"]+(\\d+)",
                Pattern.CASE_INSENSITIVE).matcher(text);
        if (m.find()) return m.group(1);

        // 兼容 JSON 里返回的附属 id
        Matcher jsonLike = Pattern.compile("\\\"(?:aid|attach)(?:Id)?\\\"\\s*:\\s*(\\d+)",
                Pattern.CASE_INSENSITIVE).matcher(text);
        return jsonLike.find() ? jsonLike.group(1) : null;
    }

    /**
     * 将相册中任意可解码图片规范化为论坛旧 swfupload 接口最兼容的 JPEG。
     *
     * 处理 HEIC/HEIF、AVIF、WebP、PNG 透明通道、厂商相册返回的错误 MIME，且限制最长边和
     * 文件大小，避免服务端的类型、像素或单文件大小限制造成“同图网页可传、App 失败”。
     */
    private File transcodeReplyImageToJpeg(Uri uri) throws Exception {
        if (uri == null) return null;
        final int maxSide = 1920;
        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
        Bitmap decoded = ImageDecoder.decodeBitmap(source, (decoder, info, ignoredSource) -> {
            int width = info.getSize().getWidth();
            int height = info.getSize().getHeight();
            int largest = Math.max(width, height);
            if (largest > maxSide) {
                float scale = maxSide / (float) largest;
                decoder.setTargetSize(Math.max(1, Math.round(width * scale)),
                        Math.max(1, Math.round(height * scale)));
            }
            // 软件位图便于 Canvas 压平透明通道，也避免部分硬件位图无法直接压缩。
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
        });
        if (decoded == null || decoded.getWidth() <= 0 || decoded.getHeight() <= 0) return null;

        Bitmap flattened = Bitmap.createBitmap(decoded.getWidth(), decoded.getHeight(),
                Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(flattened);
        canvas.drawColor(Color.WHITE);
        canvas.drawBitmap(decoded, 0, 0, null);
        if (flattened != decoded) decoded.recycle();

        byte[] jpeg = null;
        // 以 2 MiB 为上限，覆盖大多数 Discuz 站点的默认图片附件限制。
        // 若原图噪点多，逐步降低质量而不是让服务端返回模糊的通用失败提示。
        for (int quality = 88; quality >= 58; quality -= 6) {
            java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
            flattened.compress(Bitmap.CompressFormat.JPEG, quality, output);
            jpeg = output.toByteArray();
            if (jpeg.length <= 2 * 1024 * 1024 || quality == 58) break;
        }
        flattened.recycle();
        if (jpeg == null || jpeg.length == 0) return null;

        File dir = new File(getCacheDir(), "reply_uploads");
        if (!dir.exists() && !dir.mkdirs()) return null;
        File target = new File(dir, "reply_" + System.currentTimeMillis() + ".jpg");
        try (java.io.FileOutputStream output = new java.io.FileOutputStream(target)) {
            output.write(jpeg);
            output.flush();
        }
        return target;
    }

    private File copyUriToTempFile(Uri uri, String fileName) throws Exception {
        File dir = new File(getCacheDir(), "reply_uploads");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, fileName);
        try (java.io.InputStream in = getContentResolver().openInputStream(uri);
             java.io.FileOutputStream out = new java.io.FileOutputStream(file)) {
            if (in == null) return null;
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) != -1) out.write(buffer, 0, len);
        }
        return file;
    }


    /**
     * 分享帖子
     */
    private void shareThread() {
        if (postDetail == null) return;
        String shareText = postDetail.getTitle() + "\n"
                + HttpClient.BASE_URL + "thread-" + tid + "-1-1.html";
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
        startActivity(Intent.createChooser(shareIntent, "分享帖子"));
    }

    // ==================== 赞赏与踢帖 ====================

    /**
     * 显示赞赏金额选择弹窗（自定义CardView卡片样式）
     */
    /**
     * 显示打赏弹窗。
     *
     * @param target 非空时表示打赏某条评论（ReplyItem），为空表示打赏楼主正文。
     */
    private void showRewardDialog(ReplyItem target) {
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }
        String currentUid = UserSessionManager.getInstance().getUid(getApplicationContext());
        String authorUid = target != null ? target.getAuthorUid() : (postDetail != null ? postDetail.getAuthorUid() : null);
        if (!TextUtils.isEmpty(currentUid) && !TextUtils.isEmpty(authorUid)
                && currentUid.equals(authorUid)) {
            Toast.makeText(this, "不能给自己打赏", Toast.LENGTH_SHORT).show();
            return;
        }

        // 创建并配置Dialog
        Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog);
        dialog.setContentView(R.layout.dialog_reward);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        // 绑定控件
        ImageView ivAvatar = dialog.findViewById(R.id.iv_reward_author_avatar);
        TextView tvAuthorName = dialog.findViewById(R.id.tv_reward_author_name);
        TextView tvHint = dialog.findViewById(R.id.tv_reward_hint);
        Spinner spinnerAmount = dialog.findViewById(R.id.spinner_reward_amount);
        Switch switchNotify = dialog.findViewById(R.id.switch_notify_author);
        Button btnSubmit = dialog.findViewById(R.id.btn_submit_reward);

        // 设置作者信息：评论打赏显示评论者，正文打赏显示楼主
        String dialogAuthor = target != null ? target.getAuthor()
                : (postDetail != null ? postDetail.getAuthor() : null);
        String dialogAvatar = target != null ? target.getAvatarUrl()
                : (postDetail != null ? postDetail.getAvatarUrl() : null);
        if (!TextUtils.isEmpty(dialogAuthor)) {
            tvAuthorName.setText(dialogAuthor);
            tvHint.setText("给 " + dialogAuthor + " 打赏鼓励吧");
            if (!TextUtils.isEmpty(dialogAvatar)) {
                Glide.with(this)
                        .load(dialogAvatar)
                        .transform(new CircleCrop())
                        .placeholder(R.drawable.ic_account)
                        .error(R.drawable.ic_account)
                        .into(ivAvatar);
            } else {
                ivAvatar.setImageResource(R.drawable.ic_account);
            }
        }

        // 设置金币选择器
        String[] amounts = {"1", "5", "10", "50", "100"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, amounts);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAmount.setAdapter(adapter);

        // 设置好评选择器
        String[] goodReviews = {"好评", "很棒", "优秀", "给力", "赞"};
        ArrayAdapter<String> goodReviewAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, goodReviews);
        goodReviewAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinnerGoodReview = dialog.findViewById(R.id.spinner_good_review);
        spinnerGoodReview.setAdapter(goodReviewAdapter);

        // 获取鼓励话语输入框
        EditText etRewardMessage = dialog.findViewById(R.id.et_reward_message);

        // 打赏按钮点击事件
        btnSubmit.setOnClickListener(v -> {
            int selectedAmount = Integer.parseInt(amounts[spinnerAmount.getSelectedItemPosition()]);
            boolean notifyAuthor = switchNotify.isChecked();
            String goodReviewText = goodReviews[spinnerGoodReview.getSelectedItemPosition()];
            String message = etRewardMessage.getText().toString().trim();
            dialog.dismiss();
            performReward(selectedAmount, notifyAuthor, goodReviewText, message, target);
        });

        // 点击外部关闭
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
    }

    /**
     * 执行赞赏操作。
     *
     * Discuz! 标准接口实际是 action=rate，不是 action=reward；并且必须同时
     * 传入楼主正文 pid、ratesubmit=yes 以及 score{creditId}。只传 tid/reward
     * 会被 Discuz! 当成“未定义操作”，这是之前一直打赏失败的根因。
     *
     * @param target 非空时打赏该评论（ReplyItem），为空时打赏楼主正文。
     */
    private void performReward(int amount, boolean notifyAuthor, String goodReview, String message, ReplyItem target) {
        new Thread(() -> {
            try {
                if (postDetail == null) throw new IllegalStateException("帖子数据为空");

                // 评论打赏使用评论自己的 pid；楼主打赏使用正文 pid。
                String pid = target != null ? target.getPid() : postDetail.getPostPid();
                if (TextUtils.isEmpty(pid)) {
                    if (target != null) {
                        throw new IllegalStateException("无法获取评论编号");
                    }
                    // 兼容旧缓存/旧解析结果：重新读取页面补齐楼主 pid。
                    String page = httpClient.get(ForumParser.getThreadDetailUrl(tid));
                    PostDetail latest = ForumParser.parseThreadDetail(page);
                    if (latest != null) {
                        pid = latest.getPostPid();
                        if (!TextUtils.isEmpty(latest.getFormhash())) {
                            postDetail.setFormhash(latest.getFormhash());
                        }
                    }
                }
                if (TextUtils.isEmpty(pid)) {
                    throw new IllegalStateException("无法获取帖子正文编号");
                }

                // 本站的“赞赏”实际是 Discuz! 多积分评分：score1=好评，score2=金币。
                // 之前把金额发到 score1，所以网页端只新增“好评 +1”，金币没有增加。
                // showratetip=1 在本站可能返回“暂不支持高级操作”，不能据此推断积分编号。
                String rateForm = "";
                try {
                    String rateUrl = HttpClient.BASE_URL
                            + "forum.php?mod=misc&action=rate&tid=" + tid
                            + "&pid=" + pid + "&showratetip=1&inajax=1&mobile=2";
                    rateForm = httpClient.get(rateUrl);
                } catch (Exception ignored) {
                    // 预览接口失败不影响正式提交。
                }
                String fh = ForumParser.parseFormhash(rateForm);
                if (TextUtils.isEmpty(fh)) fh = postDetail.getFormhash();
                if (TextUtils.isEmpty(fh)) {
                    String page = httpClient.get(ForumParser.getThreadDetailUrl(tid));
                    fh = ForumParser.parseFormhash(page);
                }
                if (TextUtils.isEmpty(fh)) {
                    throw new IllegalStateException("无法获取操作验证");
                }

                Map<String, String> params = new HashMap<>();
                params.put("formhash", fh);
                params.put("tid", tid);
                params.put("pid", pid);
                params.put("ratesubmit", "yes");
                params.put("referer", ForumParser.getThreadDetailUrl(tid));
                // 同一次评分提交 1 个好评和所选数量的金币。
                params.put("score1", "1");
                params.put("score2", String.valueOf(amount));
                String reason = message;
                if (TextUtils.isEmpty(reason)) reason = goodReview;
                else if (!TextUtils.isEmpty(goodReview)) reason = goodReview + "：" + reason;
                if (!TextUtils.isEmpty(reason)) params.put("reason", reason);

                String rewardUrl = HttpClient.BASE_URL
                        + "forum.php?mod=misc&action=rate&tid=" + tid
                        + "&pid=" + pid + "&ratesubmit=yes&inajax=1&mobile=2";
                String result = httpClient.post(rewardUrl, params);
                boolean success = isForumActionResponseSuccessful(result);
                String rewardError = success ? "" : extractRewardError(result);

                runOnUiThread(() -> {
                    if (success) {
                        Toast.makeText(ThreadDetailActivity.this,
                                getString(R.string.reward_success, amount), Toast.LENGTH_SHORT).show();
                        refreshPostDetail();
                    } else {
                        // 不能再把“非空且非登录页”的任意响应当成成功。
                        // Discuz 在 24 小时评分限制、重复评分、积分不足等情况下，
                        // 通常仍返回正常 HTML/脚本页面，之前因此误提示“打赏成功”。
                        Toast.makeText(ThreadDetailActivity.this,
                                TextUtils.isEmpty(rewardError)
                                        ? getString(R.string.reward_failed)
                                        : rewardError,
                                Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(ThreadDetailActivity.this,
                        R.string.reward_failed, Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    /**
     * 仅当 Discuz 返回明确的评分成功标记时才判定成功。
     *
     * 不能使用“不是登录页且没有错误文本”这种宽松规则：Discuz 的评分限制
     * 页面也可能是完整 HTML，若只做排除判断就会被误判为成功。
     */
    private boolean isForumActionResponseSuccessful(String response) {
        if (TextUtils.isEmpty(response) || ForumParser.isLoginPage(response)) return false;
        if (isRewardLimitOrFailure(response)) return false;

        String lower = response.toLowerCase(java.util.Locale.ROOT);
        // Discuz 标准 Ajax 评分成功回调，以及站点可能返回的成功提示。
        return lower.contains("succeedhandle_rate")
                || lower.contains("rate_success")
                || containsAny(response, "评分成功", "打赏成功", "您已成功评分", "评价成功");
    }

    /** 识别 Discuz 评分限制/失败响应。 */
    private boolean isRewardLimitOrFailure(String response) {
        return containsAny(response,
                "24小时", "24 小时", "24hours", "24 hours",
                "每24小时只能评分一次", "每 24 小时只能评分一次",
                "24小时内已经评分", "24 小时内已经评分",
                "您已评价过本主题", "您已经评价过本主题",
                "您已评分过本主题", "您已经评分过本主题",
                "已经评分过", "已经评价过", "重复评分", "评分过本主题",
                "thread_rate_duplicate", "rate_duplicate", "评分失败",
                "评分范围错误", "thread_rate_range_invalid",
                "credit_limit_invalid", "积分不足", "余额不足",
                "提交频率过快", "操作频繁", "暂不支持高级操作",
                "formhash错误", "非法操作", "没有权限", "请先登录",
                "未定义操作", "undefined action", "操作失败");
    }

    /** 从评分接口响应中提取可直接展示给用户的失败原因。 */
    private String extractRewardError(String response) {
        if (TextUtils.isEmpty(response)) return "打赏失败，服务器未返回结果";
        if (ForumParser.isLoginPage(response) || containsAny(response, "请先登录")) {
            return "登录状态已失效，请重新登录";
        }
        if (containsAny(response, "24小时", "24 小时", "24hours", "24 hours",
                "每24小时只能评分一次", "每 24 小时只能评分一次",
                "24小时内已经评分", "24 小时内已经评分",
                "重复评分", "已评价过本主题", "已评分过本主题",
                "已经评分过", "已经评价过", "评分过本主题")) {
            return "24小时内只能对同一帖子评分一次，请稍后再试";
        }
        if (containsAny(response, "积分不足", "余额不足", "credit_limit_invalid")) {
            return "积分余额不足，无法完成打赏";
        }
        if (containsAny(response, "formhash错误", "非法操作")) {
            return "验证已失效，请刷新页面后重试";
        }
        if (containsAny(response, "没有权限", "暂不支持高级操作")) {
            return "当前账号没有评分权限";
        }
        if (containsAny(response, "提交频率过快", "操作频繁")) {
            return "操作过于频繁，请稍后再试";
        }
        return "打赏失败，请重试";
    }

    /*
     * 保留旧方法名位置的说明：评分响应必须有明确成功标记，不能只要不是
     * 登录页就返回 true，否则 24 小时限制会显示成“打赏成功”。
     */
    /*
     * 原 Discuz ajax/showmessage 响应的统一失败判断已由上述评分专用逻辑替代。
     */

    /**
     *

        // 创建并配置Dialog
        Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog);
        dialog.setContentView(R.layout.dialog_kick);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        // 绑定控件
        EditText etReason = dialog.findViewById(R.id.et_kick_reason);
        Button btnClose = dialog.findViewById(R.id.btn_close_kick);
        Button btnSubmit = dialog.findViewById(R.id.btn_submit_kick);

        // 关闭按钮
        btnClose.setOnClickListener(v -> dialog.dismiss());

        // 确定按钮
        btnSubmit.setOnClickListener(v -> {
            String reason = etReason.getText().toString().trim();
            dialog.dismiss();
            submitKickRequest(reason);
        });

        // 点击外部关闭
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
    }

    /**
     * 提交踢帖请求。
     * 踢帖是 Comiis 插件接口，但仍使用 Discuz! 当前页面的 formhash；
     * 不能长期复用详情页旧 hash，否则插件会直接拒绝请求。
     */
    private void submitKickRequest(String reason) {
        new Thread(() -> {
            try {
                String page = httpClient.get(ForumParser.getThreadDetailUrl(tid));
                String fh = ForumParser.parseFormhash(page);
                if (TextUtils.isEmpty(fh) && postDetail != null) fh = postDetail.getFormhash();
                if (TextUtils.isEmpty(fh)) {
                    throw new IllegalStateException("无法获取操作验证");
                }

                String kickUrl = HttpClient.BASE_URL + "plugin.php?id=comiis_app&comiis=kick"
                        + "&tid=" + tid + "&formhash=" + fh
                        + "&inajax=1&mobile=2";
                Map<String, String> params = new HashMap<>();
                params.put("formhash", fh);
                params.put("tid", tid);
                params.put("kick_submit", "yes");
                params.put("inajax", "1");
                if (!TextUtils.isEmpty(reason)) params.put("kick_reason", reason);

                String result = httpClient.post(kickUrl, params);
                boolean success = isForumActionResponseSuccessful(result);

                runOnUiThread(() -> {
                    if (success) {
                        Toast.makeText(ThreadDetailActivity.this,
                                R.string.kick_success, Toast.LENGTH_SHORT).show();
                        refreshPostDetail();
                    } else {
                        Toast.makeText(ThreadDetailActivity.this,
                                R.string.kick_failed, Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(ThreadDetailActivity.this,
                        R.string.kick_failed, Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    /**
     * 执行踢帖操作
     */
    private void performKick() {
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }
        String currentUid = UserSessionManager.getInstance().getUid(getApplicationContext());
        String authorUid = postDetail != null ? postDetail.getAuthorUid() : null;
        if (!TextUtils.isEmpty(currentUid) && !TextUtils.isEmpty(authorUid)
                && currentUid.equals(authorUid)) {
            Toast.makeText(this, "不能踢自己的帖子", Toast.LENGTH_SHORT).show();
            return;
        }

        // 使用自定义dialog_kick.xml布局
        Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog);
        dialog.setContentView(R.layout.dialog_kick);
        dialog.setCancelable(true);
        if (dialog.getWindow() != null) {
            // 去除 Theme_DeviceDefault_Dialog 自带的深色外层背景，只保留白色 CardView。
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        EditText etKickReason = dialog.findViewById(R.id.et_kick_reason);
        Button btnCloseKick = dialog.findViewById(R.id.btn_close_kick);
        Button btnSubmitKick = dialog.findViewById(R.id.btn_submit_kick);

        btnCloseKick.setOnClickListener(v -> dialog.dismiss());
        btnSubmitKick.setOnClickListener(v -> {
            String reason = etKickReason.getText().toString().trim();
            if (TextUtils.isEmpty(reason)) {
                etKickReason.setError("请输入踢帖理由");
                return;
            }
            dialog.dismiss();
            submitKickRequest(reason);
        });

        dialog.show();
    }

    // ==================== 编辑帖子 / 评论 ====================

    /** 编辑帖子/评论的 startActivityForResult 请求码。 */
    private static final int REQUEST_EDIT_THREAD = 3101;
    private static final int REQUEST_EDIT_REPLY = 3102;

    /**
     * 同步顶栏编辑入口与评论区编辑按钮的可见性。
     *
     * <p>只按"是否本人"显示；真正的编辑权限（时限、版规、管理组）由服务端裁定，
     * 在编辑页拉取原文时才能确定，这里不做不可靠的本地推断。
     */
    /**
     * 判断当前登录用户是否就是本帖楼主。
     *
     * <p>关注按钮与编辑按钮共用作者栏右侧位置，二者依据同一判据切换，
     * 避免出现"关注自己"或"给别人的帖子显示编辑"这类矛盾状态。
     */
    private boolean isSelfThread(PostDetail detail) {
        if (detail == null) return false;
        String currentUid = UserSessionManager.getInstance().getUid(this);
        return !TextUtils.isEmpty(currentUid)
                && !TextUtils.isEmpty(detail.getAuthorUid())
                && currentUid.equals(detail.getAuthorUid());
    }

    private void updateThreadEditEntry(PostDetail detail) {
        String currentUid = UserSessionManager.getInstance().getUid(this);
        if (replyAdapter != null) replyAdapter.setCurrentUid(currentUid);

        boolean canEdit = isSelfThread(detail) && !TextUtils.isEmpty(detail.getPostPid());
        binding.btnEditThread.setVisibility(canEdit ? View.VISIBLE : View.GONE);
        if (canEdit) {
            binding.btnEditThread.setOnClickListener(v -> startEditThread());
        } else {
            binding.btnEditThread.setOnClickListener(null);
        }
    }

    /** 编辑主题第一楼（标题 + 正文）。 */
    private void startEditThread() {
        if (postDetail == null || TextUtils.isEmpty(postDetail.getPostPid())) {
            Toast.makeText(this, "帖子信息不完整，请下拉刷新后重试", Toast.LENGTH_SHORT).show();
            return;
        }
        // 第一楼固定在第 1 页，不用当前浏览页码，否则编辑页会定位错楼层。
        startActivityForResult(EditPostActivity.newIntent(this, tid,
                postDetail.getPostPid(), postDetail.getForumFid(), 1, true),
                REQUEST_EDIT_THREAD);
    }

    /** 编辑某条评论。 */
    private void startEditReply(ReplyItem item) {
        if (item == null || TextUtils.isEmpty(item.getPid())) {
            Toast.makeText(this, "该评论缺少编号，无法编辑", Toast.LENGTH_SHORT).show();
            return;
        }
        String fid = postDetail != null ? postDetail.getForumFid() : null;
        int page = postDetail != null ? Math.max(1, postDetail.getCurrentPage()) : 1;
        startActivityForResult(EditPostActivity.newIntent(this, tid, item.getPid(),
                fid, page, false), REQUEST_EDIT_REPLY);
    }

    /**
     * 从本地列表移除已删除的评论。
     *
     * <p>删除成功后仅做本地移除并同步回复数，不再整体刷新详情，
     * 从而保留已经加载的全部评论和当前浏览位置。
     *
     * <p>同时清掉该 pid 的预处理缓存，否则同一 pid 若被论坛复用会命中陈旧渲染结果。
     */
    private void removeReplyLocally(String deletedPid) {
        if (TextUtils.isEmpty(deletedPid)) return;
        boolean removed = false;
        if (displayedReplies != null) {
            for (int i = displayedReplies.size() - 1; i >= 0; i--) {
                ReplyItem item = displayedReplies.get(i);
                if (item != null && deletedPid.equals(item.getPid())) {
                    displayedReplies.remove(i);
                    removed = true;
                }
            }
        }
        if (postDetail != null && postDetail.getReplies() != null) {
            List<ReplyItem> replies = postDetail.getReplies();
            for (int i = replies.size() - 1; i >= 0; i--) {
                ReplyItem item = replies.get(i);
                if (item != null && deletedPid.equals(item.getPid())) {
                    replies.remove(i);
                    removed = true;
                }
            }
        }
        if (removed && postDetail != null) {
            postDetail.setReplyCount(Math.max(0, postDetail.getReplyCount() - 1));
        }
        ReplyAdapter.sPreProcessCache.remove(deletedPid);
        updateReplyFilterAndOrder();
    }

    // ==================== 评论置顶（服务端） ====================

    /**
     * 置顶 / 取消置顶自己的评论。
     *
     * <p>状态必须由服务端保存：只写本机 SharedPreferences 会造成"自己看到已置顶、
     * 换端或刷新后又没有"的假成功。因此这里提交成功后立刻重新拉取详情页，
     * 让置顶标识与排序完全以服务端解析结果为准。
     *
     * <p>注意：Discuz 的 stickreply 属于版主权限（allowstickreply），普通会员
     * 即使是自己的评论也可能被服务端拒绝，此时按响应内容提示"没有置顶权限"。
     */
    private void toggleReplyPin(ReplyItem item) {
        if (item == null || TextUtils.isEmpty(item.getPid())) {
            Toast.makeText(this, "该评论缺少编号，无法置顶", Toast.LENGTH_SHORT).show();
            return;
        }
        httpClient.syncFromCookieManager();
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }
        String currentUid = UserSessionManager.getInstance().getUid(getApplicationContext());
        if (TextUtils.isEmpty(currentUid) || !currentUid.equals(item.getAuthorUid())) {
            Toast.makeText(this, R.string.reply_pin_only_self, Toast.LENGTH_SHORT).show();
            return;
        }
        // 单飞防抖：置顶请求要先取 formhash 再提交，重复点击会打出多组互相覆盖的请求。
        if (mReplyPinInProgress) {
            Toast.makeText(this, R.string.reply_pin_in_progress, Toast.LENGTH_SHORT).show();
            return;
        }

        final boolean targetPinned = !item.isPinned();
        mReplyPinInProgress = true;
        new Thread(() -> {
            boolean success = false;
            boolean noPermission = false;
            String errorMessage = null;
            try {
                String response = submitReplyPin(item.getPid(), targetPinned);
                if (containsAny(response, "管理操作成功", "succeedhandle_mods")) {
                    success = true;
                } else if (containsAny(response, "没有权限", "无权", "权限不足")) {
                    noPermission = true;
                }
            } catch (Exception e) {
                errorMessage = e.getMessage();
            }

            final boolean finalSuccess = success;
            final boolean finalNoPermission = noPermission;
            final String finalError = errorMessage;
            runOnUiThread(() -> {
                mReplyPinInProgress = false;
                if (isFinishing() || isDestroyed()) return;
                if (finalSuccess) {
                    item.setPinned(targetPinned);
                    updateReplyFilterAndOrder();
                    Toast.makeText(this, targetPinned
                                    ? R.string.reply_pin_success : R.string.reply_unpin_success,
                            Toast.LENGTH_SHORT).show();
                    // 重新读取服务端数据，确保跨端状态、排序与置顶标识一致。
                    refreshPostDetail();
                } else if (finalNoPermission) {
                    Toast.makeText(this, R.string.reply_pin_no_permission, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, TextUtils.isEmpty(finalError)
                                    ? getString(R.string.reply_pin_failed) : finalError,
                            Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    /**
     * 提交置顶请求，返回服务端原始响应交给调用方判断。
     *
     * <p>对应网页端 {@code modaction('stickreply', pid)} 弹窗最终提交的请求：
     * <pre>
     * POST forum.php?mod=topicadmin&amp;action=stickreply&amp;modsubmit=yes&amp;modclick=yes&amp;mobile=2
     *      formhash / fid / tid / page / reason / topiclist[]=pid / stickreply=1|0 / modsubmit=确定
     * </pre>
     * formhash 从桌面版详情页取，移动模板未登录态下可能不输出该字段。
     */
    private String submitReplyPin(String pid, boolean pin) throws Exception {
        if (TextUtils.isEmpty(pid) || TextUtils.isEmpty(tid)) {
            throw new IllegalStateException("缺少帖子或评论编号");
        }
        String fid = postDetail == null ? null : postDetail.getForumFid();
        if (TextUtils.isEmpty(fid)) {
            throw new IllegalStateException("缺少版块ID，无法提交置顶操作");
        }

        String detailHtml = httpClient.getDesktop(ForumParser.getThreadDesktopDetailUrl(tid));
        if (TextUtils.isEmpty(detailHtml) || ForumParser.isLoginPage(detailHtml)) {
            throw new IllegalStateException("登录状态已失效，请重新登录");
        }
        String formhash = ForumParser.parseFormhash(detailHtml);
        if (TextUtils.isEmpty(formhash) && postDetail != null) {
            formhash = postDetail.getFormhash();
        }
        if (TextUtils.isEmpty(formhash)) {
            throw new IllegalStateException("获取安全验证失败");
        }

        int page = postDetail == null ? 1 : Math.max(1, postDetail.getCurrentPage());
        Map<String, String> params = new HashMap<>();
        params.put("formhash", formhash);
        params.put("fid", fid);
        params.put("tid", tid);
        params.put("page", String.valueOf(page));
        params.put("reason", "手机版主题操作");
        params.put("topiclist[]", pid);
        params.put("stickreply", pin ? "1" : "0");
        params.put("modsubmit", "确定");

        String actionUrl = HttpClient.BASE_URL
                + "forum.php?mod=topicadmin&action=stickreply"
                + "&modsubmit=yes&modclick=yes&mobile=2";
        return httpClient.post(actionUrl, params);
    }

    // ==================== 举报 ====================

    /**
     * 显示评论举报弹窗。选项与 Discuz 移动端常见举报项保持一致，
     * 允许用输入框补充自定义说明。
     */
    private void showReplyReportDialog(ReplyItem target) {
        if (target == null || TextUtils.isEmpty(target.getPid())) return;
        httpClient.syncFromCookieManager();
        if (!httpClient.isLoggedIn()) {
            Toast.makeText(this, R.string.login_required_hint, Toast.LENGTH_SHORT).show();
            return;
        }

        final String[] reasons = {"广告/SPAM", "违规内容", "人身攻击", "色情或低俗", "其他"};
        final int[] selected = {0};
        EditText customReason = new EditText(this);
        customReason.setHint("可补充举报说明（可选）");
        customReason.setSingleLine(false);
        customReason.setMinLines(2);
        customReason.setMaxLines(4);
        int horizontal = dpToPx(20);
        customReason.setPadding(horizontal, dpToPx(8), horizontal, dpToPx(8));

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dpToPx(8), 0, dpToPx(8), 0);
        container.addView(customReason, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("举报评论")
                .setSingleChoiceItems(reasons, 0, (d, which) -> selected[0] = which)
                .setView(container)
                .setNegativeButton("取消", null)
                .setPositiveButton("提交举报", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String extra = customReason.getText() == null
                            ? "" : customReason.getText().toString().trim();
                    String reason = reasons[selected[0]];
                    if (!TextUtils.isEmpty(extra)) reason += "：" + extra;
                    dialog.dismiss();
                    submitReplyReport(target.getPid(), reason);
                }));
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
    }

    /**
     * 调用 Discuz 标准举报接口：
     * misc.php?mod=report&rtype=post&rid={pid}&tid={tid}&fid={fid}&mobile=2
     */
    private void submitReplyReport(String pid, String reason) {
        new Thread(() -> {
            try {
                if (postDetail == null) throw new IllegalStateException("帖子数据为空");
                httpClient.syncFromCookieManager();
                String page = httpClient.get(ForumParser.getThreadDetailUrl(tid, getReplyOrder()));
                if (TextUtils.isEmpty(page) || ForumParser.isLoginPage(page)) {
                    throw new IllegalStateException("登录状态已失效，请重新登录");
                }

                String formhash = ForumParser.parseFormhash(page);
                if (TextUtils.isEmpty(formhash)) formhash = postDetail.getFormhash();
                String fid = postDetail.getForumFid();
                if (TextUtils.isEmpty(fid)) {
                    Matcher fidMatcher = Pattern.compile("forum-(\\d+)-").matcher(page);
                    if (fidMatcher.find()) fid = fidMatcher.group(1);
                }
                if (TextUtils.isEmpty(formhash)) throw new IllegalStateException("无法获取举报验证");
                if (TextUtils.isEmpty(fid)) throw new IllegalStateException("无法获取版块编号");

                String reportUrl = HttpClient.BASE_URL
                        + "misc.php?mod=report&rtype=post&rid=" + pid
                        + "&tid=" + tid + "&fid=" + fid
                        + "&inajax=1&mobile=2";
                Map<String, String> params = new HashMap<>();
                params.put("formhash", formhash);
                params.put("reportsubmit", "true");
                params.put("rtype", "post");
                params.put("rid", pid);
                params.put("tid", tid);
                params.put("fid", fid);
                params.put("reason", reason);
                params.put("message", reason);
                params.put("inajax", "1");

                String result = httpClient.post(reportUrl, params);
                boolean success = isReportResponseSuccessful(result);
                String failure = extractReportError(result);
                final boolean finalSuccess = success;
                runOnUiThread(() -> Toast.makeText(ThreadDetailActivity.this,
                        finalSuccess ? "举报已提交，感谢你的反馈" :
                                (TextUtils.isEmpty(failure) ? "举报失败，请稍后重试" : failure),
                        Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(ThreadDetailActivity.this,
                        TextUtils.isEmpty(e.getMessage()) ? "举报失败，请稍后重试" : e.getMessage(),
                        Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    /** 判断 Discuz 举报接口响应是否成功。 */
    private boolean isReportResponseSuccessful(String response) {
        if (TextUtils.isEmpty(response) || ForumParser.isLoginPage(response)) return false;
        if (containsAny(response, "formhash错误", "请先登录", "没有权限", "非法操作", "举报失败", "操作失败")) {
            return false;
        }
        return containsAny(response, "举报成功", "举报已提交", "感谢您的举报", "感谢你的举报",
                "感谢您的反馈", "report_succeed", "succeedhandle_report", "success");
    }

    /** 从举报响应中提取可直接展示给用户的失败原因。 */
    private String extractReportError(String response) {
        if (TextUtils.isEmpty(response)) return "举报失败，服务器未返回结果";
        if (ForumParser.isLoginPage(response) || containsAny(response, "请先登录")) {
            return "登录状态已失效，请重新登录";
        }
        if (containsAny(response, "formhash错误", "非法操作")) {
            return "验证已失效，请刷新页面后重试";
        }
        if (containsAny(response, "没有权限")) {
            return "当前账号没有举报权限";
        }
        if (containsAny(response, "提交频率过快", "操作频繁")) {
            return "操作过于频繁，请稍后再试";
        }
        return "";
    }

    /**
     * 表情面板：内嵌到回复弹窗中（避免 PopupWindow 被弹窗遮挡）。
     * 使用本地 Discuz 表情 gif（drawable）＋网络 default 表情：
     *  - 本地 14 个经典表情（smile.gif 等）保证离线可用、有缩略图；
     *  - 点击插入 Discuz 冒号 code（如 ":)"），服务端自动渲染成表情图片。
     */
    private void showEmojiPanel() {
        if (mThreadReplyDialog == null || !mThreadReplyDialog.isShowing()) {
            showThreadReplyDialogIfNeeded();
            return;
        }
        View panel = mThreadReplyDialog.findViewById(R.id.ll_emoji_panel);
        if (panel == null) return;
        if (panel.getVisibility() == View.VISIBLE) {
            panel.setVisibility(View.GONE);
            return;
        }
        setUpEmojiTabs();
        panel.setVisibility(View.VISIBLE);
    }

    /**
     * 装配回复弹窗的表情面板（贴吧 / QQ / 狗头三分类，本地 drawable 资源）。
     */
    private void setUpEmojiTabs() {
        if (mThreadReplyDialog == null) return;
        com.google.android.material.tabs.TabLayout tabs =
                mThreadReplyDialog.findViewById(R.id.tl_emoji_tabs);
        androidx.viewpager.widget.ViewPager vp =
                mThreadReplyDialog.findViewById(R.id.vp_dialog_emoji);
        // 面板装配逻辑与发帖页共用 SmileyPanelHelper，避免两处表情数据再次分叉。
        com.forum.MT.ui.widget.SmileyPanelHelper.setUp(tabs, vp, 6, 46,
                (code, iconRes) -> insertReplyText(code));
    }

    /**
     * 在光标位置插入文本：弹窗打开时插入弹窗输入框，否则插入底部输入框。
     */
    private void insertReplyText(String insert) {
        EditText target = getActiveReplyEdit();
        if (target == null) return;
        int pos = Math.max(0, target.getSelectionStart());
        String text = target.getText() == null ? "" : target.getText().toString();
        target.setText(text.substring(0, Math.min(pos, text.length())) + insert
                + text.substring(Math.min(pos, text.length())));
        target.setSelection(Math.min(pos, text.length()) + insert.length());
        target.requestFocus();
    }

    /**
     * 返回当前活跃的回复输入框：弹窗打开时用弹窗输入框，否则用底部输入框。
     */
    private EditText getActiveReplyEdit() {
        if (mThreadDialogReplyInput != null && mThreadReplyDialog != null && mThreadReplyDialog.isShowing()) {
            return mThreadDialogReplyInput;
        }
        return binding.etReply;
    }

    /**
     * 为 Html.fromHtml 提供内联图片加载器（普通图片）
     */
    private Html.ImageGetter createInlineImageGetter(final TextView textView) {
        return createInlineImageGetter(textView, null);
    }

    /**
     * 统一的论坛 HTML 渲染入口：
     * 1) 先用 InlineHighlightPreprocessor 把发帖者的 background-color 高亮（如 #f4f4f4）
     *    转换为 <hl> 自定义标签；
     * 2) 用 InlineHighlightTagHandler 将 <hl> 渲染为 用户可自定义的行内高亮背景 + 文字色。
     *
     * @param html        原始 HTML（允许含 table:// 占位符、&lt;img&gt; 等）
     * @param imageGetter 内联图片加载器（表格/图片）
     */
    private CharSequence fromForumHtml(String html, Html.ImageGetter imageGetter) {
        String preprocessed = com.forum.MT.ui.widget.InlineHighlightPreprocessor.convert(html);
        // 帖子正文强制默认颜色：去除 <font> 的 color 属性和 style 中的 color
        if (com.forum.MT.ui.widget.ForceDefaultTextColorManager.isEnabled()) {
            preprocessed = stripFontColors(preprocessed);
        }
        com.forum.MT.ui.widget.InlineHighlightTagHandler tagHandler =
                new com.forum.MT.ui.widget.InlineHighlightTagHandler(
                        com.forum.MT.ui.widget.InlineHighlightManager.resolveBgColor(this),
                        com.forum.MT.ui.widget.InlineHighlightManager.resolveTextColor(this),
                        com.forum.MT.ui.widget.InlineHighlightManager.isEnabled(this),
                        com.forum.MT.ui.widget.InlineCodeManager.resolveBgColor(this),
                        com.forum.MT.ui.widget.InlineCodeManager.resolveTextColor(this),
                        com.forum.MT.ui.widget.InlineCodeManager.isEnabled(this));
        CharSequence rendered = Html.fromHtml(preprocessed, Html.FROM_HTML_MODE_COMPACT, imageGetter, tagHandler);
        // ★ 应用"帖子正文加粗文字粗度"设置：将 BOLD 样式的 Span 替换为自定义粗度
        int threadBoldWeight = com.forum.MT.ui.widget.ThreadBoldWeightManager.getWeight(this);
        if (threadBoldWeight != 700 && rendered instanceof android.text.Spannable) {
            android.text.Spannable sp = (android.text.Spannable) rendered;
            android.text.style.StyleSpan[] spans = sp.getSpans(0, sp.length(), android.text.style.StyleSpan.class);
            for (android.text.style.StyleSpan span : spans) {
                if (span.getStyle() == android.graphics.Typeface.BOLD) {
                    int s = sp.getSpanStart(span);
                    int e = sp.getSpanEnd(span);
                    int f = sp.getSpanFlags(span);
                    sp.removeSpan(span);
                    android.graphics.Typeface customTf = android.graphics.Typeface.create(
                            android.graphics.Typeface.DEFAULT, threadBoldWeight, false);
                    sp.setSpan(new android.text.style.TypefaceSpan(customTf), s, e, f);
                }
            }
        }
        return rendered;
    }

    /**
     * 去除 HTML 中 <font> 标签的颜色属性（color="..." 或 style="color:..."），
     * 使帖子正文强制使用默认文字颜色。
     */
    private static String stripFontColors(String html) {
        if (html == null || html.isEmpty()) return html;
        // 1) 去掉 <font color="#xxxxxx"> 形式的 color 属性
        String out = html.replaceAll("(?i)(<font\\b[^>]*?)\\scolor\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)", "$1");
        // 2) 去掉 <font style="...color:#xxxxxx;..."> 形式 style 中的 color 声明
        out = out.replaceAll("(?i)(<font\\b[^>]*?\\bstyle\\s*=\\s*\")([^\"]*?)(?:;?\\s*color\\s*:\\s*[^;\"']+;?)([^\"]*)\"", "$1$2$3\"");
        // 3) 清理可能残留的空 style=""
        out = out.replaceAll("(?i)(<font\\b[^>]*?)\\sstyle\\s*=\\s*\"\\s*\"", "$1");
        return out;
    }

    /**
     * 为 Html.fromHtml 提供内联图片加载器。
     * <p>
     * 支持两类内联资源：
     * <ul>
     *   <li><b>table://N</b> — 表格占位符，渲染为带边框的表格位图（内联显示在正文原位置）</li>
     *   <li><b>http(s)://...</b> — 普通图片（表情等），Glide 异步加载，缩放到 24dp</li>
     * </ul>
     *
     * @param tables 表格数据列表；为 null 时 table:// 占位符渲染为 1px 透明占位
     */
    private Html.ImageGetter createInlineImageGetter(final TextView textView, final List<TableData> tables) {
        return source -> {
            // ★ 表格占位符：渲染为带边框的表格位图，内联显示在正文原位置
            if (source != null && source.startsWith("table://")) {
                try {
                    int idx = Integer.parseInt(source.substring("table://".length()));
                    if (tables != null && idx >= 0 && idx < tables.size()) {
                        int maxWidth = textView.getWidth();
                        if (maxWidth <= 0) {
                            maxWidth = getResources().getDisplayMetrics().widthPixels - dpToPx(48);
                        }
                        android.graphics.Bitmap bmp = renderTableToBitmap(tables.get(idx), maxWidth);
                        if (bmp != null) {
                            android.graphics.drawable.BitmapDrawable drawable =
                                    new android.graphics.drawable.BitmapDrawable(getResources(), bmp);
                            drawable.setBounds(0, 0, bmp.getWidth(), bmp.getHeight());
                            return drawable;
                        }
                    }
                    // 表格未就绪：1px 透明占位，避免崩溃
                    return new Drawable() {
                        @Override public void draw(@NonNull Canvas canvas) {}
                        @Override public void setAlpha(int alpha) {}
                        @Override public void setColorFilter(ColorFilter cf) {}
                        @Override public int getOpacity() { return PixelFormat.TRANSPARENT; }
                        @Override public int getIntrinsicWidth() { return 1; }
                        @Override public int getIntrinsicHeight() { return 1; }
                    };
                } catch (Exception e) {
                    return new Drawable() {
                        @Override public void draw(@NonNull Canvas canvas) {}
                        @Override public void setAlpha(int alpha) {}
                        @Override public void setColorFilter(ColorFilter cf) {}
                        @Override public int getOpacity() { return PixelFormat.TRANSPARENT; }
                        @Override public int getIntrinsicWidth() { return 1; }
                        @Override public int getIntrinsicHeight() { return 1; }
                    };
                }
            }

            // 普通图片/表情：从预加载缓存读取（避免主线程网络请求）
            String imgUrl = source;
            if (imgUrl.startsWith("//")) {
                imgUrl = "https:" + imgUrl;
            } else if (imgUrl.startsWith("/")) {
                imgUrl = HttpClient.BASE_URL + imgUrl.substring(1);
            } else if (!imgUrl.startsWith("http")) {
                imgUrl = HttpClient.BASE_URL + imgUrl;
            }
            // ★ 统一缓存键：把 &amp; 解码为 &，与预加载时一致
            String cacheKey = imgUrl.replace("&amp;", "&");

            // ★ 先走 GIF 字节缓存：直接解码独立动画实例，避免任何 GifDrawable 共享状态
            byte[] gifBytes = com.forum.MT.ui.detail.ReplyAdapter.sGifBytesCache.get(cacheKey);
            if (gifBytes == null && imgUrl != null && !imgUrl.equals(cacheKey)) {
                gifBytes = com.forum.MT.ui.detail.ReplyAdapter.sGifBytesCache.get(imgUrl);
            }
            if (gifBytes != null) {
                android.graphics.drawable.Drawable independent = decodeIndependentGifDrawable(cacheKey, gifBytes, textView);
                if (independent != null) {

                    return independent;
                }
            }

            // ★ 判断是否为表情/小图标 URL
            boolean isSmileyUrl = cacheKey.contains("smiley") || cacheKey.contains("emoticon")
                    || cacheKey.contains("/static/image/");

            // ★ 表情优先查 sSmileyCache（24dp 小图），跳过 sReplyImageCache（大图缓存）
            //   防止表情被误缓存到大图缓存后按大图尺寸渲染
            if (!isSmileyUrl) {
                // ★ 优先检查 sReplyImageCache（内联大图：[attachimg] 图片、真实图片文件）
                android.graphics.drawable.Drawable bigCached = ReplyAdapter.sReplyImageCache.get(cacheKey);
                if (bigCached != null) {
                    // ★ GifDrawable：使用 Glide 加载独立实例（不共享 GifFrameLoader）
                    if (isGifDrawable(bigCached)) {
                        android.graphics.drawable.Drawable independent = getIndependentGifDrawable(imgUrl, textView);
                        if (independent != null) {
                            return independent;
                        }
                    }
                    android.graphics.drawable.Drawable.ConstantState cs = bigCached.getConstantState();
                    android.graphics.drawable.Drawable drawable = (cs != null)
                            ? cs.newDrawable(getResources())
                            : bigCached;
                    int w = drawable.getIntrinsicWidth();
                    int h = drawable.getIntrinsicHeight();
                    if (w <= 0 || h <= 0) {
                        w = dpToPx(200);
                        h = dpToPx(120);
                    }
                    int maxImgWidth = getResources().getDisplayMetrics().widthPixels - dpToPx(48);
                    if (w > maxImgWidth) {
                        float ratio = (float) maxImgWidth / w;
                        w = maxImgWidth;
                        h = (int) (h * ratio);
                    }
                    drawable.setBounds(0, 0, w, h);
                    // ★ 不在此处 start() GIF 动画——由 startGifAnimationsInTextView 统一启动
                    // 仅设置 callback，避免 FrameLoader 在 drawable 未 attach 时过早启动
                    if (drawable instanceof android.graphics.drawable.Animatable) {
                        drawable.setCallback(textView);
                    }
                    return drawable;
                }
            }

            // 从缓存读取表情图
            // ★ 从缓存读取表情 Drawable（支持 GIF 动画）
            android.graphics.drawable.Drawable cachedDrawable = ReplyAdapter.getSmileyCache().get(cacheKey);
            if (cachedDrawable == null && imgUrl != null && !imgUrl.equals(cacheKey)) {
                cachedDrawable = ReplyAdapter.getSmileyCache().get(imgUrl);
            }
            if (cachedDrawable != null) {
                // ★ GifDrawable：使用 Glide 加载独立实例（不共享 GifFrameLoader）
                if (isGifDrawable(cachedDrawable)) {
                    android.graphics.drawable.Drawable independent = getIndependentGifDrawable(imgUrl, textView);
                    if (independent != null) {
                        return independent;
                    }
                }
                android.graphics.drawable.Drawable.ConstantState cs = cachedDrawable.getConstantState();
                android.graphics.drawable.Drawable drawable = (cs != null)
                        ? cs.newDrawable(getResources())
                        : cachedDrawable;
                int maxSize = dpToPx(24);
                int w = drawable.getIntrinsicWidth();
                int h = drawable.getIntrinsicHeight();
                if (w > maxSize || h > maxSize) {
                    float ratio = (float) maxSize / Math.max(w, h);
                    w = (int) (w * ratio);
                    h = (int) (h * ratio);
                } else {
                    w = Math.max(w, 16);
                    h = Math.max(h, 16);
                }
                drawable.setBounds(0, 0, w, h);
                // ★ 不在此处 start() GIF 动画——由 startGifAnimationsInTextView 统一启动
                if (drawable instanceof android.graphics.drawable.Animatable) {
                    drawable.setCallback(textView);
                }
                return drawable;
            }
            // 缓存未命中：返回 24dp 透明占位图，预加载完成后会二次渲染更新
            android.graphics.drawable.ColorDrawable placeholder =
                    new android.graphics.drawable.ColorDrawable(0x00000000);
            placeholder.setBounds(0, 0, dpToPx(24), dpToPx(24));
            return placeholder;
        };
    }

    // ==================== 投票区域渲染 ====================

    /**
     * 在楼主帖正文中渲染投票区块。
     * 若 poll 为 null 则隐藏区域；否则动态构建投票卡片视图。
     */
    private void renderPoll(Poll poll) {
        LinearLayout container = binding.layoutPoll;
        if (container == null) return;
        container.removeAllViews();

        if (poll == null || poll.getOptions() == null || poll.getOptions().isEmpty()) {
            container.setVisibility(View.GONE);
            return;
        }

        container.setVisibility(View.VISIBLE);
        Context ctx = container.getContext();

        int dp1 = dpToPx(1);
        int dp4 = dpToPx(4);
        int dp8 = dpToPx(8);
        int dp12 = dpToPx(12);

        int colorCardBg = 0xFFF7F7F7;
        int colorTitle = 0xFF424242;
        int colorMeta = 0xFF9E9E9E;
        int colorOptionText = 0xFF424242;
        int colorBarBg = 0xFFEEEEEE;
        int colorPercent = 0xFF9E9E9E;
        int colorDivider = 0xFFEEEEEE;
        int colorStatus = 0xFF9E9E9E;

        try {
            colorCardBg = ctx.getColor(R.color.background_secondary);
            colorTitle = ctx.getColor(R.color.text_primary);
            colorMeta = ctx.getColor(R.color.text_secondary);
            colorOptionText = ctx.getColor(R.color.text_primary);
            colorBarBg = ctx.getColor(R.color.divider);
            colorPercent = ctx.getColor(R.color.text_secondary);
            colorDivider = ctx.getColor(R.color.divider);
        } catch (Exception ignored) {}

        // ---- 外层卡片容器 ----
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(colorCardBg);
        cardBg.setCornerRadius(dp8);
        card.setBackground(cardBg);
        card.setPadding(dp12, dp12, dp12, dp12);

        // ---- 标题行：投票类型 + 状态 ----
        LinearLayout titleRow = new LinearLayout(ctx);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleRowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleRowLp.bottomMargin = dp8;
        titleRow.setLayoutParams(titleRowLp);

        TextView tvTitle = new TextView(ctx);
        tvTitle.setText(poll.getPollType() != null ? poll.getPollType() : "投票");
        tvTitle.setTextColor(colorTitle);
        tvTitle.setTextSize(15);
        tvTitle.setTypeface(tvTitle.getTypeface(), android.graphics.Typeface.BOLD);
        titleRow.addView(tvTitle);

        View spacer = new View(ctx);
        LinearLayout.LayoutParams spacerLp = new LinearLayout.LayoutParams(0, 1, 1f);
        spacer.setLayoutParams(spacerLp);
        titleRow.addView(spacer);

        if (poll.isClosed()) {
            TextView tvStatus = new TextView(ctx);
            tvStatus.setText("已结束");
            tvStatus.setTextColor(android.graphics.Color.WHITE);
            tvStatus.setTextSize(11);
            tvStatus.setPadding(dp8, dp1, dp8, dp1);
            GradientDrawable statusBg = new GradientDrawable();
            statusBg.setColor(colorStatus);
            statusBg.setCornerRadius(dp4);
            tvStatus.setBackground(statusBg);
            titleRow.addView(tvStatus);
        }
        card.addView(titleRow);

        // ---- 参与人数 ----
        if (poll.getVoterCount() > 0) {
            TextView tvVoters = new TextView(ctx);
            tvVoters.setText("共有 " + poll.getVoterCount() + " 人参与投票");
            tvVoters.setTextColor(colorMeta);
            tvVoters.setTextSize(12);
            LinearLayout.LayoutParams vLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            vLp.bottomMargin = dp12;
            tvVoters.setLayoutParams(vLp);
            card.addView(tvVoters);
        }

        // ---- 分隔线 ----
        View divider = new View(ctx);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        divLp.bottomMargin = dp12;
        divider.setLayoutParams(divLp);
        divider.setBackgroundColor(colorDivider);
        card.addView(divider);

        // ---- 检查是否可以投票 ----
        boolean canVote = !poll.isClosed() && httpClient.isLoggedIn();
        boolean hasOptionIds = false;
        for (Poll.Option opt : poll.getOptions()) {
            if (opt.getOptionId() != null && !opt.getOptionId().isEmpty()) {
                hasOptionIds = true;
                break;
            }
        }
        canVote = canVote && hasOptionIds;

        int totalOptions = poll.getOptions().size();

        if (canVote) {
            // ============ 投票模式：可选项 + 结果 + 投票按钮 ============
            boolean isMultiChoice = poll.getPollType() != null && poll.getPollType().contains("多选");
            int colorAccent = 0xFF1976D2;
            try { colorAccent = ctx.getColor(R.color.primary); } catch (Exception ignored) {}

            // 用于跟踪选中的选项 ID
            java.util.Set<String> selectedIds = new java.util.HashSet<>();
            // 用于单选模式互斥
            java.util.List<android.widget.RadioButton> radioButtons = new java.util.ArrayList<>();

            for (int i = 0; i < totalOptions; i++) {
                Poll.Option opt = poll.getOptions().get(i);
                boolean isLast = (i == totalOptions - 1);

                LinearLayout optRow = new LinearLayout(ctx);
                optRow.setOrientation(LinearLayout.HORIZONTAL);
                optRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                if (!isLast) rowLp.bottomMargin = dp4;
                optRow.setLayoutParams(rowLp);

                if (isMultiChoice) {
                    // 多选：CheckBox
                    android.widget.CheckBox cb = new android.widget.CheckBox(ctx);
                    String optId = opt.getOptionId();
                    cb.setOnCheckedChangeListener((button, checked) -> {
                        if (checked) selectedIds.add(optId);
                        else selectedIds.remove(optId);
                    });
                    optRow.addView(cb);
                } else {
                    // 单选：RadioButton
                    android.widget.RadioButton rb = new android.widget.RadioButton(ctx);
                    String optId = opt.getOptionId();
                    rb.setOnCheckedChangeListener((button, checked) -> {
                        if (checked) {
                            // 单选互斥：取消其他 RadioButton
                            for (android.widget.RadioButton other : radioButtons) {
                                if (other != rb) other.setChecked(false);
                            }
                            selectedIds.clear();
                            selectedIds.add(optId);
                        }
                    });
                    radioButtons.add(rb);
                    optRow.addView(rb);
                }

                // 选项文本
                TextView tvOpt = new TextView(ctx);
                tvOpt.setText(opt.getText());
                tvOpt.setTextColor(colorOptionText);
                tvOpt.setTextSize(13);
                tvOpt.setSingleLine(false);
                tvOpt.setMaxLines(2);
                LinearLayout.LayoutParams optLp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                optLp.rightMargin = dp8;
                tvOpt.setLayoutParams(optLp);
                optRow.addView(tvOpt);

                // 百分比文本
                TextView tvPct = new TextView(ctx);
                tvPct.setText(String.format(java.util.Locale.getDefault(), "%.1f%%", opt.getPercent()));
                tvPct.setTextColor(colorPercent);
                tvPct.setTextSize(12);
                optRow.addView(tvPct);

                // 票数
                if (opt.getVoteCount() > 0) {
                    TextView tvCount = new TextView(ctx);
                    tvCount.setText("(" + opt.getVoteCount() + "票)");
                    tvCount.setTextColor(colorPercent);
                    tvCount.setTextSize(11);
                    LinearLayout.LayoutParams cntLp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    cntLp.leftMargin = dp4;
                    tvCount.setLayoutParams(cntLp);
                    optRow.addView(tvCount);
                }

                card.addView(optRow);

                // 进度条
                float pct = Math.max(0f, Math.min(100f, (float) opt.getPercent()));
                int fillColor = PollBarColorManager.resolveColor();
                if (opt.getBarColor() != null && !opt.getBarColor().isEmpty()
                        && PollBarColorManager.getCustomColor() == 0) {
                    try {
                        fillColor = android.graphics.Color.parseColor(opt.getBarColor());
                    } catch (Exception ignored) {}
                }

                LinearLayout barRow = new LinearLayout(ctx);
                barRow.setOrientation(LinearLayout.HORIZONTAL);
                barRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams barRowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(6));
                barRowLp.bottomMargin = isLast ? 0 : dp12;
                barRow.setLayoutParams(barRowLp);

                View barFill = new View(ctx);
                LinearLayout.LayoutParams barFillLp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, pct);
                barFill.setLayoutParams(barFillLp);
                GradientDrawable barFillDrawable = new GradientDrawable();
                barFillDrawable.setColor(fillColor);
                barFillDrawable.setCornerRadius(dpToPx(3));
                barFill.setBackground(barFillDrawable);
                barRow.addView(barFill);

                View barBg = new View(ctx);
                LinearLayout.LayoutParams barBgLp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 100f - pct);
                barBg.setLayoutParams(barBgLp);
                GradientDrawable barBgDrawable = new GradientDrawable();
                barBgDrawable.setColor(colorBarBg);
                barBgDrawable.setCornerRadius(dpToPx(3));
                barBg.setBackground(barBgDrawable);
                barRow.addView(barBg);

                card.addView(barRow);
            }

            // ---- 投票按钮（样式与"打赏"按钮一致） ----
            int dp16 = dpToPx(16);
            android.widget.Button btnVote = new android.widget.Button(ctx);
            btnVote.setText("投票");
            btnVote.setTextColor(android.graphics.Color.WHITE);
            btnVote.setTextSize(15);
            btnVote.setTypeface(btnVote.getTypeface(), android.graphics.Typeface.BOLD);
            GradientDrawable btnBg = new GradientDrawable();
            btnBg.setColor(0xFFFF9800);
            btnBg.setCornerRadius(dpToPx(20));
            btnVote.setBackground(btnBg);
            btnVote.setPadding(0, dpToPx(10), 0, dpToPx(10));
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            btnLp.topMargin = dp12;
            btnVote.setLayoutParams(btnLp);

            btnVote.setOnClickListener(v -> {
                if (selectedIds.isEmpty()) {
                    Toast.makeText(ctx, "请选择投票选项", Toast.LENGTH_SHORT).show();
                    return;
                }
                btnVote.setEnabled(false);
                btnVote.setText("提交中...");
                submitPollVote(poll, selectedIds, btnVote);
            });

            card.addView(btnVote);

        } else {
            // ============ 结果模式：显示投票结果（百分比 + 进度条） ============
            for (int i = 0; i < totalOptions; i++) {
                Poll.Option opt = poll.getOptions().get(i);
                boolean isLast = (i == totalOptions - 1);

                LinearLayout optRow = new LinearLayout(ctx);
                optRow.setOrientation(LinearLayout.HORIZONTAL);
                optRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                if (!isLast) rowLp.bottomMargin = dp12;
                optRow.setLayoutParams(rowLp);

                // 选项文本
                TextView tvOpt = new TextView(ctx);
                tvOpt.setText((i + 1) + ". " + opt.getText());
                tvOpt.setTextColor(colorOptionText);
                tvOpt.setTextSize(13);
                tvOpt.setSingleLine(false);
                tvOpt.setMaxLines(2);
                LinearLayout.LayoutParams optLp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                optLp.rightMargin = dp8;
                tvOpt.setLayoutParams(optLp);
                optRow.addView(tvOpt);

                // 百分比文本
                TextView tvPct = new TextView(ctx);
                tvPct.setText(String.format(java.util.Locale.getDefault(), "%.1f%%", opt.getPercent()));
                tvPct.setTextColor(colorPercent);
                tvPct.setTextSize(12);
                LinearLayout.LayoutParams pctLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                pctLp.rightMargin = dp8;
                tvPct.setLayoutParams(pctLp);
                optRow.addView(tvPct);

                // 票数
                if (opt.getVoteCount() > 0) {
                    TextView tvCount = new TextView(ctx);
                    tvCount.setText("(" + opt.getVoteCount() + "票)");
                    tvCount.setTextColor(colorPercent);
                    tvCount.setTextSize(11);
                    optRow.addView(tvCount);
                }

                card.addView(optRow);

                // 进度条
                float pct = Math.max(0f, Math.min(100f, (float) opt.getPercent()));
                int fillColor = PollBarColorManager.resolveColor();
                if (opt.getBarColor() != null && !opt.getBarColor().isEmpty()
                        && PollBarColorManager.getCustomColor() == 0) {
                    try {
                        fillColor = android.graphics.Color.parseColor(opt.getBarColor());
                    } catch (Exception ignored) {}
                }

                LinearLayout barRow = new LinearLayout(ctx);
                barRow.setOrientation(LinearLayout.HORIZONTAL);
                barRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams barRowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(6));
                barRowLp.bottomMargin = isLast ? 0 : dp12;
                barRow.setLayoutParams(barRowLp);

                View barFill = new View(ctx);
                LinearLayout.LayoutParams barFillLp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, pct);
                barFill.setLayoutParams(barFillLp);
                GradientDrawable barFillDrawable = new GradientDrawable();
                barFillDrawable.setColor(fillColor);
                barFillDrawable.setCornerRadius(dpToPx(3));
                barFill.setBackground(barFillDrawable);
                barRow.addView(barFill);

                View barBg = new View(ctx);
                LinearLayout.LayoutParams barBgLp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 100f - pct);
                barBg.setLayoutParams(barBgLp);
                GradientDrawable barBgDrawable = new GradientDrawable();
                barBgDrawable.setColor(colorBarBg);
                barBgDrawable.setCornerRadius(dpToPx(3));
                barBg.setBackground(barBgDrawable);
                barRow.addView(barBg);

                card.addView(barRow);
            }

            // 底部提示消息（如"您已经投过票,谢谢您的参与" 或 "您需要登录后才可以参与投票"）
            String bottomMsg = poll.getBottomMessage();
            if (bottomMsg != null && !bottomMsg.isEmpty()) {
                TextView tvBottom = new TextView(ctx);
                tvBottom.setText(bottomMsg);
                tvBottom.setTextColor(colorMeta);
                tvBottom.setTextSize(12);
                tvBottom.setSingleLine(false);
                LinearLayout.LayoutParams bottomLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                bottomLp.topMargin = dp8;
                tvBottom.setLayoutParams(bottomLp);
                card.addView(tvBottom);
            } else if (!poll.isClosed() && !httpClient.isLoggedIn()) {
                // 兜底：未登录且无底部消息时显示默认提示
                TextView tvLoginHint = new TextView(ctx);
                tvLoginHint.setText("登录后可以参与投票");
                tvLoginHint.setTextColor(colorMeta);
                tvLoginHint.setTextSize(12);
                LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                hintLp.topMargin = dp8;
                tvLoginHint.setLayoutParams(hintLp);
                card.addView(tvLoginHint);
            }
        }

        container.addView(card);
    }

    /**
     * 提交投票
     */
    private void submitPollVote(Poll poll, java.util.Set<String> selectedIds, android.widget.Button btnVote) {
        new Thread(() -> {
            try {
                httpClient.syncFromCookieManager();
                Map<String, String> params = new HashMap<>();
                params.put("formhash", poll.getFormhash() != null ? poll.getFormhash() : "");
                for (String id : selectedIds) {
                    params.put("pollanswers[]", id);
                }
                String referer = ForumParser.getBaseDomain() + "forum.php?mod=viewthread&tid=" + tid;
                String result = httpClient.postWithReferer(poll.getActionUrl(), params, referer);

                runOnUiThread(() -> {
                    if (result != null && (result.contains("投票成功") || result.contains("感谢您参与")
                            || result.contains("succeedhandle") || result.contains("succeed"))) {
                        Toast.makeText(this, "投票成功", Toast.LENGTH_SHORT).show();
                        // 刷新帖子以显示最新投票结果
                        reloadThreadDetail();
                    } else if (result != null && result.contains("已经参与")) {
                        Toast.makeText(this, "您已经参与过此投票", Toast.LENGTH_SHORT).show();
                        reloadThreadDetail();
                    } else if (result != null && result.contains("投票已经结束")) {
                        Toast.makeText(this, "投票已经结束", Toast.LENGTH_SHORT).show();
                        reloadThreadDetail();
                    } else {
                        Toast.makeText(this, "投票提交完成", Toast.LENGTH_SHORT).show();
                        reloadThreadDetail();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "投票失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    if (btnVote != null) {
                        btnVote.setEnabled(true);
                        btnVote.setText("投票");
                    }
                });
            }
        }).start();
    }

    /**
     * 刷新帖子详情（投票/回复等操作后调用）
     */
    private void reloadThreadDetail() {
        loadPostDetail();
    }

    private void applyThreadPageColors() {
        int topBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveThreadTopBg();
        int threadBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveThreadBg();
        int replyBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveReplyBarBg();
        int actionBtnBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveThreadActionBtnBg();
        if (binding.toolbar != null) {
            binding.toolbar.setBackgroundColor(topBg);
        }
        if (binding.layoutThreadHeader != null) {
            binding.layoutThreadHeader.setBackgroundColor(threadBg);
        }
        if (binding.layoutReply != null) {
            binding.layoutReply.setBackgroundColor(replyBg);
        }
        if (binding.btnReward != null) {
            applyActionButtonBackground(binding.btnReward, actionBtnBg);
        }
        if (binding.btnKick != null) {
            applyActionButtonBackground(binding.btnKick, actionBtnBg);
        }
    }

    private void applyActionButtonBackground(android.widget.Button button, int color) {
        if (button == null) return;
        // 清除可能的背景着色
        button.setBackgroundTintList(null);
        if (button instanceof androidx.appcompat.widget.AppCompatButton) {
            ((androidx.appcompat.widget.AppCompatButton) button).setSupportBackgroundTintList(null);
        }
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        drawable.setColor(color);
        drawable.setCornerRadius(dpToPx(20));
        button.setBackground(drawable);
        button.requestLayout();
        button.invalidate();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }

    /**
     * 将黑名单关键词写入文件（应用外部私有目录，无需额外权限）
     * @return 文件对象，写入失败时返回 null
     */
    private java.io.File writeBlacklistToFile(java.util.List<String> keywords, String fileName) {
        try {
            java.io.File dir = getExternalFilesDir("blacklist");
            if (dir == null) dir = getFilesDir();
            if (!dir.exists()) dir.mkdirs();
            java.io.File file = new java.io.File(dir, fileName);
            java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.OutputStreamWriter(
                    new java.io.FileOutputStream(file), java.nio.charset.StandardCharsets.UTF_8));
            pw.println("# MT论坛黑名单过滤导出文件");
            pw.println("# 导出时间: " + java.text.SimpleDateFormat.getDateTimeInstance()
                    .format(new java.util.Date()));
            pw.println("# 每行一个关键词，空行和#开头的行为注释");
            pw.println();
            for (String kw : keywords) {
                pw.println(kw);
            }
            pw.close();
            return file;
        } catch (Exception e) {
            android.util.Log.e("MT_DEBUG", "writeBlacklistToFile failed", e);
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 编辑成功后从服务端重新拉取，而不是拿本地 BBCode 直接贴到界面：
        // 论坛会对正文再做一遍解析（附件、表情、隐藏内容），本地拼接必然与实际不一致。
        if (requestCode == REQUEST_EDIT_THREAD || requestCode == REQUEST_EDIT_REPLY) {
            if (resultCode == RESULT_OK) {
                boolean deleted = data != null
                        && data.getBooleanExtra(EditPostActivity.RESULT_DELETED, false);
                if (deleted) {
                    boolean deletedThread = data.getBooleanExtra(
                            EditPostActivity.RESULT_DELETED_THREAD, false);
                    if (deletedThread) {
                        // 整帖已不存在，留在详情页只会刷出错误页，直接退回列表
                        // 并通知上一层刷新，避免列表里还留着已删除的帖子。
                        Toast.makeText(this, R.string.edit_post_delete_success,
                                Toast.LENGTH_SHORT).show();
                        Intent back = new Intent();
                        back.putExtra("deleted_tid", tid);
                        setResult(RESULT_OK, back);
                        finish();
                        return;
                    }
                    // 删的是评论：只在本地移除该楼层并同步回复数，
                    // 不整体刷新详情，保留“加载全部评论”已经加载的内容和当前位置。
                    String deletedPid = data.getStringExtra(EditPostActivity.RESULT_PID);
                    removeReplyLocally(deletedPid);
                    Toast.makeText(this, R.string.edit_post_delete_success,
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(this, R.string.edit_post_success, Toast.LENGTH_SHORT).show();
                binding.swipeRefresh.setRefreshing(true);
                refreshPostDetail();
            }
            return;
        }
        if (requestCode == 1001 && resultCode == RESULT_OK && data != null) {
            android.net.Uri uri = data.getData();
            if (uri == null) return;
            try {
                java.io.InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) return;
                java.io.BufferedReader reader = new java.io.BufferedReader(
                        new java.io.InputStreamReader(is, java.nio.charset.StandardCharsets.UTF_8));
                ReplyBlacklistManager mgr = ReplyBlacklistManager.getInstance(this);
                String line;
                int added = 0;
                int skipped = 0;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    if (mgr.addKeyword(line)) {
                        added++;
                    } else {
                        skipped++;
                    }
                }
                reader.close();
                if (added > 0 || skipped > 0) {
                    String msg = "已导入 " + added + " 个关键词";
                    if (skipped > 0) msg += "（跳过 " + skipped + " 个重复）";
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
                    updateReplyFilterAndOrder();
                    // 如果黑名单弹窗还在显示，重新创建弹窗以刷新列表
                    if (mBlacklistDialog != null && mBlacklistDialog.isShowing()) {
                        mBlacklistDialog.dismiss();
                        showBlacklistDialog();
                    }
                } else {
                    Toast.makeText(this, "未找到有效关键词", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "导入失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // ★ 配色变更自动重渲染：从主题设置页返回时，若配色指纹变化，重新渲染正文区
        if (cachedContentHtml != null) {
            int fp = com.forum.MT.ui.widget.ThemeVersionManager.fingerprint(this);
            if (fp != cachedThemeFingerprint) {
                cachedThemeFingerprint = fp;
                reRenderMainContent();
            }
        }
    }

    private void reRenderMainContent() {
        try {
            binding.frameContent.removeAllViews();
            binding.tvContent.setText("");
            preloadMainContentSmileys(cachedContentHtml, cachedMainTables,
                    binding.frameContent, binding.tvContent,
                    cachedImageUrls, cachedQuoteCards, cachedCodeCards, cachedHiddenCards);
            // 重新加载图片容器
            binding.llImagesContainer.removeAllViews();
            if (cachedImageUrls != null && !cachedImageUrls.isEmpty()) {
                binding.llImagesContainer.setVisibility(View.VISIBLE);
                for (String imgUrl : cachedImageUrls) {
                    ImageView imageView = new ImageView(this);
                    imageView.setLayoutParams(new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT));
                    imageView.setAdjustViewBounds(true);
                    imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    imageView.setBackgroundColor(0xFFF0F0F0);
                    imageView.setOnClickListener(v -> openImagePreview(imgUrl));
                    Glide.with(this)
                            .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(imgUrl))
                            .placeholder(new ColorDrawable(0xFFF0F0F0))
                            .timeout(15000)
                            .error(createFailedImageDrawable())
                            .into(imageView);
                    binding.llImagesContainer.addView(imageView);
                }
            } else {
                binding.llImagesContainer.setVisibility(View.GONE);
            }
            // 回复列表也重渲染（引用、代码、表格卡片配色）
            if (replyAdapter != null) {
                replyAdapter.notifyDataSetChanged();
            }
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_QUOTE", "[onResume] theme fingerprint changed -> re-rendered main content");
        } catch (Exception e) {
            android.util.Log.e("MT_QUOTE", "[onResume] re-render failed", e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        com.forum.MT.ui.widget.CommentBorderDrawable.setListener(null);
        com.forum.MT.ui.widget.HomeBarColorManager.setListener(null);
        mFailedImageUrls.clear();
    }

}