package com.forum.MT.network;

import android.text.TextUtils;

import androidx.annotation.Nullable;

import com.forum.MT.model.BannedUser;
import com.forum.MT.model.ChatMessage;
import com.forum.MT.model.ForumCategory;
import com.forum.MT.model.Poll;
import com.forum.MT.model.PostDetail;
import com.forum.MT.model.RankThread;
import com.forum.MT.model.ReplyItem;
import com.forum.MT.model.Thread;
import com.forum.MT.model.Message;
import com.forum.MT.model.UserProfile;
import com.forum.MT.model.Friend;
import com.forum.MT.model.NoticeItem;
import com.forum.MT.model.NoticeData;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;
import org.jsoup.select.Elements;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;

/**
 * 论坛 HTML 解析器
 * 解析 Discuz! 移动端输出的结构化 HTML
 */
public class ForumParser {

    private static final String BASE_DOMAIN = "https://bbs.binmt.cc/";

    public static String getBaseDomain() {
        return BASE_DOMAIN;
    }

    /**
     * 解析首页/帖子列表（Comiis App 模板适配）
     */
    public static List<Thread> parseThreadList(String html) {
        List<Thread> threads = new ArrayList<>();
        Document doc = Jsoup.parse(html);

        // Comiis App 模板的帖子容器
        Elements items = doc.select("li.forumlist_li");
        if (items.isEmpty()) {
            // 兜底：查找包含 thread- 链接的 li 元素
            Elements links = doc.select("a[href*=thread-]");
            for (Element link : links) {
                Element parent = link.closest("li");
                if (parent != null) {
                    items.add(parent);
                }
            }
        }

        // 预编译正则
        Pattern tidPattern = Pattern.compile("thread-(\\d+)-1-1\\.html");
        Pattern fidPattern = Pattern.compile("forum-(\\d+)-1\\.html");

        for (Element item : items) {
            try {
                Thread t = new Thread();

                // === 标题 & tid ===
                Element titleLink = item.select(".mmlist_li_box h2 a[href*=thread-]").first();
                if (titleLink == null) {
                    titleLink = item.select("a[href*=thread-]").first();
                }
                if (titleLink == null) continue;

                String href = titleLink.attr("href");
                Matcher tidMatcher = tidPattern.matcher(href);
                if (!tidMatcher.find()) continue;
                t.setTid(tidMatcher.group(1));

                // 标题：只取 ownText（排除热度徽章等子元素文本）
                String title = titleLink.ownText().trim();
                if (title.isEmpty()) title = titleLink.text().trim();

                // === 回收站标记 ===
                // 帖子被移入回收站后，Comiis 模板会在标题链接内多输出一个标记元素
                // （常见 em/span，可能还带 comiis_font 图标字符）。第三方客户端直接取
                // .text() 会把它和标题拼成「回收站灌水」，这里识别后单独渲染成红框徽章。
                if (markRecycledFromMarker(titleLink, title, t)
                        || markRecycledFromMarker(titleLink.parent(), title, t)) {
                    title = stripRecycleMarker(title);
                }
                t.setClosed(hasClosedMarker(item, titleLink, title));
                t.setTitle(title);

                // === 作者 ===
                Element authorEl = item.select(".forumlist_li_top .top_user").first();
                if (authorEl != null) {
                    t.setAuthor(authorEl.text().trim());
                    // 从作者链接中提取 UID
                    String authorHref = authorEl.attr("href");
                    Matcher m = Pattern.compile("uid=(\\d+)").matcher(authorHref);
                    if (m.find()) t.setAuthorUid(m.group(1));
                }

                // === 头像 ===
                Element avatarEl = item.select(".forumlist_li_top .top_tximg").first();
                if (avatarEl != null) {
                    String src = avatarEl.attr("src");
                    if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                    t.setAvatarUrl(src);
                }

                // === 等级 ===
                Element levelEl = item.select(".forumlist_li_top .top_lev").first();
                if (levelEl != null) {
                    t.setAuthorLevel(levelEl.text().trim());
                }

                // === 发布时间 ===
                Element timeEl = item.select(".forumlist_li_time .f_d").first();
                if (timeEl != null) {
                    t.setPublishTime(timeEl.text().trim());
                }

                // === 版块 ===
                Element forumLink = item.select(".comiis_xznalist_bk a[href*=forum-]").first();
                if (forumLink != null) {
                    // 版块名称：ownText 排除 <i> 图标文字
                    String forumName = forumLink.ownText().trim();
                    if (forumName.isEmpty()) forumName = forumLink.text().trim();
                    t.setForumName(forumName);

                    String forumHref = forumLink.attr("href");
                    Matcher fidMatcher = fidPattern.matcher(forumHref);
                    if (fidMatcher.find()) t.setForumFid(fidMatcher.group(1));
                }

                // === 内容摘要 ===
                Element summaryEl = item.select(".list_body .f_b").first();
                if (summaryEl != null) {
                    t.setSummary(summaryEl.text().trim());
                }

                // === 统计信息（点赞/回复/查看） ===
                Elements stats = item.select(".comiis_xznalist_bottom ul li .comiis_tm");
                // 顺序：第1个=点赞，第2个=回复，第3个=查看
                if (stats.size() >= 3) {
                    t.setLikes(parseIntFromText(stats.get(0).text()));
                    t.setReplies(parseIntFromText(stats.get(1).text()));
                    t.setViews(parseIntFromText(stats.get(2).text()));
} else if (stats.size() >= 2) {
                    t.setLikes(parseIntFromText(stats.get(0).text()));
                    t.setReplies(parseIntFromText(stats.get(1).text()));
                }

                // === 特殊标记 ===
                // 图片检测
                t.setHasImage(item.select(".mmlist_li_box .comiis_pyqlist_imgs, .mmlist_li_box .comiis_pyqlist_img").size() > 0);
                
                // 提取帖子封面图URL
                Element imgEl = item.select(".mmlist_li_box .comiis_pyqlist_imgs img, .mmlist_li_box .comiis_pyqlist_img img, .mmlist_li_box img").first();
                if (imgEl != null) {
                    String imgSrc = firstNonEmptyAttr(imgEl, "comiis_loadimages", "data-original", "data-src", "data-file", "file", "src");
                    if (!TextUtils.isEmpty(imgSrc)) {
                        String fullUrl = resolveAttachmentUrl(imgSrc);
                        if (isPostImageUrl(fullUrl)) {
                            t.setThumbnailUrl(fullUrl);
                        }
                    }
                }

// === 隐藏内容检测 ===
                Element bodyText = item.select(".list_body .f_b").first();
                if (bodyText != null && bodyText.text().contains("本内容被作者隐藏")) {
                    t.setHasHiddenContent(true);
                }

                populateThreadImages(item, t);
                t.setSticky(isStickyThread(item));

                threads.add(t);
            } catch (Exception ignored) {}
        }

        return threads;
    }

    /**
     * 解析搜索结果列表
     * 解析搜索结果列表（Comiis 手机版模板适配）
     * 手机版搜索结果页使用与首页/版块列表相同的 Comiis 模板结构。
     *
     * DOM 结构（手机版搜索结果页）：
     *   div.comiis_forumlist.comiis_xznlist > ul
     *     li.forumlist_li.comiis_znalist ── 每个搜索结果条目
     *       .forumlist_li_top
     *         img.top_tximg                        ── 头像
     *         .top_user                            ── 作者
     *         .top_lev                             ── 等级
     *         .forumlist_li_time .f_d              ── 发布时间
     *       .mmlist_li_box h2 a[href*=thread-]     ── 标题链接（含 tid）
     *       .list_body a.f_b                       ── 内容摘要
     *       .comiis_xznalist_bk a[href*=forum-]    ── 版块
     *       .comiis_xznalist_bottom ul li .comiis_tm ── 点赞/回复/查看数
     *
     * @param html 搜索结果页 HTML
     * @return 帖子列表
     */
    public static List<Thread> parseSearchResults(String html) {
        List<Thread> threads = new ArrayList<>();
        Document doc = Jsoup.parse(html);

        // Comiis 手机版搜索结果容器
        Elements items = doc.select("li.forumlist_li");
        if (items.isEmpty()) {
            // 兜底：查找包含 thread- 链接的 li 元素
            Elements links = doc.select("a[href*=thread-]");
            for (Element link : links) {
                Element parent = link.closest("li");
                if (parent != null) {
                    items.add(parent);
                }
            }
        }

        // 预编译正则
        Pattern tidPattern = Pattern.compile("thread-(\\d+)-1-1\\.html");
        Pattern fidPattern = Pattern.compile("forum-(\\d+)-1\\.html");

        for (Element item : items) {
            try {
                Thread t = new Thread();

                // === 标题 & tid ===
                Element titleLink = item.select(".mmlist_li_box h2 a[href*=thread-]").first();
                if (titleLink == null) {
                    titleLink = item.select("a[href*=thread-]").first();
                }
                if (titleLink == null) continue;

                String href = titleLink.attr("href");
                Matcher tidMatcher = tidPattern.matcher(href);
                if (!tidMatcher.find()) continue;
                t.setTid(tidMatcher.group(1));

                // 标题：用 text() 获取完整文本（高亮关键词被 <strong><font> 包裹）
                String title = titleLink.text().trim();
                if (title.isEmpty()) continue;
                t.setTitle(title);

                // === 作者 ===
                Element authorEl = item.select(".forumlist_li_top .top_user").first();
                if (authorEl != null) {
                    t.setAuthor(authorEl.text().trim());
                    String authorHref = authorEl.attr("href");
                    Matcher m = Pattern.compile("uid=(\\d+)").matcher(authorHref);
                    if (m.find()) t.setAuthorUid(m.group(1));
                }

                // === 头像 ===
                Element avatarEl = item.select(".forumlist_li_top .top_tximg").first();
                if (avatarEl != null) {
                    String src = avatarEl.attr("src");
                    if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                    t.setAvatarUrl(src);
                }

                // === 等级 ===
                Element levelEl = item.select(".forumlist_li_top .top_lev").first();
                if (levelEl != null) {
                    t.setAuthorLevel(levelEl.text().trim());
                }

                // === 发布时间 ===
                Element timeEl = item.select(".forumlist_li_time .f_d").first();
                if (timeEl != null) {
                    t.setPublishTime(timeEl.text().trim());
                }

                // === 版块 ===
                Element forumLink = item.select(".comiis_xznalist_bk a[href*=forum-]").first();
                if (forumLink != null) {
                    String forumName = forumLink.ownText().trim();
                    if (forumName.isEmpty()) forumName = forumLink.text().trim();
                    t.setForumName(forumName);

                    String forumHref = forumLink.attr("href");
                    Matcher fidMatcher = fidPattern.matcher(forumHref);
                    if (fidMatcher.find()) t.setForumFid(fidMatcher.group(1));
                }

                // === 内容摘要 ===
                Element summaryEl = item.select(".list_body .f_b").first();
                if (summaryEl != null) {
                    String summaryText = summaryEl.text().trim();
                    t.setSummary(summaryText);
                    if (summaryText.contains("本内容被作者隐藏")) {
                        t.setHasHiddenContent(true);
                    }
                }

                // === 统计信息（点赞/回复/查看） ===
                Elements stats = item.select(".comiis_xznalist_bottom ul li .comiis_tm");
                if (stats.size() >= 3) {
                    t.setLikes(parseIntFromText(stats.get(0).text()));
                    t.setReplies(parseIntFromText(stats.get(1).text()));
                    t.setViews(parseIntFromText(stats.get(2).text()));
                } else if (stats.size() >= 2) {
                    t.setLikes(parseIntFromText(stats.get(0).text()));
                    t.setReplies(parseIntFromText(stats.get(1).text()));
                }

                // === 图片检测 ===
                t.setHasImage(item.select(".mmlist_li_box .comiis_pyqlist_imgs, .mmlist_li_box .comiis_pyqlist_img").size() > 0);
                
                // 提取帖子封面图URL
                Element imgEl = item.select(".mmlist_li_box .comiis_pyqlist_imgs img, .mmlist_li_box .comiis_pyqlist_img img, .mmlist_li_box img").first();
                if (imgEl != null) {
                    String imgSrc = firstNonEmptyAttr(imgEl, "comiis_loadimages", "data-original", "data-src", "data-file", "file", "src");
                    if (!TextUtils.isEmpty(imgSrc)) {
                        String fullUrl = resolveAttachmentUrl(imgSrc);
                        if (isPostImageUrl(fullUrl)) {
                            t.setThumbnailUrl(fullUrl);
                        }
                    }
                }

                populateThreadImages(item, t);
                threads.add(t);
            } catch (Exception ignored) {}
        }

        return threads;
    }

    /**
     * 解析版块内帖子列表（forumdisplay 页面，Comiis App 模板适配）
     * 与 parseThreadList() 使用相同 Comiis 模板选择器
     */
    public static List<Thread> parseForumThreadList(String html) {
        List<Thread> threads = new ArrayList<>();
        Document doc = Jsoup.parse(html);

        // Comiis App 模板的帖子容器
        Elements items = doc.select("li.forumlist_li");
        if (items.isEmpty()) {
            // 兜底：查找包含 thread- 链接的 li 元素
            Elements links = doc.select("a[href*=thread-]");
            for (Element link : links) {
                Element parent = link.closest("li");
                if (parent != null) {
                    items.add(parent);
                }
            }
        }

        // 预编译正则
        Pattern tidPattern = Pattern.compile("thread-(\\d+)-1-1\\.html");
        Pattern fidPattern = Pattern.compile("forum-(\\d+)-1\\.html");

        for (Element item : items) {
            try {
                Thread t = new Thread();

                // === 标题 & tid ===
                Element titleLink = item.select(".mmlist_li_box h2 a[href*=thread-]").first();
                if (titleLink == null) {
                    titleLink = item.select("a[href*=thread-]").first();
                }
                if (titleLink == null) continue;

                String href = titleLink.attr("href");
                Matcher tidMatcher = tidPattern.matcher(href);
                if (!tidMatcher.find()) continue;
                t.setTid(tidMatcher.group(1));

                // 标题：只取 ownText（排除热度徽章等子元素文本）
                String title = titleLink.ownText().trim();
                if (title.isEmpty()) title = titleLink.text().trim();

                // === 回收站标记 ===
                // 已移入回收站的帖子，模板会在标题链接内多输出一个标记元素，
                // 识别后从标题剔除，交由列表单独渲染成红框徽章。
                if (markRecycledFromMarker(titleLink, title, t)
                        || markRecycledFromMarker(titleLink.parent(), title, t)) {
                    title = stripRecycleMarker(title);
                }
                t.setClosed(hasClosedMarker(item, titleLink, title));
                t.setTitle(title);

                // === 作者 ===
                Element authorEl = item.select(".forumlist_li_top .top_user").first();
                if (authorEl != null) {
                    t.setAuthor(authorEl.text().trim());
                    // 从作者链接中提取 UID
                    String authorHref = authorEl.attr("href");
                    Matcher m = Pattern.compile("uid=(\\d+)").matcher(authorHref);
                    if (m.find()) t.setAuthorUid(m.group(1));
                }

                // === 头像 ===
                Element avatarEl = item.select(".forumlist_li_top .top_tximg").first();
                if (avatarEl != null) {
                    String src = avatarEl.attr("src");
                    if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                    t.setAvatarUrl(src);
                }

                // === 等级 ===
                Element levelEl = item.select(".forumlist_li_top .top_lev").first();
                if (levelEl != null) {
                    t.setAuthorLevel(levelEl.text().trim());
                }

                // === 发布时间 ===
                Element timeEl = item.select(".forumlist_li_time .f_d").first();
                if (timeEl != null) {
                    t.setPublishTime(timeEl.text().trim());
                }

                // === 版块 ===
                Element forumLink = item.select(".comiis_xznalist_bk a[href*=forum-]").first();
                if (forumLink != null) {
                    // 版块名称：ownText 排除 <i> 图标文字
                    String forumName = forumLink.ownText().trim();
                    if (forumName.isEmpty()) forumName = forumLink.text().trim();
                    t.setForumName(forumName);

                    String forumHref = forumLink.attr("href");
                    Matcher fidMatcher = fidPattern.matcher(forumHref);
                    if (fidMatcher.find()) t.setForumFid(fidMatcher.group(1));
                }

                // === 内容摘要 ===
                Element summaryEl = item.select(".list_body .f_b").first();
                if (summaryEl != null) {
                    t.setSummary(summaryEl.text().trim());
                }

                // === 统计信息（点赞/回复/查看） ===
                Elements stats = item.select(".comiis_xznalist_bottom ul li .comiis_tm");
                // 顺序：第1个=点赞，第2个=回复，第3个=查看
                if (stats.size() >= 3) {
                    t.setLikes(parseIntFromText(stats.get(0).text()));
                    t.setReplies(parseIntFromText(stats.get(1).text()));
                    t.setViews(parseIntFromText(stats.get(2).text()));
} else if (stats.size() >= 2) {
                    t.setLikes(parseIntFromText(stats.get(0).text()));
                    t.setReplies(parseIntFromText(stats.get(1).text()));
                }

                // === 特殊标记 ===
                // 图片检测
                t.setHasImage(item.select(".mmlist_li_box .comiis_pyqlist_imgs, .mmlist_li_box .comiis_pyqlist_img").size() > 0);
                
                // 提取帖子封面图URL
                Element imgEl = item.select(".mmlist_li_box .comiis_pyqlist_imgs img, .mmlist_li_box .comiis_pyqlist_img img, .mmlist_li_box img").first();
                if (imgEl != null) {
                    String imgSrc = firstNonEmptyAttr(imgEl, "comiis_loadimages", "data-original", "data-src", "data-file", "file", "src");
                    if (!TextUtils.isEmpty(imgSrc)) {
                        String fullUrl = resolveAttachmentUrl(imgSrc);
                        if (isPostImageUrl(fullUrl)) {
                            t.setThumbnailUrl(fullUrl);
                        }
                    }
                }

                // 隐藏内容检测
                Element bodyText = item.select(".list_body .f_b").first();
                if (bodyText != null && bodyText.text().contains("本内容被作者隐藏")) {
                    t.setHasHiddenContent(true);
                }

                populateThreadImages(item, t);

                // 置顶标记兼容 Comiis 的“热度”徽章和常见 sticky 标记。
                t.setSticky(isStickyThread(item));

                threads.add(t);
            } catch (Exception ignored) {}
        }

        return threads;
    }

    private static boolean isStickyThread(Element item) {
        if (item == null) return false;
        if (!item.select("span[title^=\"热度\"], [title*=\"置顶\"], [class*=\"sticky\"], [class*=\"thread_sticky\"], [class*=\"threadtop\"]").isEmpty()) {
            return true;
        }
        for (Element marker : item.select("span, em, i, label")) {
            String text = marker.text().trim();
            if (text.equals("置顶") || text.contains("置顶")) return true;
        }
        return false;
    }
    /**
     * 解析版块分类列表（Comiis App 模板适配）
     * 数据来源：forum.php?forumlist=1&mobile=2
     *
     * DOM 结构（forumlist 页）：
     *   div.comiis_forumlist.comiis_km{gid} ── 每个分组
     *     div.comiis_bbs_show h2 a               ── 分组标题（如"MT专区"）
     *     div#sub_forum_{gid}.comiis_forum_nbox
     *       ul li a[href*=forum-]                ── 子版块链接
     *         img[alt]                              ── 版块名称
     *         img[src]                              ── 版块图标
     *
     * 备用结构（发帖弹窗页，部分 Comiis 版本仍在使用）：
     *   div.comiis_bbslists_gid ul > li.comiis_fxpostlistkey[fid={gid}]  ── 分组
     *     ul.comiis_fxpostlistbox_{gid} > li      ── 子版块
     */
    public static List<ForumCategory> parseForumCategories(String html) {
        List<ForumCategory> categories = new ArrayList<>();
        Document doc = Jsoup.parse(html);

        // === 主方案：forumlist 页面结构（forum.php?forumlist=1&mobile=2） ===
        Elements categoryBlocks = doc.select("div.comiis_forumlist");
        if (categoryBlocks.isEmpty()) {
            // 兜底：尝试发帖弹窗选择结构
            return parseForumCategoriesFromPostDialog(doc);
        }

        Pattern fidPattern = Pattern.compile("forum-(\\d+)-1\\.html");

        for (Element block : categoryBlocks) {
            try {
                // 分组标题：div.comiis_bbs_show h2 a
                Element titleEl = block.select("div.comiis_bbs_show h2 a").first();
                if (titleEl == null) continue;
                String categoryName = titleEl.text().trim();
                if (categoryName.isEmpty()) continue;

                // 该分组下的子版块
                List<ForumCategory.Forum> forums = new ArrayList<>();
                Elements forumLinks = block.select("div.comiis_forum_nbox ul li a[href*=forum-]");
                for (Element link : forumLinks) {
                    String href = link.attr("href");
                    Matcher m = fidPattern.matcher(href);
                    if (!m.find()) continue;
                    String fid = m.group(1);

                    // 版块名称：优先从 img[alt] 获取（更可靠）
                    Element img = link.select("img[alt]").first();
                    String fName = (img != null && !img.attr("alt").isEmpty())
                            ? img.attr("alt").trim()
                            : link.select("p").text().trim();
                    if (fName.isEmpty()) continue;

                    ForumCategory.Forum forum = new ForumCategory.Forum(fid, fName);

                    // 版块图标
                    Element iconImg = link.select("em img").first();
                    if (iconImg != null) {
                        String src = iconImg.attr("src");
                        if (!src.isEmpty()) {
                            if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                            forum.setIconUrl(src);
                        }
                    }

                    // 新帖数：解析 <span class="bg_a f_f">N</span> 徽章（今日新帖）
                    Element newPostsBadge = link.select("span.bg_a.f_f").first();
                    if (newPostsBadge != null) {
                        String badgeText = newPostsBadge.text().trim();
                        if (!badgeText.isEmpty()) {
                            try {
                                forum.setTodayPosts(Integer.parseInt(badgeText));
                            } catch (NumberFormatException ignored) {}
                        }
                    }

                    forums.add(forum);
                }

                if (!forums.isEmpty()) {
                    categories.add(new ForumCategory(categoryName, forums));
                }
            } catch (Exception ignored) {}
        }

        return categories;
    }

    /**
     * 备用解析：发帖弹窗中的板块选择结构（部分 Comiis 版本）
     * 分组 ul 中 li.comiis_fxpostlistkey[fid={gid}] ── 分组标题
     * 对应 ul.comiis_fxpostlistbox_{gid} > li       ── 子版块
     */
    private static List<ForumCategory> parseForumCategoriesFromPostDialog(Document doc) {
        List<ForumCategory> categories = new ArrayList<>();

        Elements groupLis = doc.select("div.comiis_bbslists_gid ul > li.comiis_fxpostlistkey");
        for (Element groupLi : groupLis) {
            try {
                String gid = groupLi.attr("fid");
                String categoryName = groupLi.select("a").text().trim();
                if (categoryName.isEmpty() || gid.isEmpty()) continue;

                List<ForumCategory.Forum> forums = new ArrayList<>();
                Elements subLis = doc.select("ul.comiis_fxpostlistbox_" + gid + " > li");
                for (Element subLi : subLis) {
                    Element link = subLi.select("a.bbslist_ico[href*=fid=]").first();
                    if (link == null) continue;
                    String href = link.attr("href");
                    String fid = extractParam(href, "fid");
                    if (fid == null) continue;

                    // 版块名称：优先 img[alt]
                    Element img = link.select("img[alt]").first();
                    String fName = img != null ? img.attr("alt").trim() : "";
                    if (fName.isEmpty()) {
                        Element nameEl = subLi.select("a.post_tit em").first();
                        if (nameEl != null) fName = nameEl.text().trim();
                    }
                    if (fName.isEmpty()) continue;

                    ForumCategory.Forum forum = new ForumCategory.Forum(fid, fName);

                    if (img != null) {
                        String src = img.attr("src");
                        if (!src.isEmpty()) {
                            if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                            forum.setIconUrl(src);
                        }
                    }

                    forums.add(forum);
                }

                if (!forums.isEmpty()) {
                    categories.add(new ForumCategory(categoryName, forums));
                }
            } catch (Exception ignored) {}
        }

        return categories;
    }

    /**
     * 检测服务器返回的 HTML 是否为登录页（Cookie 已过期/未登录）
     * 通过检查 Discuz! 登录表单特征来判断
     *
     * 注意：个人空间子页面（好友/粉丝/收藏/我的帖子/积分详情）各自有不同的 DOM 结构，
     * 检测时必须覆盖这些结构的"已登录特征"，否则会被误判为登录页。
     */
    public static boolean isLoginPage(String html) {
        if (TextUtils.isEmpty(html)) return true;
        Document doc = Jsoup.parse(html);

        // 明确登录页特征必须优先判断。登录页通常仍包含首页/热帖 thread- 链接，
        // 若先判断“多个 thread 链接”，会把登录页误判为已登录收藏页。
        Element loginForm = doc.select(
                "form[method=post][action*=login], form[method=post][action*=logging]").first();
        if (loginForm != null) return true;
        String pageTitle = doc.title().toLowerCase();
        if (pageTitle.contains("登录") || pageTitle.contains("login")) return true;
        if (doc.select("input[type=password]").size() > 0) return true;

        // === 正向确认：页面含有已登录特征 → 快速返回 false ===
        // 这些特征出现在已登录的各种页面中，优先级高于登录表单检测（避免误判）

        // 特征A：好友/粉丝列表 — 存在多个 a[href*=uid=] 链接（含用户名文本）
        Elements uidLinks = doc.select("a[href*=uid=]");
        if (uidLinks.size() >= 2) {
            boolean hasUsernames = false;
            for (Element link : uidLinks) {
                if (!TextUtils.isEmpty(link.text().trim())) {
                    hasUsernames = true;
                    break;
                }
            }
            if (hasUsernames) return false;
        }

        // 特征B：收藏/帖子列表 — 存在多个 a[href*=thread-] 链接（含标题文本）
        Elements threadLinks = doc.select("a[href*=thread-]");
        if (threadLinks.size() >= 2) {
            boolean hasTitles = false;
            for (Element link : threadLinks) {
                if (!TextUtils.isEmpty(link.text().trim())) {
                    hasTitles = true;
                    break;
                }
            }
            if (hasTitles) return false;
        }

        // 特征C：帖子列表（Comiis 模板结构）
        if (doc.select("li.forumlist_li").size() > 0) return false;

        // 特征D：个人空间/资料页
        if (doc.select(".comiis_space_tx, .comiis_space_profile, .comiis_space_profileico, .comiis_space_profilejf").size() > 0) {
            return false;
        }

        // 走到这里：没有任何已登录特征，也没有明确的登录页特征
        // 安全的做法是返回 false（不武断判定为登录页），让调用方自行根据解析结果判断
        return false;
    }

    /**
     * 解析网页端关注状态。
     *
     * @return 1=已关注，0=未关注，-1=网页未提供可确认状态
     */
    public static int parseFollowState(String html) {
        if (TextUtils.isEmpty(html)) return -1;
        Document doc = Jsoup.parse(html);
        Elements buttons = doc.select(
                ".comiis_space_flw a#followmod, .comiis_space_flw a.followmod, "
                        + ".comiis_space_tx a#followmod, .comiis_space_tx a.followmod, "
                        + "a#followmod, a.followmod");
        if (buttons.isEmpty()) return -1;

        boolean sawAdd = false;
        boolean sawBg0 = false;
        for (Element button : buttons) {
            // Jsoup 会把 &amp; 还原，但这里再统一解码一次，兼容部分页面把链接编码在属性中。
            String href = button.attr("href").replace("&amp;", "&").toLowerCase();
            String text = button.text().trim();
            String classes = button.className().toLowerCase();

            // Comiis 已关注按钮的服务端/JS状态：op=del、已关注/取消关注、bg_b。
            if (href.contains("op=del") || text.contains("已关注")
                    || text.contains("取消关注") || classes.contains("bg_b")) {
                return 1;
            }
            // 未关注按钮的状态：op=add；未登录提示也只能表示当前未建立关注关系。
            if (href.contains("op=add") || href.contains("logging&action=login")
                    || href.contains("logging%26action%3dlogin")) {
                sawAdd = true;
            }
            // 登录后的 Comiis 页面有时只保留 bg_0，不输出 op=add href。
            // 注意不能把 bg_a（未登录按钮）当成明确未关注。
            if (classes.contains("bg_0")) sawBg0 = true;
        }
        if (sawAdd || sawBg0) return 0;
        return -1;
    }

    /**
     * 解析网页端好友状态。
     * Discuz! Comiis模板在用户空间页渲染好友操作按钮：
     *   非好友 → a[href*=ac=friend][href*=op=add]，文本“加好友”
     *   已是好友 → a[href*=ac=friend][href*=op=ignore]，文本“解除好友”/“删除好友”
     *   申请待验证 → 页面文本含“等待验证”/“等待对方确认”
     *
     * @return 0=非好友，1=已是好友，2=申请待验证，-1=未知
     */
    public static int parseFriendStatus(String html, Document doc) {
        if (TextUtils.isEmpty(html)) return -1;
        if (doc == null) doc = Jsoup.parse(html);

        // 1. 查找含 ac=friend 的链接
        Elements friendLinks = doc.select("a[href*=ac=friend]");
        boolean sawAdd = false;
        boolean sawIgnore = false;
        for (Element link : friendLinks) {
            String href = link.attr("href").replace("&amp;", "&").toLowerCase();
            String text = link.text().trim();
            if (href.contains("op=add")) {
                sawAdd = true;
            }
            if (href.contains("op=ignore") || href.contains("op=del")) {
                sawIgnore = true;
            }
            // 文本匹配（部分模板不输出 op 参数，仅有文本）
            if (text.contains("解除好友") || text.contains("删除好友")) {
                sawIgnore = true;
            }
            if (text.contains("加好友") || text.contains("加为好友")) {
                sawAdd = true;
            }
        }

        // 2. 已是好友
        if (sawIgnore) return 1;

        // 3. 申请待验证（文本标记，无链接）
        String bodyText = doc.body() == null ? "" : doc.body().text();
        if (bodyText.contains("等待验证") || bodyText.contains("等待对方确认")
                || bodyText.contains("好友申请已发送")) {
            return 2;
        }

        // 4. 非好友
        if (sawAdd) return 0;

        // 5. 未知
        return -1;
    }

    /** 判断关注列表页面是否包含可识别的用户条目或明确的空列表标记。 */
    public static boolean isFollowingListPage(String html) {
        if (TextUtils.isEmpty(html)) return false;
        Document doc = Jsoup.parse(html);
        if (!doc.select(".comiis_userlist01, .comiis_friend_boxs, .comiis_follow_box, .comiis_followlist").isEmpty()) {
            return true;
        }
        // 不同版本模板可能省略外层 class，但仍会保留关注列表语义和用户条目。
        String bodyText = doc.body() == null ? "" : doc.body().text();
        boolean hasFollowTitle = bodyText.contains("我的关注") || bodyText.contains("关注列表")
                || bodyText.contains("正在关注") || bodyText.contains("关注的人");
        boolean hasUserItem = !doc.select("li a[href*=uid=], a[href*=home.php?mod=space&uid=]").isEmpty();
        boolean hasEmptyMarker = bodyText.contains("暂无关注") || bodyText.contains("还没有关注")
                || bodyText.contains("没有关注");
        return hasFollowTitle && (hasUserItem || hasEmptyMarker);
    }

    /**
     * 解析用户信息
     * 适配 Comiis App 模板（bbs.binmt.cc 使用的第三方 Discuz! 模板）
     */
    public static UserProfile parseUserProfile(String html) {
        UserProfile profile = new UserProfile();
        Document doc = Jsoup.parse(html);

        // ============================================================
        // 1. 头部信息区：div.comiis_space_info > div.comiis_space_tx
        // ============================================================

        // 用户名：Comiis 模板使用 h2.fyy；兜底保留通用选择器
        Element usernameEl = doc.select(".comiis_space_tx h2, .username, .user_name, h1, .profile_name").first();
        if (usernameEl != null) profile.setUsername(usernameEl.text().trim());

        // 头像：★ 修复 — 必须限定在 .comiis_space_tx 范围内，否则会匹配到导航栏中的当前用户头像
        Element avatarEl = doc.select(".comiis_space_tx .user_img img, .comiis_space_tx img[src*=avatar], .comiis_space_tx img").first();
        // 兜底：从 avatar.php?uid=X 直接构造（最可靠）
        if (avatarEl == null) {
            avatarEl = doc.select("img[src*=avatar]").first();
        }
        if (avatarEl != null) {
            String src = avatarEl.attr("src");
            if (!src.startsWith("http")) src = BASE_DOMAIN + src;
            profile.setAvatarUrl(src);
        } else {
            // 最后兜底：如果解析到了UID，用 UID 构造头像 URL
            if (profile.getUid() != null && !profile.getUid().isEmpty()) {
                profile.setAvatarUrl(BASE_DOMAIN + "uc_server/avatar.php?uid=" + profile.getUid() + "&size=middle");
            }
        }

        // UID：从 "用户ID" 行前的 div.profile_rs 获取
        Element uidEl = doc.select(".comiis_space_profile li:contains(用户ID) .profile_rs, .uid, em:contains(UID)").first();
        if (uidEl != null) {
            String text = uidEl.text().trim();
            Matcher m = Pattern.compile("(\\d+)").matcher(text);
            if (m.find()) profile.setUid(m.group(1));
        }

        // 等级：Comiis 模板使用 span.kmlevs.kmlv（包含 Lv.X 文字）
        // ★ 修复：选择器优先级问题——第一个 .kmlevs 是性别图标（bg_boy/girl），不是等级。
        // 必须精确匹配同时包含 kmlevs 和 kmlv 类的元素（<span class="kmlevs kmlv">Lv.7</span>）
        // 去掉模糊的 .comiis_space_tx .kmlevs 以防止优先选中性别图标
        Element levelEl = doc.select(".comiis_space_tx .kmlevs.kmlv, .comiis_space_tx .kmlv, .level, .lv, em:contains(Lv)").first();
        if (levelEl != null) profile.setLevel(levelEl.text().trim());

        // 用户组：Comiis 模板使用 span.kmlev（如 "硕士生"）
        Element groupEl = doc.select(".comiis_space_tx .kmlev").first();
        if (groupEl != null) profile.setGroupName(groupEl.text().trim());
        // ============================================================
        // 1.1 当前登录用户对该用户的关注状态
        // ============================================================
        // 不能只看按钮文字：Comiis 在部分页面即使已关注也仍显示“关注”。
        // 统一按服务端生成的 href/class/确认弹窗解析；解析不到时保持 unknown，
        // 绝不能把 unknown 当成“未关注”，也不能用本地缓存覆盖它。
        int followState = parseFollowState(html);
        if (followState >= 0) {
            profile.setFollowed(followState == 1);
            profile.setFollowStateKnown(true);
        }

        // ============================================================
        // 1.2 当前登录用户与该用户的好友状态
        // ============================================================
        // Discuz! Comiis模板在用户空间页渲染好友操作按钮：
        //   非好友 → a[href*=ac=friend][href*=op=add]，文本“加好友”
        //   已是好友 → a[href*=ac=friend][href*=op=ignore]，文本“解除好友”
        //   申请待验证 → 页面文本含“等待验证”/“等待对方确认”
        // 解析不到时保持 -1（未知），上层默认按非好友处理（向后兼容）。
        profile.setFriendStatus(parseFriendStatus(html, doc));

        // ============================================================
        // 1.3 当前登录用户是否已拉黑该用户（Comiis 黑名单）
        // ============================================================
        // 主页操作栏：
        //   未拉黑 → <span class="f_b">拉黑ta</span>（JS: comiis_adduserblacklist()）
        //   已拉黑 → <span class="f_wb">解除拉黑</span>（href 含 op=blacklist&subop=delete）
        boolean blacklisted = false;
        if (html.contains("subop=delete") && html.contains("op=blacklist")) {
            blacklisted = true;
        } else if (doc.select("a[href*=op=blacklist][href*=subop=delete]").first() != null) {
            blacklisted = true;
        }
        profile.setBlocked(blacklisted);

        // ============================================================
        // 2. 统计数据图标区：div.comiis_space_profileico
        // ============================================================

        // 结构：ul > li > a > i + span，内容如 "帖子 1"、"回复 22"、"好友 52680"、"粉丝 436"

        // 帖子数
        Element threadEl = doc.select(".comiis_space_profileico li:contains(帖子) span, em:contains(帖子) + span, .thread_count").first();
        if (threadEl != null) profile.setThreads(parseIntFromText(threadEl.text()));

        // 回复数 / 帖子数（UserProfile 有 posts 字段）
        Element postsEl = doc.select(".comiis_space_profileico li:contains(回复) span, em:contains(回复) + span, .posts, .user_posts").first();
        if (postsEl != null) profile.setPosts(parseIntFromText(postsEl.text()));

        // 好友
        Element friendEl = doc.select(".comiis_space_profileico li:contains(好友) span, em:contains(好友) + span, .friend_count").first();
        if (friendEl != null) profile.setFriends(parseIntFromText(friendEl.text()));

        // 关注数位于 .comiis_space_tx 顶部摘要中，例如“2 关注”。
        // 不能从 profileico 按固定位置取值：当前论坛实际顺序是 帖子/回复/好友/粉丝/人气，第四项不是关注。
        Element followingEl = null;
        for (Element span : doc.select(".comiis_space_tx p span")) {
            String text = span.text().trim();
            if (text.matches(".*\\d[\\d,，]*\\s*关注$")) {
                followingEl = span;
                break;
            }
        }
        if (followingEl == null) {
            followingEl = doc.select(".comiis_space_profileico li:contains(关注) span, em:contains(关注) + span, .following_count").first();
        }
        if (followingEl != null) {
            profile.setFollowing(parseIntFromText(followingEl.text()));
        }

        // 粉丝
        Element followerEl = doc.select(".comiis_space_profileico li:contains(粉丝) span, em:contains(粉丝) + span, .follower_count").first();
        if (followerEl != null) profile.setFollowers(parseIntFromText(followerEl.text()));

        // 人气/浏览
        Element viewsEl = doc.select(".comiis_space_profileico li:contains(人气) span").first();
        if (viewsEl != null) profile.setViews(parseIntFromText(viewsEl.text()));

        // ============================================================
        // 3. 积分/金币区域：div.comiis_space_profilejf
        // ============================================================
        // 结构：ul > li.b_t.b_r（4列：积分、好评、金币、信誉）
        Elements profileJfLis = doc.select(".comiis_space_profilejf ul li");

        // 积分（第1个 li）
        if (profileJfLis.size() >= 1) {
            Element creditsEl = profileJfLis.get(0).select(".f_0, span").first();
            if (creditsEl == null) creditsEl = profileJfLis.get(0); // 兜底取整个 li 文本
            profile.setCredits(parseIntFromText(creditsEl.text()));
        }

        // 金币（第3个 li）
        if (profileJfLis.size() >= 3) {
            Element goldEl = profileJfLis.get(2).select(".f_0, span").first();
            if (goldEl == null) goldEl = profileJfLis.get(2);
            profile.setGold(parseIntFromText(goldEl.text()));
        }

        // ============================================================
        // 4. 详细资料区：div.comiis_space_profile（UID、生日、性别、在线时间、注册时间、最后访问）
        // ============================================================
        // 结构：ul > li.b_t > div.profile_rs + span（标签名）

        // 注册时间
        Element regLi = doc.select(".comiis_space_profile li:contains(注册时间)").first();
        if (regLi != null) {
            Element regVal = regLi.select(".profile_rs").first();
            if (regVal != null) profile.setRegDate(regVal.text().trim());
        } else {
            // 兜底
            Element regEl = doc.select("li:contains(注册时间), .regdate").first();
            if (regEl != null) profile.setRegDate(regEl.text().replace("注册时间:", "").trim());
        }

        // 最后访问时间
        Element lastVisitLi = doc.select(".comiis_space_profile li:contains(最后访问)").first();
        if (lastVisitLi != null) {
            Element lastVisitVal = lastVisitLi.select(".profile_rs").first();
            if (lastVisitVal != null) profile.setLastVisit(lastVisitVal.text().trim());
        }

        // 在线时间
        Element onlineLi = doc.select(".comiis_space_profile li:contains(在线时间)").first();
        if (onlineLi != null) {
            Element onlineVal = onlineLi.select(".profile_rs").first();
            if (onlineVal != null) profile.setOnlineTime(onlineVal.text().trim());
        }

        // 性别
        Element genderLi = doc.select(".comiis_space_profile li:contains(性别)").first();
        if (genderLi != null) {
            Element genderVal = genderLi.select(".profile_rs").first();
            if (genderVal != null) {
                String g = genderVal.text().trim();
                if (g.contains("男")) profile.setGender("boy");
                else if (g.contains("女")) profile.setGender("girl");
            }
        }

        // ============================================================
        // 5. 签名区
        // ============================================================
        Element sigEl = doc.select(".profile_face, .signature, .sigin").first();
        if (sigEl != null) profile.setSignature(sigEl.text().trim());

        return profile;
    }

    /**
     * 解析消息/私信列表
     */
    public static List<Message> parseMessageList(String html) {
        List<Message> messages = new ArrayList<>();
        Document doc = Jsoup.parse(html);

        Elements items = doc.select("li.pm, li.msg, div.message_item, li[data-pmid]");
        // ★ 过滤分类标题（如"私人消息"、"公共消息"），Discuz 私信页面的分类标题
        // 会被 div.comiis_pmlist ul > li 选中，需跳过避免显示为普通消息
        java.util.Set<String> excludedTitles = new java.util.HashSet<>();
        excludedTitles.add("私人消息");
        excludedTitles.add("公共消息");

        for (Element item : items) {
            try {
                // 跳过分类标题
                String itemText = item.text().trim();
                if (excludedTitles.contains(itemText)) continue;
                // 兜底：如果 li 没有子链接，也跳过（分类标题通常只有文本）
                if (item.select("a").isEmpty()) continue;

                Message msg = new Message();

                Element link = item.select("a[href*=pmid=], a[href*=do=pm]").first();
                if (link != null) {
                    String pmid = extractParam(link.attr("href"), "pmid");
                    if (pmid != null) msg.setPmid(pmid);
                }

                Element titleEl = item.select(".title, .subject, h4").first();
                if (titleEl != null) msg.setTitle(titleEl.text().trim());

                Element authorEl = item.select(".author, .by, .from").first();
                if (authorEl != null) msg.setAuthor(authorEl.text().trim());

                Element timeEl = item.select(".time, .date, .dateline").first();
                if (timeEl != null) msg.setTime(timeEl.text().trim());

                Element summaryEl = item.select(".summary, .message_preview, p").first();
                if (summaryEl != null) msg.setSummary(summaryEl.text().trim());

                Element avatarEl = item.select("img[src*=avatar]").first();
                if (avatarEl != null) msg.setAvatarUrl(avatarEl.attr("src"));

                msg.setRead(item.select("em:contains(已读), .read").size() > 0);

                messages.add(msg);
            } catch (Exception ignored) {}
        }

        return messages;
    }

    /**
     * 解析 Comiis 移动版通知条目。
     *
     * 真实结构：li.b_b.bg_f.cl > .ntc_body + h2.f_d。
     * Comiis 移动模板不会使用桌面版的 div.nts/dl.cl，因此必须单独处理。
     */
    private static List<Message> parseComiisNoticeItems(Elements items) {
        List<Message> notices = new ArrayList<>();
        for (Element item : items) {
            try {
                Element body = item.select("div.ntc_body").first();
                if (body == null) continue;

                Message notice = new Message();
                notice.setType(0);

                // 某些版本会给未读条目添加 ntc_l/new/unread，已读条目添加 read/old。
                // 没有状态类时按已读处理，避免把历史通知全部误报成未读。
                boolean unread = item.hasClass("ntc_l") || item.hasClass("new")
                        || item.hasClass("unread") || item.hasClass("un_read")
                        || "0".equals(item.attr("data-read"))
                        || "unread".equalsIgnoreCase(item.attr("data-status"));
                boolean read = !unread;
                if (item.hasClass("read") || item.hasClass("old")
                        || "1".equals(item.attr("data-read"))) read = true;
                notice.setRead(read);

                // 移动版的通知 ID 可能放在 li 属性、data 属性，或任意位置的 a_note_* 链接中。
                // 不能只查 h2：部分列表项的屏蔽链接不在 h2 内，会导致该条退回内容键，
                // 与快照中的同类通知碰撞后左侧未读条被错误合并。
                String noticeId = firstNonEmptyAttr(item, "notice", "data-notice", "data-notice-id", "data-id");
                if (TextUtils.isEmpty(noticeId)) {
                    Element ignore = item.select("a[id^=a_note_], [id^=a_note_]").first();
                    if (ignore != null) {
                        Matcher idMatcher = Pattern.compile("a_note_(\\d+)").matcher(ignore.id());
                        if (idMatcher.find()) noticeId = idMatcher.group(1);
                    }
                }
                if (!TextUtils.isEmpty(noticeId)) notice.setPmid(noticeId);

                // ★ 提取发送者 UID：优先选择不含 do=wall/do=home 的链接（那些是指向自己的留言板/空间）。
                //   留言通知的 HTML 常同时包含 <a href="...&uid=SENDER_UID">发送者</a> 和
                //   <a href="...&uid=OWN_UID&do=wall">查看留言板</a>，后者会导致跳转到自己的主页。
                java.util.List<Element> uidLinks = new java.util.ArrayList<>();
                uidLinks.addAll(body.select("a[href*=space-uid-]"));
                uidLinks.addAll(body.select("a[href*=uid=]"));
                uidLinks.addAll(body.select("a[href*=authorid=]"));
                uidLinks.addAll(body.select("a[href*=touid=]"));
                Element author = null;
                for (Element link : uidLinks) {
                    String href = link.attr("href");
                    // 跳过指向自己留言板/空间的链接
                    if (href.contains("do=wall") || href.contains("do=home")) continue;
                    author = link;
                    break;
                }
                // ★ 不再回退到 do=wall 链接（那是指向自己的，会导致跳转到自己主页）
                if (author != null) {
                    if (TextUtils.isEmpty(notice.getAuthor()) && !TextUtils.isEmpty(author.text())) {
                        notice.setAuthor(author.text().trim());
                    }
                    String authorUid = extractNoticeUid(author);
                    if (!TextUtils.isEmpty(authorUid)) notice.setAuthorUid(authorUid);
                }

                // 好友申请的发送者 UID 常不在用户名链接上，而在"批准申请/同意/忽略"链接、
                // data-* 属性或内嵌脚本中；扫描整条通知，避免点击同意时丢失 UID。
                if (TextUtils.isEmpty(notice.getAuthorUid())) {
                    Element agreeLink = item.select("a").stream()
                            .filter(a -> {
                                String t = a.text();
                                return t.contains("同意") || t.contains("接受")
                                        || t.contains("加为好友") || t.contains("批准申请")
                                        || t.contains("批准") || t.contains("忽略");
                            })
                            .findFirst().orElse(null);
                    String requestUid = extractNoticeUid(agreeLink);
                    if (TextUtils.isEmpty(requestUid)) requestUid = extractNoticeUid(item);
                    if (!TextUtils.isEmpty(requestUid)) notice.setAuthorUid(requestUid);
                }

                Element avatarImg = item.select("a.notice_img img[src*=avatar], img[src*=avatar], img[src*=uc_server]").first();
                if (avatarImg != null) {
                    String src = avatarImg.attr("abs:src");
                    if (TextUtils.isEmpty(src)) src = avatarImg.attr("src");
                    if (!TextUtils.isEmpty(src) && !src.startsWith("http")) src = BASE_DOMAIN + src;
                    notice.setAvatarUrl(src);
                }

                // ★ 补充提取：头像链接本身可能含 space-uid-XXX 或 uid=XXX
                //   Comiis 移动版通知中，留言/评论/打招呼等类型的 UID 常在头像链接上，
                //   body 内不一定有用户链接。跳过 do=wall/do=home 链接（指向自己的）。
                if (TextUtils.isEmpty(notice.getAuthorUid())) {
                    for (Element avatarLink : item.select("a[href*=space-uid-], a[href*=uid=]")) {
                        String href = avatarLink.attr("href");
                        if (href.contains("do=wall") || href.contains("do=home")) continue;
                        String uid = extractNoticeUid(avatarLink);
                        if (!TextUtils.isEmpty(uid)) {
                            notice.setAuthorUid(uid);
                            if (TextUtils.isEmpty(notice.getAuthor()) && !TextUtils.isEmpty(avatarLink.text())) {
                                notice.setAuthor(avatarLink.text().trim());
                            }
                            break;
                        }
                    }
                }

                // ★ 终极兜底：从头像图片 URL 提取 UID（如 avatar.php?uid=12345）
                if (TextUtils.isEmpty(notice.getAuthorUid()) && !TextUtils.isEmpty(notice.getAvatarUrl())) {
                    Matcher avatarUidM = Pattern.compile("(?:uid=)(\\d+)", Pattern.CASE_INSENSITIVE)
                            .matcher(notice.getAvatarUrl());
                    if (avatarUidM.find()) {
                        notice.setAuthorUid(avatarUidM.group(1));
                    }
                }

                Element titleLink = body.select("a[href*=forum.php?mod=redirect]").first();
                if (titleLink == null) titleLink = body.select("a[href*=thread-]").first();
                if (titleLink != null) notice.setSummary(titleLink.text().trim());

                String fullText = body.text().replace('\u00a0', ' ').trim();
                if (fullText.length() > 200) fullText = fullText.substring(0, 200);
                notice.setTitle(fullText);

                if (titleLink != null) {
                    Matcher tidMatcher = Pattern.compile("(?:ptid=|thread-)(\\d+)").matcher(titleLink.attr("href"));
                    if (tidMatcher.find()) {
                        String summary = notice.getSummary();
                        notice.setSummary((summary == null ? "" : summary) + " tid=" + tidMatcher.group(1));
                    }
                }

                // Comiis 移动版提取 pid（回复楼层定位）
                // 移动版通知中 "查看" 链接通常是 <a href="forum.php?mod=redirect&goto=findpost&pid=123456&ptid=789">
                Element findPostLink = body.select("a[href*=goto=findpost], a[href*=pid=]").first();
                if (findPostLink != null) {
                    String href = findPostLink.attr("href");
                    Matcher pm = Pattern.compile("pid=(\\d+)").matcher(href);
                    if (pm.find()) {
                        notice.setPid(pm.group(1));
                    }
                }

                Element time = item.select("h2.f_d").first();
                if (time != null) {
                    String timeText = time.ownText().replace('\u00a0', ' ').trim();
                    if (TextUtils.isEmpty(timeText)) timeText = time.text().replace('\u00a0', ' ').trim();
                    notice.setTime(timeText);
                }

                if (fullText.contains("回复了您的") || fullText.contains("评论了您的")) {
                    notice.setType(2);
                } else if (fullText.contains("系统") || fullText.contains("管理")
                        || fullText.contains("删除")) {
                    notice.setType(1);
                }
                notices.add(notice);
            } catch (Exception ignored) {
            }
        }
        return notices;
    }

    private static String extractNoticeUid(Element element) {
        if (element == null) return null;
        String[] attrs = {"href", "data-uid", "data-userid", "data-authorid", "data-touid",
                "data-id", "onclick", "value"};
        Pattern[] patterns = {
                Pattern.compile("(?:^|[?&#])uid=(\\d+)", Pattern.CASE_INSENSITIVE),
                Pattern.compile("(?:space-uid-|space_uid_|authorid=|touid=|userid=)(\\d+)", Pattern.CASE_INSENSITIVE),
                Pattern.compile("(?:data-(?:uid|userid|authorid|touid)|value)\\s*=\\s*[\\\"']?(\\d+)", Pattern.CASE_INSENSITIVE)
        };
        java.util.List<Element> candidates = new java.util.ArrayList<>();
        candidates.add(element);
        candidates.addAll(element.select("*[href], *[data-uid], *[data-userid], *[data-authorid], *[data-touid], *[onclick], *[value], *[id]"));
        for (Element current : candidates) {
            // ★ 跳过指向自己留言板/空间的链接（uid 是自己的）
            String href = current.attr("href");
            if (!TextUtils.isEmpty(href) && (href.contains("do=wall") || href.contains("do=home"))) continue;
            for (String attr : attrs) {
                String value = current.attr(attr);
                if (TextUtils.isEmpty(value)) continue;
                String uid = matchNoticeUid(value, patterns);
                if (!TextUtils.isEmpty(uid)) return uid;
            }
            String uid = matchNoticeUid(current.outerHtml(), patterns);
            if (!TextUtils.isEmpty(uid)) return uid;
        }
        // ★ 最终兜底：扫描整个 outerHtml，但先移除 do=wall/do=home 链接的 HTML，
        //   避免从指向自己的留言板链接中提取到自己的 UID。
        String outerHtml = element.outerHtml();
        outerHtml = outerHtml.replaceAll("(?is)<a\\s[^>]*href=\"[^\"]*(?:do=wall|do=home)[^\"]*\"[^>]*>.*?</a>", "");
        return matchNoticeUid(outerHtml, patterns);
    }

    private static String matchNoticeUid(String text, Pattern[] patterns) {
        if (TextUtils.isEmpty(text)) return null;
        String normalized = text.replace("\\u003d", "=")
                .replace("&amp;", "&")
                .replace("%3D", "=").replace("%26", "&");
        Pattern[] extra = {
                Pattern.compile("(?:uid|userid|authorid|touid)\\s*[=:]\\s*[\\\"']?(\\d+)", Pattern.CASE_INSENSITIVE),
                Pattern.compile("(?:space[-_]uid[-_]|user[-_]?id[-_]|friendhk[_-])(\\d+)", Pattern.CASE_INSENSITIVE),
                Pattern.compile("(?:addFriend|acceptFriend|friend(?:Request|Apply))\\s*\\(\\s*[\\\"']?(\\d+)", Pattern.CASE_INSENSITIVE)
        };
        for (Pattern pattern : extra) {
            Matcher matcher = pattern.matcher(normalized);
            if (matcher.find()) return matcher.group(1);
        }
        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(normalized);
            if (matcher.find()) return matcher.group(1);
        }
        return null;
    }

/**
     * 2026-06-26 修复：基于真实 HTML 结构调整选择器，使用桌面版 URL（不加 &mobile=2）
     *
     * 真实 DOM 结构（桌面版）：
     *   div.xld.xlda
     *     div.nts
     *       dl.cl {notice="NOTICE_ID"}              ← 每条通知
     *         dd.m.avt.mbn                           ← 头像区域
     *           a[href*=space-uid-] > img[src*=avatar]
     *         dt                                     ← 屏蔽链接 + 时间
     *           a.d.b[href*=op=ignore]                屏蔽链接
     *           span.xg1.xw0 > span[title]            时间
     *         dd.ntc_body                            ← 通知内容
     *           a[href*=space-uid-]                   用户名（发送者）
     *           a[href*=forum.php?mod=redirect]       帖子标题链接
     *           a.lit[href*=findpost]                 查看链接
     *
     * @param html 通知列表页 HTML（桌面版，不含 &mobile=2）
     * @return 通知条目列表
     */
    public static List<Message> parseNoticeList(String html) {
        List<Message> notices = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return notices;

        Document doc = Jsoup.parse(html);

        // Comiis 移动版通知页面使用 li.b_b.bg_f.cl；优先走移动版解析器。
        Elements mobileItems = doc.select("li.b_b.bg_f.cl");
        if (!mobileItems.isEmpty()) {
            return parseComiisNoticeItems(mobileItems);
        }

        // 检查是否有“没有提醒内容”
        if (html.contains("没有提醒内容") || html.contains("暂无提醒")
                || html.contains("没有新的") || html.contains("notip")) {
            return notices;
        }

        // ★ 核心选择器：桌面版通知使用 dl.cl 元素，位于 div.nts 容器内
        Elements items = doc.select("div.nts > dl.cl");
        if (items.isEmpty()) {
            // 兜底：直接查找所有带 notice 属性的 dl
            items = doc.select("dl.cl[notice]");
        }
        if (items.isEmpty()) {
            // 最终兜底：查找所有 dl.cl
            items = doc.select("dl.cl");
        }

        for (Element item : items) {
            try {
                Message notice = new Message();
                notice.setType(0);

                // ★ 判断已读/未读：桌面版 Discuz! 未读通知的 dl.cl 含有 ntc_l 类
                // 已读通知没有 ntc_l 类，未读通知有 <dl class="cl ntc_l">
                notice.setRead(!item.hasClass("ntc_l"));

                // ★ 提取 notice ID（用于删除操作）
                String noticeId = item.attr("notice");
                if (!TextUtils.isEmpty(noticeId)) {
                    notice.setPmid(noticeId);
                }

                // ★ 提取发送者 UID（用于屏蔽操作和好友申请同意）
                Element avatarLink = item.select("dd.avt a[href*=space-uid-]").first();
                if (avatarLink == null) {
                    avatarLink = item.select("dd.m a[href*=uid=]").first();
                }
                if (avatarLink != null) {
                    Matcher m = Pattern.compile("uid=(\\d+)").matcher(avatarLink.attr("href"));
                    if (m.find()) {
                        notice.setAuthorUid(m.group(1));
                    }
                }

                // ★ 好友申请等通知的用户链接和操作链接都在 dd.ntc_body 内，
                //   头像区域可能缺失或不含 UID。从正文链接中补充提取。
                if (TextUtils.isEmpty(notice.getAuthorUid())) {
                    Element bodyEl = item.select("dd.ntc_body").first();
                    if (bodyEl != null) {
                        String requestUid = extractNoticeUid(bodyEl);
                        if (!TextUtils.isEmpty(requestUid)) notice.setAuthorUid(requestUid);
                    }
                    // 最终兜底：扫描整个通知项
                    if (TextUtils.isEmpty(notice.getAuthorUid())) {
                        String requestUid = extractNoticeUid(item);
                        if (!TextUtils.isEmpty(requestUid)) notice.setAuthorUid(requestUid);
                    }
                }

                // ★ 头像
                Element avatarImg = item.select("dd.avt img[src*=avatar], img[src*=uc_server]").first();
                if (avatarImg != null) {
                    String src = avatarImg.attr("src");
                    if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                    notice.setAvatarUrl(src);
                }

                // ★ 时间
                Element timeEl = item.select("dt span.xg1 span[title], dt span.xg1").first();
                if (timeEl == null) {
                    timeEl = item.select("span[title]").first();
                }
                if (timeEl != null) {
                    String timeText = timeEl.attr("title");
                    if (TextUtils.isEmpty(timeText)) {
                        timeText = timeEl.text().trim();
                    }
                    notice.setTime(timeText);
                }

                // ★ 通知正文（ntc_body）
                Element bodyEl = item.select("dd.ntc_body").first();
                if (bodyEl == null) continue;

                // 发送者用户名（第一个 a[href*=space-uid-] 或 a[href*=uid=]）
                Element authorEl = bodyEl.select("a[href*=space-uid-], a[href*=uid=]").first();
                if (authorEl != null) {
                    notice.setAuthor(authorEl.text().trim());
                }

                // 帖子标题（指向 forum.php?mod=redirect 的链接）
                Element titleLink = bodyEl.select("a[href*=forum.php?mod=redirect]").first();
                if (titleLink != null) {
                    String title = titleLink.text().trim();
                    // 去除"回复了您的帖子"等前缀
                    notice.setSummary(title);
                }

                // ★ 完整通知文本作为标题（如 "ruolin 回复了您的帖子 XXX"）
                String fullText = bodyEl.text().trim();
                // 去除"查看"等操作文字
                fullText = fullText.replaceAll("查看\\s*$", "").trim();
                if (fullText.length() > 200) fullText = fullText.substring(0, 200);
                notice.setTitle(fullText);

                // ★ 提取帖子 tid（用于点击跳转）
                Element postLink = bodyEl.select("a[href*=ptid=]").first();
                if (postLink != null) {
                    String href = postLink.attr("href");
                    Matcher m = Pattern.compile("ptid=(\\d+)").matcher(href);
                    if (m.find()) {
                        notice.setSummary((notice.getSummary() != null ? notice.getSummary() + " " : "") + "tid=" + m.group(1));
                    }
                }

                // ★ 提取回复 pid（用于定位到具体楼层）
                // 桌面版通知中有一个 <a class="lit" href="forum.php?mod=redirect&goto=findpost&pid=123456&ptid=789">
                Element findPostLink = bodyEl.select("a.lit[href*=findpost], a[href*=goto=findpost]").first();
                if (findPostLink != null) {
                    String href = findPostLink.attr("href");
                    Matcher m = Pattern.compile("pid=(\\d+)").matcher(href);
                    if (m.find()) {
                        notice.setPid(m.group(1));
                    }
                }

                // ★ 判断通知类型
                if (fullText.contains("回复了您的帖子") || fullText.contains("回复了您的") || fullText.contains("评论了您的")) {
                    notice.setType(2); // 回复提醒
                } else if (fullText.contains("删除") || fullText.contains("系统") || fullText.contains("管理")) {
                    notice.setType(1); // 系统通知
                }

                notices.add(notice);
            } catch (Exception ignored) {}
        }

        return notices;
    }

    /**
     * 解析私信列表（Comiis App 模板 home.php?mod=space&do=pm&mobile=2 页面）
     *
     * 真实 DOM 结构（2026-08-13 抓取）：
     *   div.comiis_pms_box > div.comiis_pmlist > ul > li
     *     a.kmdel (删除按钮)
     *     a.b_b[href*=subop=view&touid=XXX] (主链接)
     *       img[src*=avatar.php?uid=XXX] (头像)
     *       h2 > span.f_d (时间，如"昨天 20:10") + 用户名文本
     *       p.f_c (消息预览)
     *
     * 注意：Comiis 模板没有 pmid 参数，使用 touid 作为会话标识。
     *
     * @param html PM列表页HTML
     * @return 私信列表
     */
    public static List<Message> parsePmList(String html) {
        List<Message> messages = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return messages;

        Document doc = Jsoup.parse(html);

        // 主方案：Comiis App 模板结构
        // div.comiis_pmlist > ul > li
        Elements items = doc.select("div.comiis_pmlist ul > li");
        // 兜底：尝试直接查找 li 或 a.b_b
        if (items.isEmpty()) {
            items = doc.select("li.b_b, li.pm, li[data-pmid]");
        }
        // 再兜底：从 subop=view 链接向上查找父 li
        if (items.isEmpty()) {
            Elements pmLinks = doc.select("a[href*=subop=view]");
            for (Element pmLink : pmLinks) {
                Element parent = pmLink.closest("li");
                if (parent != null) items.add(parent);
            }
        }

        for (Element item : items) {
            try {
                Message msg = new Message();

                // 主链接 (a.b_b 或 a[href*=subop=view])
                Element link = item.select("a.b_b, a[href*=subop=view]").first();
                if (link == null) link = item.select("a[href*=touid=], a[href*=uid=]").first();
                if (link == null) link = item.select("a").first();
                if (link == null) continue;

                String href = link.attr("href");

                // 会话ID = touid（Comiis 模板用 touid 标识会话）
                String touid = extractParam(href, "touid");
                if (touid == null) touid = extractParam(href, "uid");
                msg.setPmid(touid); // 将 touid 存入 pmid 字段，用于 ChatActivity 跳转

                // 对方UID（与会话ID相同）
                msg.setAuthorUid(touid);

                // 用户名：从 h2 中提取（排除 span.f_d 的时间部分）
                Element h2 = link.select("h2").first();
                if (h2 != null) {
                    String fullText = h2.text().trim();
                    Element timeSpan = h2.select("span.f_d").first();
                    if (timeSpan != null) {
                        String timeText = timeSpan.text().trim();
                        fullText = fullText.replace(timeText, "").trim();
                    }
                    msg.setAuthor(fullText);
                } else {
                    // 兜底：从 a[href*=touid=] 文本提取
                    String linkText = link.text().trim();
                    if (!linkText.isEmpty()) msg.setAuthor(linkText);
                }

                // 保存网页端删除按钮生成的真实 open_href，Comiis 删除接口依赖其中的 formhash。
                Element deleteEl = item.select("a.kmdel[open_href]").first();
                if (deleteEl != null) {
                    String deleteUrl = deleteEl.attr("abs:open_href");
                    if (TextUtils.isEmpty(deleteUrl)) deleteUrl = deleteEl.attr("open_href");
                    msg.setDeleteUrl(deleteUrl);
                }

                // 消息预览 (p.f_c)
                Element previewEl = link.select("p.f_c").first();
                if (previewEl != null) msg.setSummary(previewEl.text().trim());

                // 标题（预览内容作为标题）
                String summary = msg.getSummary();
                msg.setTitle(summary != null ? summary : "");

                // 时间 (span.f_d)
                Element timeEl = link.select("span.f_d").first();
                if (timeEl != null) msg.setTime(timeEl.text().trim());

                // 头像 (img[src*=avatar.php])
                Element avatarEl = link.select("img[src*=avatar]").first();
                if (avatarEl != null) {
                    String src = avatarEl.attr("src");
                    if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                    msg.setAvatarUrl(src);
                }

                // 已读/未读
                // ★ 与 parsePrivateMessageList 统一：MT 论坛用【空的 span.kmnums】标记未读。
                //   Comiis 模板同样输出该 span；只判存在性，不能读文本。
                boolean isUnread = item.selectFirst("span.kmnums") != null
                        || item.hasClass("new") || item.hasClass("unread")
                        || item.select(".un_read, .no_read, .newpm_avt").size() > 0;
                msg.setRead(!isUnread);

                messages.add(msg);
            } catch (Exception ignored) {}
        }

        return messages;
    }
    /** 从聊天页标题读取 Comiis 的实时在线状态。 */
    public static String parseChatOnlineStatus(String html) {
        if (TextUtils.isEmpty(html)) return "离线";
        Document doc = Jsoup.parse(html);
        Element title = doc.select(".comiis_head h2, #comiis_head h2, h2.flex").first();
        String text = title != null ? title.text().trim() : doc.title();
        if (text.contains("在线")) return "在线";
        if (text.contains("离线")) return "离线";
        return "离线";
    }

/**
     * 解析私信会话详情（Comiis App 模板）。
     *
     * 真实 DOM 结构（2026-08-13 抓取）：
     *   div#comiis_pm_list
     *     div.comiis_msg_date (日期分隔线)
     *     div.comiis_friend_msg.cl / div.comiis_self_msg.cl
     */
    public static List<ChatMessage> parseChatMessages(String html, String selfUid, String fallbackAvatar) {
        List<ChatMessage> result = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return result;
        // 必须带 baseUri：私信正文里的图片经常是 /data/attachment/... 这样的相对路径，
        // 没有 baseUri 时 absUrl() 与 BBCode 补全都拿不到可请求的绝对地址，
        // 结果气泡里只剩一个永远加载不出来的占位框。
        Document doc = Jsoup.parse(html, BASE_DOMAIN);
        Set<String> seen = new HashSet<>();

        // 主方案：Comiis 模板结构
        Elements items = doc.select("div.comiis_friend_msg, div.comiis_self_msg");
        // 兜底：原有标准选择器
        if (items.isEmpty()) {
            items = doc.select("div.pmbox, div.pm_c, div.pm_body, li.pm, li.pm_list, li.cl, .comiis_pm, .comiis_pmitem, [data-pmid]");
        }

        for (Element item : items) {
            try {
                boolean isOutgoing = item.hasClass("comiis_self_msg");

                // 消息内容：div.msg_mes
                Element body = item.select("div.msg_mes").first();
                if (body == null) {
                    // 兜底：原有选择器
                    body = item.select(".pm_content, .pm_body, .message, .content, .pmbox_content, .t_f, .msgtext, .f_c").first();
                }
                if (body == null) body = item;
                // 表情：网页把 [code] 渲染成 <img src=".../smiley/...">，
                // body.text() 完全取不到，只保留纯文本会让对方发来的表情整条消失。
                // 这里额外产出一份精简 HTML 供适配器渲染 ImageSpan，
                // 同时把表情折算成占位记号写进纯文本，避免"纯表情消息"正文为空而被丢弃、
                // 也避免两条不同表情的消息因正文都是空串而被去重键判成同一条。
                String contentHtml = buildChatContentHtml(body);
                String content = buildChatContentText(body);
                if (content.isEmpty() || content.length() > 5000) continue;

                // 头像链接：img.msg_avt 或 img[src*=avatar]
                Element avatarEl = item.select("img.msg_avt, img[src*=avatar], img[src*=uc_server], img.top_tximg").first();
                String avatar = avatarEl != null ? avatarEl.attr("src") : fallbackAvatar;
                if (avatar != null && !avatar.isEmpty() && !avatar.startsWith("http")) avatar = BASE_DOMAIN + avatar;

                // 对方UID：从头像/用户链接中提取
                Element userLink = item.select("a[href*=uid=]").first();
                String authorUid = userLink != null ? extractParam(userLink.attr("href"), "uid") : null;

                // 日期分隔线：读取当前消息之前最近的 comiis_msg_date。
                String date = "";
                Element previous = item.previousElementSibling();
                while (previous != null) {
                    if (previous.hasClass("comiis_msg_date")) {
                        date = previous.text().trim();
                        break;
                    }
                    previous = previous.previousElementSibling();
                }

                // 时间：div.msg_time.f_d
                Element timeEl = item.select("div.msg_time.f_d, .time, .date, .dateline, .kmtime, .pm_time, .f_g").first();
                String time = timeEl != null ? timeEl.text().trim() : "";

                // 去重键
                String key = (isOutgoing ? "self" : "friend") + "|" + time + "|" + content;
                if (!seen.add(key)) continue;

                ChatMessage message = new ChatMessage();
                message.setContent(content);
                message.setContentHtml(contentHtml);
                message.setAvatarUrl(avatar);
                message.setAuthorUid(authorUid);
                message.setDate(date);
                message.setTime(time);
                // 方向判断：comiis_self_msg = 自己发送 (outgoing=true)
                message.setOutgoing(isOutgoing);

                // 作者名：从头像链接的 alt 获取，或直接使用 selfUid 判断
                if (isOutgoing) {
                    message.setAuthor(selfUid); // 自己
                } else {
                    Element img = item.select("img[alt]").first();
                    String author = img != null ? img.attr("alt").trim() : "";
                    message.setAuthor(author);
                }

                result.add(message);
            } catch (Exception ignored) {}
        }
        return result;
    }

    /**
     * 私信正文 → 精简 HTML，只保留文本、换行与表情 {@code <img>}。
     *
     * <p>直接把 {@code body.html()} 交给适配器是不行的：私信正文里可能夹带
     * 链接、样式容器等结构，交给 {@code Html.fromHtml} 会引入不受控的排版，
     * 而气泡的链接渲染已由适配器自己的正则处理。这里只输出适配器需要的两种节点。
     *
     * @return 含 {@code <img>} 的精简 HTML；正文没有表情时返回 null，
     *         让适配器走纯文本快路径
     */
    @Nullable
    private static String buildChatContentHtml(Element body) {
        if (body == null) return null;
        // 这里不能用"没有 <img> 子节点就直接返回 null"来提前退出：私信正文里的图片
        // 有相当一部分根本不是 <img>，而是服务端原样回显的 [img]url[/img] BBCode
        // 纯文本。提前退出会让这些消息拿不到富文本，最终在气泡里显示成一串裸代码。
        StringBuilder sb = new StringBuilder();
        boolean hasImage = appendChatNodes(body, sb, true);
        if (!hasImage) return null;
        String html = sb.toString().trim();
        return html.isEmpty() ? null : html;
    }

    /**
     * 私信正文 → 纯文本，表情折算成其表情代码。
     *
     * <p>不能简单用 {@code body.text()}：表情是 {@code <img>}，取不到任何文本，
     * 于是"只发了一个表情"的消息正文为空会被整条丢弃，而两条不同表情的消息
     * 又会因为正文都是空串而被去重键判成重复。这里用 {@code <img>} 的
     * {@code alt}（论坛会写入表情代码）或文件名兜底，保证正文稳定且互不相同。
     */
    private static String buildChatContentText(Element body) {
        if (body == null) return "";
        StringBuilder sb = new StringBuilder();
        appendChatNodes(body, sb, false);
        // Jsoup text() 会压缩空白，这里手工拼接后同样收敛连续空格，保持与旧行为一致。
        return sb.toString().replaceAll("[ \\t]+", " ").trim();
    }

    /**
     * 递归遍历私信正文节点。
     *
     * @param asHtml true 输出精简 HTML（表情保留为 {@code <img>}），
     *               false 输出纯文本（表情降级为表情代码文本）
     * @return 遍历过程中是否遇到过表情图片
     */
    private static boolean appendChatNodes(Element parent, StringBuilder out, boolean asHtml) {
        boolean hasImage = false;
        for (org.jsoup.nodes.Node node : parent.childNodes()) {
            if (node instanceof org.jsoup.nodes.TextNode) {
                String text = ((org.jsoup.nodes.TextNode) node).text();
                if (text.isEmpty()) continue;
                boolean textHasImage = appendChatText(text, out, asHtml, parent.baseUri());
                hasImage = hasImage || textHasImage;
                continue;
            }
            if (!(node instanceof Element)) continue;
            Element element = (Element) node;
            String tag = element.normalName();
            if ("img".equals(tag)) {
                String src = resolveImageSrc(element);
                if (TextUtils.isEmpty(src)) continue;
                hasImage = true;
                if (asHtml) {
                    out.append("<img src=\"").append(escapeHtmlText(src)).append("\">");
                } else {
                    out.append(smileyTextFallback(element, src));
                }
                continue;
            }
            if ("br".equals(tag)) {
                out.append(asHtml ? "<br>" : "\n");
                continue;
            }
            boolean childHasImage = appendChatNodes(element, out, asHtml);
            hasImage = hasImage || childHasImage;
            if ("p".equals(tag) || "div".equals(tag)) {
                out.append(asHtml ? "<br>" : "\n");
            }
        }
        return hasImage;
    }

    /**
     * 私信正文里的 {@code [img]url[/img]} / {@code [img=宽,高]url[/img]} BBCode。
     *
     * <p>论坛并不总把私信里的图片渲染成 {@code <img>}：手机版发图、以及带表情的
     * 消息，服务端经常把 BBCode 原样回显在文本节点里。只认 {@code <img>} 标签会让
     * 这些消息在气泡里显示成一串裸代码，看起来就是"图片不显示"。
     */
    private static final Pattern CHAT_BB_IMG_PATTERN = Pattern.compile(
            "\\[img(?:=[^\\]]*)?\\]\\s*([^\\[\\]\\r\\n]+?)\\s*\\[/img\\]",
            Pattern.CASE_INSENSITIVE);

    /**
     * 输出一个文本节点，顺带把其中的 {@code [img]} BBCode 展开成图片。
     *
     * @param baseUri 用于把相对地址补全成绝对地址，可为空
     * @return 该文本节点里是否含有图片
     */
    private static boolean appendChatText(String text, StringBuilder out,
                                          boolean asHtml, String baseUri) {
        boolean hasImage = false;
        Matcher matcher = CHAT_BB_IMG_PATTERN.matcher(text);
        int last = 0;
        while (matcher.find()) {
            appendChatPlainText(text.substring(last, matcher.start()), out, asHtml);
            last = matcher.end();
            String url = absoluteChatImageUrl(matcher.group(1), baseUri);
            if (TextUtils.isEmpty(url)) continue;
            hasImage = true;
            if (asHtml) {
                out.append("<img src=\"").append(escapeHtmlText(url)).append("\">");
            } else {
                out.append(bbImageTextFallback(url));
            }
        }
        appendChatPlainText(text.substring(last), out, asHtml);
        return hasImage;
    }

    /** 输出一段不含图片的纯文字，负责剥掉行首缩进。 */
    private static void appendChatPlainText(String text, StringBuilder out, boolean asHtml) {
        if (text.isEmpty()) return;
        // 行首缩进必须剥掉：网页源码里 `你好<br />\n你好` 的 <br> 之后是一个
        // 以换行开头的 TextNode，Jsoup 的 text() 会把换行归一化成空格并保留在
        // 行首，于是每一行都凭空多出前导空格，气泡里看起来就是逐行递增的缩进。
        if (endsWithLineBreak(out, asHtml)) {
            text = stripLeadingSpaces(text);
            if (text.isEmpty()) return;
        }
        out.append(asHtml ? escapeHtmlText(text) : text);
    }

    /**
     * BBCode 里的图片地址 → 绝对地址。
     *
     * <p>本地相册路径（{@code /storage/...}、{@code file:}、{@code content:}）是
     * 发送端残留，服务端拿不到也渲染不出来，直接丢弃。
     */
    @Nullable
    private static String absoluteChatImageUrl(String rawUrl, String baseUri) {
        String value = rawUrl == null ? "" : rawUrl.trim();
        if (value.isEmpty()) return null;
        String lower = value.toLowerCase(java.util.Locale.ROOT);
        if (lower.startsWith("/storage/") || lower.startsWith("file:")
                || lower.startsWith("content:") || lower.startsWith("data:")) {
            return null;
        }
        if (isPlaceholderImage(value)) return null;
        if (lower.startsWith("http://") || lower.startsWith("https://")) return value;
        if (TextUtils.isEmpty(baseUri)) return value;
        try {
            return new java.net.URL(new java.net.URL(baseUri), value).toExternalForm();
        } catch (Exception ignored) {
            return value;
        }
    }

    /**
     * 私信去重键使用的正文归一化结果。
     *
     * <p>去重键不能直接用正文原文：图片与表情在正文里的表示形式随解析器演进反复
     * 变过（{@code [img]url[/img]} 裸码 → {@code [图片]}，表情代码 → 表情名），
     * 每变一次，同一条历史消息算出的键就换一个，数据库的唯一索引拦不住，
     * 于是旧消息被当作新消息追加到表尾 —— 界面上就是"最新消息后面又冒出几条旧的"。
     *
     * <p>这里把所有 {@code [xxx]} 记号（图片占位、表情码、BBCode）与空白全部剔除，
     * 只留下用户真正打出的文字。这样无论渲染层怎么改，键都稳定。纯表情/纯图片消息
     * 归一化后为空串，此时键退化为"方向 + 时间戳"，而时间戳带到秒，足以区分。
     */
    public static String chatDedupContentKey(@Nullable String content) {
        if (TextUtils.isEmpty(content)) return "";
        String value = CHAT_BB_IMG_PATTERN.matcher(content).replaceAll("");
        // 记号长度设上限，避免把正文里成对出现的方括号连带正常文字一起吃掉。
        value = value.replaceAll("\\[[^\\[\\]]{0,40}\\]", "");
        return value.replaceAll("\\s+", "");
    }

    /** BBCode 图片在纯文本里的替身，规则与 {@link #smileyTextFallback} 一致。 */
    private static String bbImageTextFallback(String url) {
        if (!com.forum.MT.ui.detail.ForumSmileyData.isSmileyUrl(url)) {
            return "[图片]";
        }
        int slash = url.lastIndexOf('/');
        String file = slash >= 0 ? url.substring(slash + 1) : url;
        int dot = file.lastIndexOf('.');
        if (dot > 0) file = file.substring(0, dot);
        return file.isEmpty() ? "[图片]" : "[" + file + "]";
    }

    /**
     * 把正文里残留的 {@code [img]url[/img]} 原文升级成 {纯文本, 精简 HTML}。
     *
     * <p>供本地持久化的历史消息做数据迁移用：这些消息是在解析器还不认识 BBCode
     * 图片的版本下入库的，正文里存的是一串裸代码，既渲染不出图片，其去重键
     * 也与新版解析结果不一致（同一条消息会被当成两条重复插入）。
     *
     * @return {纯文本, 精简 HTML}；正文里没有 BBCode 图片时返回 null
     */
    @Nullable
    public static String[] upgradeChatBbImageContent(@Nullable String content) {
        if (TextUtils.isEmpty(content) || content.indexOf('[') < 0) return null;
        if (!CHAT_BB_IMG_PATTERN.matcher(content).find()) return null;
        StringBuilder text = new StringBuilder();
        StringBuilder html = new StringBuilder();
        boolean hasImage = appendChatText(content, text, false, BASE_DOMAIN);
        appendChatText(content, html, true, BASE_DOMAIN);
        if (!hasImage) return null;
        String plain = text.toString().replaceAll("[ \\t]+", " ").trim();
        String rich = html.toString().trim();
        return new String[]{plain, rich.isEmpty() ? null : rich};
    }

    /**
     * 取 {@code <img>} 的真实地址。
     *
     * <p>Comiis/Discuz 的图片经常做懒加载：{@code src} 放一张 1px 占位图
     * （{@code static/image/common/none.gif}、base64 透明图等），真实地址写在
     * {@code data-original} / {@code zoomfile} / {@code file} / {@code _src} 里。
     * 只读 {@code src} 会把整张图渲染成一个透明点，看起来就是"图片不显示"。
     */
    @Nullable
    private static String resolveImageSrc(Element img) {
        String[] candidates = {"data-original", "data-src", "zoomfile", "file", "_src", "src"};
        for (String attr : candidates) {
            String value = img.attr(attr);
            if (TextUtils.isEmpty(value)) continue;
            if (isPlaceholderImage(value)) continue;
            String abs = img.absUrl(attr);
            return TextUtils.isEmpty(abs) ? value : abs;
        }
        return null;
    }

    /** 懒加载占位图，不能当作真实图片地址。 */
    private static boolean isPlaceholderImage(String url) {
        String lower = url.toLowerCase(java.util.Locale.ROOT);
        return lower.startsWith("data:")
                || lower.contains("common/none.gif")
                || lower.endsWith("/none.gif")
                || lower.contains("blank.gif")
                || lower.contains("loading.gif");
    }

    /** 表情图在纯文本里的替身：优先用 alt 里的表情代码，否则退化成文件名记号。 */
    private static String smileyTextFallback(Element img, String src) {
        // 真实图片（非表情）用固定记号，不要拿 OSS 上的随机文件名或 alt 当正文：
        // 那串名字既没有可读性，又会让"同一张图重发"的去重键不稳定。
        if (!com.forum.MT.ui.detail.ForumSmileyData.isSmileyUrl(src)) {
            return "[图片]";
        }
        String alt = img.attr("alt").trim();
        if (!alt.isEmpty()) {
            return alt.startsWith("[") ? alt : "[" + alt + "]";
        }
        int slash = src.lastIndexOf('/');
        String file = slash >= 0 ? src.substring(slash + 1) : src;
        int dot = file.lastIndexOf('.');
        if (dot > 0) file = file.substring(0, dot);
        return file.isEmpty() ? "[图片]" : "[" + file + "]";
    }

    private static String escapeHtmlText(String text) {
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    /** 输出缓冲是否刚好停在一个换行边界（行首）。 */
    private static boolean endsWithLineBreak(StringBuilder out, boolean asHtml) {
        if (out.length() == 0) return true;
        if (asHtml) {
            String tail = out.substring(Math.max(0, out.length() - 4));
            return tail.endsWith("<br>");
        }
        return out.charAt(out.length() - 1) == '\n';
    }

    private static String stripLeadingSpaces(String text) {
        int i = 0;
        while (i < text.length() && (text.charAt(i) == ' ' || text.charAt(i) == '\t'
                || text.charAt(i) == '\n' || text.charAt(i) == '\r'
                || text.charAt(i) == '\u00A0')) {
            i++;
        }
        return text.substring(i);
    }

    /**
     * 解析粉丝列表为 Message。
     *
     * Comiis 粉丝页真实结构：
     * div.comiis_userlist01 > li.b_t
     *   p.ytit.f_d                 操作按钮
     *   a.list01_limg > img        头像
     *   p.tit > a[href*=uid=]       用户名及 UID
     *   p.txt                       粉丝/关注统计
     *
     * 粉丝列表本身没有可靠的已读/未读标记，因此按已读处理；消息页的粉丝角标
     * 仍由服务器返回的通知数据决定，不能把普通粉丝条目误计为未读。
     */
    public static List<Message> parseFollowerList(String html) {
        List<Message> followers = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return followers;

        Document doc = Jsoup.parse(html);
        Elements items = doc.select("div.comiis_userlist01 > li.b_t");
        if (items.isEmpty()) {
            // 兼容部分 Comiis 页面省略外层容器的情况。
            items = doc.select("li.b_t");
        }

        Set<String> seenUids = new HashSet<>();
        for (Element item : items) {
            try {
                Element userLink = item.select("p.tit > a[href*=uid=]").first();
                if (userLink == null) userLink = item.select("a[href*=uid=]").first();
                if (userLink == null) continue;

                String href = userLink.attr("href");
                String uid = extractParam(href, "uid");
                if (TextUtils.isEmpty(uid)) {
                    Matcher uidMatcher = Pattern.compile("(?:^|[?&])uid=(\\d+)").matcher(href);
                    if (uidMatcher.find()) uid = uidMatcher.group(1);
                }
                if (TextUtils.isEmpty(uid) || !seenUids.add(uid)) continue;

                String author = userLink.text().trim();
                if (TextUtils.isEmpty(author)) continue;

                Message follower = new Message();
                follower.setType(1);
                follower.setPmid(uid);
                follower.setAuthorUid(uid);
                follower.setAuthor(author);
                follower.setSummary("关注了你");
                follower.setTitle(author + " 关注了你");
                follower.setTime("");
                follower.setRead(true);

                Element avatarEl = item.select("a.list01_limg img[src*=avatar], a.list01_limg img, img[src*=avatar]").first();
                if (avatarEl != null) {
                    String src = avatarEl.attr("abs:src");
                    if (TextUtils.isEmpty(src)) src = avatarEl.attr("src");
                    if (!TextUtils.isEmpty(src) && !src.startsWith("http")) {
                        src = BASE_DOMAIN + (src.startsWith("/") ? src.substring(1) : src);
                    }
                    follower.setAvatarUrl(src);
                }

                followers.add(follower);
            } catch (Exception ignored) {
            }
        }
        return followers;
    }

    /**
     * 解析帖子详情页（Comiis App 模板适配，viewthread 页面）
     *
     * DOM 结构关键区域：
     *   div.comiis_head a.kmtit                    — 版块名称
     *   div.comiis_viewtit h2 div.km_tits          — 帖子标题
     *   script 中 var tid / formhash               — tid / formhash（备选：input[name=formhash]）
     *   第一个 div.comiis_postli（id=pidxxxxx）    — 楼主帖子
     *      div.comiis_postli_top                   — 帖主信息区
     *        a.postli_top_tximg img.top_tximg      — 头像
     *        a.top_user.f_b                        — 用户名（href 含 uid=）
     *        a.top_lev.bg_a.f_f                    — 等级
     *        i.comiis_font.top_gender.bg_boy/girl  — 性别
     *        a.followmod                           — 关注按钮
     *        div.comiis_postli_time span.kmtime    — 发布时间
     *        div.comiis_postli_time code.comiis_iplocality — 地点（楼主）
     *      div.comiis_message                      — 正文区
     *        div.comiis_a.comiis_message_table.cl  — 正文HTML
     *        div.comiis_quote.bg_h.f_c             — 隐藏内容提示
     *        div.comiis_rate h2.rate_btn           — 赞赏按钮
     *   后续 div.comiis_postli（除第一个）          — 各回复
     *      div.comiis_postli_top
     *        span.f_d.y                            — 楼层标签（沙发/椅子/凉席/报纸/地板/N#）
     *        a.top_user.f_b                        — 用户名
     *        a.top_lev.bg_a.f_f                    — 等级
     *        i.comiis_font.top_gender              — 性别
     *        span.top_lev.bg_c.f_f                 — "楼主"标识（仅楼主回复显示）
     *      div.comiis_message div.comiis_a.comiis_message_table.cl — 回复内容
     *      div.comiis_postli_times                 — 回复时间地点（底栏）
     *        span.f_d.comiis_tm                    — 时间
     *        code.comiis_iplocality                — 地点
     *
     * @param html 帖子详情页 HTML
     * @return PostDetail 对象，包含帖主信息、正文、回复列表等
     */

    // ==================== 隐藏内容辅助（对齐开源 sqapp 机制） ====================

    /**
     * 判断候选节点是否为隐藏内容块（语义 + 类名双重判别，避免普通引用误判）。
     * 来源：开源 sqapp ForumParser.isHiddenContentMarker()
     */
    private static boolean isHiddenContentMarker(Element candidate) {
        if (candidate == null) return false;
        String lowerClass = candidate.className().toLowerCase(java.util.Locale.ROOT);
        String lowerId = candidate.id().toLowerCase(java.util.Locale.ROOT);
        boolean hasHiddenClass = lowerClass.contains("hide") || lowerClass.contains("hidden")
                || lowerClass.contains("locked")
                || lowerId.contains("hide") || lowerId.contains("hidden");
        if (hasHiddenClass) return true;
        // 只有类名/ID不匹配时才调用 .text()（慢路径）
        String text = candidate.text().replace('\u00a0', ' ').trim();
        String lowerText = text.toLowerCase(java.util.Locale.ROOT);
        boolean explicitHiddenTitle = lowerText.contains("本帖隐藏的内容")
                || lowerText.contains("本帖隐藏内容");
        if (explicitHiddenTitle) return true;
        boolean hiddenSemantic = (lowerText.contains("游客") && lowerText.contains("回复"));
        if (!hiddenSemantic) return false;
        boolean replyGate = !candidate.select(
                "a[href*=action=reply], a[href*=mod=post], a[onclick*=showWindow]").isEmpty();
        return replyGate || lowerText.contains("游客");
    }

    /**
     * 从正文容器里剔除"社交操作区"。
     *
     * <p>Comiis 移动端把点赞人列表、赞赏区都塞在正文容器
     * {@code div.comiis_a.comiis_message_table} 内部，而不是正文之外：
     * <pre>
     * div.comiis_a.comiis_message_table
     *   ├─ (真正的帖子正文)
     *   ├─ div.comiis_rate            赞赏按钮 / 打赏者头像
     *   └─ div.comiis_dzhan_img
     *      └─ ul.comiis_recommend_list_a
     *         └─ li > a > img         点赞人头像（uc_server/avatar.php）
     * </pre>
     * 直接把容器 html() 当正文输出，会把 32px 的点赞人头像当成正文图片，
     * 按内容宽度放大成一张大图贴在正文底部（例：thread-172019）。
     * 同时"赞赏""1 赞"这类按钮文字也会变成正文里的游离文本。
     *
     * <p>图片列表侧早就用同一套选择器排除了这些区域（见
     * {@code imgScanRoot.select(".comiis_recommend_list_a img").remove()} 等），
     * 这里是把正文 HTML 侧对齐，消除两者的不一致。
     *
     * <p>刻意<b>不</b>删 {@code .comiis_tags}：它不含图片，但带标签文字链接，
     * 而 PostDetail 没有独立的 tags 字段，标签只能靠正文 HTML 呈现，
     * 删掉会让有标签的帖子丢标签。
     *
     * <p>必须作用在克隆节点上。{@code likeCount} 读的是
     * {@code opMsg.select(".comiis_recommend_num")}，而该元素就在
     * {@code .comiis_dzhan_img} 内；{@code rewardCount} 读的是
     * {@code doc.select("div.comiis_rate")}。在原 DOM 上删会让这两个计数变 0。
     */
    private static void stripSocialActionAreas(Element clone) {
        if (clone == null) return;
        clone.select("div.comiis_dzhan_img, div.comiis_rate").remove();
    }

    /**
     * 收集正文根节点下所有（最内层 / 互不嵌套的）隐藏内容节点。
     * 来源：开源 sqapp ForumParser.findHiddenContentMarkers()
     */
    private static List<Element> findHiddenContentMarkers(Element root) {
        List<Element> result = new ArrayList<>();
        if (root == null) return result;

        // ★ 优化：用 CSS 选择器代替 getAllElements() 遍历整个 DOM 树。
        // 隐藏内容通常出现在：
        //   - 类名含 hide/hidden/locked 的 div
        //   - div.comiis_quote
        //   - div.locked
        // 先通过 CSS 选择器精准定位，再检查文本语义。
        Elements candidates = root.select(
            "div.comiis_quote, div.locked, " +
            "div[class*=hide], div[class*=hidden], div[class*=locked], " +
            "div[id*=hide], div[id*=hidden], " +
            "section[class*=hide], section[class*=hidden], " +
            "blockquote[class*=hide], blockquote[class*=hidden]"
        );

        // 额外检查：文本包含"本帖隐藏的内容"的结构元素（可能没有特殊类名）
        // 使用 :containsOwn 仅匹配直接子文本，避免匹配嵌套的引用块
        Elements textCandidates = root.select(
            "div:containsOwn(本帖隐藏的内容), " +
            "div:containsOwn(本帖隐藏内容), " +
            "section:containsOwn(本帖隐藏的内容), " +
            "section:containsOwn(本帖隐藏内容), " +
            "blockquote:containsOwn(本帖隐藏的内容), " +
            "blockquote:containsOwn(本帖隐藏内容)"
        );
        for (Element tc : textCandidates) {
            if (!candidates.contains(tc)) {
                candidates.add(tc);
            }
        }

        // 检查"游客,回复"语义：只用 CSS 类名选择器不能表达 AND 语义，
        // 但 :containsOwn 可能匹配到无关元素，谨慎使用。
        // 用更精确的 :contains (匹配子节点文本) 但限制范围：
        Elements guestCandidates = root.select(
            "div:contains(游客), section:contains(游客), blockquote:contains(游客)"
        );
        for (Element gc : guestCandidates) {
            if (candidates.contains(gc)) continue;
            String text = gc.text().replace('\u00a0', ' ').trim().toLowerCase(java.util.Locale.ROOT);
            if (text.contains("游客") && text.contains("回复")) {
                candidates.add(gc);
            }
        }

        for (Element candidate : candidates) {
            if (!isHiddenContentMarker(candidate)) continue;
            boolean containsAnotherCandidate = false;
            for (Element other : candidates) {
                if (other == candidate) continue;
                if (other.parents().contains(candidate)
                        && isHiddenContentMarker(other)) {
                    containsAnotherCandidate = true;
                    break;
                }
            }
            if (!containsAnotherCandidate && !isDescendantOfAny(candidate, result)) {
                result.add(candidate);
            }
        }
        return result;
    }

    private static boolean isDescendantOfAny(Element element, List<Element> parents) {
        if (element == null || parents == null) return false;
        for (Element parent : parents) {
            if (parent != null && parent != element && element.parents().contains(parent)) return true;
        }
        return false;
    }

    /**
     * 提取已解锁的隐藏正文；游客页只有提示语时返回空字符串。
     * 来源：开源 sqapp ForumParser.extractHiddenContentHtml()
     */
    private static String extractHiddenContentHtml(Element marker) {
        if (marker == null) return "";
        Element clone = marker.clone();
        clone.select("script, style").remove();
        String text = clone.text().replace('\u00a0', ' ').trim().toLowerCase(java.util.Locale.ROOT);
        boolean isPromptOnly = text.contains("隐藏内容")
                && (text.contains("回复") || text.contains("游客"));
        if (isPromptOnly) return "";
        // 排除隐藏提示链接本身（a[href 含 action=reply / mod=post] 等门控链接）
        clone.select("a[href*=action=reply], a[href*=mod=post], a[onclick*=showWindow]").remove();
        String html = clone.html().trim();
        // 若移除后只剩空标签/提示文本，也视为未解锁
        String remainingText = clone.text().replace('\u00a0', ' ').trim();
        if (TextUtils.isEmpty(remainingText)
                || (remainingText.contains("隐藏内容") && remainingText.length() < 30)) {
            return "";
        }
        return html;
    }

    /**
     * 保留隐藏节点在正文中的位置，同时添加客户端专用标记 data-sqapp-hidden，
     * 供渲染端识别为“隐藏内容”卡片，并替换内部 HTML 为真实隐藏正文（已解锁时）。
     * 来源：开源 sqapp ForumParser.replaceHiddenMarkerWithPlaceholder()
     */
    private static void replaceHiddenMarkerWithPlaceholder(Element marker, String unlockedHtml) {
        if (marker == null) return;
        marker.attr("data-sqapp-hidden", "true");
        marker.addClass("sqapp-hidden-content");
        if (!TextUtils.isEmpty(unlockedHtml)) {
            marker.html(unlockedHtml);
        }
    }

    public static PostDetail parseThreadDetail(String html) {
        PostDetail detail = new PostDetail();

        // 某些帖子请求可能返回空响应（网络断开、服务端临时无响应或被重定向）。
        // 不能把 null 直接交给 Jsoup/Pattern.matcher，否则 Android 会抛出
        // "s == null" 这类不具备可读性的 NPE，详情页就会完全空白。
        if (TextUtils.isEmpty(html)) {
            detail.setReplies(new ArrayList<ReplyItem>());
            detail.setImageUrls(new ArrayList<String>());
            detail.setCurrentPage(1);
            detail.setTotalPages(1);
            return detail;
        }

        android.util.Log.d("ForumParser", "parseThreadDetail: html length=" + html.length());
        // ★ 调试：统计原始HTML中的附件链接（确认附件是否进入解析器）
        try {
            int attachCnt = 0;
            int attachImgCnt = 0;
            int attachBbcnt = 0;
            int ignoreJsCnt = 0;
            String lower = html.toLowerCase(java.util.Locale.ROOT);
            int idx = 0;
            while ((idx = lower.indexOf("mod=attachment", idx)) >= 0) { attachCnt++; idx += "mod=attachment".length(); }
            idx = 0;
            while ((idx = lower.indexOf("aid=", idx)) >= 0) { attachImgCnt++; idx += "aid=".length(); }
            idx = 0;
            while ((idx = lower.indexOf("[attach", idx)) >= 0) { attachBbcnt++; idx += "[attach".length(); }
            idx = 0;
            while ((idx = lower.indexOf("ignore_js_op", idx)) >= 0) { ignoreJsCnt++; idx += "ignore_js_op".length(); }
            android.util.Log.d("ForumParser", "parseThreadDetail ATTACH-STATS mod=attachment=" + attachCnt
                    + " aid=" + attachImgCnt + " [attach=" + attachBbcnt + " ignore_js_op=" + ignoreJsCnt);
            // ★ 定位附件链接在原始HTML中的位置 → 写入文件供诊断
            if (attachCnt > 0 || attachBbcnt > 0) {
                StringBuilder sb = new StringBuilder();
                int pos = lower.indexOf("mod=attachment");
                if (pos >= 0) {
                    int start = Math.max(0, pos - 300);
                    int end = Math.min(html.length(), pos + 500);
                    sb.append("=== mod=attachment context ===\n").append(html.substring(start, end)).append("\n\n");
                }
                pos = html.indexOf("[attach");
                if (pos >= 0) {
                    int start = Math.max(0, pos - 300);
                    int end = Math.min(html.length(), pos + 500);
                    sb.append("=== [attach context ===\n").append(html.substring(start, end)).append("\n\n");
                }
                try {
                    java.io.File f = new java.io.File("/data/data/com.forum.MT/files/attach_debug.txt");
                    f.getParentFile().mkdirs();
                    java.io.FileWriter fw = new java.io.FileWriter(f);
                    fw.write(sb.toString());
                    fw.close();
                    // 也写入 sdcard 供 proot 读取
                    java.io.File f2 = new java.io.File("/sdcard/MT2/mcp/attach_debug.txt");
                    f2.getParentFile().mkdirs();
                    java.io.FileWriter fw2 = new java.io.FileWriter(f2);
                    fw2.write(sb.toString());
                    fw2.close();
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        // ★ 调试转储：完整原始HTML写入文件供附件结构分析（仅debug构建保留）
        try {
            java.io.File f = new java.io.File("/data/local/tmp/mt_raw_post.html");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
            fos.write(html.getBytes("UTF-8"));
            fos.close();
        } catch (Exception ignored) { }

        Document doc = Jsoup.parse(html);

        // === 1. 版块信息 ===
        Element forumLink = doc.select("div.comiis_head a.kmtit[href*=forum-]").first();
        if (forumLink != null) {
            detail.setForumName(forumLink.ownText().trim());
            String href = forumLink.attr("href");
            Matcher m = Pattern.compile("forum-(\\d+)-").matcher(href);
            if (m.find()) detail.setForumFid(m.group(1));
        }

        // === 2. 帖子标题 + 浏览量 ===
        Element titleEl = doc.select("div.comiis_viewtit h2 div.km_tits").first();
        if (titleEl != null) {
            detail.setTitle(titleEl.text().trim());
        }
        // Comiis 模板：浏览量在标题下方的 p.xg1 中，如 "查看: 1234"
        Element viewArea = doc.select("div.comiis_viewtit p.xg1").first();
        if (viewArea != null) {
            // 尝试精确选择器：某些模板用 span.y 显示查看数
            Element viewSpan = viewArea.select("span.y:contains(查看)").first();
            if (viewSpan == null) {
                // 兜底：遍历所有 span 查找包含"查看"文字的
                Elements spans = viewArea.select("span");
                for (Element span : spans) {
                    String text = span.text().trim();
                    if (text.contains("查看") || text.contains("浏览")) {
                        viewSpan = span;
                        break;
                    }
                }
            }
            if (viewSpan != null) {
                detail.setViews(parseIntFromText(viewSpan.text()));
            }
        }
        // 如果上面没找到，尝试从更宽泛的选择器查找
        if (detail.getViews() == 0) {
            Element fallbackView = doc.select("p.xg1:contains(查看), span:contains(查看:), span:contains(浏览:)").first();
            if (fallbackView != null) {
                detail.setViews(parseIntFromText(fallbackView.text()));
            }
        }
        // 桌面版模板：浏览量在 span.comiis_cks > strong 中
        if (detail.getViews() == 0) {
            Element desktopViewEl = doc.select("span.comiis_cks strong").first();
            if (desktopViewEl != null) {
                detail.setViews(parseIntFromText(desktopViewEl.text()));
            }
        }
        // 移动版模板：回复数在 comiis_pltit h2 > span.f_d 中（如 "全部评论18"）
        if (detail.getReplyCount() == 0) {
            Element replyCountEl = doc.select("div.comiis_pltit h2 span.f_d").first();
            if (replyCountEl != null) {
                detail.setReplyCount(parseIntFromText(replyCountEl.text()));
            }
        }

        // === 3. formhash & tid ===
        Element fhInput = doc.select("input[name=formhash]").first();
        if (fhInput != null) {
            detail.setFormhash(fhInput.attr("value"));
        }
        if (detail.getFormhash() == null || detail.getFormhash().isEmpty()) {
            Matcher fhM = Pattern.compile("formhash\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(html);
            if (fhM.find()) detail.setFormhash(fhM.group(1));
        }
        Matcher tidM = Pattern.compile("tid\\s*=\\s*['\"](\\d+)['\"]").matcher(html);
        if (tidM.find()) detail.setTid(tidM.group(1));

        // === 3.1 当前用户的点赞/收藏状态（必须以网页端状态为准） ===
        parseCurrentActionStates(doc, html, detail);

// === 4. 所有 postli 元素 ===
        Elements allPostlis = doc.select("div.comiis_postli");
        android.util.Log.d("ForumParser", "allPostlis size=" + allPostlis.size());
        // 非标准模板：只把真正包含正文容器的帖子外壳当作 postli，
        // 避免把导航栏/按钮等普通 div[class*=post] 误当成楼主帖子。
        if (allPostlis.isEmpty()) {
            allPostlis = doc.select(
                    "article:has(div.comiis_message), article:has(td.t_f), "
                            + "div[class*=post]:has(div.comiis_message), "
                            + "div[class*=post]:has(td.t_f), "
                            + "div[class*=thread]:has(div.comiis_message), "
                            + "div[class*=thread]:has(td.t_f)");
        }
        if (allPostlis.isEmpty()) {
            // 页面可能没有 postli 外壳，但仍然包含正文容器。此时不能直接返回空 detail，
            // 否则客户端会把一个实际有内容的帖子显示成空白。
            Element fallbackContent = doc.select(
                    "div.comiis_message, td.t_f, div.message, div.postbody, article").first();
            if (fallbackContent != null) {
                Element clone = fallbackContent.clone();
                clone.select("script, style, div.comiis_favshare, div.comiis_postli_time, a.followmod")
                        .remove();
                stripSocialActionAreas(clone);
                String fallbackHtml = clone.html().trim();
                if (!TextUtils.isEmpty(fallbackHtml)) {
                    detail.setContentHtml(fallbackHtml);
                }
            }
            detail.setReplies(new ArrayList<ReplyItem>());
            detail.setImageUrls(new ArrayList<String>());
            detail.setCurrentPage(1);
            detail.setTotalPages(1);
            return detail;
        }

        // 第一个 postli 通常是楼主帖子（首页），但非首页时可能是普通回复。
        // 通过检查是否有 comiis_postli_top_v1 类来区分楼主（楼主有此特殊类）。
        Element opPostli = allPostlis.first();
        // Discuz! 的赞赏接口不是只按 tid 操作，必须传入具体正文 pid。
        // Comiis 模板把它放在楼主 postli 的 id="pidxxxx" 中。
        String opPid = opPostli.id();
        // 只有楼主帖子才有 comiis_postli_top_v1 类，非首页的第一个 postli 没有此类
        Element opTopV1 = opPostli.select("div.comiis_postli_topv1").first();
        if (opTopV1 != null && !TextUtils.isEmpty(opPid) && opPid.startsWith("pid")) {
            detail.setPostPid(opPid.substring(3));
        }

        // === 5. 帖主（楼主）信息 ===
        Element opTop = opPostli.select("div.comiis_postli_top").first();
        if (opTop != null) {
            // 头像
            Element avatarImg = opTop.select("a.postli_top_tximg img.top_tximg").first();
            if (avatarImg != null) {
                String src = avatarImg.attr("src");
                if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                detail.setAvatarUrl(src);
            }
            // 用户名 & UID
            Element authorEl = opTop.select("a.top_user.f_b").first();
            if (authorEl != null) {
                detail.setAuthor(authorEl.text().trim());
                Matcher m = Pattern.compile("uid=(\\d+)").matcher(authorEl.attr("href"));
                if (m.find()) detail.setAuthorUid(m.group(1));
            }
            // 等级
            Element levelEl = opTop.select("a.top_lev.bg_a").first();
            if (levelEl != null) detail.setAuthorLevel(levelEl.text().trim());
            // 性别
            Element genderEl = opTop.select("i.comiis_font.top_gender").first();
            if (genderEl != null) {
                String cls = genderEl.className();
                if (cls.contains("bg_boy")) detail.setGender("boy");
                else if (cls.contains("bg_girl")) detail.setGender("girl");
            }
            // 关注状态
            Element followEl = opTop.select("a.followmod").first();
            if (followEl != null) {
                detail.setFollowed(followEl.text().trim().contains("已关注"));
            }
            // 楼主时间 & 地点
            Element opTimeArea = opTop.select("div.comiis_postli_time").first();
            if (opTimeArea != null) {
                Element timeEl = opTimeArea.select("span.kmtime").first();
                if (timeEl != null) detail.setPublishTime(timeEl.text().trim());
                Element locCode = opTimeArea.select("code.comiis_iplocality").first();
                if (locCode != null) detail.setLocation(locCode.text().trim());
            }
        }

        // === 6. 帖子正文 + 附件图片 ===
        Element opMsg = opPostli.select("div.comiis_message").first();
        if (opMsg != null) {
            // ★ 尝试多种选择器提取正文内容（优先精确选择器，兜底取整个消息区）
            Element contentDiv = opMsg.select("div.comiis_a.comiis_message_table.cl").first();
            if (contentDiv == null) {
                contentDiv = opMsg.select("div.comiis_a").first();
            }
            if (contentDiv == null) {
                contentDiv = opMsg.select("div.comiis_message_table").first();
            }
            if (contentDiv == null && !TextUtils.isEmpty(opMsg.html())) {
                // ★ 最终兜底：移除回复按钮等干扰元素后直接取内容
                Element msgClone = opMsg.clone();
                msgClone.select("div.comiis_favshare").remove();
                msgClone.select("a.followmod").remove();
                msgClone.select("div.comiis_postli_time").remove();
                msgClone.select("div.comiis_message_table.cl").remove();
                String remaining = msgClone.html().trim();
                if (!TextUtils.isEmpty(remaining) && remaining.length() > 50) {
                    contentDiv = opMsg; // 使用opMsg自身作为内容容器
                }
            }
            if (contentDiv != null) {
                // 正文容器内混有点赞人/赞赏区，必须在克隆上剔除后再输出，
                // 否则点赞人头像会被当成正文图片放大显示。
                Element contentOut = contentDiv.clone();
                stripSocialActionAreas(contentOut);
                String content = contentOut.html().trim();
                // 如果内容太短可能只是干扰文本，尝试更精确提取
                if (content.length() < 10 && opMsg.select("td.t_f").first() != null) {
                    content = opMsg.select("td.t_f").first().html().trim();
                }
                detail.setContentHtml(content);
            } else {
                // 兜底：直接取整个消息区，并移除操作区域
                Element msgClone = opMsg.clone();
                msgClone.select("div.comiis_favshare, a.followmod, div.comiis_postli_time").remove();
                stripSocialActionAreas(msgClone);
                String fallbackHtml = msgClone.html().trim();
                if (fallbackHtml.length() > 30) {
                    detail.setContentHtml(fallbackHtml);
                }
            }

            // 无论正文使用哪一个选择器，都必须提取正文中的懒加载图片。
            // 旧代码把这段逻辑放在 contentDiv == null 分支中，导致大多数正常帖子
            // 虽然 HTML 中有图片，但 imageUrls 始终为空。
            // 隐藏内容检测（对齐开源 sqapp 机制：语义判别 + 真实内容提取 + 原位置标记）
            // ★ 引用块与隐藏内容提示框都使用 comiis_quote 类，不能把第一个
            // comiis_quote 直接当作隐藏内容。只有满足隐藏语义（"本帖隐藏的内容"/
            // "游客+回复"/hide 类名）时才判定为隐藏内容，避免引用误判、隐藏漏判。
            //
            // 注意：为了保留隐藏块在正文中的原始位置，这里在 contentHtml 的副本
            // （content 变量）上也执行标记，渲染端用 data-sqapp-hidden 识别并内联卡片。
            // content 变量的赋值在上一段，因此需要同步更新 content：
            Element hiddenOwner = null;
            if (contentDiv != null) {
                hiddenOwner = contentDiv;
            } else if (opMsg != null) {
                hiddenOwner = opMsg;
            }
            if (hiddenOwner != null) {
                Element contentClone = hiddenOwner.clone();
                contentClone.select("script, style").remove();
                // 与上面 setContentHtml 保持一致：这条分支会用 contentClone 覆盖
                // 正文 HTML，若不同样剔除，有隐藏内容的帖子仍会漏出点赞人头像
                // （thread-172019 正是这种：既有隐藏块又有点赞人）。
                stripSocialActionAreas(contentClone);
                List<Element> hiddenMarkers = findHiddenContentMarkers(contentClone);
                if (!hiddenMarkers.isEmpty()) {
                    detail.setHasHiddenContent(true);
                    StringBuilder hiddenHtml = new StringBuilder();
                    for (Element marker : hiddenMarkers) {
                        String part = extractHiddenContentHtml(marker);
                        if (!TextUtils.isEmpty(part)) {
                            if (hiddenHtml.length() > 0) hiddenHtml.append("<br />");
                            hiddenHtml.append(part);
                        }
                        replaceHiddenMarkerWithPlaceholder(marker, part);
                    }
                    detail.setHiddenContentHtml(hiddenHtml.toString().trim());
                    // 同步更新正文 HTML：隐藏块原位替换为 data-sqapp-hidden 标记
                    String marked = contentClone.html().trim();
                    if (!TextUtils.isEmpty(marked) && marked.length() > 10) {
                        detail.setContentHtml(marked);
                    }
                }
            }

            // ===== 投票解析 =====
            // comiis_poll 与正文 comiis_a 同级，在 div.comiis_messages 内，
            // 不属于 contentDiv，需要单独提取。
            Poll poll = parsePoll(opMsg);
            if (poll != null) {
                detail.setPoll(poll);
            }

            // ★ 图片提取移到隐藏内容处理之后：使用已标记的 contentClone（隐藏内容已被
            // data-sqapp-hidden 标记），克隆后移除隐藏区域，只从正文可见区域提取图片。
            // 这样隐藏内容中的飞书网盘等图片不会被误提到底部图片列表。
            Element messagesDiv = opMsg.select("div.comiis_messages").first();
            if (messagesDiv == null) messagesDiv = opMsg;
            Element imgScanRoot = messagesDiv.clone();
            imgScanRoot.select("script, style").remove();
            // ★ 用同样的隐藏内容检测逻辑找到并移除隐藏区域
            List<Element> hiddenMarkers = findHiddenContentMarkers(imgScanRoot);
            for (Element hm : hiddenMarkers) {
                hm.remove();
            }
            // 移除打赏/好评/推荐区域的头像图片（不属于帖子正文图片）
            imgScanRoot.select(".comiis_rate img").remove();
            imgScanRoot.select(".comiis_recommend_list_a img").remove();
            imgScanRoot.select(".comiis_dzhan_img img").remove();
            List<String> attachImageUrls = new ArrayList<>();
            for (Element img : imgScanRoot.select("img")) {
                String realSrc = firstNonEmptyAttr(img,
                        "comiis_loadimages", "file", "data-original", "data-src",
                        "data-file", "data-lazy-src", "src");
                String fullUrl = resolveAttachmentUrl(realSrc);
                if (isPostImageUrl(fullUrl) && !attachImageUrls.contains(fullUrl)) {
                    attachImageUrls.add(fullUrl);
                }
            }
            detail.setImageUrls(attachImageUrls);
            // 点赞数（从 comiis_recommend_num 元素获取真实值，非 li 个数）
            Element recommendNum = opMsg.select(".comiis_recommend_num").first();
            if (recommendNum != null) {
                detail.setLikeCount(parseIntFromText(recommendNum.text()));
            }
        }

        // === 6.5 收藏数（从底部栏 comiis_favorite_a_num 元素获取） ===
        Element favoriteNum = doc.select("span.comiis_favorite_a_num").first();
        if (favoriteNum != null) {
            detail.setFavoriteCount(parseIntFromText(favoriteNum.text()));
        }

        // === 7. 回复标题栏：评论总数 ===
        Element pltit = doc.select("div.comiis_pltit").first();
        if (pltit != null) {
            Element countSpan = pltit.select("span.f_d").first();
            if (countSpan != null) {
                detail.setReplyCount(parseIntFromText(countSpan.text()));
            }
        }

        // === 8. 回复列表 ===
        // 楼主帖子是第一个 postli（id 以 pid 开头且有 comiis_postli_top_v1 类）。
        // 但非首页的第一个 postli 可能不是楼主，而是该页的第一条回复。
        // 安全做法：遍历所有 postli，跳过没有 pid id 的元素（如 post_new），
        // 跳过楼主帖子（通过判断是否是 OP）。
        List<ReplyItem> replies = new ArrayList<>();
        Pattern uidPtn = Pattern.compile("uid=(\\d+)");
        String opPidVal = detail.getPostPid();  // 楼主的 pid

        for (int i = 0; i < allPostlis.size(); i++) {
            try {
                Element rp = allPostlis.get(i);
                String pidAttr = rp.id();
                // 跳过非 pid 元素（如 post_new）
                if (pidAttr == null || !pidAttr.startsWith("pid")) {
                    continue;
                }
                // 跳过楼主帖子（首页第一个 postli）
                if (opPidVal != null && !opPidVal.isEmpty()
                        && pidAttr.equals("pid" + opPidVal)) {
                    continue;
                }
                ReplyItem reply = new ReplyItem();
                reply.setPid(pidAttr.substring(3));
                Element rTop = rp.select("div.comiis_postli_top").first();
                if (rTop == null) {
                    android.util.Log.d("ForumParser", "skip reply pid=" + pidAttr + " (no postli_top)");
                    continue;
                }

                // 楼层号
                Element floorEl = rTop.select("span.f_d.y").first();
                if (floorEl != null) reply.setFloorLabel(floorEl.text().trim());

                // 用户名 & UID
                Element userEl = rTop.select("a.top_user.f_b").first();
                if (userEl != null) {
                    reply.setAuthor(userEl.text().trim());
                    Matcher m = uidPtn.matcher(userEl.attr("href"));
                    if (m.find()) reply.setAuthorUid(m.group(1));
                }
                // 等级
                Element levEl = rTop.select("a.top_lev.bg_a").first();
                if (levEl != null) reply.setAuthorLevel(levEl.text().trim());
                // 性别
                Element gEl = rTop.select("i.comiis_font.top_gender").first();
                if (gEl != null) {
                    String cls = gEl.className();
                    if (cls.contains("bg_boy")) reply.setGender("boy");
                    else if (cls.contains("bg_girl")) reply.setGender("girl");
                }
                // 楼主标识
                Element opTag = rTop.select("span.top_lev.bg_c.f_f").first();
                if (opTag != null && opTag.text().contains("楼主")) {
                    reply.setOP(true);
                }
                // 头像
                Element rAvatar = rTop.select("a.postli_top_tximg img.top_tximg").first();
                if (rAvatar != null) {
                    String src = rAvatar.attr("src");
                    if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                    reply.setAvatarUrl(src);
                }

                // 置顶回复标识。不同模板输出方式不一致，需要多路兜底：
                //   1) Comiis 手机模板：楼层容器带 top_reply / comiis_top / sticky 一类的 class
                //   2) 桌面/mi 模板：楼层号旁输出 <img src=".../settop.png" title="置顶回复">
                //   3) 少数模板直接在楼层信息区输出纯文本"置顶"
                reply.setPinned(detectReplyPinned(rp));

                // 回复内容（★ 添加兜底选择器）
                Element rContent = rp.select("div.comiis_message div.comiis_a.comiis_message_table.cl").first();
                if (rContent == null) {
                    rContent = rp.select("div.comiis_message div.comiis_a").first();
                }
                if (rContent == null) {
                    rContent = rp.select("div.comiis_message").first();
                }
                if (rContent != null) {
                    // ★ 修复：回复中的图片列表可能用两种 class：
                    //   ul.comiis_img_one — 网页端插入的图片
                    //   ul.comiis_img_list — 附件图片列表（如截图证据等）
                    // 两者都是 div.comiis_a 的同级元素，旧逻辑只取 div.comiis_a 会丢掉这些图片。
                    for (Element ul : rp.select("div.comiis_messages > ul.comiis_img_one, div.comiis_messages > ul.comiis_img_list")) {
                        if (ul.parent() != rContent) {
                            rContent.appendChild(ul.clone());
                        }
                    }
                    // Discuz 回复内容中通常包含 div.comiis_quote 引用块。
                    // 引用与当前回复必须拆开保存，否则客户端会把引用文本和新回复连成一段。
                    Element quote = rContent.select("div.comiis_quote, blockquote, .quote").first();
                    if (quote != null) {
                        reply.setQuotedContentHtml(quote.html().trim());
                        String quotedText = quote.text().replace('\u00a0', ' ').trim();
                        // ★ 修复：Discuz 引用块中"回复xxx 发表于时间"元信息与正文在 text() 展平后
                        // 会粘连成一行（如"回复LZY·网络资源 发表于2026-7-12 08:38你好"）。
                        // 识别"发表于...时间"边界，在时间后插入换行，让引用原文分两行显示。
                        quotedText = insertNewlineAfterQuoteTime(quotedText);
                        reply.setQuotedContentText(quotedText);
                        quote.remove();
                    }
                    reply.setContentHtml(rContent.html().trim());
                    reply.setContentText(rContent.text().replace('\u00a0', ' ').trim());
                }

                // 回复时间 & 地点（底栏 div.comiis_postli_times）
                Element rTimes = rp.select("div.comiis_postli_times").first();
                if (rTimes != null) {
                    Element timeEl = rTimes.select("span.comiis_tm").first();
                    if (timeEl != null) reply.setTime(timeEl.text().trim());
                    Element locCode = rTimes.select("code.comiis_iplocality").first();
                    if (locCode != null) reply.setLocation(locCode.text().trim());
                }

                replies.add(reply);
            } catch (Exception ignored) {}
        }
        detail.setReplies(replies);
        android.util.Log.d("ForumParser", "parsed replies count=" + replies.size());

        // === 9. 分页信息 ===
        Element pageInput = doc.select("input[name=page]").first();
        if (pageInput != null) {
            int curPage = parseIntFromText(pageInput.attr("value"));
            detail.setCurrentPage(curPage > 0 ? curPage : 1);
        } else {
            detail.setCurrentPage(1);
        }
        // 从分页组件中提取最大页码
        // MT论坛移动版分页：<div class="pg"><strong>1</strong><a href="...thread-xxx-2-1.html">2</a>...<span title="共 N 页"> / N 页</span></div>
        int maxPage = 1;
        // 方式1: 从 <span title="共 N 页"> 提取
        Element pgDiv = doc.select("div.pg").first();
        if (pgDiv != null) {
            Element span = pgDiv.select("span[title*=共]").first();
            if (span != null) {
                String title = span.attr("title");
                Matcher titleM = Pattern.compile("共\\s*(\\d+)\\s*页").matcher(title);
                if (titleM.find()) {
                    maxPage = parseIntFromText(titleM.group(1));
                } else {
                    // 从文本 " / N 页" 提取
                    Matcher textM = Pattern.compile("/?\\s*(\\d+)\\s*页").matcher(span.text());
                    if (textM.find()) {
                        maxPage = parseIntFromText(textM.group(1));
                    }
                }
            }
            // 方式2: 从分页数字链接 thread-{tid}-{page}-1.html 提取
            if (maxPage <= 1) {
                Elements numLinks = pgDiv.select("a[href*=-1.html]");
                Pattern tidPagePtn = Pattern.compile("thread-\\d+-(\\d+)-1\\.html");
                for (Element pl : numLinks) {
                    Matcher pm = tidPagePtn.matcher(pl.attr("href"));
                    if (pm.find()) {
                        try {
                            int p = Integer.parseInt(pm.group(1));
                            if (p > maxPage) maxPage = p;
                        } catch (Exception ignored) {}
                    }
                }
            }
        }
        // 方式3: 兜底，从 a[href*=page=] 提取（兼容桌面版）
        if (maxPage <= 1) {
            Elements pageLinks = doc.select("a[href*=page=]");
            Pattern pagePtn = Pattern.compile("[&?]page=(\\d+)");
            for (Element pl : pageLinks) {
                Matcher pm = pagePtn.matcher(pl.attr("href"));
                if (pm.find()) {
                    try {
                        int p = Integer.parseInt(pm.group(1));
                        if (p > maxPage) maxPage = p;
                    } catch (Exception ignored) {}
                }
            }
        }
detail.setTotalPages(maxPage);

          // === 10. 赞赏与好评统计（如有） ===
          // Comiis 移动端结构：rate_tip 同时包含“X人打赏”和“Y好评”，
          // 下方 ul li 为打赏头像列表；rate_tip 中的链接指向全部打赏明细。
          Element rateDiv = doc.select("div.comiis_rate").first();
          List<String> rewardAvatars = new ArrayList<>();
          List<String> goodReviewAvatars = new ArrayList<>();
          if (rateDiv != null) {
              Element rateTip = rateDiv.select("p.rate_tip").first();
              String rateTipText = rateTip != null ? rateTip.text().trim() : rateDiv.text().trim();
              Matcher rewardCountMatcher = Pattern.compile("(\\d+)\\s*人?打赏").matcher(rateTipText);
              if (rewardCountMatcher.find()) {
                  detail.setRewardCount(parseIntFromText(rewardCountMatcher.group(1)));
              } else {
                  Element rateBtn = rateDiv.select("h2.rate_btn").first();
                  if (rateBtn != null && rateBtn.text().contains("赞赏")) {
                      detail.setRewardCount(parseIntFromText(rateBtn.text()));
                  }
              }

              Matcher goodCountMatcher = Pattern.compile("(\\d+)\\s*好评").matcher(rateTipText);
              if (goodCountMatcher.find()) {
                  detail.setGoodReviewCount(parseIntFromText(goodCountMatcher.group(1)));
              }

              if (rateTip != null) {
                  Element rewardLink = rateTip.select("a[href*=viewratings]").first();
                  if (rewardLink != null) {
                      String href = rewardLink.attr("href");
                      detail.setRewardDetailUrl(resolveAttachmentUrl(href));
                  }
              }

              for (Element img : rateDiv.select("ul > li img")) {
                  String avatar = resolveAvatarUrl(firstNonEmptyAttr(img,
                          "src", "data-src", "data-original", "data-lazy-src"));
                  if (!TextUtils.isEmpty(avatar) && !rewardAvatars.contains(avatar)) {
                      rewardAvatars.add(avatar);
                  }
              }
          }
          detail.setRewardUserAvatars(rewardAvatars);
          detail.setGoodReviewUserAvatars(goodReviewAvatars);

          return detail;
    }

    /**
     * 解析“查看全部打赏”页面中的打赏金币总数。
     * 页面格式通常为：总计：金币 +4，好评 +2。
     */
    public static int parseRewardCoins(String html) {
        if (TextUtils.isEmpty(html)) return 0;
        String text = Jsoup.parse(html).text();
        Matcher matcher = Pattern.compile("金币\\s*\\+\\s*(\\d+)").matcher(text);
        if (matcher.find()) return parseIntFromText(matcher.group(1));
        return 0;
    }
    /**
     * 从桌面版评分表提取真正获得“好评”的用户头像。
     * 移动版只展示打赏头像，不包含好评用户明细，因此由详情页加载时补充。
     */
    public static List<String> parseGoodReviewAvatarUrls(String html) {
        List<String> avatars = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return avatars;
        Document doc = Jsoup.parse(html);
        for (Element row : doc.select("tr[id^=rate_]")) {
            Elements cells = row.select("> td");
            if (cells.size() >= 2 && cells.get(1).text().contains("+")) {
                Element img = row.select("td:first-child img").first();
                String avatar = resolveAvatarUrl(firstNonEmptyAttr(img,
                        "src", "data-src", "data-original", "data-lazy-src"));
                if (!TextUtils.isEmpty(avatar) && !avatars.contains(avatar)) {
                    avatars.add(avatar);
                }
            }
        }
        return avatars;
    }
/**
     * 从 Comiis 详情页解析当前登录用户的点赞/收藏状态。
     * uid 非 0 且页面存在对应操作控件时标记状态已知。
     */
    private static void parseCurrentActionStates(Document doc, String html, PostDetail detail) {
        if (doc == null || detail == null || TextUtils.isEmpty(html)) return;

        Matcher uidMatcher = Pattern.compile("(?:var\\s+)?uid\\s*=\\s*['\"](\\d+)['\"]",
                Pattern.CASE_INSENSITIVE).matcher(html);
        if (!uidMatcher.find() || "0".equals(uidMatcher.group(1))) return;

        Element recommend = doc.select(
                "a.comiis_recommend_addkey, a.comiis_recommend_new, "
                        + ".comiis_recommend_addkey").first();
        if (recommend != null) {
            Element icon = recommend.select("i.comiis_recommend_color").first();
            String classes = recommend.className() + " " +
                    (icon != null ? icon.className() : "");
            String iconHtml = icon != null ? icon.html() : "";
            boolean liked = classes.contains("f_a") || iconHtml.contains("e654");
            detail.setLiked(liked);
            detail.setLikedStateKnown(true);
        }

        Element favoriteIcon = doc.select("#comiis_favorite_a i.comiis_favorite_a_color").first();
        if (favoriteIcon != null) {
            String classes = favoriteIcon.className();
            String iconHtml = favoriteIcon.html();
            boolean favorited = classes.contains("f_a") || iconHtml.contains("e64c");
            detail.setFavorited(favorited);
            detail.setFavoritedStateKnown(true);
        }
    }


    /**
     * 判断单个回复楼层是否被服务端置顶。
     *
     * <p>Discuz 的"置顶回复"（topicadmin action=stickreply）在不同模板下标记方式完全不同，
     * 这里按可靠性从高到低依次判断，任一命中即认为置顶：
     * <ol>
     *   <li>楼层容器上的置顶类名（Comiis 手机模板）</li>
     *   <li>楼层号旁的置顶图标：{@code <img src="…/settop.png" title="置顶回复">}（桌面 / comiis_mi 模板）</li>
     *   <li>楼层信息区里的纯文本"置顶"标签（少数模板）</li>
     * </ol>
     *
     * <p>第 3 条只扫描楼层信息区（{@code div.comiis_postli_top}），不扫正文，
     * 否则正文里出现"置顶"两个字的回复会被误判。
     *
     * @param replyEl 单个楼层容器元素
     * @return true=服务端已置顶
     */
    private static boolean detectReplyPinned(Element replyEl) {
        if (replyEl == null) return false;

        // 1) 模板类名
        if (!replyEl.select(".comiis_top, .top_reply, i.comiis_top, "
                + "[class*=pinned], [class*=sticky], [class*=top_reply]").isEmpty()) {
            return true;
        }

        // 2) 置顶图标：优先看 title/alt，再看图片文件名，避免模板换文案后失效
        for (Element img : replyEl.select("img")) {
            String title = img.attr("title");
            String alt = img.attr("alt");
            if ((title != null && title.contains("置顶"))
                    || (alt != null && alt.contains("置顶"))) {
                return true;
            }
            String src = img.attr("src");
            if (src != null && (src.contains("settop") || src.contains("stickreply"))) {
                return true;
            }
        }

        // 3) 楼层信息区里的纯文本标签
        Element top = replyEl.select("div.comiis_postli_top").first();
        if (top != null) {
            for (Element marker : top.select("*")) {
                String text = marker.text();
                if (text == null) continue;
                text = text.replaceAll("\\s+", " ").trim();
                if ("置顶".equals(text) || "顶".equals(text) || "置顶回复".equals(text)) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * 提取 formhash（发帖/回复需要）
     * 优先从 input[name=formhash] 提取，再尝试 JS 变量，最后尝试收藏对话框表单。
     */
    /**
     * 解析 Discuz 登录失败时的错误提示。
     * Discuz 在登录失败时会重新渲染登录页，并在 alertinfo / messagetext 区域显示中文提示。
     * 覆盖：安全提问、密码错误、用户不存在、尝试次数过多、需要验证码等。
     */
    public static String parseLoginError(String html) {
        if (html == null || html.isEmpty()) return null;

        // 优先取 Discuz 的 messagetext / alertinfo 节点
        Document doc = Jsoup.parse(html);
        for (String sel : new String[]{"div.messagetext", "div.alert_info", "p.messagetext",
                "div.alert_error", "p.alert_info", ".alert_info p"}) {
            Element el = doc.selectFirst(sel);
            if (el != null) {
                String t = el.text().trim();
                if (!t.isEmpty()) return t;
            }
        }

        // 兜底：关键字匹配
        String[] rules = {
                "安全提问", "请回答安全提问",
                "密码错误", "密码不正确",
                "不存在", "用户名不存在",
                "尝试次数过多", "已被锁", "请稍后再试",
                "验证码", "请输入验证码",
                "未激活", "尚未激活"
        };
        for (String r : rules) {
            if (html.contains(r)) {
                return r.contains("安全提问") ? "请正确填写安全提问及答案" : r;
            }
        }
        return null;
    }

    public static String parseFormhash(String html) {
        if (TextUtils.isEmpty(html)) return null;
        Document doc = Jsoup.parse(html);
        Element input = doc.select("input[name=formhash]").first();
        if (input != null) return input.attr("value");

        // 尝试从 JavaScript 变量中提取
        Matcher m = Pattern.compile("formhash\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(html);
        if (m.find()) return m.group(1);

        return null;
    }

    /**
     * 从收藏页面 HTML 中提取删除/添加收藏对话框里的 formhash。
     * Comiis 模板的收藏对话框表单 id 为 favoriteform_{favid}，
     * 内部包含隐藏的 input[name=formhash]。
     */
    public static String parseFavoriteFormhash(String html) {
        if (TextUtils.isEmpty(html)) return null;
        Document doc = Jsoup.parse(html);
        // 收藏对话框表单 id 包含 "favoriteform"
        Element form = doc.select("form[id*=favoriteform]").first();
        if (form != null) {
            Element input = form.select("input[name=formhash]").first();
            if (input != null) {
                String val = input.attr("value");
                if (!TextUtils.isEmpty(val)) return val;
            }
        }
        // 兜底：尝试从页面中任意 form 的 input[name=formhash] 提取
        Element fallback = doc.select("input[name=formhash]").first();
        if (fallback != null) {
            String val = fallback.attr("value");
            if (!TextUtils.isEmpty(val)) return val;
        }
        // 最后尝试从 JS 变量提取
        Matcher m = Pattern.compile("formhash\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(html);
        if (m.find()) return m.group(1);
        return null;
    }

    /**
     * 从 URL 中提取参数
     */
    private static String extractParam(String url, String param) {
        if (url == null || url.isEmpty()) return null;
        try {
            Pattern p = Pattern.compile(param + "=(\\d+)");
            Matcher m = p.matcher(url);
            if (m.find()) return m.group(1);

            // 尝试更通用的匹配（非纯数字参数）
            Pattern p2 = Pattern.compile(param + "=([^&]+)");
            Matcher m2 = p2.matcher(url);
            if (m2.find()) return m2.group(1);
        } catch (Exception ignored) {}
        return null;
    }

    /** Extract user UIDs from a following-list page. */
    public static Set<String> extractFollowingUids(String html) {
        Set<String> uids = new HashSet<>();
        if (TextUtils.isEmpty(html)) return uids;
        Document doc = Jsoup.parse(html);
        Elements links = doc.select("div.comiis_userlist01 > li.b_t > p.tit > a[href*=uid=], li.b_t p.tit a[href*=uid=]");
        if (links.isEmpty()) links = doc.select("a[href*=home.php?mod=space&uid=]");
        for (Element link : links) {
            String uid = extractParam(link.attr("href"), "uid");
            if (!TextUtils.isEmpty(uid)) uids.add(uid);
        }
        return uids;
    }


    /** 判断关注列表是否还有下一页。 */
    public static boolean hasUserListPageAfter(String html, int currentPage) {
        if (TextUtils.isEmpty(html)) return false;
        Document doc = Jsoup.parse(html);
        for (Element link : doc.select("a[href*=page=]")) {
            Matcher matcher = Pattern.compile("(?:^|[?&])page=(\\d+)")
                    .matcher(link.attr("href"));
            if (matcher.find()) {
                try {
                    if (Integer.parseInt(matcher.group(1)) > currentPage) return true;
                } catch (Exception ignored) {
                }
            }
        }
        return false;
    }

    /**
     * 解析好友/关注/粉丝列表
     * 适配 Comiis App 模板。
     * 基于真实登录页面分析（2026-06-13 实机验证），采用精确选择器：
     *
     * 真实 DOM 结构（好友页）：
     *   div.comiis_friend_boxs
     *     div.mt10.bg_f.b_b.cl
     *       div.comiis_userlist01.cl
     *         li.b_t
     *           p.ytit.f_d ── 操作链接（删除/分组/取消/打招呼/发消息）
     *           a.list01_limg > img[src*=avatar] ── 头像
     *           p.tit > a[href*="home.php?mod=space&uid="] ── 用户名（唯一可靠标识）
     *           p.txt > font ── 等级/积分
     *
     * 关注/粉丝页结构与好友页类似，用户条目位于相同 li.b_t 容器内。
     *
     * ★ 关键修复：不再使用宽泛的 a[href*=uid=]（会误匹配选项卡、删除按钮等），
     *   改为精确的：div.comiis_userlist01 > li.b_t > p.tit > a[href*=uid=]
     *
     * @param html 好友/关注/粉丝页 HTML
     * @return 好友/用户列表
     */
    public static List<Friend> parseFriendList(String html) {
        List<Friend> friends = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return friends;
        Document doc = Jsoup.parse(html);

        // ★ 精确策略：先找用户条目容器 li.b_t，再从中提取用户名链接
        //   div.comiis_userlist01 是 Comiis 模板的用户列表容器
        Elements userItems = doc.select("div.comiis_userlist01 > li.b_t");
        if (userItems.isEmpty()) {
            // 兜底：直接找 li.b_t（某些页面结构略有不同）
            userItems = doc.select("li.b_t");
        }

        for (Element li : userItems) {
            try {
                // 用户名链接：唯一可靠的是 p.tit 内的 a[href*=uid=]
                Element usernameLink = li.select("p.tit > a[href*=uid=]").first();
                if (usernameLink == null) {
                    // 兜底：直接的 a[href*=uid=]（关注页结构可能略有不同）
                    usernameLink = li.select("a[href*=uid=]").first();
                }
                if (usernameLink == null) continue;

                String username = usernameLink.text().trim();
                if (TextUtils.isEmpty(username)) continue;

                String href = usernameLink.attr("href");
                Matcher m = Pattern.compile("uid=(\\d+)").matcher(href);
                if (!m.find()) continue;
                String uid = m.group(1);

                // 去重
                boolean duplicate = false;
                for (Friend existing : friends) {
                    if (uid.equals(existing.getUid())) {
                        duplicate = true;
                        break;
                    }
                }
                if (duplicate) continue;

                Friend f = new Friend();
                f.setUid(uid);
                f.setUsername(username);

                // 头像
                Element avatarImg = li.select("a.list01_limg img[src*=avatar], img[src*=avatar]").first();
                if (avatarImg != null) {
                    String src = avatarImg.attr("src");
                    if (!src.startsWith("http")) src = BASE_DOMAIN + src;
                    f.setAvatarUrl(src);
                }

                // 等级（从 p.txt 或 span.kmlevs 中提取）
                Element levelEl = li.select(".kmlevs, .kmlv, span:contains(Lv)").first();
                if (levelEl == null) {
                    // 从 p.txt > font 中提取（好友页结构）
                    Elements txtFonts = li.select("p.txt > font");
                    boolean found = false;
                    for (Element font : txtFonts) {
                        String t = font.text().trim();
                        if (t.contains("Lv") || t.contains("硕士") || t.contains("博士")
                                || t.contains("大学") || t.contains("高中") || t.contains("初中")
                                || t.contains("小学") || t.contains("学前")) {
                            if (t.contains("积分")) {
                                t = t.replaceAll("积分.*", "").trim();
                            }
                            f.setLevel(t);
                            found = true;
                            break;
                        }
                    }
                    // 兜底：关注/粉丝页结构可能不同，搜索整个 li 的文本
                    if (!found) {
                        String liText = li.text().trim();
                        // 先尝试找 Lv 等级
                        Pattern levelPattern = Pattern.compile("Lv[^\\s]*\\s*[^\\s积分]+");
                        Matcher levelMatcher = levelPattern.matcher(liText);
                        if (levelMatcher.find()) {
                            f.setLevel(levelMatcher.group().trim());
                        } else {
                            // 再找"初中生""高中生""大学生""研究生"等
                            Pattern levelPattern2 = Pattern.compile("(?:初中|高中|大学|研究|小学|学前)生");
                            Matcher levelMatcher2 = levelPattern2.matcher(liText);
                            if (levelMatcher2.find()) {
                                f.setLevel(levelMatcher2.group().trim());
                            }
                        }
                    }
                } else {
                    f.setLevel(levelEl.text().trim());
                }

                // 用户组（从 p.txt 中提取，如"版主"、"管理员"、"超级版主"等）
                // 根据 Comiis 模板结构：p.txt 包含多个 <font>，依次为 等级、用户组、积分
                Elements txtFonts2 = li.select("p.txt > font");
                String levelText = f.getLevel();
                boolean foundLevel = false;
                for (Element font : txtFonts2) {
                    String t = font.text().trim();
                    if (TextUtils.isEmpty(t)) continue;
                    // 第一个 font 通常是等级，跳过已识别的等级
                    if (!foundLevel && (t.contains("Lv") || t.contains("硕士") || t.contains("博士")
                            || t.contains("大学") || t.contains("高中") || t.contains("初中")
                            || t.contains("小学") || t.contains("学前"))) {
                        foundLevel = true;
                        continue;
                    }
                    // 跳过积分
                    if (t.contains("积分")) continue;
                    // 跳过粉丝/关注 数字（粉丝页结构：如"23 粉丝"、"229 关注"）
                    if (t.contains("粉丝") || t.contains("关注")) continue;
                    // 剩余的就是用户组（如"版主"、"管理员"等）
                    f.setGroupName(t);
                    break;
                }

                // 积分（从 p.txt 中提取）
                Element creditsEl = li.select("p.txt > font:contains(积分)").first();
                if (creditsEl != null) {
                    f.setCredits(creditsEl.text().trim());
                }

                friends.add(f);
            } catch (Exception ignored) {}
        }

        return friends;
    
    }

    /**
     * 从用户资料页提取等级信息
     * 选择器：.kmlev (如"博士生"、"高中生"等)
     */
    public static String parseProfileLevel(String html) {
        if (TextUtils.isEmpty(html)) return null;
        Document doc = Jsoup.parse(html);
        // 先找 .kmlev（等级名称，如"博士生"、"高中生"）
        Element kmlev = doc.select(".kmlev").first();
        if (kmlev != null) {
            String level = kmlev.text().trim();
            if (!TextUtils.isEmpty(level)) return level;
        }
        // 兜底：找 .kmlevs（Lv 标签）
        Element kmlevs = doc.select(".kmlevs").first();
        if (kmlevs != null) {
            String level = kmlevs.text().trim();
            if (!TextUtils.isEmpty(level)) return level;
        }
        return null;
    }

public static List<Thread> parseFavoriteList(String html) {
        List<Thread> favorites = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return favorites;
        Document doc = Jsoup.parse(html);

        // 收藏页不同 UA/模板可能使用 thread-xxx.html、thread.php?tid=xxx，
        // 或 forum.php?mod=viewthread&tid=xxx，不能只依赖一种 URL。
        Elements links = doc.select("a[href*=thread-], a[href*=thread.php], a[href*=viewthread]");
        Pattern tidPretty = Pattern.compile("(?:^|/)thread-(\\d+)(?:-[^./?#]+)*\\.html", Pattern.CASE_INSENSITIVE);
        Pattern tidQuery = Pattern.compile("[?&](?:tid|threadid)=(\\d+)", Pattern.CASE_INSENSITIVE);
        Pattern favidPattern = Pattern.compile("(?:favid|fav_id)\\s*[=:/]\\s*['\"]?(\\d+)", Pattern.CASE_INSENSITIVE);
        Pattern favidHrefPattern = Pattern.compile("[?&](?:favid|fav_id)=(\\d+)", Pattern.CASE_INSENSITIVE);
        java.util.HashSet<String> seen = new java.util.HashSet<>();

        for (Element link : links) {
            try {
                String href = link.attr("href");
                Matcher m = tidPretty.matcher(href);
                String tid = m.find() ? m.group(1) : "";
                if (TextUtils.isEmpty(tid)) {
                    m = tidQuery.matcher(href);
                    if (m.find()) tid = m.group(1);
                }
                if (TextUtils.isEmpty(tid) || seen.contains(tid)) continue;

                // 标题优先取 title 属性（网页端此处不含回收站标记），其次取
                // ownText（排除标记等子元素），最后才退回整段 text。
                String title = link.attr("title").trim();
                if (TextUtils.isEmpty(title)) title = link.ownText().trim();
                boolean titleFromFullText = false;
                if (TextUtils.isEmpty(title)) {
                    title = link.text().trim();
                    titleFromFullText = true;
                }
                if (TextUtils.isEmpty(title)) continue;

                Thread t = new Thread();
                t.setTid(tid);
                // 收藏的帖子也可能已被移入回收站，剔除标记后单独渲染徽章
                if (titleFromFullText) {
                    // 整段文本已含标记，只能按前缀剔除
                    String stripped = stripRecycleMarker(title);
                    if (!stripped.equals(title)) {
                        t.setRecycled(true);
                        title = stripped;
                    }
                } else if (markRecycledFromMarker(link, title, t)) {
                    title = stripRecycleMarker(title);
                }
                t.setClosed(hasClosedMarker(link.parent(), link, title));
                t.setTitle(title);

                String favid = firstNonEmpty(link.attr("data-favid"), link.attr("data-fav-id"),
                        link.attr("favid"), link.attr("data-id"));
                Matcher hrefFav = favidHrefPattern.matcher(href);
                if (TextUtils.isEmpty(favid) && hrefFav.find()) favid = hrefFav.group(1);

                // 删除链接通常与标题同处于 li，也可能放在 div/表格行的上层容器。
                Element parent = link;
                for (int depth = 0; parent != null && depth < 6 && TextUtils.isEmpty(favid); depth++) {
                    Elements deleteLinks = parent.select(
                            "a[href*=spacecp][href*=favorite], "
                                    + "a[href*=favid], a[data-favid], a[data-fav-id]");
                    for (Element deleteLink : deleteLinks) {
                        String deleteHref = deleteLink.attr("href");
                        Matcher dm = favidHrefPattern.matcher(deleteHref);
                        if (dm.find()) { favid = dm.group(1); break; }
                        favid = firstNonEmpty(deleteLink.attr("data-favid"),
                                deleteLink.attr("data-fav-id"), deleteLink.attr("favid"));
                        if (!TextUtils.isEmpty(favid)) break;
                    }
                    if (TextUtils.isEmpty(favid)) {
                        Matcher fm = favidPattern.matcher(parent.outerHtml());
                        if (fm.find()) favid = fm.group(1);
                    }
                    parent = parent.parent();
                }

                t.setFavid(favid);
                seen.add(tid);
                favorites.add(t);
            } catch (Exception ignored) {}
        }
        return favorites;
    }

    /** 回收站徽章文案（Discuz 默认输出「回收站」，个别站点用「回收箱」）。 */
    private static final Pattern RECYCLE_MARKER =
            Pattern.compile("回收(?:站|箱)");

    /**
     * 判断标题容器内是否带有「回收站」标记。
     *
     * Comiis 模板把标记包成标题链接内的子元素（常见 em/span），且元素文本里
     * 往往还混有 comiis_font 的图标字符（PUA 区），所以不能要求文本严格等于
     * 「回收站」。这里改用「容器整体文本含该字样，但已提取的标题不含」作为
     * 判据：既能兼容图标前缀与多层嵌套，也不会把标题本身叫「回收站灌水」的
     * 正常帖子误判成已回收。
     */
    private static boolean markRecycledFromMarker(Element container, String title, Thread target) {
        if (container == null) return false;
        String full = container.text();
        if (TextUtils.isEmpty(full)) return false;
        if (!RECYCLE_MARKER.matcher(full).find()) return false;
        // 标题自身就含该字样时，说明是正常标题而非标记
        if (!TextUtils.isEmpty(title) && RECYCLE_MARKER.matcher(title).find()) return false;
        target.setRecycled(true);
        return true;
    }

    /** 判断列表项中是否存在服务端输出的关闭/锁定标记。 */
    private static boolean hasClosedMarker(Element item, Element titleLink, String title) {
        if (item == null) return false;
        for (Element marker : item.select("span, em, i, label, font, img[alt], [title]")) {
            if (marker == titleLink || (titleLink != null && marker.parents().contains(titleLink))) continue;
            String text = marker.text().trim();
            String hint = marker.attr("title") + " " + marker.attr("alt") + " " + marker.className();
            if (text.matches("(?is).*?(已关闭|关闭|锁定|已锁定|closed|locked).*")) return true;
            if (hint.matches("(?is).*?(closed|locked|thread[_-]?close|icon[_-]?lock|关闭|锁定).*")) return true;
        }
        Element parent = titleLink == null ? null : titleLink.parent();
        if (parent != null) {
            String siblingText = parent.text();
            if (title != null && !title.isEmpty()) siblingText = siblingText.replace(title, "");
            if (siblingText.matches("(?is).*?(已关闭|关闭|锁定|已锁定|closed|locked).*")) return true;
        }
        return false;
    }

    /** 去掉标题开头残留的「回收站」标记文本（部分模板不套子元素）。 */
    private static String stripRecycleMarker(String title) {
        if (TextUtils.isEmpty(title)) return title;
        String cleaned = title.replaceFirst("^\\s*[\\[\\【\\(]?\\s*回收(?:站|箱)\\s*[\\]\\】\\)]?\\s*", "");
        return cleaned.trim();
    }

    private static String firstNonEmpty(String... values) {
        if (values == null) return "";
        for (String value : values) {
            if (!TextUtils.isEmpty(value)) return value;
        }
        return "";
    }

    /**
     * 解析积分详情（home.php?mod=space&do=profile&mobile=2）
     * 返回积分、金币、好评、信誉等键值对
     */
    public static Map<String, String> parseCreditDetails(String html) {
        Map<String, String> credits = new HashMap<>();
        if (TextUtils.isEmpty(html)) return credits;
        Document doc = Jsoup.parse(html);
        Elements jfLis = doc.select(".comiis_space_profilejf ul li");
        for (int i = 0; i < jfLis.size(); i++) {
            try {
                Element li = jfLis.get(i);
                Element valEl = li.select(".f_0, span").first();
                String value = valEl != null ? valEl.text().trim() : li.text().trim();
                // 提取标签名（去掉数字值）
                String label = li.ownText().trim();
                if (label.isEmpty()) label = "项目" + (i + 1);
                credits.put(label, value);
            } catch (Exception ignored) {}
        }
        // 再从 comiis_space_profile 中提取详细资料
        Elements profileLis = doc.select(".comiis_space_profile li");
        for (Element li : profileLis) {
            try {
                String label = li.select("span").first() != null ? li.select("span").first().text().trim() : "";
                String value = li.select(".profile_rs").first() != null ? li.select(".profile_rs").first().text().trim() : "";
                if (!label.isEmpty() && !value.isEmpty()) {
                    credits.put(label, value);
                }
            } catch (Exception ignored) {}
        }
        return credits;
    }

    /**
     * 解析用户资料数据中的可编辑字段（供编辑资料页使用）
     */
    public static Map<String, String> parseEditableProfile(String html) {
        Map<String, String> fields = new HashMap<>();
        if (TextUtils.isEmpty(html)) return fields;
        Document doc = Jsoup.parse(html);
        // 查找所有表单输入字段
        Elements inputs = doc.select("input[type=text], input[type=email], input[type=url], textarea, select");
        for (Element input : inputs) {
            try {
                String name = input.attr("name");
                String value = input.val().trim();
                if (!name.isEmpty()) {
                    fields.put(name, value);
                }
            } catch (Exception ignored) {}
        }
        return fields;
    }

    public static int parseIntFromText(String text) {
        if (text == null || text.isEmpty()) return 0;
        try {
            Matcher m = Pattern.compile("(\\d+)").matcher(text);
            if (m.find()) return Integer.parseInt(m.group(1));
        } catch (Exception ignored) {}
        return 0;
    }

    private static String firstNonEmptyAttr(Element element, String... names) {
        if (element == null || names == null) return null;
        for (String name : names) {
            if (name != null && element.hasAttr(name)) {
                String value = element.attr(name);
                if (!TextUtils.isEmpty(value)) return value.trim();
            }
        }
        return null;
    }

    private static String resolveAvatarUrl(String url) {
        if (TextUtils.isEmpty(url)) return null;
        if (url.startsWith("http://") || url.startsWith("https://")) return url;
        if (url.startsWith("//")) return "https:" + url;
        if (url.startsWith("/")) return BASE_DOMAIN + url.substring(1);
        return BASE_DOMAIN + url;
    }

    private static boolean isPostImageUrl(String url) {
        if (TextUtils.isEmpty(url)) return false;
        String lower = url.toLowerCase();
        return !lower.contains("none.gif")
                && !lower.contains("none.png")
                && !lower.contains("loading")
                && !lower.contains("smiley")
                && !lower.contains("face")
                && !lower.contains("icon")
                && !lower.contains("stamp")
                && !lower.contains("magic")
                && !lower.contains("emoticon")
                && !lower.contains("/static/image/")
                && !lower.contains("avatar.php");
    }

    /**
     * 补全附件图片URL（处理相对路径、懒加载路径等）
     * MT论坛移动版使用 comiis_loadimages 属性存储真实URL
     */
    private static String resolveAttachmentUrl(String url) {
        if (TextUtils.isEmpty(url)) return null;
        // 如果已经是完整URL
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return url;
        }
        if (url.startsWith("//")) {
            return "https:" + url;
        }
        if (url.startsWith("/")) {
            return BASE_DOMAIN + url.substring(1);
        }
        // 纯相对路径
        return BASE_DOMAIN + url;
    }

    /**
     * 提取列表卡片中的多张帖子图片，供所有帖子列表页面统一使用。
     */
    private static void populateThreadImages(Element item, Thread thread) {
        List<String> imageUrls = new ArrayList<>();
        Elements imageElements = item.select(
                ".comiis_pyqlist_imgs img, .comiis_pyqlist_img img");
        for (Element image : imageElements) {
            String src = firstNonEmptyAttr(image,
                    "comiis_loadimages", "data-original", "data-src",
                    "data-file", "file", "data-lazy-src", "src");
            String fullUrl = resolveAttachmentUrl(src);
            if (isPostImageUrl(fullUrl) && !imageUrls.contains(fullUrl)) {
                imageUrls.add(fullUrl);
                if (imageUrls.size() >= 4) break;
            }
        }

        // 某些空间帖子页没有图片容器，使用卡片正文区域中的图片作为兜底。
        if (imageUrls.isEmpty()) {
            Elements fallbackImages = item.select(".mmlist_li_box img");
            for (Element image : fallbackImages) {
                String src = firstNonEmptyAttr(image,
                        "comiis_loadimages", "data-original", "data-src",
                        "data-file", "file", "data-lazy-src", "src");
                String fullUrl = resolveAttachmentUrl(src);
                if (isPostImageUrl(fullUrl) && !imageUrls.contains(fullUrl)) {
                    imageUrls.add(fullUrl);
                    if (imageUrls.size() >= 4) break;
                }
            }
        }

        thread.setImageUrls(imageUrls);
        if (!imageUrls.isEmpty()) {
            thread.setHasImage(true);
            if (TextUtils.isEmpty(thread.getThumbnailUrl())) {
                thread.setThumbnailUrl(imageUrls.get(0));
            }
        }
    }

    /**
     * 解析热帖排行榜页面（{@code misc.php?mod=ranklist&type=thread}）。
     *
     * <p>页面结构（2026-08 实测，comiis_app 模板）：
     * <pre>
     * div.comiis_postphb &gt; ul &gt; li.b_t
     *   div.postphb_mun     ── 名次。前 3 名是奖牌图片 &lt;img alt="1"&gt;，第 4 名起是纯文本 "4"
     *   a.postphb_tit       ── 标题，href 形如 https://bbs.binmt.cc/thread-25910-1-1.html
     *   p &gt; span.y.f_d      ── 指标原文，如 "4254热度" / "1244418人气" / "3847回复"
     *   p &gt; a.f_ok          ── 作者链接（含 uid）与头像 img
     *   p &gt; span.f_d        ── 发布时间 "2019-10-29 19:22"
     * </pre>
     *
     * <p>名次不用 li 的下标推算而是优先读页面值：榜单第一页固定 20 条，
     * 但前 3 名用图片、之后用文本，两种写法都得覆盖，读不到才回退到下标。
     *
     * @return 榜单条目，解析失败或页面为登录页时返回空列表（调用方自行区分空榜与失败）
     */
    public static List<RankThread> parseThreadRanklist(String html) {
        List<RankThread> result = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return result;
        try {
            Document doc = Jsoup.parse(html);
            Elements items = doc.select("div.comiis_postphb ul li");
            if (items.isEmpty()) {
                // 模板兜底：直接找带名次容器的行
                items = doc.select("li:has(.postphb_mun)");
            }
            Pattern tidPattern = Pattern.compile("thread-(\\d+)-\\d+-\\d+\\.html");
            Pattern uidPattern = Pattern.compile("uid=(\\d+)");
            int index = 0;
            for (Element item : items) {
                Element titleLink = item.select("a.postphb_tit").first();
                if (titleLink == null) titleLink = item.select("a[href*=thread-]").first();
                if (titleLink == null) continue;

                String href = titleLink.attr("href");
                Matcher tidMatcher = tidPattern.matcher(href);
                String tid = null;
                if (tidMatcher.find()) {
                    tid = tidMatcher.group(1);
                } else {
                    // 少数链接是 viewthread 形式，退回通用 tid= 取值
                    Matcher alt = Pattern.compile("[?&]tid=(\\d+)").matcher(href);
                    if (alt.find()) tid = alt.group(1);
                }
                if (TextUtils.isEmpty(tid)) continue;

                index++;
                RankThread rank = new RankThread();
                rank.setTid(tid);
                // title 属性常为空，正文文本才是标题
                String title = titleLink.text().trim();
                if (TextUtils.isEmpty(title)) title = titleLink.attr("title").trim();
                rank.setTitle(title);

                // 名次：先读奖牌图 alt，再读纯文本，最后回退到遍历下标
                int rankNo = 0;
                Element numEl = item.select(".postphb_mun").first();
                if (numEl != null) {
                    Element medal = numEl.select("img").first();
                    String rankText = medal != null ? medal.attr("alt") : numEl.text();
                    rankNo = parseIntSafe(rankText);
                }
                rank.setRank(rankNo > 0 ? rankNo : index);

                // 指标原文：span.y 是"XX热度"这一列；没有该类时取 p 下第一个 span
                Element metricEl = item.select("p span.y").first();
                if (metricEl == null) {
                    Elements spans = item.select("p span");
                    if (!spans.isEmpty()) metricEl = spans.first();
                }
                if (metricEl != null) rank.setMetricText(metricEl.text().trim());

                Element authorLink = item.select("p a.f_ok").first();
                if (authorLink == null) authorLink = item.select("p a[href*=uid=]").first();
                if (authorLink != null) {
                    rank.setAuthor(authorLink.text().trim());
                    Matcher uidMatcher = uidPattern.matcher(authorLink.attr("href"));
                    if (uidMatcher.find()) rank.setAuthorUid(uidMatcher.group(1));
                    Element avatar = authorLink.select("img").first();
                    if (avatar != null) {
                        String src = avatar.hasAttr("src") ? avatar.attr("src") : avatar.attr("data-src");
                        if (!TextUtils.isEmpty(src)) rank.setAvatarUrl(toAbsoluteUrl(src));
                    }
                }

                // 时间在最后一个 span（第一个是指标），只有一个 span 时说明没有时间列
                Elements spans = item.select("p span");
                if (spans.size() > 1) {
                    rank.setPublishTime(spans.last().text().trim());
                }

                result.add(rank);
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    /**
     * 从 "4254热度" 这类文本中取出前导数字；取不到返回 0。
     */
    private static int parseIntSafe(String text) {
        if (TextUtils.isEmpty(text)) return 0;
        Matcher m = Pattern.compile("(\\d+)").matcher(text);
        if (!m.find()) return 0;
        try {
            return Integer.parseInt(m.group(1));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /**
     * 把可能的协议相对/站内相对地址补成绝对地址。
     */
    private static String toAbsoluteUrl(String src) {
        if (TextUtils.isEmpty(src)) return src;
        if (src.startsWith("http://") || src.startsWith("https://")) return src;
        if (src.startsWith("//")) return "https:" + src;
        if (src.startsWith("/")) return BASE_DOMAIN + src.substring(1);
        return BASE_DOMAIN + src;
    }

    /**
     * 热帖排行榜URL。
     *
     * @param view    榜单类型：heats(热度) / views(人气) / replies(回复) / favtimes(收藏)
     * @param orderby 时间范围：today / thisweek / thismonth / all
     */
    public static String getThreadRanklistUrl(String view, String orderby) {
        return BASE_DOMAIN + "misc.php?mod=ranklist&type=thread"
                + "&view=" + view + "&orderby=" + orderby + "&mobile=2";
    }

    /**
     * 获取移动端帖子列表URL
     */
    public static String getThreadListUrl(String fid, int page) {
        return BASE_DOMAIN + "forum.php?mod=forumdisplay&fid=" + fid + "&page=" + page + "&mobile=2";
    }

    /**
     * 获取首页帖子流URL
     */
    public static String getHomeUrl(int page) {
        return BASE_DOMAIN + "forum.php?mod=guide&view=newthread&page=" + page + "&mobile=2&index=1";
    }

    /**
     * 获取导读URL
     */
    public static String getGuideUrl(String view, int page) {
        return BASE_DOMAIN + "forum.php?mod=guide&view=" + view + "&page=" + page + "&mobile=2&index=1";
    }

    /**
     * 获取带排序的导读URL
     * @param view     hot/newthread/new/digest 等
     * @param page     页码
     * @param orderby  排序字段：lastpost/dateline/replies，传 null 使用默认
     * @param ascdesc  排序方向：desc/asc，传 null 使用 desc
     */
    public static String getGuideUrl(String view, int page, String orderby, String ascdesc) {
        StringBuilder url = new StringBuilder(BASE_DOMAIN + "forum.php?mod=guide&view=" + view + "&page=" + page + "&mobile=2&index=1");
        if (orderby != null) {
            url.append("&orderby=").append(orderby);
            if (ascdesc != null) {
                url.append("&ascdesc=").append(ascdesc);
            }
        }
        return url.toString();
    }

    /**
     * 获取登录URL
     */
    public static String getLoginUrl() {
        return BASE_DOMAIN + "member.php?mod=logging&action=login&mobile=2";
    }

/**
     * 获取登录提交URL
     * ★ 修复：从登录页面HTML中提取 form 的 action 属性作为登录提交地址
     * 不再手动拼接，因为 loginhash 和 formhash 是不同的值
     */
    public static String getLoginPostUrl() {
        return BASE_DOMAIN + "member.php?mod=logging&action=login&loginsubmit=yes&loginhash=" + "&mobile=2";
    }

    /**
     * 从登录页面HTML中提取正确的登录提交URL（含 loginhash）
     */
    public static String extractLoginPostUrl(String loginPageHtml) {
        if (TextUtils.isEmpty(loginPageHtml)) return getLoginPostUrl();
        Document doc = Jsoup.parse(loginPageHtml);
        Element form = doc.select("form[id=loginform]").first();
        if (form == null) {
            form = doc.select("form[method=post][action*=login]").first();
        }
        if (form != null) {
            String action = form.attr("action");
            if (!TextUtils.isEmpty(action)) {
                if (action.startsWith("http")) return action;
                return BASE_DOMAIN + action;
            }
        }
        return getLoginPostUrl();
    }

    /**
     * 获取用户空间URL
     */
    public static String getUserSpaceUrl(String uid) {
        return BASE_DOMAIN + "home.php?mod=space&uid=" + uid + "&do=profile&mobile=2";
    }

    /**
     * 获取消息列表URL
     */
    public static String getMessageUrl() {
        return BASE_DOMAIN + "home.php?mod=space&do=pm";
    }

    /**
     * 获取帖子详情URL。
     * 本论坛 Comiis 模板的评论排序参数实际为：
     *   ordertype=1：倒序（最新评论在前）
     *   不传 ordertype：正序（最早评论在前）
     */
    public static String getThreadDetailUrl(String tid) {
        return BASE_DOMAIN + "forum.php?mod=viewthread&tid=" + tid + "&mobile=2";
    }

    public static String getThreadDetailUrl(String tid, String order) {
        StringBuilder url = new StringBuilder(BASE_DOMAIN)
                .append("forum.php?mod=viewthread&tid=").append(tid)
                .append("&mobile=2");
        if ("desc".equalsIgnoreCase(order)) {
            url.append("&ordertype=1");
        }
        return url.toString();
    }

    /** 获取指定评论页，并沿用论坛实际的 ordertype 排序参数。 */
    public static String getThreadDetailUrl(String tid, int page, String order) {
        StringBuilder url = new StringBuilder(BASE_DOMAIN)
                .append("forum.php?mod=viewthread&tid=").append(tid)
                .append("&page=").append(page)
                .append("&mobile=2");
        if ("desc".equalsIgnoreCase(order)) {
            url.append("&ordertype=1");
        }
        return url.toString();
    }


    /**
     * 获取帖子详情URL（桌面版）
     */
    public static String getThreadDesktopDetailUrl(String tid) {
        return BASE_DOMAIN + "forum.php?mod=viewthread&tid=" + tid;
    }

    /**
     * 从桌面版帖子详情页 HTML 中提取浏览量。
     * 桌面版结构：<span class="y comiis_cks"><strong>11802</strong><br>查看</span>
     */
    public static int parseViewsFromDesktop(String html) {
        if (TextUtils.isEmpty(html)) return 0;
        try {
            Document doc = Jsoup.parse(html);
            Element viewEl = doc.select("span.comiis_cks strong").first();
            if (viewEl != null) {
                return parseIntFromText(viewEl.text());
            }
        } catch (Exception ignored) {}
        return 0;
    }

    /**
     * 获取发帖页面URL
     */
    public static String getNewThreadUrl(String fid) {
        return BASE_DOMAIN + "forum.php?mod=post&action=newthread&fid=" + fid + "&mobile=2";
    }

    /**
     * 构建 Discuz! 搜索排序参数
     * @param orderby lastpost(最新回复)/dateline(最新发布)/replies(最多回复)
     * @return 排序参数字符串，含前导 &
     */
    public static String buildSortQuery(String orderby) {
        if ("replies".equals(orderby)) {
            return "&orderby=replies&ascdesc=desc";
        } else if ("dateline".equals(orderby)) {
            return "&orderby=dateline&ascdesc=desc";
        }
        return "&orderby=lastpost&ascdesc=desc"; // 默认：最新回复
    }

    /**
     * 获取搜索URL（强制 mobile=2，否则返回桌面版HTML无法解析forumlist_li）
     * @param keyword 搜索关键词
     * @param page 页码，从1开始
     * @param orderby 排序方式：lastpost/dateline/replies
     */
    public static String getSearchUrl(String keyword, int page, String orderby) {
        try {
            String encoded = URLEncoder.encode(keyword, "UTF-8");
            String url = BASE_DOMAIN + "search.php?mod=forum&searchsubmit=yes&srchtxt=" + encoded
                    + buildSortQuery(orderby) + "&mobile=2";
            if (page > 1) {
                url += "&page=" + page;
            }
            return url;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            String url = BASE_DOMAIN + "search.php?mod=forum&searchsubmit=yes&mobile=2";
            if (page > 1) {
                url += "&page=" + page;
            }
            return url;
        }
    }

    /**
     * 获取搜索URL（默认按最新回复排序）
     * @param keyword 搜索关键词
     * @param page 页码，从1开始
     */
    public static String getSearchUrl(String keyword, int page) {
        return getSearchUrl(keyword, page, "lastpost");
    }

    /**
     * 从搜索结果HTML中提取分页信息
     * Discuz! 搜索分页依赖 searchid（搜索会话ID），
     * 分页链接格式为 search.php?mod=forum&searchid=XXX&page=N
     * @return 最大页码，如果只有一页或无分页则返回1
     */
    public static int parseSearchTotalPages(String html) {
        if (TextUtils.isEmpty(html)) return 1;
        Document doc = Jsoup.parse(html);
        // 搜索分页链接: <a href="search.php?mod=forum&searchid=XXX&page=N"
        Elements pageLinks = doc.select("a[href*=searchid]");
        if (pageLinks.isEmpty()) {
            // 兜底：查找任何带 page= 的链接
            pageLinks = doc.select("a[href*=page=]");
        }
        int maxPage = 1;
        Pattern pagePtn = Pattern.compile("[&?]page=(\\d+)");
        for (Element pl : pageLinks) {
            Matcher pm = pagePtn.matcher(pl.attr("href"));
            if (pm.find()) {
                try {
                    int p = Integer.parseInt(pm.group(1));
                    if (p > maxPage) maxPage = p;
                } catch (Exception ignored) {}
            }
        }
        return maxPage;
    }

    /**
     * 从搜索结果第一页的HTML中提取 searchid（Discuz! 搜索会话ID）
     * @return searchid 字符串，如果没有找到则返回 null
     */
    public static String extractSearchId(String html) {
        if (TextUtils.isEmpty(html)) return null;
        Matcher m = Pattern.compile("searchid=(\\d+)").matcher(html);
        if (m.find()) {
            return m.group(1);
        }
        return null;
    }

    /**
     * 获取搜索分页URL（带 searchid 和完整参数，匹配真实分页链接格式）
     * 真实分页URL示例：
     * search.php?mod=forum&searchid=290&orderby=lastpost&ascdesc=desc&searchsubmit=yes&page=2&mobile=2
     * @param searchId 搜索会话ID（从第1页HTML中提取）
     * @param page 页码，从2开始
     * @param orderby 排序方式：lastpost/dateline/replies
     * @return 分页URL
     */
    public static String getSearchPageUrl(String searchId, int page, String orderby) {
        return BASE_DOMAIN + "search.php?mod=forum&searchid=" + searchId
                + buildSortQuery(orderby) + "&searchsubmit=yes&page=" + page + "&mobile=2";
    }

    /**
     * 获取搜索分页URL（默认按最新回复排序）
     * @param searchId 搜索会话ID
     * @param page 页码
     * @return 分页URL
     */
    public static String getSearchPageUrl(String searchId, int page) {
        return getSearchPageUrl(searchId, page, "lastpost");
    }

    /**
     * 获取社区页面URL（版块列表+签到入口+统计数据）
     * forumlist=1 返回版块列表页面，包含签到入口和统计信息
     */
    public static String getForumlistMobileUrl() {
        return BASE_DOMAIN + "forum.php?forumlist=1&mobile=2";
    }

    /**
     * 获取单个版块的手机版页面 URL
     * @param fid 版块 ID
     * @return 完整 URL，如 https://bbs.binmt.cc/forum-2-1.html?mobile=2
     */
    public static String getForumPageUrl(String fid) {
        return BASE_DOMAIN + "forum-" + fid + "-1.html?mobile=2";
    }

    /**
     * 从单个版块页面 HTML 中提取描述文本
     * 解析结构：div.comiis_forumlist_heads > a.top_left > p.f_f.comiis_tm8（第二个 p 标签）
     * 例如：MT管理器公测群：592479528
     *
     * @param html 单个版块页面的 HTML
     * @return 描述文本，如果找不到则返回 null
     */
    @Nullable
    public static String parseForumDescription(String html) {
        if (html == null || html.isEmpty()) return null;
        try {
            Document doc = Jsoup.parse(html);
            Element header = doc.selectFirst("div.comiis_forumlist_heads");
            if (header == null) return null;

            // 选择所有 p.f_f.comiis_tm8 标签
            Elements pElements = header.select("p.f_f.comiis_tm8");
            // 第一个 p 是统计信息（今日/帖子/关注），第二个 p 是描述
            if (pElements.size() >= 2) {
                String desc = pElements.get(1).text().trim();
                if (!desc.isEmpty()) return desc;
            }
        } catch (Exception ignored) {}
        return null;
    }

    /**
     * 解析社区页面（forum.php?forumlist=1&mobile=2）
     * 提取：签到入口文本、formhash、登录状态、4项统计数据、全量版块列表
     *
     * @param html 社区页面 HTML
     * @return CommunityPageData 对象
     */
    public static CommunityPageData parseCommunityPage(String html) {
        CommunityPageData data = new CommunityPageData();
        Document doc = Jsoup.parse(html);
        
        // === 1. 提取 formhash ===
        // 方式1：从 input[name=formhash] 提取
        Element fhInput = doc.select("input[name=formhash]").first();
        if (fhInput != null) {
            String fh = fhInput.attr("value");
            if (!fh.isEmpty()) {
                data.setFormhash(fh);
            }
        }
        // 方式2：从 JavaScript 中 formhash=xxx 提取（MT论坛 k_misign 插件）
        if (data.getFormhash() == null || data.getFormhash().isEmpty()) {
            Matcher fhMatcher = Pattern.compile("formhash\\s*=\\s*['\"]?([a-f0-9]{8})['\"]?").matcher(html);
            if (fhMatcher.find()) {
                data.setFormhash(fhMatcher.group(1));
            }
        }
        
        // === 2. 解析签到入口（适配 MT 论坛 k_misign 签到插件） ===
        // MT论坛使用科站网签到插件 k_misign，签到按钮结构：
        // <a class="signBtn" href="member.php?mod=logging&action=login&mobile=2">  （未登录时指向登录页）
        // JS代码: $.ajax({type:'POST', url:'plugin.php?id=k_misign:sign&operation=qiandao&format=text&formhash=xxx'})
        
        // 2a. 查找 signBtn class 的签到按钮
        Element signBtn = doc.select("a.signBtn").first();
        if (signBtn != null) {
            String signHref = signBtn.attr("href");
            String rawSignText = signBtn.text().trim();
            // 清理不可见Unicode字符（如 &nbsp; → \u00A0，trim()去不掉）
            rawSignText = rawSignText
                    .replace((char)0x00A0, ' ').replace((char)0x200B, ' ')
                    .replace((char)0x200C, ' ').replace((char)0x200D, ' ')
                    .replace((char)0xFEFF, ' ').replace((char)0x3000, ' ')
                    .trim();
            data.setSignInText(rawSignText);
            android.util.Log.d("ForumParser", "signBtn found: text='" + rawSignText + "' href='" + signHref + "'");
            if (!signHref.isEmpty()) {
                if (!signHref.startsWith("http")) {
                    signHref = BASE_DOMAIN + signHref;
                }
                data.setSignInUrl(signHref);
            }
            // 检查签到链接是否指向登录页 → 当前未登录
            if (signHref.contains("member.php?mod=logging")) {
                data.setLoginRequired(true);
            }
        } else {
            // 2b. 兜底：查找包含 "签到" 文字的元素
            android.util.Log.d("ForumParser", "signBtn NOT found, trying fallback");
            Element signInLink = doc.select("a:containsOwn(签到)").first();
            if (signInLink != null) {
                String signText = signInLink.text().trim();
                signText = signText
                    .replace((char)0x00A0, ' ').replace((char)0x200B, ' ')
                    .replace((char)0x200C, ' ').replace((char)0x200D, ' ')
                    .replace((char)0xFEFF, ' ').replace((char)0x3000, ' ')
                    .trim();
                data.setSignInText(signText);
                String signHref = signInLink.attr("href");
                android.util.Log.d("ForumParser", "fallback a:containsOwn found: text='" + signText + "' href='" + signHref + "'");
                if (!signHref.isEmpty()) {
                    if (!signHref.startsWith("http")) {
                        signHref = BASE_DOMAIN + signHref;
                    }
                    data.setSignInUrl(signHref);
                }
                if (signHref.contains("member.php?mod=logging")) {
                    data.setLoginRequired(true);
                }
            } else {
                // 2c. 兜底：查找包含 "签到" 图标文字的元素
                Element signIcon = doc.select("i:contains(签到), span:contains(签到), em:contains(签到)").first();
                if (signIcon != null) {
                    String signText = signIcon.text().trim();
                    signText = signText
                        .replace((char)0x00A0, ' ').replace((char)0x200B, ' ')
                        .replace((char)0x200C, ' ').replace((char)0x200D, ' ')
                        .replace((char)0xFEFF, ' ').replace((char)0x3000, ' ')
                        .trim();
                    data.setSignInText(signText);
                    android.util.Log.d("ForumParser", "fallback icon found: text='" + signText + "'");
                } else {
                    android.util.Log.d("ForumParser", "NO sign-in element found at all!");
                }
            }
        }
        
        // 2d. 根据签到文字判断是否已签到（同步到 alreadySignedIn 标志）
        String signInTextStr = data.getSignInText();
        if (signInTextStr != null && !signInTextStr.isEmpty()) {
            // 再次清理不可见字符（多重保险）
            signInTextStr = signInTextStr
                            .replace((char)0x00A0, ' ').replace((char)0x200B, ' ')
                            .replace((char)0x200C, ' ').replace((char)0x200D, ' ')
                            .replace((char)0xFEFF, ' ').replace((char)0x3000, ' ')
                            .trim();
            if (signInTextStr.contains("今日已签") || signInTextStr.contains("已签到")
                    || signInTextStr.contains("已经签到") || signInTextStr.contains("已签")) {
                data.setAlreadySignedIn(true);
            }
        }

        // 2e. 提取真实的签到 AJAX URL（k_misign 插件）
        Matcher signUrlMatcher = Pattern.compile("(plugin\\.php\\?id=k_misign[^'\"\\s]*)").matcher(html);
        if (signUrlMatcher.find()) {
            String ajaxUrl = signUrlMatcher.group(1);
            if (!ajaxUrl.startsWith("http")) {
                ajaxUrl = BASE_DOMAIN + ajaxUrl;
            }
            // 替换 formhash 占位符为实际值
            String fh = data.getFormhash();
            if (fh != null && !fh.isEmpty()) {
                ajaxUrl = ajaxUrl.replaceAll("formhash=[a-f0-9]*", "formhash=" + fh);
            }
            data.setSignInUrl(ajaxUrl);
        }
        
        // === 3. 解析4项统计数据 ===
        // 统计数据通常位于页面顶部或版块列表区域上方，格式如 "今日23 昨日4584 帖子4474223 会员345343"
        // 尝试在页面中查找包含这些关键词的文本
        String pageText = doc.body() != null ? doc.body().text() : "";
        
        // 方法1：查找包含 "今日" "昨日" "帖子" "会员" 的统计信息块
        // 常用结构：span.stats_num 或特定 class 的容器
        // 尝试匹配 "今日23" 这种模式（中文+数字连写）
        
        // 今日
        Pattern todayPtn = Pattern.compile("今日[：:\\s]*([0-9,，]+)");
        Matcher m = todayPtn.matcher(pageText);
        if (m.find()) {
            data.setTodayPosts(parseIntFromText(m.group(1)));
        }
        
        // 昨日
        Pattern yesterdayPtn = Pattern.compile("昨日[：:\\s]*([0-9,，]+)");
        m = yesterdayPtn.matcher(pageText);
        if (m.find()) {
            data.setYesterdayPosts(parseIntFromText(m.group(1)));
        }
        
        // 帖子总数
        Pattern postsPtn = Pattern.compile("帖子[：:\\s]*([0-9,，]+)");
        m = postsPtn.matcher(pageText);
        if (m.find()) {
            data.setTotalPosts(parseIntFromText(m.group(1)));
        }
        
        // 会员总数
        Pattern membersPtn = Pattern.compile("会员[：:\\s]*([0-9,，]+)");
        m = membersPtn.matcher(pageText);
        if (m.find()) {
            data.setTotalMembers(parseIntFromText(m.group(1)));
        }
        
        // 方法2：如果上述正则没匹配到，尝试从特定 CSS 选择器中提取
        if (data.getTodayPosts() == 0 && data.getYesterdayPosts() == 0) {
            // Comiis 模板中统计信息可能位于 div.comiis_stats 或类似容器中
            Element statsEl = doc.select("div.comiis_stats, div.stats, .forum_stats, .statistic").first();
            if (statsEl != null) {
                String statsText = statsEl.text();
                m = todayPtn.matcher(statsText);
                if (m.find()) data.setTodayPosts(parseIntFromText(m.group(1)));
                m = yesterdayPtn.matcher(statsText);
                if (m.find()) data.setYesterdayPosts(parseIntFromText(m.group(1)));
                m = postsPtn.matcher(statsText);
                if (m.find()) data.setTotalPosts(parseIntFromText(m.group(1)));
                m = membersPtn.matcher(statsText);
                if (m.find()) data.setTotalMembers(parseIntFromText(m.group(1)));
            }
        }
        
        // === 3. 解析全量版块列表 ===
        // 复用 parseForumCategories 的解析逻辑，将结果扁平化为 Forum 列表
        List<ForumCategory> categories = parseForumCategories(html);
        List<ForumCategory.Forum> allForums = new ArrayList<>();
        if (categories != null) {
            for (ForumCategory cat : categories) {
                if (cat.getForums() != null) {
                    for (ForumCategory.Forum forum : cat.getForums()) {
                        allForums.add(forum);
                    }
                }
            }
        }
        data.setForums(allForums);
        data.setCategories(categories);
        
        return data;
    }

    /**
     * 社区页面数据容器（内部静态类，用于封装 parseCommunityPage 的返回值）
     */
    public static class CommunityPageData {
        private String signInText = "";
        private String signInUrl = "";
        private String formhash = "";
        private boolean alreadySignedIn = false;
        private boolean loginRequired = false;
        private int todayPosts = 0;
        private int yesterdayPosts = 0;
        private int totalPosts = 0;
        private int totalMembers = 0;
        private List<ForumCategory.Forum> forums = new ArrayList<>();
        private List<ForumCategory> categories = new ArrayList<>();
        
        public String getSignInText() { return signInText; }
        public void setSignInText(String signInText) { this.signInText = signInText; }
        
        public String getSignInUrl() { return signInUrl; }
        public void setSignInUrl(String signInUrl) { this.signInUrl = signInUrl; }
        
        public String getFormhash() { return formhash; }
        public void setFormhash(String formhash) { this.formhash = formhash; }
        
        public boolean isAlreadySignedIn() { return alreadySignedIn; }
        public void setAlreadySignedIn(boolean alreadySignedIn) { this.alreadySignedIn = alreadySignedIn; }
        
        public boolean isLoginRequired() { return loginRequired; }
        public void setLoginRequired(boolean loginRequired) { this.loginRequired = loginRequired; }
        
        public int getTodayPosts() { return todayPosts; }
        public void setTodayPosts(int todayPosts) { this.todayPosts = todayPosts; }
        
        public int getYesterdayPosts() { return yesterdayPosts; }
        public void setYesterdayPosts(int yesterdayPosts) { this.yesterdayPosts = yesterdayPosts; }
        
        public int getTotalPosts() { return totalPosts; }
        public void setTotalPosts(int totalPosts) { this.totalPosts = totalPosts; }
        
        public int getTotalMembers() { return totalMembers; }
        public void setTotalMembers(int totalMembers) { this.totalMembers = totalMembers; }
        
        public List<ForumCategory.Forum> getForums() { return forums; }
        public void setForums(List<ForumCategory.Forum> forums) { this.forums = forums; }
        
        public List<ForumCategory> getCategories() { return categories; }
        public void setCategories(List<ForumCategory> categories) { this.categories = categories; }

    }
/**
     * 解析私信列表（会话列表）
     * 完全对齐官方 APK MessageParser.parsePrivateMessageList 的选择器逻辑：
     *   选择器：div.pml dl
     *   UID：dd.m.avt a[href] → extractUidFromUrl
     *   头像：dd.m.avt img[src] → normalizeUrl
     *   未读：dl.hasClass("newpm")
     *   用户名：优先 dd.pm_c a.xw1；若存在 dd.pm_c span.xi2.xw1 则改用 dd.pm_c a[href*=space-uid]
     *   消息内容：dd.pm_c ownText()；为空则取 dd.pm_c 第一个 TextNode
     *   时间：dd.pm_c span.xg1 span[title] 的 title；否则 dd.pm_c span.xg1 text 按空格分割取第一段
     *   回复数：span.xg1.z text 中正则提取数字
     */
    public static List<Message> parsePrivateMessageList(String html) {
        List<Message> messages = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return messages;

        Document doc = Jsoup.parse(html);

        // 官方选择器：div.pml dl
        Elements items = doc.select("div.pml dl");
        // 兜底
        if (items.isEmpty()) items = doc.select("div.pml > dl");
        if (items.isEmpty()) items = doc.select("dl");

        for (Element item : items) {
            try {
                Message msg = new Message();

                // ① UID：dd.m.avt a → href → extractUidFromUrl
                Element avtLink = item.selectFirst("dd.m.avt a");
                String uid = "";
                if (avtLink != null) {
                    String href = avtLink.attr("href");
                    uid = extractUidFromUrl(href);
                }
                if (uid == null || uid.isEmpty()) {
                    // 兜底：直接从 href 提取 touid/uid 参数
                    Element link = item.selectFirst("a[href*=touid=], a[href*=uid=]");
                    if (link != null) {
                        String href = link.attr("href");
                        uid = extractParam(href, "touid");
                        if (uid == null) uid = extractParam(href, "uid");
                    }
                }
                if (uid == null || uid.isEmpty()) continue;

                msg.setPmid(uid);
                msg.setAuthorUid(uid);

                // ② 头像：dd.m.avt img → src → normalizeUrl
                Element avtImg = item.selectFirst("dd.m.avt img");
                if (avtImg != null) {
                    String src = avtImg.attr("src");
                    src = normalizeUrl(src);
                    if (src != null && !src.isEmpty()) msg.setAvatarUrl(src);
                }

                // ③ 未读标记
                // ★ 唯一权威判据：MT 论坛私信列表用【空的 span.kmnums】标记未读会话。
                //   注意该 span 未读时本身就是空字符串，只能判存在性，不能读文本。
                //   历史实现曾用 dd.pm_c 内的 strong/b 以及 a.b_b / .xw1.b 判未读，
                //   这是错的：b_b 是 Discuz 移动模板的 border-bottom 样式类，
                //   列表里每条都有，strong/b 也会被私信正文自带的加粗命中，
                //   结果是"根本没有新消息，所有会话却全部标成未读"。
                boolean hasKmnums = item.selectFirst("span.kmnums") != null;
                // 兼容部分模板的显式未读类名
                boolean hasNewpmClass = item.hasClass("newpm")
                        || item.selectFirst("div.newpm_avt") != null;
                boolean unread = hasKmnums || hasNewpmClass;
                msg.setRead(!unread);
                if (com.forum.MT.util.Dbg.ON) {
                    android.util.Log.e("MT_PM_DBG", "parsePM: uid=" + uid
                        + " kmnums=" + hasKmnums + " newpmClass=" + hasNewpmClass
                        + " unread=" + unread);
                }

                // ④ 用户名：
                //   先取 dd.pm_c a.xw1 的 text 作为默认用户名
                Element nameEl = item.selectFirst("dd.pm_c a.xw1");
                String author = "";
                if (nameEl != null) {
                    String t = nameEl.text().trim();
                    if (!t.isEmpty()) author = t;
                }
                //   如果存在 dd.pm_c span.xi2.xw1，说明用户名是链接形式，改取 dd.pm_c a[href*=space-uid]
                Element xi2Check = item.selectFirst("dd.pm_c span.xi2.xw1");
                if (xi2Check != null) {
                    Element spaceLink = item.selectFirst("dd.pm_c a[href*=space-uid]");
                    if (spaceLink != null) {
                        String t = spaceLink.text().trim();
                        if (!t.isEmpty()) author = t;
                    }
                }
                if (author.isEmpty()) {
                    // 兜底：从 a[href*=space-uid] 或 a.xw1 取
                    Element fallback = item.selectFirst("a[href*=space-uid]");
                    if (fallback != null) author = fallback.text().trim();
                }
                msg.setAuthor(author);

                // ⑤ 消息内容：dd.pm_c ownText()；为空则取第一个 TextNode
                Element pmC = item.selectFirst("dd.pm_c");
                String summary = "";
                if (pmC != null) {
                    String ownText = pmC.ownText().trim();
                    if (!ownText.isEmpty()) {
                        summary = ownText;
                    } else {
                        // 取第一个 TextNode
                        for (org.jsoup.nodes.Node node : pmC.childNodes()) {
                            if (node instanceof org.jsoup.nodes.TextNode) {
                                String t = ((org.jsoup.nodes.TextNode) node).text().trim();
                                if (!t.isEmpty()) {
                                    summary = t;
                                    break;
                                }
                            }
                        }
                    }
                }
                // 兜底1：dd.pm_c 内除用户名链接外的其余文本（取 a.xw1 后面的文本）
                if (summary.isEmpty() && pmC != null) {
                    Element xw1 = pmC.selectFirst("a.xw1");
                    if (xw1 != null) {
                        // 去掉用户名链接自身 + 时间 span 后取剩余文本
                        xw1.remove();
                        pmC.select("span.xg1, span[title]").remove();
                        summary = pmC.text().trim();
                    }
                }
                // 兜底2：整个 dd.pm_c 文本（去掉时间）
                if (summary.isEmpty() && pmC != null) {
                    Element clone = pmC.clone();
                    clone.select("span.xg1, span.xi2, span[title]").remove();
                    summary = clone.text().trim();
                }
                // 清洗 Discuz 格式前缀："对 XX说: 内容" / "对 XX 说: 内容" / "回复 XX: 内容"
                summary = cleanPrivateMessagePrefix(summary);
                msg.setSummary(summary);
                msg.setTitle(summary != null ? summary : "");

                // ⑥ 时间：dd.pm_c span.xg1 span[title] 的 title；否则 dd.pm_c span.xg1 text 按空格分割取第一段
                String time = "";
                Element timeTitleEl = item.selectFirst("dd.pm_c span.xg1 span[title]");
                if (timeTitleEl != null) {
                    String title = timeTitleEl.attr("title").trim();
                    if (!title.isEmpty()) time = title;
                }
                if (time.isEmpty()) {
                    Element xg1El = item.selectFirst("dd.pm_c span.xg1");
                    if (xg1El != null) {
                        String xg1Text = xg1El.text().trim();
                        if (!xg1Text.isEmpty()) {
                            // 按空格分割取第一段
                            String[] parts = xg1Text.split(" ");
                            if (parts.length > 0) time = parts[0].trim();
                        }
                    }
                }
                msg.setTime(time);

                messages.add(msg);
            } catch (Exception ignored) {}
        }

        return messages;
    }

    /**
     * 清洗 Discuz 私信内容前缀：
     *   "对 XX说: 内容" / "对 XX 说: 内容" / "对 XX说：内容" / "回复 XX: 内容"
     * 只保留冒号后的实际内容；无法匹配时原样返回。
     */
    private static String cleanPrivateMessagePrefix(String text) {
        if (text == null) return "";
        String s = text.trim();
        if (s.isEmpty()) return s;
        // 匹配：对<可选空格>XX<可选空格>(说|回复|Reply):[空格]内容
        // 说明：XX 可能是用户名（不能以冒号结尾），内容从冒号后开始
        String[] patterns = {
            "^对\\s*[^:：]{1,40}\\s*说\\s*[:：]\\s*",
            "^对\\s*[^:：]{1,40}\\s*[:：]\\s*",
            "^回复\\s*[^:：]{1,40}\\s*[:：]\\s*",
            "^回复\\s*[:：]\\s*",
            "^Re\\s*[:：]\\s*",
            "^回信\\s*[:：]\\s*"
        };
        String candidate = s;
        for (String p : patterns) {
            if (candidate.matches(p + ".*")) {
                candidate = candidate.replaceFirst(p, "");
                break;
            }
        }
        String result = candidate.trim();
        return result.isEmpty() ? s : result;
    }

    /**
     * 从 URL 中提取用户 UID（对齐官方 MessageParser.extractUidFromUrl）。
     * 支持 home.php?mod=space&uid=XXX 和 space-uid-XXX 格式。
     */
    private static String extractUidFromUrl(String url) {
        if (url == null || url.isEmpty()) return null;
        // 先尝试 uid= 参数
        String uid = extractParam(url, "uid");
        if (uid != null && !uid.isEmpty()) return uid;
        // 再尝试 space-uid-XXX 格式
        Matcher m = Pattern.compile("space-uid-(\\d+)").matcher(url);
        if (m.find()) return m.group(1);
        return null;
    }

    /**
     * 规范化 URL（对齐官方 MessageParser.normalizeUrl）。
     * 相对路径补全为完整 URL。
     */
    private static String normalizeUrl(String url) {
        if (url == null || url.isEmpty()) return null;
        if (url.startsWith("http://") || url.startsWith("https://")) return url;
        if (url.startsWith("//")) return "https:" + url;
        if (url.startsWith("/")) return BASE_DOMAIN + url;
        return BASE_DOMAIN + "/" + url;
    }

    /**
     * 解析通知列表项
     * 对应 Discuz! home.php?mod=space&do=notice&view=xxx
     */
    public static List<NoticeItem> parseNoticeItems(String html) {
        // 委托给已有的 parseNoticeList（使用 Comiis 移动模板/桌面版选择器，已验证有效）
        // 然后将 Message 转换为 NoticeItem
        List<NoticeItem> result = new ArrayList<>();
        List<Message> messages = parseNoticeList(html);
        if (messages == null || messages.isEmpty()) return result;
        for (Message msg : messages) {
            NoticeItem ni = new NoticeItem();
            ni.setNoticeId(msg.getPmid());
            ni.setUsername(msg.getAuthor());
            ni.setUid(msg.getAuthorUid());
            ni.setContent(msg.getTitle());     // 完整通知文本
            ni.setThreadTitle(msg.getSummary()); // 帖子标题（来自 summary）
            ni.setTime(msg.getTime());
            ni.setAvatarUrl(msg.getAvatarUrl());
            ni.setPid(msg.getPid());   // 传递回复PID（用于定位楼层）
            ni.setBold(!msg.isRead());
            // 根据类型设置
            if (msg.getType() == 2) {
                ni.setType("reply");
            } else if (msg.getType() == 1) {
                ni.setType("system");
            } else {
                ni.setType("notice");
            }
            result.add(ni);
        }
        return result;
    }

    /**
     * 解析通知分页信息
     * 返回总页数字符串，如 "5"
     */
    public static String parseNoticePagination(String html) {
        if (TextUtils.isEmpty(html)) return null;
        Document doc = Jsoup.parse(html);
        // 查找分页链接中的最后一页
        Elements pageLinks = doc.select("a[href*=page=], a[href*=/page/]");
        int maxPage = 1;
        Pattern pagePattern = Pattern.compile("(?:page|p)=(\\d+)");
        for (Element link : pageLinks) {
            String href = link.attr("href");
            Matcher m = pagePattern.matcher(href);
            if (m.find()) {
                try {
                    int p = Integer.parseInt(m.group(1));
                    if (p > maxPage) maxPage = p;
                } catch (NumberFormatException ignored) {}
            }
        }
        return String.valueOf(maxPage);
    }

    /**
     * ★ 修复：轻量解析方法，仅解析回复列表，不解析楼主帖。
     * 用于 loadMoreReplies 等非首页场景，避免第一个回复被当作楼主帖解析导致内容错乱。
     * @param html 帖子详情页 HTML（任意页均可）
     * @return 回复列表，不包含楼主帖
     */
    private static String insertNewlineAfterQuoteTime(String text) {
        if (TextUtils.isEmpty(text)) return text;
        try {
            // 匹配开头："回复" + 用户名（非贪婪） + "发表于" + 日期时间
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                    "(?s)^\\s*回复\\s*(.*?)\\s*发表于\\s*" +
                    "(\\d{4}[-/年]\\d{1,2}[-/月]\\d{1,2}日?\\s*\\d{1,2}:\\d{2}(?::\\d{2})?)");
            java.util.regex.Matcher m = p.matcher(text);
            if (m.find()) {
                int timeEnd = m.end(2);
                String head = text.substring(0, timeEnd);
                String tail = text.substring(timeEnd).trim();
                return tail.isEmpty() ? head : head + "\n" + tail;
            }
        } catch (Exception ignored) {}
        return text;
    }

    // ==================== 投票解析 ====================

    /**
     * 从楼主帖正文中解析投票数据。
     *
     * DOM 结构（div.comiis_message 内，与 div.comiis_a 同级）：
     *   div.comiis_poll > form#poll
     *     input[name=formhash]
     *     div.comiis_poll_top > h2（类型）, p.f_c（人数）, p.kmbtn span（状态）
     *     div.comiis_poll_list > ul > li（kmnop=选项, poll_ok=结果条，交替）
     *
     * @param opMsg 楼主帖的 div.comiis_message 元素
     * @return Poll 对象，无投票返回 null
     */
    public static Poll parsePoll(Element opMsg) {
        if (opMsg == null) return null;

        Element pollDiv = opMsg.select("div.comiis_poll").first();
        if (pollDiv == null) return null;

        Element form = pollDiv.select("form#poll").first();
        if (form == null) form = pollDiv.select("form[name=poll]").first();

        Poll poll = new Poll();

        // form action URL 和 formhash
        if (form != null) {
            String action = form.attr("action");
            if (!TextUtils.isEmpty(action)) {
                poll.setActionUrl(action.contains("http") ? action : BASE_DOMAIN + action);
            }
            Element hashInput = form.select("input[name=formhash]").first();
            if (hashInput != null) {
                poll.setFormhash(hashInput.attr("value"));
            }
        }

        // 投票类型（"单选投票" / "多选投票"）
        Element typeEl = pollDiv.select(".comiis_poll_top h2").first();
        if (typeEl != null) {
            poll.setPollType(typeEl.text().trim());
        }

        // 参与人数
        Element voterEl = pollDiv.select(".comiis_poll_top p.f_c").first();
        if (voterEl != null) {
            String voterText = voterEl.text().trim();
            Matcher m = Pattern.compile("(\\d+)").matcher(voterText);
            if (m.find()) {
                poll.setVoterCount(Integer.parseInt(m.group(1)));
            }
        }

        // 投票状态（"投票已经结束" 等）
        Element statusEl = pollDiv.select(".comiis_poll_top p.kmbtn span").first();
        if (statusEl != null) {
            String statusText = statusEl.text().trim();
            poll.setClosed(statusText.contains("结束") || statusText.contains("已关闭"));
        }

        // 解析选项列表
        // ul 内 li.kmnop（选项标签）与 li.poll_ok（结果条）交替出现
        Element listEl = pollDiv.select(".comiis_poll_list ul").first();
        if (listEl == null) listEl = pollDiv.select(".comiis_poll_list").first();
        if (listEl != null) {
            List<Poll.Option> options = new ArrayList<>();
            Elements lis = listEl.select("li");
            String currentLabel = null;
            String currentOptionId = null;

            for (Element li : lis) {
                String cls = li.className();
                if (cls != null && cls.contains("kmnop")) {
                    // 选项标签
                    Element label = li.select("label").first();
                    if (label != null) {
                        currentLabel = label.text().trim();
                    }
                    // 投票选项 input（radio/checkbox），value 即 optionId
                    Element inputEl = li.select("input[name=pollanswers]").first();
                    if (inputEl == null) inputEl = li.select("input[type=radio],input[type=checkbox]").first();
                    if (inputEl != null) {
                        currentOptionId = inputEl.attr("value");
                    }
                } else if (cls != null && cls.contains("poll_ok")) {
                    // 结果条
                    double percent = 0;
                    int voteCount = 0;
                    String barColor = null;

                    // 进度条：span > em[style*="width"]
                    Element barEm = li.select("span > em[style]").first();
                    if (barEm != null) {
                        String style = barEm.attr("style");
                        // width:80.00%
                        Matcher wMatcher = Pattern.compile("width:\\s*([\\d.]+)%").matcher(style);
                        if (wMatcher.find()) {
                            percent = Double.parseDouble(wMatcher.group(1));
                        }
                        // background-color:#E92725
                        Matcher cMatcher = Pattern.compile("background-color:\\s*(#[0-9A-Fa-f]{3,8})").matcher(style);
                        if (cMatcher.find()) {
                            barColor = cMatcher.group(1);
                        }
                    }

                    // 票数和百分比文本：em "80.00% (24)"
                    Element resultEm = li.select("> em[style]").first();
                    if (resultEm == null) {
                        // 兜底：取最后一个 em
                        resultEm = li.select("em").last();
                    }
                    if (resultEm != null) {
                        String resultText = resultEm.text().trim();
                        Matcher countMatcher = Pattern.compile("\\((\\d+)\\)").matcher(resultText);
                        if (countMatcher.find()) {
                            voteCount = Integer.parseInt(countMatcher.group(1));
                        }
                        if (percent == 0) {
                            Matcher pMatcher = Pattern.compile("([\\d.]+)%").matcher(resultText);
                            if (pMatcher.find()) {
                                percent = Double.parseDouble(pMatcher.group(1));
                            }
                        }
                    }

                    if (currentLabel != null) {
                        Poll.Option opt = new Poll.Option(currentLabel, percent, voteCount, barColor);
                        if (currentOptionId != null) {
                            opt.setOptionId(currentOptionId);
                        }
                        options.add(opt);
                        currentLabel = null;
                        currentOptionId = null;
                    }
                }
            }
            poll.setOptions(options);
        }

        // 底部提示消息（如"您已经投过票,谢谢您的参与" 或 "您需要登录后才可以参与投票"）
        Element bottomEl = pollDiv.select(".comiis_poll_bottom").first();
        if (bottomEl != null) {
            String bottomText = bottomEl.text().trim();
            if (!bottomText.isEmpty()) {
                poll.setBottomMessage(bottomText);
            }
        }

        return poll;
    }

    /**
     * 解析小黑屋 JSON API 响应。
     *
     * <p>API: {@code forum.php?mod=misc&action=showdarkroom&cid=&ajaxdata=json}
     * 返回非标准 JSON（key 无引号），包含 operator / operatorid 字段。
     *
     * @param jsonStr API 返回的 JSON 字符串
     * @return 解析结果，包含用户列表和下一页 cid
     */
    public static DarkroomResult parseDarkroomJson(String jsonStr) {
        DarkroomResult result = new DarkroomResult();
        if (TextUtils.isEmpty(jsonStr)) return result;
        try {
            // 修复非标准 JSON：给无引号的 key 加引号
            String fixed = jsonStr.replaceAll("(\\{)(\\d+):", "{\"$2\":")
                                  .replaceAll("(,)(\\d+):", ",\"$2\":");
            JSONObject root = new JSONObject(fixed);

            // message 字段含下一页 cid，格式 "1|27948"
            String message = root.optString("message", "");
            String[] parts = message.split("\\|");
            if (parts.length > 0) {
                result.nextCid = parts[parts.length - 1];
            }

            JSONObject dataObj = root.optJSONObject("data");
            if (dataObj != null) {
                Iterator<String> keys = dataObj.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    JSONObject item = dataObj.optJSONObject(key);
                    if (item == null) continue;

                    BannedUser user = new BannedUser();
                    user.setUid(item.optString("uid", ""));
                    user.setUsername(item.optString("username", ""));
                    user.setAction(item.optString("action", ""));
                    user.setGroupexpiry(item.optString("groupexpiry", ""));
                    user.setReason(item.optString("reason", ""));
                    user.setOperator(item.optString("operator", ""));
                    user.setOperatorid(item.optString("operatorid", ""));
                    user.setCid(item.optString("cid", ""));

                    // dateline 含 HTML 标签，提取 title 属性或纯文本
                    String dateline = item.optString("dateline", "");
                    if (dateline.contains("title=\"")) {
                        Matcher m = Pattern.compile("title=\"([^\"]+)\"").matcher(dateline);
                        if (m.find()) {
                            dateline = m.group(1);
                        }
                    }
                    dateline = dateline.replaceAll("&nbsp;", " ").replaceAll("<[^>]+>", "").trim();
                    user.setDateline(dateline);

                    if (!TextUtils.isEmpty(user.getUsername())) {
                        result.users.add(user);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 解析留言板页面（home.php?mod=space&uid=X&do=wall）中的留言列表。
     * Comiis 模板条目结构：
     *   <dl id="comment_20112_li" class="comiis_list_readimgs b_t cl">
     *     <dt><a class="rzlist_tximg"><img src="avatar"></a>
     *       <h2><a class="top_user f_b" href="...uid=123">作者名</a></h2>
     *       <span class="top_time f_d">时间</span></dt>
     *     <dd class="plface">
     *       留言正文
     *       <div class="comiis_quote">回复块</div>
     *     </dd></dl>
     */
    public static List<Message> parseWallMessages(String html) {
        List<Message> list = new ArrayList<>();
        if (TextUtils.isEmpty(html)) return list;
        try {
            Document doc = Jsoup.parse(html);
            Elements items = doc.select("dl[id^=comment_]");
            if (items.isEmpty()) {
                // 兜底：部分模板可能用 div
                items = doc.select("div[id^=comment_][class*=comiis_list_readimgs]");
            }
            for (Element item : items) {
                // 1. 提取主留言（含内嵌引用卡片）
                Message mainMsg = parseMainWallEntry(item);
                if (mainMsg != null) list.add(mainMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /** 提取主留言：作者/头像/时间来自 dt，正文来自 dd.plface（移除回复块后）。 */
    private static Message parseMainWallEntry(Element item) {
        Message message = new Message();
        message.setType(0);
        message.setPmid(extractWallId(item));

        Element dt = item.selectFirst("dt");
        if (dt != null) {
            extractWallAuthor(dt, message);
            // 自己的留言会渲染编辑/删除链接（id 以 _edit / _delete 结尾）。
            Element editLink = dt.selectFirst("a[id$=_edit][href*=ac=comment]");
            if (editLink != null) {
                message.setWallEditUrl(normalizeUrl(editLink.attr("href")));
            }
            Element deleteLink = dt.selectFirst("a[id$=_delete][href*=ac=comment]");
            if (deleteLink != null) {
                message.setWallDeleteUrl(normalizeUrl(deleteLink.attr("href")));
            }
            Element replyLink = dt.selectFirst("a[id$=_reply][href*=ac=comment]");
            if (replyLink != null) {
                message.setWallReplyUrl(normalizeUrl(replyLink.attr("href")));
            }
        }

        // 留言页实际使用 dd.pm_c；dd.plface 仅作为旧模板兼容。
        Element body = item.selectFirst("dd.pm_c");
        if (body == null) body = item.selectFirst("dd.plface");
        if (body == null) body = item.selectFirst("dd");
        if (body != null) {
            // 引用卡片（主人对其他留言的回复）直接绑定到本条留言，不拆成独立条目。
            message.setQuotedContent(extractQuotedContent(body));
            // 作者通常和正文同在 pm_c 中，先从正文容器取一次，避免只依赖 dt。
            if (TextUtils.isEmpty(message.getAuthor())) extractWallAuthor(body, message);

            Element clone = body.clone();
            // 引用卡片属于回复上下文，不能再拼入主留言正文。
            clone.select(
                    "[id^=comment_reply_], [id^=reply_], .reply, .comment_reply, "
                    + ".comiis_quote, .quote, blockquote, [class*=quote]").remove();
            clone.select("a.xw1, a.b_b, a[href*=space-uid], a[href*=uid=], "
                    + "a[href*=touid], span.xg1, span.xi2, span[title], img").remove();
            message.setSummary(extractTextWithNewlines(clone).trim());
        }

        // 最后才从条目范围兜底查作者；引用块作者不参与主留言作者选择。
        if (TextUtils.isEmpty(message.getAuthor())) extractWallAuthor(item, message);

        if (TextUtils.isEmpty(message.getSummary()) && TextUtils.isEmpty(message.getAuthor())) {
            return null;
        }
        return message;
    }

    /**
     * 提取元素纯文本，保留 <br> 和块级元素产生的换行。
     * Jsoup 的 {@link Element#text()} 会把换行合并成空格，留言正文需要保留换行。
     */
    private static String extractTextWithNewlines(Element el) {
        if (el == null) return "";
        StringBuilder sb = new StringBuilder();
        appendTextNodes(el, sb);
        return sb.toString()
                .replaceAll("[ \t]+", " ")
                .replaceAll("\n{3,}", "\n\n")
                .trim();
    }

    private static void appendTextNodes(Node node, StringBuilder sb) {
        if (node instanceof TextNode) {
            sb.append(((TextNode) node).getWholeText());
        } else if (node instanceof Element) {
            Element e = (Element) node;
            if ("br".equals(e.tagName())) {
                sb.append("\n");
                return;
            }
            for (Node child : e.childNodes()) {
                appendTextNodes(child, sb);
            }
            if (e.isBlock() || isBlockTag(e.tagName())) {
                sb.append("\n");
            }
        }
    }

    private static boolean isBlockTag(String tag) {
        return "p".equals(tag) || "div".equals(tag) || "li".equals(tag)
                || "tr".equals(tag) || tag.length() == 2 && tag.charAt(0) == 'h';
    }

    /** 提取留言项内的所有回复块。 */
    private static List<Message> parseWallReplies(Element item) {
        List<Message> replies = new ArrayList<>();
        Elements replyEls = item.select(
                "[id^=comment_reply_], [id^=reply_], .reply, .comment_reply, .comiis_quote, blockquote");
        for (Element reply : replyEls) {
            // 只保留最外层回复节点，避免同一回复同时命中 .reply 和 .comiis_quote。
            boolean nestedInReply = false;
            for (Element parent : reply.parents()) {
                if (parent != item && (parent.is("[id^=comment_reply_]")
                        || parent.is("[id^=reply_]")
                        || parent.hasClass("reply")
                        || parent.hasClass("comment_reply")
                        || parent.hasClass("comiis_quote")
                        || parent.tagName().equals("blockquote"))) {
                    nestedInReply = true;
                    break;
                }
            }
            if (nestedInReply) continue;
            Message msg = parseWallReplyEntry(reply);
            if (msg != null) replies.add(msg);
        }
        return replies;
    }

    /** 解析单个回复块。 */
    private static Message parseWallReplyEntry(Element reply) {
        Message message = new Message();
        message.setType(3);
        message.setPmid(extractWallId(reply));
        message.setQuotedContent(extractQuotedContent(reply));

        // 回复的作者/头像/时间直接在回复块内搜索
        extractWallAuthor(reply, message);

        // 正文：克隆后移除引用块和头部链接
        Element clone = reply.clone();
        clone.select(
                ".comiis_quote, .quote, [class*=quote]").remove();
        // 移除作者链接和时间标签，避免混入正文
        clone.select("a.top_user, a[href*=mod=space], a[href*=space-uid-], "
                + "a[href*=uid=], a[href*=touid=]").remove();
        clone.select("span.top_time, .xg1, .f_d, [class*=time]").remove();
        clone.select("img").remove();

        String content = clone.text().trim();
        content = content.replaceFirst("^回复\\s*[:：]?\\s*", "").trim();
        message.setSummary(content);

        if (TextUtils.isEmpty(message.getSummary()) && TextUtils.isEmpty(message.getAuthor())) {
            return null;
        }
        return message;
    }

    /**
     * 从元素中提取作者名、UID、头像、时间。
     * 支持多种 Comiis/Discuz 模板选择器。
     */
    private static void extractWallAuthor(Element source, Message message) {
        // 真实留言模板常用 a.xw1 / a.b_b；同时兼容各类 UID 链接。
        Elements authorLinks = source.select(
                "a.xw1, a.b_b, a.top_user, a[href*=space-uid-], "
                + "a[href*=space-uid], a[href*=touid=], a[href*=uid=]");
        for (Element candidate : authorLinks) {
            // 主留言不要误取灰色引用卡片里的作者。
            Element quote = candidate.closest(
                    ".comiis_quote, .quote, blockquote, [class*=quote], [id^=comment_reply_], [id^=reply_]");
            if (quote != null && quote != source) continue;
            String author = candidate.text().trim();
            if (TextUtils.isEmpty(author) || isDateLike(author)) continue;
            message.setAuthor(author);
            String uid = extractUidFromUrl(candidate.attr("href"));
            if (!TextUtils.isEmpty(uid)) message.setAuthorUid(uid);
            break;
        }

        // 头像
        Element avatar = source.selectFirst("img[src]");
        if (avatar != null) message.setAvatarUrl(normalizeUrl(avatar.attr("src")));

        // 时间
        Element time = source.selectFirst("span.top_time, .f_d, .xg1, [class*=time]");
        if (time != null) {
            String t = time.text().trim();
            if (!TextUtils.isEmpty(t) && !isDateLike(t)) {
                message.setTime(t);
            }
        }
        // 兜底：从文本中搜索日期片段
        if (TextUtils.isEmpty(message.getTime())) {
            String text = source.text().trim();
            if (isDateLike(text)) {
                java.util.regex.Matcher dm = Pattern.compile(
                        "\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}(?:\\s*\\d{1,2}:\\d{2}(?::\\d{2})?)?"
                        + "|\\d+\\s*(?:分钟|小时|天前|秒前)"
                        + "|\\d{1,2}:\\d{2}").matcher(text);
                if (dm.find()) message.setTime(dm.group().trim());
            }
        }
    }

    private static String extractWallId(Element element) {
        if (element == null) return "";
        Matcher idMatcher = Pattern.compile("(?:comment|reply)[_\\-](\\d+)").matcher(element.id());
        if (idMatcher.find()) return idMatcher.group(1);
        for (org.jsoup.nodes.Node node : element.childNodes()) {
            if (node instanceof Element) {
                String found = extractWallId((Element) node);
                if (!TextUtils.isEmpty(found)) return found;
            }
        }
        return "";
    }

    private static String extractQuotedContent(Element content) {
        if (content == null) return "";
        Element quote = content.selectFirst(".comiis_quote, .quote, [class*=quote]");
        if (quote == null) return "";
        // 部分模板把被回复留言的作者和时间放在同一块内，引用区只保留引用正文。
        Element quoteClone = quote.clone();
        quoteClone.select("img, dt, span.top_time, .xg1, [class*=head], [class*=time]").remove();
        Element author = quoteClone.selectFirst(
                "a.top_user, a[href*=mod=space][href*=uid=], a[href*=space-uid-]");
        if (author != null) author.remove();
        return quoteClone.text().trim();
    }

    private static String firstVisibleAuthor(Element root, int maxItems) {
        if (root == null) return "";
        Elements authors = root.select(
                "a.top_user, a[href*=mod=space][href*=uid=], a[href*=space-uid-], "
                        + "strong.xw1, b.xw1, .top_user, .name, [class*=username]");
        if (authors.isEmpty()) {
            String text = root.text().trim();
            if (isDateLike(text)) return "";
            return text.split("\\s", 2).length > 0 ? text.split("\\s", 2)[0].trim() : "";
        }

        int count = 0;
        for (Element candidate : authors) {
            if (count++ >= maxItems) break;
            // 如果候选文本本身就是日期，说明误抓到了时间块。
            if (isDateLike(candidate.text())) continue;
            String author = candidate.text().trim();
            if (!TextUtils.isEmpty(author)) return author;
        }
        return "";
    }

    private static boolean isDateLike(String text) {
        if (TextUtils.isEmpty(text)) return false;
        return text.matches(".*(\\d{4}-\\d{2}-\\d{2}|\\d{2}:\\d{2}|\\d+\\s*(分钟|小时|天前|秒前)).*");
    }

    /** 从留言页分页链接中提取最大页码。 */
    public static int parseWallMaxPage(String html) {
        if (TextUtils.isEmpty(html)) return 1;
        int maxPage = 1;
        try {
            Document doc = Jsoup.parse(html);
            for (Element link : doc.select("a[href*=page=], option[value*=page=]")) {
                String url = link.hasAttr("href") ? link.attr("href") : link.attr("value");
                Matcher matcher = Pattern.compile("(?:^|[?&])page=(\\d+)").matcher(url);
                if (matcher.find()) {
                    maxPage = Math.max(maxPage, Integer.parseInt(matcher.group(1)));
                }
            }
            Element pageInfo = doc.selectFirst(".pg, .comiis_p12, .page, [class*=page]");
            if (pageInfo != null) {
                Matcher matcher = Pattern.compile("(?:共\\s*)?(\\d+)\\s*页").matcher(pageInfo.text());
                while (matcher.find()) {
                    maxPage = Math.max(maxPage, Integer.parseInt(matcher.group(1)));
                }
            }
        } catch (Exception ignored) {
        }
        return Math.max(1, maxPage);
    }

    /** 小黑屋 JSON 解析结果 */
    public static class DarkroomResult {
        public List<BannedUser> users = new ArrayList<>();
        public String nextCid = "";
        public boolean hasMore() {
            return !TextUtils.isEmpty(nextCid) && !nextCid.equals("0");
        }
    }
}
