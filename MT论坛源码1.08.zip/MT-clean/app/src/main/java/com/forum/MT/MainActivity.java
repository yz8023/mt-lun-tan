package com.forum.MT;
import com.forum.MT.ui.BaseActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.forum.MT.databinding.ActivityMainBinding;
import com.forum.MT.ui.home.HomeFragment;
import com.forum.MT.ui.community.CommunityFragment;
import com.forum.MT.ui.message.MessageFragment;
import com.forum.MT.ui.profile.ProfileFragment;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.network.NoticeBadgeManager;
import com.forum.MT.network.UpdateChecker;
import com.forum.MT.ui.post.PostActivity;
import com.forum.MT.session.AutoSignInManager;
import com.forum.MT.session.MessageSoundPlayer;
import com.forum.MT.session.SignInSoundPlayer;
import com.forum.MT.ui.widget.BottomNavBarColorManager;
import com.forum.MT.ui.widget.CardBorderManager;
import com.forum.MT.ui.widget.NavBarStyleManager;
import com.forum.MT.ui.widget.NavPostCenterManager;
import com.forum.MT.ui.widget.RainbowBorderDrawable;
import com.forum.MT.ui.widget.StatusBarColorManager;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** * 主活动 — 胶囊导航栏（首页/圈子/凸起发布/消息/我的） */
public class MainActivity extends BaseActivity {

    private ActivityMainBinding binding;

    // ★ 常驻 Fragment（show/hide 切换，不销毁重建 → 无缝切换、不重复刷新）
    private Fragment homeFragment, communityFragment, messageFragment, profileFragment;
    private static final int TAB_HOME = 0, TAB_COMMUNITY = 1, TAB_MESSAGE = 2, TAB_PROFILE = 3;
    private int currentTab = -1;
    /** 当前 tab 重复点击的时间戳，用于双击检测（双击当前 tab → 刷新该页） */
    private long lastRetapTime = 0L;
    private static final long DOUBLE_TAP_MS = 400;

    // 导航项（5项）
    private View navHome, navCommunity, navPost, navMessage, navProfile;
    // 图标（含凸起发布按钮图标）
    private ImageView ivHomeIcon, ivCommunityIcon, ivPostIcon, ivMessageIcon, ivProfileIcon;
    // 文字
    private TextView tvHomeText, tvCommunityText, tvMessageText, tvProfileText;

    // ★ 消息角标
    private TextView tvMessageBadge;
    private Handler mainHandler;
    private ExecutorService executor;
    // 5分钟刷新一次：消息红点延迟 5 分钟可接受。
    // 阿里云 WAF 对持续高频请求会封 IP 5-30 分钟，60s 轮询 + 7 并发仍会累积触发封禁。
    // 5 分钟一次大幅降低累积请求量，配合全局 300ms 间隔节流，正常浏览基本不会触发限流。
    private static final long BADGE_REFRESH_INTERVAL_MS = 300_000L; // 5分钟刷新一次
    private final java.util.Map<String, Integer> previousUnreadCounts = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Map<String, String> previousUnreadFingerprints = new java.util.concurrent.ConcurrentHashMap<>();
    private final AtomicBoolean badgeRefreshInFlight = new AtomicBoolean(false);
    // 每次手动“全部已读”递增；旧轮询结果返回后不得覆盖刚清零的角标。
    private final java.util.concurrent.atomic.AtomicInteger badgeRefreshGeneration =
            new java.util.concurrent.atomic.AtomicInteger(0);
    private boolean unreadBaselineReady = false;

    // 双击返回退出
    private static final long EXIT_INTERVAL_MS = 2000;
    private long lastBackPressTime = 0;
    private RainbowBorderDrawable rainbowNavBackgroundCapsule;
    private RainbowBorderDrawable rainbowNavBackgroundFullWidth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        float density = getResources().getDisplayMetrics().density;
        // 预创建两种流水灯背景（胶囊圆角 vs 全宽直角）
        rainbowNavBackgroundCapsule = new RainbowBorderDrawable(0xFFFFFFFF, 24f * density, density);
        rainbowNavBackgroundFullWidth = new RainbowBorderDrawable(0xFFFFFFFF, 0f, density);

        // 应用当前导航栏样式
        applyNavBarStyle();

        // 系统导航栏 inset 处理
        applyWindowInsetsForNavBar();

        // 初始化常驻 Fragment 容器（show/hide 模式，不再使用 Navigation Component）
        // ★ 修复：Activity 被销毁重建后，FragmentManager 仍持有已添加的 Fragment，
        //   但成员变量(homeFragment 等)全为 null，导致 switchTab 无法 hide 旧 Fragment，
        //   表现为"导航栏高亮首页但实际显示的是我的"。
        FragmentManager fm = getSupportFragmentManager();
        Fragment f0 = fm.findFragmentByTag("tab_0");
        Fragment f1 = fm.findFragmentByTag("tab_1");
        Fragment f2 = fm.findFragmentByTag("tab_2");
        Fragment f3 = fm.findFragmentByTag("tab_3");
        if (f0 instanceof HomeFragment) homeFragment = (HomeFragment) f0;
        if (f1 instanceof CommunityFragment) communityFragment = (CommunityFragment) f1;
        if (f2 instanceof MessageFragment) messageFragment = (MessageFragment) f2;
        if (f3 instanceof ProfileFragment) profileFragment = (ProfileFragment) f3;

        int initialTab = (savedInstanceState != null)
                ? savedInstanceState.getInt("current_tab", TAB_HOME) : TAB_HOME;
        currentTab = -1; // 强制 switchTab 不跳过
        switchTab(initialTab);
        updateNavSelection(getNavResId(initialTab));

        // 恢复持久化的 Cookie
        HttpClient.getInstance().init(this);

        // ★ 消息角标初始化
        mainHandler = new Handler(Looper.getMainLooper());
        executor = Executors.newFixedThreadPool(7);
        tvMessageBadge = findViewById(R.id.nav_message_badge);
        if (tvMessageBadge != null) {
            tvMessageBadge.setVisibility(View.GONE);
            refreshMessageBadge();
            checkForUpdateOnStartup();
        }

        // 初始化导航视图引用（含凸起发布按钮）
        initNavigationBar();
        applyPostButtonTheme();
        // 重新应用导航栏样式（此时 ivPostIcon 已初始化，确保 + 按钮居中定位生效）
        applyNavBarStyle();

        // 注册底部导航栏颜色变更监听（从主题设置页返回时自动刷新）
        BottomNavBarColorManager.setListener(() -> {
            if (isFinishing() || isDestroyed()) return;
            runOnUiThread(() -> refreshNavTheme());
        });
        // 卡片边框效果变更监听（从主题设置页返回时刷新导航栏边框）
        CardBorderManager.setListener(enabled -> {
            if (isFinishing() || isDestroyed()) return;
            runOnUiThread(() -> refreshNavTheme());
        });
        // 导航栏样式变更监听
        NavBarStyleManager.setListener(() -> {
            if (isFinishing() || isDestroyed()) return;
            runOnUiThread(() -> {
                applyNavBarStyle();
                refreshNavTheme();
            });
        });
        // 加号居中开关变更监听
        NavPostCenterManager.setListener(() -> {
            if (isFinishing() || isDestroyed()) return;
            runOnUiThread(() -> applyNavBarStyle());
        });

        // ===== 应用状态栏颜色 =====
        applyStatusBarColor();
        StatusBarColorManager.setListener(() -> {
            if (isFinishing() || isDestroyed()) return;
            runOnUiThread(() -> applyStatusBarColor());
        });
    }

    /** 应用状态栏颜色（根据亮度自动调整图标色）。 */
    private void applyStatusBarColor() {
        if (isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        int color = StatusBarColorManager.resolveStatusBarColor();
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(color);
        }
        // 根据背景亮度自动调整状态栏图标颜色
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            int brightness = (int) (0.299 * android.graphics.Color.red(color)
                    + 0.587 * android.graphics.Color.green(color)
                    + 0.114 * android.graphics.Color.blue(color));
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (brightness > 128) {
                // 浅色背景 → 深色图标
                getWindow().getDecorView().setSystemUiVisibility(
                        flags | android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            } else {
                // 深色背景 → 浅色图标
                getWindow().getDecorView().setSystemUiVisibility(
                        flags & ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }
    }

    /** 应用导航栏样式：胶囊悬浮 vs 官方全宽贴底。 */
    private void applyNavBarStyle() {
        if (binding == null || binding.bottomNavContainer == null) return;
        float density = getResources().getDisplayMetrics().density;
        boolean official = NavBarStyleManager.isOfficialStyle();

        android.view.ViewGroup.MarginLayoutParams lp =
                (android.view.ViewGroup.MarginLayoutParams) binding.bottomNavContainer.getLayoutParams();
        if (official) {
            // 官方样式：全宽、无水平边距、无底边距、无阴影
            lp.leftMargin = 0;
            lp.rightMargin = 0;
            lp.bottomMargin = 0;
            binding.bottomNavContainer.setLayoutParams(lp);
            binding.bottomNavContainer.setElevation(0f);
            // 全宽矩形背景（官方样式不加任何边框效果）
            applyNavFlatBackground();
            // 官方样式：+ 按钮上下居中（取消上移）
            if (ivPostIcon != null) {
                android.view.ViewGroup.MarginLayoutParams iconLp =
                        (android.view.ViewGroup.MarginLayoutParams) ivPostIcon.getLayoutParams();
                iconLp.topMargin = 0;
                ivPostIcon.setLayoutParams(iconLp);
            }
        } else {
            // 默认胶囊样式：16dp水平边距、12dp底边距、8dp阴影
            int margin16 = (int) (16f * density);
            int margin12 = (int) (12f * density);
            lp.leftMargin = margin16;
            lp.rightMargin = margin16;
            lp.bottomMargin = margin12;
            binding.bottomNavContainer.setLayoutParams(lp);
            binding.bottomNavContainer.setElevation(8f * density);
            // 胶囊圆角背景
            if (RainbowBorderDrawable.isGloballyEnabled()) {
                if (rainbowNavBackgroundCapsule == null) {
                    rainbowNavBackgroundCapsule = new RainbowBorderDrawable(0xFFFFFFFF, 24f * density, density);
                }
                rainbowNavBackgroundCapsule.setFillColor(BottomNavBarColorManager.resolveBgColor());
                binding.bottomNavContainer.setBackground(rainbowNavBackgroundCapsule);
            } else {
                applyNavFlatBackground();
            }
            // 胶囊样式：+ 按钮居中或上移（取决于用户设置）
            if (ivPostIcon != null) {
                android.view.ViewGroup.MarginLayoutParams iconLp =
                        (android.view.ViewGroup.MarginLayoutParams) ivPostIcon.getLayoutParams();
                iconLp.topMargin = NavPostCenterManager.isPostCenter()
                        ? 0
                        : (int) (-14f * density);
                ivPostIcon.setLayoutParams(iconLp);
            }
        }
        // 重新触发 inset 计算
        binding.bottomNavContainer.requestApplyInsets();
    }

    /** 应用系统导航栏 inset 到底部导航栏容器（仅官方样式下生效）。 */
    private void applyWindowInsetsForNavBar() {
        if (binding == null || binding.bottomNavContainer == null) return;
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(binding.bottomNavContainer, (v, insets) -> {
            if (NavBarStyleManager.isOfficialStyle()) {
                androidx.core.graphics.Insets navBars = insets.getInsets(
                        androidx.core.view.WindowInsetsCompat.Type.navigationBars());
                v.setPadding(v.getPaddingLeft(), v.getPaddingTop(),
                        v.getPaddingRight(), navBars.bottom);
            } else {
                // 胶囊样式：恢复 XML 中定义的 padding
                v.setPadding(v.getPaddingLeft(), v.getPaddingTop(),
                        v.getPaddingRight(), (int) (8 * getResources().getDisplayMetrics().density));
            }
            return insets;
        });
    }

    /** 应用底部导航栏背景色与文字/图标颜色。 */
    private void refreshNavTheme() {
        try {
            if (binding == null || binding.bottomNavContainer == null) return;
            float density = getResources().getDisplayMetrics().density;
            boolean official = NavBarStyleManager.isOfficialStyle();

            if (RainbowBorderDrawable.isGloballyEnabled() && !official) {
                if (rainbowNavBackgroundCapsule == null) {
                    rainbowNavBackgroundCapsule = new RainbowBorderDrawable(0xFFFFFFFF, 24f * density, density);
                }
                // 更新流水灯填充色为用户自定义的导航栏背景色
                rainbowNavBackgroundCapsule.setFillColor(BottomNavBarColorManager.resolveBgColor());
                binding.bottomNavContainer.setBackground(rainbowNavBackgroundCapsule);
            } else {
                applyNavFlatBackground();
            }
            applyPostButtonTheme();
            updateNavSelection(currentNavSelection);
        } catch (Exception e) {
            android.util.Log.e("MainActivity", "refreshNavTheme error", e);
        }
    }

    /** 应用凸起发帖按钮的背景色与 "+" 图标色。 */
    private void applyPostButtonTheme() {
        try {
            if (ivPostIcon == null) return;
            float density = getResources().getDisplayMetrics().density;
            // 背景色：保留原阴影造型，直接用代码构造圆形渐变背景（替代修改 XML drawable）
            int bgColor = BottomNavBarColorManager.resolvePostBgColor();

            // 外圈阴影（52dp 半透明黑）
            android.graphics.drawable.GradientDrawable shadow = new android.graphics.drawable.GradientDrawable();
            shadow.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            shadow.setColor(0x33000000);
            // 内圈实心圆（48dp 指定背景色）
            android.graphics.drawable.GradientDrawable inner = new android.graphics.drawable.GradientDrawable();
            inner.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            inner.setColor(bgColor);

            android.graphics.drawable.LayerDrawable layer = new android.graphics.drawable.LayerDrawable(
                    new android.graphics.drawable.Drawable[]{shadow, inner});
            int inset = (int) (2 * density);
            layer.setLayerInset(1, inset, inset, inset, inset);
            ivPostIcon.setBackground(layer);

            // "+" 图标色
            int iconColor = BottomNavBarColorManager.resolvePostIconColor();
            ivPostIcon.setColorFilter(iconColor);
        } catch (Exception e) {
            android.util.Log.e("MainActivity", "applyPostButtonTheme error", e);
        }
    }

    /** 非彩虹模式下：用保留 24dp 胶囊圆角的纯色背景，替代 setBackgroundColor 导致的方法直角矩形。 */
    private void applyNavFlatBackground() {
        if (binding == null || binding.bottomNavContainer == null) return;
        float density = getResources().getDisplayMetrics().density;
        boolean official = NavBarStyleManager.isOfficialStyle();
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setColor(BottomNavBarColorManager.resolveBgColor());
        bg.setCornerRadius(official ? 0f : 24f * density);
        // 卡片边框效果开启时，给导航栏也加上静态描边边框（官方样式除外）
        if (CardBorderManager.isEnabled() && !official) {
            int strokeColor = CardBorderManager.resolveStrokeColor();
            bg.setStroke((int) (2f * density + 0.5f), strokeColor);
        }
        binding.bottomNavContainer.setBackground(bg);
    }

    private void checkForUpdateOnStartup() {
        // 如果用户关闭了"自动检测更新"，则不检查
        if (!getSharedPreferences("app_settings", MODE_PRIVATE)
                .getBoolean("auto_check_update", true)) {
            return;
        }
        UpdateChecker.check(this, result -> {
            if (!result.success || !result.hasUpdate
                    || isFinishing()
                    || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("发现新版本")
                    .setMessage("更新文件夹检测到新内容，是否打开更新页面？")
                    .setNegativeButton("稍后", null)
                    .setPositiveButton("立即更新", (dialog, which) -> {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    android.net.Uri.parse(UpdateChecker.UPDATE_URL)));
                        } catch (Exception e) {
                            Toast.makeText(this, "没有可用的浏览器", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
        });
    }

    /**
     * 初始化悬浮胶囊导航栏（5项：首页/圈子/凸起发布/消息/我的）
     */
    private void initNavigationBar() {
        navHome = findViewById(R.id.nav_home_tab);
        navCommunity = findViewById(R.id.nav_community_tab);
        navPost = findViewById(R.id.nav_post_tab);
        navMessage = findViewById(R.id.nav_message_tab);
        navProfile = findViewById(R.id.nav_profile_tab);

        ivHomeIcon = findViewById(R.id.nav_home_icon);
        ivCommunityIcon = findViewById(R.id.nav_community_icon);
        ivPostIcon = findViewById(R.id.nav_post_icon);
        ivMessageIcon = findViewById(R.id.nav_message_icon);
        ivProfileIcon = findViewById(R.id.nav_profile_icon);

        tvHomeText = findViewById(R.id.nav_home_text);
        tvCommunityText = findViewById(R.id.nav_community_text);
        tvMessageText = findViewById(R.id.nav_message_text);
        tvProfileText = findViewById(R.id.nav_profile_text);

        // 空指针保护
        if (navHome == null || navCommunity == null || navPost == null || navMessage == null || navProfile == null) {
            android.util.Log.e("MainActivity", "Navigation bar views are null");
            return;
        }
        if (ivHomeIcon == null || ivCommunityIcon == null || ivPostIcon == null || ivMessageIcon == null || ivProfileIcon == null) {
            android.util.Log.e("MainActivity", "Navigation bar icons are null");
            return;
        }
        if (tvHomeText == null || tvCommunityText == null || tvMessageText == null || tvProfileText == null) {
            android.util.Log.e("MainActivity", "Navigation bar texts are null");
            return;
        }

        // 前4项 — show/hide 常驻 Fragment 切换
        navHome.setOnClickListener(v -> navigateTo(R.id.nav_home));
        navCommunity.setOnClickListener(v -> navigateTo(R.id.nav_community));
        navMessage.setOnClickListener(v -> navigateTo(R.id.nav_message));
        navProfile.setOnClickListener(v -> navigateTo(R.id.nav_profile));

        // 中间凸起发布按钮 — 启动 PostActivity
        navPost.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PostActivity.class);
            startActivity(intent);
        });

        // 初始选中状态
        updateNavSelection(R.id.nav_home);
    }

    /**
     * 导航到指定目的地（show/hide 常驻 Fragment，不销毁重建 → 无缝切换）。
     * 双击当前 tab 触发该页数据刷新。
     */
    private void navigateTo(int resId) {
        int tab;
        if (resId == R.id.nav_home) tab = TAB_HOME;
        else if (resId == R.id.nav_community) tab = TAB_COMMUNITY;
        else if (resId == R.id.nav_message) tab = TAB_MESSAGE;
        else if (resId == R.id.nav_profile) tab = TAB_PROFILE;
        else return;

        if (tab == currentTab) {
            // 已在当前 tab：检测双击 → 刷新该页；单击不切换（无缝）
            long now = System.currentTimeMillis();
            if (now - lastRetapTime < DOUBLE_TAP_MS) {
                refreshCurrentTab(tab);
                lastRetapTime = 0L; // 防三连击多次刷新
            } else {
                lastRetapTime = now;
            }
            updateNavSelection(resId);
            return;
        }

        switchTab(tab);
        updateNavSelection(resId);
        lastRetapTime = 0L; // 切换 tab 后重置双击计时
    }

    /** 双击当前 tab 时调用：刷新该 Fragment 的数据 */
    private void refreshCurrentTab(int tab) {
        Fragment f = getFragment(tab);
        if (f == null) return;
        if (f instanceof HomeFragment) ((HomeFragment) f).refreshData();
        else if (f instanceof CommunityFragment) ((CommunityFragment) f).refreshData();
        else if (f instanceof MessageFragment) ((MessageFragment) f).refreshData();
        else if (f instanceof ProfileFragment) ((ProfileFragment) f).refreshData();
    }

    /** 获取/懒创建指定 tab 的 Fragment 实例（常驻，不销毁） */
    private Fragment getFragment(int tab) {
        switch (tab) {
            case TAB_HOME: if (homeFragment == null) homeFragment = new HomeFragment(); return homeFragment;
            case TAB_COMMUNITY: if (communityFragment == null) communityFragment = new CommunityFragment(); return communityFragment;
            case TAB_MESSAGE: if (messageFragment == null) messageFragment = new MessageFragment(); return messageFragment;
            case TAB_PROFILE: if (profileFragment == null) profileFragment = new ProfileFragment(); return profileFragment;
            default: return null;
        }
    }

    /** show/hide 切换 tab：隐藏其他 Fragment，显示目标（未添加则 add） */
    private void switchTab(int tab) {
        if (tab == currentTab) return;
        Fragment target = getFragment(tab);
        if (target == null) return;
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        if (homeFragment != null && homeFragment != target) ft.hide(homeFragment);
        if (communityFragment != null && communityFragment != target) ft.hide(communityFragment);
        if (messageFragment != null && messageFragment != target) ft.hide(messageFragment);
        if (profileFragment != null && profileFragment != target) ft.hide(profileFragment);
        if (!target.isAdded()) {
            ft.add(R.id.nav_host_fragment, target, "tab_" + tab);
        } else {
            ft.show(target);
        }
        // ★ 用 commitNowAllowingStateLoss 同步执行，避免异步 commit 与
        //    Activity onSaveInstanceState 竞争导致 hide 状态丢失、
        //    返回后旧 Fragment(如"我的")重新显示盖住当前 Fragment
        ft.commitNowAllowingStateLoss();
        currentTab = tab;
    }

    /**
     * 更新导航栏选中状态
     */
    private int currentNavSelection = R.id.nav_home;

    private void updateNavSelection(int selectedId) {
        currentNavSelection = selectedId;
        resetAllSelection();

        if (selectedId == R.id.nav_home) {
            setItemActive(ivHomeIcon, tvHomeText);
        } else if (selectedId == R.id.nav_community) {
            setItemActive(ivCommunityIcon, tvCommunityText);
        } else if (selectedId == R.id.nav_message) {
            setItemActive(ivMessageIcon, tvMessageText);
        } else if (selectedId == R.id.nav_profile) {
            setItemActive(ivProfileIcon, tvProfileText);
        }
    }

    /**
     * 重置所有导航项为未选中状态
     */
    private void resetAllSelection() {
        setItemInactive(ivHomeIcon, tvHomeText);
        setItemInactive(ivCommunityIcon, tvCommunityText);
        setItemInactive(ivMessageIcon, tvMessageText);
        setItemInactive(ivProfileIcon, tvProfileText);
    }

    private void setItemActive(ImageView icon, TextView text) {
        if (icon == null || text == null) return;
        icon.setImageResource(getActiveIconRes(icon.getId()));
        icon.clearAnimation();
        Animation anim = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        anim.setDuration(150);
        icon.startAnimation(anim);
        icon.setColorFilter(BottomNavBarColorManager.resolveActiveColor());
        text.setTextColor(BottomNavBarColorManager.resolveActiveColor());
    }

    private void setItemInactive(ImageView icon, TextView text) {
        if (icon == null || text == null) return;
        icon.setImageResource(getInactiveIconRes(icon.getId()));
        // 深色导航栏背景时未选中项用浅色，否则用自定义未选中色（默认灰色）
        int inactiveColor = BottomNavBarColorManager.isBgDark()
                ? android.graphics.Color.WHITE
                : BottomNavBarColorManager.resolveInactiveColor();
        icon.setColorFilter(inactiveColor);
        text.setTextColor(inactiveColor);
    }

    private int getActiveIconRes(int viewId) {
        if (viewId == R.id.nav_home_icon) {
            return R.drawable.ic_home;
        } else if (viewId == R.id.nav_community_icon) {
            return R.drawable.ic_discover;
        } else if (viewId == R.id.nav_message_icon) {
            return R.drawable.ic_message;
        } else if (viewId == R.id.nav_profile_icon) {
            return R.drawable.ic_profile;
        }
        return 0;
    }

    private int getInactiveIconRes(int viewId) {
        return getActiveIconRes(viewId);
    }

    // ==================== 消息角标 ====================

    /**
     * 刷新消息角标（获取未读PM数）
     */
    private void refreshMessageBadge() {
        if (isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        if (!HttpClient.getInstance().isLoggedIn()) {
            badgeRefreshInFlight.set(false);
            if (tvMessageBadge != null) tvMessageBadge.setVisibility(View.GONE);
            scheduleNextBadgeRefresh();
            return;
        }
        // 防止上一次网络刷新尚未结束时重复提交任务。
        if (!badgeRefreshInFlight.compareAndSet(false, true)) return;
        final int requestGeneration = badgeRefreshGeneration.get();
        if (executor == null || executor.isShutdown() || executor.isTerminated()) {
            badgeRefreshInFlight.set(false);
            scheduleNextBadgeRefresh();
            return;
        }

        // 六类列表并行请求；原来单线程逐个请求，尤其 PM 还会请求会话详情，导致角标延迟明显。
        try {
            executor.execute(() -> {
                java.util.Map<String, Integer> counts = new java.util.concurrent.ConcurrentHashMap<>();
                java.util.Map<String, String> fingerprints = new java.util.concurrent.ConcurrentHashMap<>();
                // 坛友互动必须按五个真实子分类分别拉取，不能再用旧的 view=interactive
                // 父分类结果覆盖已计算好的子分类汇总角标。
                String[] types = {"pm", "follower", "mypost_at", "mypost_post",
                        "interactive_poke", "interactive_friend", "interactive_click",
                        "interactive_wall", "interactive_comment", "system", "app"};
                try {
                    HttpClient.getInstance().syncFromCookieManager();
                    CountDownLatch latch = new CountDownLatch(types.length);
                    for (String type : types) {
                        final String viewType = type;
                        final String url;
                        if ("pm".equals(viewType)) {
                            url = HttpClient.BASE_URL + "home.php?mod=space&do=pm&mobile=2";
                        } else if ("follower".equals(viewType)) {
                            url = HttpClient.BASE_URL + "home.php?mod=follow&do=follower&uid="
                                    + getCurrentUid() + "&mobile=2";
                        } else if ("mypost_at".equals(viewType)) {
                            // @我的（官方APK参数：view=mypost&type=at）
                            url = HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=mypost&type=at";
                        } else if ("mypost_post".equals(viewType)) {
                            // 我的帖子（官方APK参数：view=mypost&type=post）
                            url = HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=mypost&type=post";
                        } else if (viewType.startsWith("interactive_")) {
                            String interactiveType = viewType.substring("interactive_".length());
                            url = HttpClient.BASE_URL
                                    + "home.php?mod=space&do=notice&view=interactive&type="
                                    + interactiveType;
                        } else {
                            url = HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=" + viewType;
                        }
                        try {
                            executor.execute(() -> {
                                try {
                                    putUnreadData(counts, fingerprints, viewType, url);
                                } finally {
                                    latch.countDown();
                                }
                            });
                        } catch (java.util.concurrent.RejectedExecutionException rejected) {
                            latch.countDown();
                        }
                    }
                    latch.await(25, java.util.concurrent.TimeUnit.SECONDS);

                    // 五个互动子分类请求完成后按稳定通知键去重汇总，再写入父分类角标。
                    String[] interactiveTypes = {"poke", "friend", "click", "wall", "comment"};
                    int interactiveTotal = NoticeBadgeManager.getInteractiveAggregate(
                            MainActivity.this, interactiveTypes);
                    NoticeBadgeManager.setNewCount(MainActivity.this, "interactive", interactiveTotal);
                    counts.put("interactive", interactiveTotal);

                    runOnUiThread(() -> {
                        badgeRefreshInFlight.set(false);
                        if (isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                        // 若请求期间用户点击了“全部已读”，丢弃该请求的旧快照。
                        if (requestGeneration != badgeRefreshGeneration.get()) {
                            scheduleNextBadgeRefresh();
                            return;
                        }
                        applyUnreadCounts(counts, fingerprints);
                    });
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    runOnUiThread(() -> {
                        badgeRefreshInFlight.set(false);
                        if (!isFinishing()) scheduleNextBadgeRefresh();
                    });
                } catch (Exception ignored) {
                    runOnUiThread(() -> {
                        badgeRefreshInFlight.set(false);
                        if (!isFinishing()) scheduleNextBadgeRefresh();
                    });
                }
            });
        } catch (java.util.concurrent.RejectedExecutionException rejected) {
            badgeRefreshInFlight.set(false);
            scheduleNextBadgeRefresh();
        }
    }

    private String getCurrentUid() {
        String uid = com.forum.MT.session.UserSessionManager
                .getInstance().getUid(this);
        return uid == null || uid.isEmpty() ? "0" : uid;
    }

    private int fetchUnreadCount(String url, String viewType) {
        try {
            String html = ("pm".equals(viewType) || "follower".equals(viewType))
                    ? HttpClient.getInstance().get(url)
                    : HttpClient.getInstance().getDesktop(url);
            if (html == null || html.isEmpty() || ForumParser.isLoginPage(html)) return 0;
            List<com.forum.MT.model.Message> items;
            if ("pm".equals(viewType)) items = ForumParser.parsePmList(html);
            else if ("follower".equals(viewType)) items = ForumParser.parseFollowerList(html);
            else items = ForumParser.parseNoticeList(html);
            int count = 0;
            if (items != null) for (com.forum.MT.model.Message item : items) {
                if (!item.isRead()) count++;
            }
            return count;
        } catch (Exception ignored) {
            return 0;
        }
    }

    private void putUnreadData(java.util.Map<String, Integer> counts,
                                 java.util.Map<String, String> fingerprints,
                                 String viewType, String url) {
        try {
            String html = ("pm".equals(viewType) || "follower".equals(viewType))
                    ? HttpClient.getInstance().get(url)
                    : HttpClient.getInstance().getDesktop(url);
            if (html == null || html.isEmpty() || ForumParser.isLoginPage(html)) {
                // 临时网络失败或登录页不能把已有未读角标误清零。
                counts.put(viewType, NoticeBadgeManager.getNewCount(this, viewType));
                fingerprints.put(viewType, "");
                return;
            }

            // 与 NoticeActivity 使用同一套“当前列表 - 已查看快照”算法。
            String snapshot = NoticeBadgeManager.buildSnapshot(
                    viewType, html, HttpClient.getInstance());
            int count = NoticeBadgeManager.saveCurrentAndGetNewCount(
                    MainActivity.this, viewType, snapshot);
            counts.put(viewType, count);
            fingerprints.put(viewType, snapshot);
        } catch (Exception ignored) {
            // 保留最近一次可靠计数，避免单次请求异常让底部导航角标直接消失。
            counts.put(viewType, NoticeBadgeManager.getNewCount(this, viewType));
            fingerprints.put(viewType, "");
        }
    }

    private void applyUnreadCounts(java.util.Map<String, Integer> counts,
                                   java.util.Map<String, String> fingerprints) {
        // 底部导航栏显示所有消息分类的新增总数，不能只显示私信数量。
        int totalCount = 0;
        String[] allTypes = {"pm", "follower", "mypost_at", "mypost_post", "interactive", "system", "app"};
        for (String type : allTypes) {
            totalCount += getCount(counts, type);
        }
        updateBadgeDisplay(totalCount);

        if (unreadBaselineReady) {
            boolean hasNewPrivateChat = hasNewUnread("pm", counts, fingerprints);
            boolean hasNewOtherNotice = false;
            String[] otherTypes = {"follower", "mypost_at", "mypost_post", "interactive", "system", "app"};
            for (String type : otherTypes) {
                if (hasNewUnread(type, counts, fingerprints)) {
                    hasNewOtherNotice = true;
                    break;
                }
            }
            if (hasNewPrivateChat) MessageSoundPlayer.playPrivateChat(this);
            else if (hasNewOtherNotice) MessageSoundPlayer.playNotice(this);
        }

        previousUnreadCounts.clear();
        previousUnreadCounts.putAll(counts);
        previousUnreadFingerprints.clear();
        previousUnreadFingerprints.putAll(fingerprints);
        unreadBaselineReady = true;
        scheduleNextBadgeRefresh();
    }

    private boolean hasNewUnread(String type, java.util.Map<String, Integer> counts,
                                 java.util.Map<String, String> fingerprints) {
        int currentCount = getCount(counts, type);
        int oldCount = getCount(previousUnreadCounts, type);
        String currentFingerprint = fingerprints.get(type);
        String oldFingerprint = previousUnreadFingerprints.get(type);
        return currentCount > oldCount
                || (currentCount > 0 && !java.util.Objects.equals(currentFingerprint, oldFingerprint));
    }

    private int getCount(java.util.Map<String, Integer> counts, String key) {
        Integer value = counts.get(key);
        return value == null ? 0 : value;
    }

    private void updateBadgeDisplay(int count) {
        if (tvMessageBadge == null) return;
        if (count > 0) {
            tvMessageBadge.setVisibility(View.VISIBLE);
            tvMessageBadge.setText(count > 99 ? "99+" : String.valueOf(count));
        } else {
            tvMessageBadge.setVisibility(View.GONE);
        }
        scheduleNextBadgeRefresh();
    }

    /**
     * 供消息页"全部已读"后立即同步底部导航栏角标，
     * 避免等待 5 秒轮询才消失。
     */
    public void refreshBottomBadgeNow() {
        // 使已发出的网络轮询结果失效，避免旧数据把角标重新显示出来。
        badgeRefreshGeneration.incrementAndGet();
        if (isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        if (mainHandler == null) return;
        runOnUiThread(() -> {
            // 直接以当前已清零的各分类 newCount 汇总为 0（markAllViewed 已把 newCount 置 0）
            int total = 0;
            String[] allTypes = {"pm", "follower", "mypost_at", "mypost_post", "interactive", "system", "app"};
            for (String type : allTypes) {
                total += NoticeBadgeManager.getNewCount(this, type);
            }
            updateBadgeDisplay(total);
        });
    }

    private void scheduleNextBadgeRefresh() {
        mainHandler.removeCallbacks(badgeRunnable);
        mainHandler.postDelayed(badgeRunnable, BADGE_REFRESH_INTERVAL_MS);
    }

    private final Runnable badgeRunnable = this::refreshMessageBadge;

    @Override
    protected void onStart() {
        super.onStart();
        AutoSignInManager.checkAndSignIn(this, (success, performed, message) -> {
            if (performed && success && !isFinishing()) {
                Toast.makeText(this, "自动签到成功", Toast.LENGTH_SHORT).show();
                SignInSoundPlayer.play(this);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // ★ 多层防御：从帖子返回时强制让 Fragment 可见性与 currentTab 一致
        final int tab = currentTab;
        // 第一层：立即同步
        syncFragmentVisibility(tab);
        // 第二层：post 到主线程队列尾部，确保 FragmentManager 已完成 view 恢复
        //          （Fragment 的 view 可能在 onResume 之后才创建/恢复）
        getWindow().getDecorView().post(() -> syncFragmentVisibility(tab));
        // 从消息页/后台返回时立即刷新，不等待下一轮定时任务。
        if (mainHandler != null && tvMessageBadge != null) {
            mainHandler.removeCallbacks(badgeRunnable);
            refreshMessageBadge();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        // 第三层：窗口获得焦点时再同步一次（最晚时机，覆盖 view 延迟重建场景）
        if (hasFocus) {
            syncFragmentVisibility(currentTab);
        }
    }

    /** 强制让指定 tab 的 Fragment 可见，其余全部隐藏（同步执行） */
    private void syncFragmentVisibility(int tab) {
        FragmentManager fm = getSupportFragmentManager();
        java.util.List<Fragment> frags = fm.getFragments();
        if (frags == null || frags.isEmpty()) return;

        // ★ 先从 FragmentManager 恢复成员变量引用：
        //   Activity 被系统重建后成员变量(homeFragment/profileFragment)会丢，
        //   但 FragmentManager 里仍持有恢复的 Fragment 实例，按 tag 找回并赋值，
        //   否则防御同步会因为成员变量为 null 而无法隐藏"我的"Fragment。
        for (Fragment f : frags) {
            if (f == null) continue;
            if (f instanceof HomeFragment) homeFragment = (HomeFragment) f;
            else if (f instanceof CommunityFragment) communityFragment = (CommunityFragment) f;
            else if (f instanceof MessageFragment) messageFragment = (MessageFragment) f;
            else if (f instanceof ProfileFragment) profileFragment = (ProfileFragment) f;
        }

        // 按类型找当前 tab 对应的 Fragment 实例（不依赖 currentTab 的成员变量）
        Class<?> targetClass;
        switch (tab) {
            case TAB_HOME: targetClass = HomeFragment.class; break;
            case TAB_COMMUNITY: targetClass = CommunityFragment.class; break;
            case TAB_MESSAGE: targetClass = MessageFragment.class; break;
            case TAB_PROFILE: targetClass = ProfileFragment.class; break;
            default: return;
        }
        Fragment target = null;
        for (Fragment f : frags) {
            if (f != null && targetClass.isInstance(f)) { target = f; break; }
        }
        if (target == null) return; // 当前 tab 的 Fragment 尚未创建，不动

        // 强制隐藏所有非当前 tab 的 Fragment，并强制显示当前 tab 的 Fragment
        boolean changed = false;
        FragmentTransaction ft = fm.beginTransaction();
        for (Fragment f : frags) {
            if (f == null || f == target) continue;
            if (!f.isHidden()) { ft.hide(f); changed = true; }
            // ★ View 级兜底：即使 FragmentManager 的 isHidden 状态错乱，
            //   也强制把 view 设为 GONE（解决"我的"Fragment 盖住首页）
            if (f.getView() != null && f.getView().getVisibility() == View.VISIBLE) {
                f.getView().setVisibility(View.GONE);
            }
        }
        if (target.isHidden()) {
            ft.show(target);
            changed = true;
        }
        if (target.getView() != null && target.getView().getVisibility() != View.VISIBLE) {
            target.getView().setVisibility(View.VISIBLE);
        }
        if (changed) {
            ft.commitNowAllowingStateLoss();
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("current_tab", currentTab);
    }

    private int getNavResId(int tab) {
        switch (tab) {
            case TAB_COMMUNITY: return R.id.nav_community;
            case TAB_MESSAGE: return R.id.nav_message;
            case TAB_PROFILE: return R.id.nav_profile;
            default: return R.id.nav_home;
        }
    }

    @Override
    protected void onStop() {
        if (mainHandler != null) mainHandler.removeCallbacks(badgeRunnable);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        // 清理导航栏颜色变更监听，避免内存泄漏
        BottomNavBarColorManager.setListener(null);
        NavBarStyleManager.setListener(null);
        NavPostCenterManager.setListener(null);
        StatusBarColorManager.setListener(null);
        CardBorderManager.setListener(null);
        if (rainbowNavBackgroundCapsule != null) {
            rainbowNavBackgroundCapsule.setVisible(false, false);
        }
        if (rainbowNavBackgroundFullWidth != null) {
            rainbowNavBackgroundFullWidth.setVisible(false, false);
        }
        if (mainHandler != null) {
            mainHandler.removeCallbacksAndMessages(null);
        }
        if (executor != null) {
            executor.shutdownNow();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // 让已注册的 OnBackPressedCallback（如留言弹窗）优先处理
        if (getOnBackPressedDispatcher().hasEnabledCallbacks()) {
            super.onBackPressed();
            return;
        }
        // 不在首页时，返回键先回到首页
        if (currentTab != TAB_HOME) {
            navigateTo(R.id.nav_home);
            return;
        }
        // 首页时：首次返回提示，连续第二次返回才退出
        long now = System.currentTimeMillis();
        if (lastBackPressTime > 0 && now - lastBackPressTime < EXIT_INTERVAL_MS) {
            finishAffinity(); // 直接退出
            super.onBackPressed();
            return;
        }
        lastBackPressTime = now;
        Toast.makeText(this, "再按一次返回键退出", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        if (currentTab != TAB_HOME) {
            navigateTo(R.id.nav_home);
            return true;
        }
        return false;
    }
}