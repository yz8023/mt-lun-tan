package com.forum.MT.ui.post;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.ui.BaseActivity;
import com.forum.MT.ui.detail.ReplyAdapter;
import com.forum.MT.ui.widget.HomeBarColorManager;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PostPreviewActivity extends BaseActivity {

    public static final String EXTRA_TITLE = "preview_title";
    public static final String EXTRA_CONTENT = "preview_content";
    public static final String EXTRA_AUTHOR = "preview_author";

    private TextView tvTitle, tvContent, tvAuthorName, tvTime;
    private LinearLayout frameContent;
    private LinearLayout layoutContent;
    private int contentWidth;
    private int textColor;
    private float density;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_preview);

        String title = getIntent().getStringExtra(EXTRA_TITLE);
        String content = getIntent().getStringExtra(EXTRA_CONTENT);
        String author = getIntent().getStringExtra(EXTRA_AUTHOR);

        tvTitle = findViewById(R.id.tv_title);
        tvContent = findViewById(R.id.tv_content);
        tvAuthorName = findViewById(R.id.tv_author_name);
        tvTime = findViewById(R.id.tv_time);
        frameContent = findViewById(R.id.frame_content);
        layoutContent = findViewById(R.id.layout_content);

        density = getResources().getDisplayMetrics().density;
        contentWidth = getResources().getDisplayMetrics().widthPixels - (int) (density * 32);

        applyThemeColors();

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        if (title != null && !title.isEmpty()) {
            tvTitle.setText(title);
        } else {
            tvTitle.setVisibility(View.GONE);
        }

        tvAuthorName.setText((author != null && !author.isEmpty()) ? author : "我");
        tvTime.setText("刚刚");

        renderContent(content != null ? content : "");
    }

    private void applyThemeColors() {
        int topBg = HomeBarColorManager.resolveThreadTopBg();
        int threadBg = HomeBarColorManager.resolveThreadBg();

        findViewById(R.id.toolbar).setBackgroundColor(topBg);
        layoutContent.setBackgroundColor(threadBg);
        View root = findViewById(android.R.id.content);
        if (root != null) root.setBackgroundColor(threadBg);

        boolean isDark = isColorDark(threadBg);
        textColor = isDark ? 0xFFFFFFFF : 0xFF333333;
        int secondaryColor = isDark ? 0xCCFFFFFF : 0xFF999999;

        tvTitle.setTextColor(textColor);
        tvAuthorName.setTextColor(textColor);
        tvTime.setTextColor(secondaryColor);
        tvContent.setTextColor(textColor);
    }

    private static boolean isColorDark(int color) {
        double r = ((color >> 16) & 0xFF) / 255.0;
        double g = ((color >> 8) & 0xFF) / 255.0;
        double b = (color & 0xFF) / 255.0;
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 0.45;
    }

    /**
     * 渲染正文：按 <img> 标签拆分 HTML，
     * 文本段用 TextView + Html.fromHtml 渲染，
     * 图片段用独立 ImageView + Glide 加载，
     * 交替添加到 frameContent 容器中（和帖子页面一致）。
     */
    private void renderContent(String bbcode) {
        String html = bbcodeToHtml(bbcode);

        // 清空 frameContent（保留原始 tvContent 作为第一个文本段）
        frameContent.removeView(tvContent);

        // 按 <img> 标签拆分
        Pattern imgPattern = Pattern.compile(
                "<img\\s+[^>]*src=\"([^\"]+)\"[^>]*/?>",
                Pattern.CASE_INSENSITIVE);
        Matcher m = imgPattern.matcher(html);
        List<Object> segments = new ArrayList<>();
        int lastEnd = 0;
        while (m.find()) {
            if (m.start() > lastEnd) {
                segments.add(html.substring(lastEnd, m.start()));
            }
            segments.add(m.group(1)); // 图片 URL 字符串
            lastEnd = m.end();
        }
        if (lastEnd < html.length()) {
            segments.add(html.substring(lastEnd));
        }

        // 如果没有图片，直接用 tvContent 渲染整段
        boolean hasImage = false;
        for (Object seg : segments) {
            if (seg instanceof String && !((String) seg).isEmpty()) continue;
            if (!(seg instanceof String)) { hasImage = true; break; }
        }
        if (!hasImage) {
            // 全是文本，用 tvContent
            Spanned spanned = Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT, null, null);
            tvContent.setText(spanned);
            tvContent.setMovementMethod(LinkMovementMethod.getInstance());
            frameContent.addView(tvContent);
            return;
        }

        // 有图片，交替渲染
        for (Object seg : segments) {
            if (seg instanceof String) {
                String textSeg = (String) seg;
                if (textSeg.trim().isEmpty()) continue;
                TextView tv = new TextView(this);
                tv.setTextSize(15);
                tv.setTextColor(textColor);
                tv.setLineSpacing(density * 6, 1f);
                tv.setText(Html.fromHtml(textSeg, Html.FROM_HTML_MODE_COMPACT, null, null));
                tv.setMovementMethod(LinkMovementMethod.getInstance());
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.bottomMargin = (int) (density * 6);
                tv.setLayoutParams(lp);
                frameContent.addView(tv);
            } else {
                // 图片段
                String imgUrl = (String) seg;
                addImageView(imgUrl);
            }
        }
    }

    /** 添加一个 ImageView 到内容区，用 Glide + buildForumImageRequest 加载。 */
    private void addImageView(String imgUrl) {
        String fullUrl = imgUrl;
        if (fullUrl.startsWith("//")) fullUrl = "https:" + fullUrl;
        else if (fullUrl.startsWith("/") && !fullUrl.startsWith("//"))
            fullUrl = "https://bbs.binmt.cc/" + fullUrl.substring(1);

        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = (int) (density * 8);
        lp.topMargin = (int) (density * 4);
        imageView.setLayoutParams(lp);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setBackgroundColor(0xFFF5F5F5);
        // 设置最大高度，避免超长图占满屏幕
        imageView.setMaxHeight((int) (contentWidth * 1.5));

        Glide.with(this)
                .load(ReplyAdapter.buildForumImageRequest(fullUrl))
                .placeholder(new android.graphics.drawable.ColorDrawable(0xFFF0F0F0))
                .timeout(15000)
                .into(imageView);

        frameContent.addView(imageView);
    }

    static String bbcodeToHtml(String bbcode) {
        if (bbcode == null || bbcode.isEmpty()) return "";
        String s = bbcode;
        s = s.replace("\r\n", "\n").replace("\r", "\n");
        s = s.replace("\n", "<br>");
        s = s.replaceAll("(?i)\\[b\\]", "<b>");
        s = s.replaceAll("(?i)\\[/b\\]", "</b>");
        s = s.replaceAll("(?i)\\[i\\]", "<i>");
        s = s.replaceAll("(?i)\\[/i\\]", "</i>");
        s = s.replaceAll("(?i)\\[u\\]", "<u>");
        s = s.replaceAll("(?i)\\[/u\\]", "</u>");
        s = s.replaceAll("(?i)\\[s\\]", "<s>");
        s = s.replaceAll("(?i)\\[/s\\]", "</s>");
        s = s.replaceAll("(?i)\\[del\\]", "<s>");
        s = s.replaceAll("(?i)\\[/del\\]", "</s>");
        s = s.replaceAll("(?i)\\[color=([^\\]]+)\\]", "<font color=\"$1\">");
        s = s.replaceAll("(?i)\\[/color\\]", "</font>");
        s = s.replaceAll("(?i)\\[size=([^\\]]+)\\]", "<font size=\"$1\">");
        s = s.replaceAll("(?i)\\[/size\\]", "</font>");
        s = s.replaceAll("(?i)\\[url=([^\\]]+)\\](.*?)\\[/url\\]", "<a href=\"$1\">$2</a>");
        s = s.replaceAll("(?i)\\[url\\](.*?)\\[/url\\]", "<a href=\"$1\">$1</a>");
        s = s.replaceAll("(?i)\\[img(?:=[^\\]]*)?\\]\\s*([^\\[\\]]+?)\\s*\\[/img\\]", "<img src=\"$1\">");
        s = s.replaceAll("(?i)\\[attachimg\\](\\d+)\\[/attachimg\\]", "<img src=\"https://bbs.binmt.cc/forum.php?mod=image&aid=$1&size=300x300&nocache=1\">");
        s = s.replaceAll("(?i)\\[quote\\]", "<blockquote>");
        s = s.replaceAll("(?i)\\[/quote\\]", "</blockquote>");
        s = s.replaceAll("(?i)\\[code\\]", "<pre><tt>");
        s = s.replaceAll("(?i)\\[/code\\]", "</tt></pre>");
        s = s.replaceAll("(?i)\\[/?(?:free|hide)(?:=[^\\]]+)?\\]", "");
        s = s.replaceAll("(?i)\\[list\\]", "<ul>");
        s = s.replaceAll("(?i)\\[/list\\]", "</ul>");
        s = s.replaceAll("(?i)\\[\\*\\]", "<li>");
        s = s.replaceAll("(?i)\\[align=([^\\]]+)\\]", "<div align=\"$1\">");
        s = s.replaceAll("(?i)\\[/align\\]", "</div>");
        s = s.replace("[hr]", "<hr>");
        s = s.replaceAll("(?i)\\[table\\]", "<table border=\"1\">");
        s = s.replaceAll("(?i)\\[/table\\]", "</table>");
        s = s.replaceAll("(?i)\\[tr\\]", "<tr>");
        s = s.replaceAll("(?i)\\[/tr\\]", "</tr>");
        s = s.replaceAll("(?i)\\[td\\]", "<td>");
        s = s.replaceAll("(?i)\\[/td\\]", "</td>");
        s = s.replaceAll("(?i)\\[mention\\](.*?)\\[/mention\\]", "@$1");
        s = s.replaceAll("(?i)\\[/?(?:font|backcolor|float|indent|sup|sub|spoiler)(?:=[^\\]]+)?\\]", "");
        return s;
    }
}
