package com.forum.MT.ui.history;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.forum.MT.R;
import com.forum.MT.adapter.BrowseHistoryAdapter;
import com.forum.MT.databinding.ActivityBrowseHistoryBinding;
import com.forum.MT.model.BrowseHistory;
import com.forum.MT.storage.HistoryStore;
import com.forum.MT.ui.BaseActivity;
import com.forum.MT.ui.detail.ThreadDetailActivity;
import com.forum.MT.ui.widget.AccentColorManager;

import java.util.List;

/**
 * 浏览历史页面。
 *
 * <p>数据全部来自本地 {@link HistoryStore}，无需网络请求。
 * 点击条目跳转帖子详情；长按可删除单条；Toolbar 可清空全部。
 */
public class BrowseHistoryActivity extends BaseActivity {

    private ActivityBrowseHistoryBinding binding;
    private BrowseHistoryAdapter adapter;
    private HistoryStore store;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBrowseHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        // 强调色 Toolbar
        try {
            int accent = AccentColorManager.resolveAccentColor();
            binding.toolbar.setBackgroundColor(accent);
            binding.toolbar.setTitleTextColor(0xFFFFFFFF);
            binding.toolbar.setNavigationIconTint(0xFFFFFFFF);
        } catch (Exception ignored) {
        }

        store = new HistoryStore(this);

        adapter = new BrowseHistoryAdapter(this);
        adapter.setOnItemClickListener(item -> {
            if (item.getTid() != null) {
                Intent intent = new Intent(this, ThreadDetailActivity.class);
                intent.putExtra("tid", item.getTid());
                startActivity(intent);
            }
        });
        adapter.setOnItemLongClickListener((item, position) -> showDeleteDialog(item, position));
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);

        // SwipeRefresh（本地数据刷新）
        binding.swipeRefresh.setOnRefreshListener(this::loadData);
        binding.swipeRefresh.setColorSchemeResources(R.color.primary);

        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 从帖子详情返回后刷新列表（可能新增了浏览记录）
        loadData();
    }

    private void loadData() {
        List<BrowseHistory> list = store.getAll();
        adapter.setItems(list);
        binding.swipeRefresh.setRefreshing(false);
        if (list.isEmpty()) {
            binding.recyclerView.setVisibility(View.GONE);
            binding.tvEmpty.setVisibility(View.VISIBLE);
        } else {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.tvEmpty.setVisibility(View.GONE);
        }
    }

    private void showDeleteDialog(BrowseHistory item, int position) {
        new AlertDialog.Builder(this)
                .setTitle("删除记录")
                .setMessage("确定删除这条浏览记录？")
                .setPositiveButton("删除", (d, w) -> {
                    store.remove(item.getTid());
                    adapter.removeItem(position);
                    if (adapter.getItemCount() == 0) {
                        binding.recyclerView.setVisibility(View.GONE);
                        binding.tvEmpty.setVisibility(View.VISIBLE);
                    }
                    Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        menu.add(0, 1, 0, "清空").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == 1) {
            if (adapter.getItemCount() == 0) {
                Toast.makeText(this, "暂无记录可清空", Toast.LENGTH_SHORT).show();
                return true;
            }
            new AlertDialog.Builder(this)
                    .setTitle("清空历史")
                    .setMessage("确定清空全部浏览历史？")
                    .setPositiveButton("清空", (d, w) -> {
                        store.clear();
                        adapter.setItems(null);
                        binding.recyclerView.setVisibility(View.GONE);
                        binding.tvEmpty.setVisibility(View.VISIBLE);
                        Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
