package com.forum.MT.ui.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Spanned;
import android.text.style.ImageSpan;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 动画表情加载器。
 *
 * <p>存在的原因：项目内置的 256 个 {@code smiley_*} drawable 全部是静态 PNG，
 * 而论坛 CDN 上 QQ 分类的表情（{@code /smiley/qq/qqNNN.gif}）是多帧 GIF。
 * 只查本地资源就只能拿到一张静止的图，表情永远不会动。贴吧（{@code comiis_tb/tb_N.png}）
 * 与狗头（{@code doge/N.png}）在服务端本身就是静态 PNG，无需走这里。
 *
 * <p>渲染策略是"先静后动"：先用本地静态 PNG 立即占位（不闪、不留空洞），
 * 同时异步取 GIF 字节并解码成动画 Drawable，就绪后原地替换并启动。
 * 占位与动图使用同一个固定尺寸的边界，替换时不会触发重排。
 *
 * <p>为什么每个表情都单独解码一份：{@code AnimatedImageDrawable} 与 Glide 的
 * {@code GifDrawable} 都带有可变的播放状态，多个 ImageSpan 共用同一个实例会串帧，
 * 而且 {@link Drawable#setCallback} 只能挂一个宿主 View，共用会让除最后一个之外的
 * 所有宿主收不到重绘通知。字节缓存共享、解码结果不共享。
 */
public final class AnimatedSmileyLoader {

    /** GIF 原始字节缓存。表情体积很小（约 1~6KB），全量缓存代价可以接受。 */
    private static final ConcurrentHashMap<String, byte[]> sBytesCache =
            new ConcurrentHashMap<>();
    /** 确认过没有动图版本的 URL，避免反复发起注定失败的请求。 */
    private static final ConcurrentHashMap<String, Boolean> sMissing =
            new ConcurrentHashMap<>();

    /**
     * 单线程队列。表情解码很轻，但同一条消息里可能有十几个表情，
     * 串行处理可以避免瞬间占满 Glide 的线程池影响头像加载。
     */
    private static final ExecutorService sExecutor =
            Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "smiley-gif");
                t.setPriority(Thread.MIN_PRIORITY);
                return t;
            });

    private static final Handler sMain = new Handler(Looper.getMainLooper());

    private AnimatedSmileyLoader() {}

    /**
     * 取一个可替换内容的表情 Drawable。
     *
     * <p>返回值立即可用（内容为 {@code placeholder}）。若 {@code gifUrl} 指向动图，
     * 会在后台解码完成后自动换成动画并开始播放。
     *
     * @param gifUrl      动图 URL；为 null 表示该表情没有动图版本，直接返回占位
     * @param placeholder 本地静态图，可为 null
     * @param size        表情边长（px），占位与动图统一使用
     * @param host        宿主 TextView，用于动画帧的重绘调度
     */
    @Nullable
    public static Drawable obtain(@NonNull Context context, @Nullable String gifUrl,
                                  @Nullable Drawable placeholder, int size,
                                  @NonNull TextView host) {
        if (placeholder == null && gifUrl == null) return null;
        SwappableDrawable wrapper = new SwappableDrawable(placeholder, size);
        if (gifUrl == null || sMissing.containsKey(gifUrl)) return wrapper;

        final Context appContext = context.getApplicationContext();
        final String url = gifUrl;
        byte[] cached = sBytesCache.get(url);
        if (cached != null) {
            // 字节已缓存：仍放到后台解码，避免在 bind 里做同步解码拖慢滚动。
            sExecutor.execute(() -> decodeAndSwap(appContext, url, cached, wrapper, size, host));
            return wrapper;
        }
        sExecutor.execute(() -> {
            byte[] bytes = fetchBytes(appContext, url);
            if (bytes == null) {
                sMissing.put(url, Boolean.TRUE);
                return;
            }
            decodeAndSwap(appContext, url, bytes, wrapper, size, host);
        });
        return wrapper;
    }

    /** 取 GIF 字节：走 Glide 的磁盘缓存，所以只有首次会真正联网。 */
    @Nullable
    private static byte[] fetchBytes(Context context, String url) {
        try {
            java.io.File file = com.bumptech.glide.Glide.with(context)
                    .asFile()
                    .load(url)
                    .submit()
                    .get();
            if (file == null || !file.exists()) return null;
            byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
            if (bytes == null || bytes.length == 0) return null;
            // 单帧 GIF 没有动画价值，标记为"无动图"省掉后续解码。
            if (countFrames(bytes) <= 1) return null;
            sBytesCache.put(url, bytes);
            return bytes;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 粗略数 GIF 帧数：统计图形控制扩展块（{@code 00 21 F9 04}）出现次数。
     * 只用于区分"单帧"和"多帧"，不要求精确。
     */
    private static int countFrames(byte[] bytes) {
        int count = 0;
        for (int i = 0; i + 3 < bytes.length; i++) {
            if (bytes[i] == 0x00 && (bytes[i + 1] & 0xFF) == 0x21
                    && (bytes[i + 2] & 0xFF) == 0xF9 && bytes[i + 3] == 0x04) {
                count++;
                if (count > 1) return count;
            }
        }
        return count;
    }

    private static void decodeAndSwap(Context context, String url, byte[] bytes,
                                      SwappableDrawable wrapper, int size, TextView host) {
        Drawable animated = decode(context, url, bytes, size);
        if (animated == null) {
            sMissing.put(url, Boolean.TRUE);
            return;
        }
        sMain.post(() -> {
            // 宿主可能已被 RecyclerView 回收并重新绑定到另一条消息，
            // 此时这个 wrapper 已不在 TextView 的文本里，替换毫无意义还会浪费重绘。
            if (!isStillAttached(host, wrapper)) return;
            wrapper.swap(animated);
            startAnimation(animated, host);
            host.invalidate();
        });
    }

    /** wrapper 是否仍挂在宿主的当前文本上。 */
    private static boolean isStillAttached(TextView host, SwappableDrawable wrapper) {
        CharSequence text = host.getText();
        if (!(text instanceof Spanned)) return false;
        Spanned spanned = (Spanned) text;
        ImageSpan[] spans = spanned.getSpans(0, spanned.length(), ImageSpan.class);
        for (ImageSpan span : spans) {
            if (span.getDrawable() == wrapper) return true;
        }
        return false;
    }

    /**
     * 解码出一个独立的动画 Drawable。
     *
     * <p>优先用原生 {@code ImageDecoder}（API 28+）：它产出的
     * {@code AnimatedImageDrawable} 不共享任何解码状态。低版本退回 Glide.asGif，
     * 并用唯一 signature + 跳过内存缓存保证拿到独立实例。
     */
    @Nullable
    private static Drawable decode(Context context, String url, byte[] bytes, int size) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                // ImageDecoder 会消耗 ByteBuffer，必须给它一份私有副本，
                // 否则缓存里的字节数组被反复包装时位置指针会串。
                byte[] copy = Arrays.copyOf(bytes, bytes.length);
                Drawable decoded = android.graphics.ImageDecoder.decodeDrawable(
                        android.graphics.ImageDecoder.createSource(ByteBuffer.wrap(copy)),
                        (decoder, info, source) -> decoder.setTargetSize(size, size));
                if (decoded != null) {
                    decoded.setBounds(0, 0, size, size);
                    return decoded;
                }
            } catch (Exception ignored) {
            }
        }
        try {
            byte[] copy = Arrays.copyOf(bytes, bytes.length);
            Drawable fresh = com.bumptech.glide.Glide.with(context)
                    .asGif()
                    .load(copy)
                    .skipMemoryCache(true)
                    .diskCacheStrategy(
                            com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                    .signature(new com.bumptech.glide.signature.ObjectKey(
                            url + "#" + System.nanoTime()))
                    .submit()
                    .get();
            if (fresh != null) {
                fresh.setBounds(0, 0, size, size);
                return fresh;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /**
     * 启动动画。
     *
     * <p>关键点：{@code TextView.verifyDrawable()} 只认 compound drawable，
     * 不认 ImageSpan 里的 drawable，所以动画帧调用
     * {@code invalidateSelf()} 时宿主不会重绘，表情看着就是静止的。
     * 这里挂一个自定义 Callback 直接调 {@code host.invalidate()} 绕过该限制。
     */
    private static void startAnimation(Drawable drawable, TextView host) {
        drawable.setCallback(new Drawable.Callback() {
            @Override
            public void invalidateDrawable(@NonNull Drawable who) {
                host.invalidate();
            }

            @Override
            public void scheduleDrawable(@NonNull Drawable who,
                                         @NonNull Runnable what, long when) {
                host.postDelayed(what, Math.max(0L, when - android.os.SystemClock.uptimeMillis()));
            }

            @Override
            public void unscheduleDrawable(@NonNull Drawable who, @NonNull Runnable what) {
                host.removeCallbacks(what);
            }
        });
        try {
            drawable.setVisible(true, false);
        } catch (Exception ignored) {
        }
        if (drawable instanceof Animatable) {
            Animatable animatable = (Animatable) drawable;
            if (drawable instanceof android.graphics.drawable.AnimatedImageDrawable) {
                // 无限循环，否则默认只播放 GIF 头里声明的次数，播完就停住。
                ((android.graphics.drawable.AnimatedImageDrawable) drawable)
                        .setRepeatCount(
                                android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE);
            }
            animatable.start();
        }
    }

    /**
     * 内容可替换的固定尺寸 Drawable。
     *
     * <p>{@link ImageSpan} 在构造时就把 Drawable 存下来且不提供替换入口，
     * 因此"先静后动"必须靠这一层间接：span 始终持有 wrapper，
     * 动图就绪后只换 wrapper 内部的实际内容。尺寸恒定，所以替换不影响文本布局。
     */
    private static final class SwappableDrawable extends Drawable {
        @Nullable private Drawable current;
        private final int size;

        SwappableDrawable(@Nullable Drawable initial, int size) {
            this.size = size;
            this.current = initial;
            setBounds(0, 0, size, size);
            if (initial != null) initial.setBounds(0, 0, size, size);
        }

        void swap(@NonNull Drawable next) {
            Drawable previous = current;
            if (previous instanceof Animatable) {
                try { ((Animatable) previous).stop(); } catch (Exception ignored) {}
                previous.setCallback(null);
            }
            next.setBounds(0, 0, size, size);
            current = next;
            invalidateSelf();
        }

        @Override
        public void draw(@NonNull Canvas canvas) {
            if (current != null) current.draw(canvas);
        }

        @Override
        public void setBounds(int left, int top, int right, int bottom) {
            super.setBounds(left, top, right, bottom);
            if (current != null) current.setBounds(left, top, right, bottom);
        }

        @Override
        public void setBounds(@NonNull Rect bounds) {
            setBounds(bounds.left, bounds.top, bounds.right, bounds.bottom);
        }

        @Override
        public int getIntrinsicWidth() { return size; }

        @Override
        public int getIntrinsicHeight() { return size; }

        @Override
        public void setAlpha(int alpha) {
            if (current != null) current.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(@Nullable ColorFilter colorFilter) {
            if (current != null) current.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }
}
