package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

/**
 * 帖子列表项右上角「板块标签」与「关注」按钮颜色自定义管理。
 *
 * 用户可在主题设置页为帖子列表中的板块标签（如"逆向交流""综合交流"等）
 * 和「关注」按钮分别设置独立的背景颜色。
 *
 * 颜色值为 0 时表示使用默认样式。
 *
 * 偏好键：
 *   thread_tag_bg    (int)  — 板块标签背景色
 *   thread_follow_bg (int)  — 关注按钮背景色
 */
public final class ThreadTagColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_TAG_BG = "thread_tag_bg";
    public static final String KEY_FOLLOW_BG = "thread_follow_bg";

    /** 默认板块标签背景色 #E0F7FA */
    public static final int DEFAULT_TAG_BG = Color.rgb(0xE0, 0xF7, 0xFA);
    /** 默认关注按钮背景色 #F3E5F5 */
    public static final int DEFAULT_FOLLOW_BG = Color.rgb(0xF3, 0xE5, 0xF5);

    private static volatile int tagBg = 0;
    private static volatile int followBg = 0;

    private static volatile Runnable listener;

    private ThreadTagColorManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        tagBg = prefs.getInt(KEY_TAG_BG, 0);
        followBg = prefs.getInt(KEY_FOLLOW_BG, 0);
    }

    // ========== 板块标签背景 ==========

    public static int getTagBg() {
        return tagBg;
    }

    public static void setTagBg(Context context, int color) {
        tagBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_TAG_BG, color).apply();
        }
        notifyListener();
    }

    public static int resolveTagBg() {
        return tagBg != 0 ? tagBg : DEFAULT_TAG_BG;
    }

    // ========== 关注按钮背景 ==========

    public static int getFollowBg() {
        return followBg;
    }

    public static void setFollowBg(Context context, int color) {
        followBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_FOLLOW_BG, color).apply();
        }
        notifyListener();
    }

    public static int resolveFollowBg() {
        return followBg != 0 ? followBg : DEFAULT_FOLLOW_BG;
    }

    // ========== 工具方法 ==========

    /**
     * 为板块标签 View 应用背景色（保留圆角形状）。
     */
    public static void applyTagBg(View view) {
        applyBg(view, resolveTagBg(), 12f);
    }

    /**
     * 为关注按钮 View 应用背景色（保留圆角形状）。
     */
    public static void applyFollowBg(View view) {
        applyBg(view, resolveFollowBg(), 18f);
    }

    private static void applyBg(View view, int color, float cornerRadiusDp) {
        if (view == null) return;
        float density = view.getResources().getDisplayMetrics().density;
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setColor(color);
        gd.setCornerRadius(cornerRadiusDp * density);
        view.setBackground(gd);
    }

    /**
     * 根据背景亮度判断应使用深色还是浅色文字。
     */
    public static int textColorForBg(int bgColor) {
        double r = Color.red(bgColor) / 255.0;
        double g = Color.green(bgColor) / 255.0;
        double b = Color.blue(bgColor) / 255.0;
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.5 ? 0xFF333333 : 0xFFFFFFFF;
    }

    // ========== 监听器 ==========

    public static void setListener(Runnable r) {
        listener = r;
    }

    private static void notifyListener() {
        Runnable r = listener;
        if (r != null) r.run();
    }
}