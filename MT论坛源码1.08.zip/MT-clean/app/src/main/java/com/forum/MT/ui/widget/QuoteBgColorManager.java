package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理引用内容卡片样式颜色的设置：
 * 背景色、边框色、标题文字色、正文文字色。
 * 颜色为 0 表示使用默认值。
 */
public class QuoteBgColorManager {

    private static final String PREFS_NAME = "mt_forum_prefs";
    private static final String KEY_QUOTE_BG_COLOR    = "quote_bg_color";
    private static final String KEY_QUOTE_BORDER_COLOR = "quote_border_color";
    private static final String KEY_QUOTE_TITLE_COLOR = "quote_title_color";
    private static final String KEY_QUOTE_TEXT_COLOR  = "quote_text_color";

    /** 默认引用卡片背景（浅绿） */
    public static final int DEFAULT_BG_COLOR    = 0xFFF0FDFA;
    /** 默认引用卡片边框（青绿） */
    public static final int DEFAULT_BORDER_COLOR = 0xFF2DD4BF;
    /** 默认引用标题文字颜色（深青） */
    public static final int DEFAULT_TITLE_COLOR = 0xFF0F766E;
    /** 默认引用正文文字颜色（深蓝黑） */
    public static final int DEFAULT_TEXT_COLOR  = 0xFF1A1A2E;

    private QuoteBgColorManager() {}

    // ==================== 背景色 ====================

    public static int getBgColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_QUOTE_BG_COLOR, 0);
    }

    public static int resolveBgColor(Context context) {
        int color = getBgColor(context);
        return color != 0 ? color : DEFAULT_BG_COLOR;
    }

    public static void setBgColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_QUOTE_BG_COLOR, color).apply();
    }

    // ==================== 边框色 ====================

    public static int getBorderColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_QUOTE_BORDER_COLOR, 0);
    }

    public static int resolveBorderColor(Context context) {
        int color = getBorderColor(context);
        return color != 0 ? color : DEFAULT_BORDER_COLOR;
    }

    public static void setBorderColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_QUOTE_BORDER_COLOR, color).apply();
    }

    // ==================== 标题文字色 ====================

    public static int getTitleColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_QUOTE_TITLE_COLOR, 0);
    }

    public static int resolveTitleColor(Context context) {
        int color = getTitleColor(context);
        return color != 0 ? color : DEFAULT_TITLE_COLOR;
    }

    public static void setTitleColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_QUOTE_TITLE_COLOR, color).apply();
    }

    // ==================== 正文文字色 ====================

    public static int getTextColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_QUOTE_TEXT_COLOR, 0);
    }

    public static int resolveTextColor(Context context) {
        int color = getTextColor(context);
        return color != 0 ? color : DEFAULT_TEXT_COLOR;
    }

    public static void setTextColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_QUOTE_TEXT_COLOR, color).apply();
    }
}