package com.forum.MT;

import android.app.Application;

import com.forum.MT.network.HttpClient;
import com.forum.MT.ui.widget.RainbowBorderDrawable;

/**
 * 全局 Application 类
 * 在所有 Activity 启动前完成初始化，确保登录态 Cookie 从磁盘恢复
 */
public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // 恢复持久化的流水灯开关，未设置时默认开启
        com.forum.MT.ui.widget.RainbowBorderDrawable.initialize(this);

        // 恢复评论描边边框偏好
        com.forum.MT.ui.widget.CommentBorderDrawable.initialize(this);

        // 恢复板块卡片自定义颜色
        com.forum.MT.ui.widget.ForumCardColorManager.initialize(this);

        // 恢复卡片边框效果偏好
        com.forum.MT.ui.widget.CardBorderManager.initialize(this);

        // 恢复内容卡片自定义颜色
        com.forum.MT.ui.widget.CardColorManager.initialize(this);

        // 恢复底部导航栏自定义颜色
        com.forum.MT.ui.widget.BottomNavBarColorManager.initialize(this);
        com.forum.MT.ui.widget.NavBarStyleManager.initialize(this);
        com.forum.MT.ui.widget.NavPostCenterManager.initialize(this);

        // 恢复首页内容栏左右滑动开关
        com.forum.MT.ui.widget.HomeTabSwipeManager.initialize(this);

        // 恢复全局强调色（选中/高亮文字）
        com.forum.MT.ui.widget.AccentColorManager.initialize(this);

        // 恢复投票进度条自定义颜色
        com.forum.MT.ui.widget.PollBarColorManager.initialize(this);

        // 恢复全局背景自定义颜色
        com.forum.MT.ui.widget.BackgroundColorManager.initialize(this);

        // 恢复首页标题颜色
        com.forum.MT.ui.widget.TitleColorManager.initialize(this);

        // 恢复状态栏颜色
        com.forum.MT.ui.widget.StatusBarColorManager.initialize(this);

        // 恢复首页标题栏与分类栏背景颜色
        com.forum.MT.ui.widget.HomeBarColorManager.initialize(this);

        // 恢复帖子板块标签与关注按钮自定义颜色
        com.forum.MT.ui.widget.ThreadTagColorManager.initialize(this);

        // 恢复「隐藏带回收站的帖子」设置
        com.forum.MT.ui.widget.RecycleFilterManager.initialize(this);

        // 帖子正文强制默认颜色
        com.forum.MT.ui.widget.ForceDefaultTextColorManager.initialize(this);

        // 恢复持久化的 Cookie —— 在任何 Activity 启动前执行
        // 防止从最近任务直接恢复 SearchActivity 等非 MainActivity 时登录态丢失
        HttpClient.getInstance().init(this);

        // MCP 默认关闭；只有用户在设置中明确开启后才启动本机只读服务。
        com.forum.MT.mcp.McpServerManager.getInstance(this).start();
    }
}