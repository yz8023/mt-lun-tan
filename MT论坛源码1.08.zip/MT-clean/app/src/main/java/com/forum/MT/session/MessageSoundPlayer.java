package com.forum.MT.session;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.forum.MT.R;

/** 消息接收提示音播放器。 */
public final class MessageSoundPlayer {
    private static final String TAG = "MessageSoundPlayer";
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static final Object LOCK = new Object();
    private static MediaPlayer activePlayer;

    private MessageSoundPlayer() {}

    public static void playPrivateChat(Context context) {
        play(context, R.raw.private_chat_message);
    }

    public static void playNotice(Context context) {
        play(context, R.raw.notice_message);
    }

    private static void play(Context context, int resourceId) {
        if (context == null) return;
        // 检查提示音全局开关，关闭则不播放
        if (!SoundSettingsManager.isSoundEnabled(context)) return;
        Context appContext = context.getApplicationContext();
        MAIN_HANDLER.post(() -> {
            synchronized (LOCK) {
                releaseActivePlayer();
                try {
                    MediaPlayer player = MediaPlayer.create(appContext, resourceId);
                    if (player == null) return;
                    player.setVolume(1.0f, 1.0f);
                    activePlayer = player;
                    player.setOnCompletionListener(mp -> {
                        synchronized (LOCK) {
                            if (activePlayer == mp) activePlayer = null;
                        }
                        mp.release();
                    });
                    player.setOnErrorListener((mp, what, extra) -> {
                        Log.e(TAG, "message sound error: " + what + ", " + extra);
                        synchronized (LOCK) {
                            if (activePlayer == mp) activePlayer = null;
                        }
                        mp.release();
                        return true;
                    });
                    player.start();
                } catch (Exception e) {
                    Log.e(TAG, "Unable to play message sound", e);
                    releaseActivePlayer();
                }
            }
        });
    }

    private static void releaseActivePlayer() {
        if (activePlayer == null) return;
        try {
            if (activePlayer.isPlaying()) activePlayer.stop();
        } catch (Exception ignored) {}
        try {
            activePlayer.release();
        } catch (Exception ignored) {}
        activePlayer = null;
    }
}
