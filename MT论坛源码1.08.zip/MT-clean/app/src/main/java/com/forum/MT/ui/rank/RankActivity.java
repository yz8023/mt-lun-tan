package com.forum.MT.ui.rank;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.forum.MT.R;
import com.forum.MT.adapter.RankAdapter;
import com.forum.MT.databinding.ActivityRankBinding;
import com.forum.MT.model.RankThread;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.ui.BaseActivity;
import com.forum.MT.ui.detail.ThreadDetailActivity;
import com.forum.MT.ui.space.UserProfileActivity;
import com.forum.MT.ui.widget.AccentColorManager;

import java.util.List;

/**
 * 热帖排行榜页面。
 *
 * <p>数据来自 {@code misc.php?mod=ranklist&type=thread}，两个维度组合：
 * 榜单类型（热度/人气/回复/收藏）× 时间范围（24小时/7天/30天/全部）。
 * 时间范围是滚动窗口而非自然日历周期：论坛页面上这几个入口自带的 id 就是窗口秒数
 * （today=86400、thisweek=604800、thismonth=2592000），实测返回的最早帖子时间正好
 * 落在"当前时间往前推该秒数"的边界上，所以不存在零点清零。
 * 论坛该页面每次固定返回 20 条且无分页参数，因此不做翻页，只支持下拉刷新。
 *
 * <p>该页面无需登录即可访问（实测匿名请求可正常返回榜单），
 * 所以拿到登录页时只提示、不强制跳登录，避免游客状态下无法查看。
 */
public class RankActivity extends BaseActivity {

    /** 默认展示热度榜 30 天窗口：样本量更大，排名比 24 小时窗口更稳定。 */
    private static final String DEFAULT_VIEW = "heats";
    private static final String DEFAULT_RANGE = "thismonth";

    private ActivityRankBinding binding;
    private HttpClient httpClient;
    private RankAdapter adapter;

    private String currentView = DEFAULT_VIEW;
    private String currentRange = DEFAULT_RANGE;

    /** 请求序号：切换筛选时旧请求的回包必须丢弃，否则慢响应会覆盖新榜单。 */
    private int requestSeq;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRankBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        httpClient = HttpClient.getInstance();

        binding.toolbar.setTitle(R.string.rank_title);
        binding.toolbar.setNavigationIcon(null);
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        adapter = new RankAdapter(this);
        adapter.setOnItemClickListener(item -> {
            if (item == null || TextUtils.isEmpty(item.getTid())) return;
            Intent intent = new Intent(this, ThreadDetailActivity.class);
            intent.putExtra("tid", item.getTid());
            startActivity(intent);
        });
        adapter.setOnAuthorClickListener(item -> {
            if (item == null || TextUtils.isEmpty(item.getAuthorUid())) return;
            Intent intent = new Intent(this, UserProfileActivity.class);
            intent.putExtra("uid", item.getAuthorUid());
            intent.putExtra("username", item.getAuthor());
            startActivity(intent);
        });

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);

        binding.swipeRefresh.setOnRefreshListener(this::loadData);
        binding.swipeRefresh.setColorSchemeResources(R.color.primary);

        binding.btnViewHeats.setOnClickListener(v -> switchView("heats"));
        binding.btnViewViews.setOnClickListener(v -> switchView("views"));
        binding.btnViewReplies.setOnClickListener(v -> switchView("replies"));
        binding.btnViewFavtimes.setOnClickListener(v -> switchView("favtimes"));

        binding.btnRangeToday.setOnClickListener(v -> switchRange("today"));
        binding.btnRangeWeek.setOnClickListener(v -> switchRange("thisweek"));
        binding.btnRangeMonth.setOnClickListener(v -> switchRange("thismonth"));
        binding.btnRangeAll.setOnClickListener(v -> switchRange("all"));

        updateChips();
        loadData();
    }

    private void switchView(String view) {
        if (view.equals(currentView)) return;
        currentView = view;
        updateChips();
        loadData();
    }

    private void switchRange(String range) {
        if (range.equals(currentRange)) return;
        currentRange = range;
        updateChips();
        loadData();
    }

    /** 同步两组筛选按钮的选中样式。选中态跟随用户自定义强调色。 */
    private void updateChips() {
        applyChipStyle(binding.btnViewHeats, "heats".equals(currentView));
        applyChipStyle(binding.btnViewViews, "views".equals(currentView));
        applyChipStyle(binding.btnViewReplies, "replies".equals(currentView));
        applyChipStyle(binding.btnViewFavtimes, "favtimes".equals(currentView));

        applyChipStyle(binding.btnRangeToday, "today".equals(currentRange));
        applyChipStyle(binding.btnRangeWeek, "thisweek".equals(currentRange));
        applyChipStyle(binding.btnRangeMonth, "thismonth".equals(currentRange));
        applyChipStyle(binding.btnRangeAll, "all".equals(currentRange));
    }

    private void applyChipStyle(TextView chip, boolean active) {
        chip.setBackgroundResource(active ? R.drawable.chip_active_bg : R.drawable.chip_inactive_bg);
        chip.setBackgroundTintList(active
                ? ColorStateList.valueOf(AccentColorManager.resolveAccentColor()) : null);
        chip.setTextColor(ContextCompat.getColor(this,
                active ? R.color.text_white : R.color.text_hint));
    }

    private void loadData() {
        final int seq = ++requestSeq;
        final String view = currentView;
        final String range = currentRange;

        binding.tvEmpty.setVisibility(View.GONE);
        if (!binding.swipeRefresh.isRefreshing()) {
            binding.progressBar.setVisibility(View.VISIBLE);
        }

        new Thread(() -> {
            List<RankThread> items = null;
            boolean loginPage = false;
            try {
                String html = httpClient.get(ForumParser.getThreadRanklistUrl(view, range));
                if (ForumParser.isLoginPage(html)) {
                    loginPage = true;
                } else {
                    items = ForumParser.parseThreadRanklist(html);
                }
            } catch (Exception ignored) {
                // 网络异常与解析空结果都走"失败提示"分支，交给下拉重试
            }

            final List<RankThread> result = items;
            final boolean needLogin = loginPage;
            runOnUiThread(() -> {
                if (isDestroyed() || isFinishing()) return;
                // 丢弃过期请求：用户已切到别的榜单
                if (seq != requestSeq) return;

                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);

                if (result != null && !result.isEmpty()) {
                    adapter.setItems(result);
                    binding.tvEmpty.setVisibility(View.GONE);
                    binding.recyclerView.scrollToPosition(0);
                    return;
                }

                adapter.setItems(null);
                binding.tvEmpty.setVisibility(View.VISIBLE);
                if (needLogin) {
                    binding.tvEmpty.setText(R.string.rank_load_failed);
                } else if (result != null) {
                    // 请求成功但榜单为空（如 24 小时窗口内尚无数据）
                    binding.tvEmpty.setText(R.string.rank_empty);
                } else {
                    binding.tvEmpty.setText(R.string.rank_load_failed);
                }
            });
        }).start();
    }
}
