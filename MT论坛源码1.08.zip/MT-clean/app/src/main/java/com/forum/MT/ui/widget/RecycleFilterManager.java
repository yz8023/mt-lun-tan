package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理「隐藏带回收站的帖子」设置。
 *
 * <p>MT 论坛的帖子被版主移入回收站后，模板仍会在「我的主题」「收藏」「版块列表」
 * 等列表里输出该帖，只是在标题前多一个「回收站」标记（本 App 解析为
 * {@link com.forum.MT.model.Thread#isRecycled()} 并渲染成红框徽章）。
 * 这类帖子点进去多半只剩「主题不存在或已被删除」的提示，对普通浏览是噪音。
 *
 * <p>开启本开关后，帖子列表在装配数据时直接剔除已回收的帖子。开关默认关闭，
 * 以保持与旧版本一致的行为（用户仍能看到徽章、自行判断）。
 *
 * <p>切换开关会通过 {@link #setListener(Runnable)} 通知已存在的列表实例立即重新
 * 过滤，无需退出页面重新加载。
 */
public final class RecycleFilterManager {

    private static final String PREF_NAME = "app_settings";
    private static final String KEY_HIDE_RECYCLED = "hide_recycled_threads";

    /** 内存缓存，避免列表绑定时频繁读磁盘。 */
    private static volatile boolean hideRecycled = false;
    private static volatile boolean initialized = false;

    private static volatile Runnable listener;

    private RecycleFilterManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        hideRecycled = prefs(context).getBoolean(KEY_HIDE_RECYCLED, false);
        initialized = true;
    }

    /**
     * 是否隐藏已回收的帖子。
     *
     * <p>未经 {@link #initialize(Context)} 时会惰性读一次磁盘，保证任何调用点
     * （包括 Adapter 内部）都能拿到正确值。
     */
    public static boolean isEnabled(Context context) {
        if (!initialized && context != null) {
            initialize(context);
        }
        return hideRecycled;
    }

    /** 不带 Context 的快速读取，仅在确定已初始化的绑定路径中使用。 */
    public static boolean isEnabled() {
        return hideRecycled;
    }

    public static void setEnabled(Context context, boolean enabled) {
        hideRecycled = enabled;
        initialized = true;
        if (context != null) {
            prefs(context).edit().putBoolean(KEY_HIDE_RECYCLED, enabled).apply();
        }
        notifyListener();
    }

    /** 注册变更监听（同一时刻仅一个，传 null 取消）。 */
    public static void setListener(Runnable r) {
        listener = r;
    }

    private static void notifyListener() {
        Runnable r = listener;
        if (r != null) {
            r.run();
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }
}
