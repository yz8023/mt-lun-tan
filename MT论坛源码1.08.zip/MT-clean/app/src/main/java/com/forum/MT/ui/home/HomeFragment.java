package com.forum.MT.ui.home;
import com.forum.MT.ui.BaseFragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.forum.MT.R;
import com.forum.MT.databinding.FragmentHomeBinding;
import com.forum.MT.ui.search.SearchActivity;

/**
 * 首页 Fragment
 * 顶部标题栏 + 分类 Tab（热门/最新/抢沙发/精华）+ ViewPager2 滑动切换
 */
public class HomeFragment extends BaseFragment {

    private FragmentHomeBinding binding;
    private ViewPager2 viewPager;
    private TabPagerAdapter pagerAdapter;

    private static final String[] TAB_TYPES = {"hot", "newthread", "first_reply", "digest"};
    private static final TextView[] TAB_VIEWS = new TextView[4];

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 应用首页标题颜色
        applyTitleColor();

        // 应用首页标题栏与分类栏背景颜色
        applyHomeBarColors();

        // 搜索栏点击 -> 打开搜索页面
        binding.searchBar.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), SearchActivity.class);
            startActivity(intent);
        });

        // 排行榜按钮 -> 打开热帖排行榜
        binding.btnRank.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(),
                    com.forum.MT.ui.rank.RankActivity.class);
            startActivity(intent);
        });

        // 搜索栏键盘搜索按钮 -> 打开搜索页面并携带关键词
        binding.searchBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                String keyword = binding.searchBar.getText().toString().trim();
                if (!TextUtils.isEmpty(keyword)) {
                    Intent intent = new Intent(requireContext(), SearchActivity.class);
                    intent.putExtra("keyword", keyword);
                    startActivity(intent);
                }
                return true;
            }
            return false;
        });

        // 分类 Tab 点击事件
        TAB_VIEWS[0] = binding.tabHot;
        TAB_VIEWS[1] = binding.tabNewest;
        TAB_VIEWS[2] = binding.tabFirstReply;
        TAB_VIEWS[3] = binding.tabEssence;

        for (int i = 0; i < TAB_VIEWS.length; i++) {
            final int index = i;
            TAB_VIEWS[i].setOnClickListener(v -> viewPager.setCurrentItem(index, true));
        }

        // ViewPager2 设置
        viewPager = binding.viewPager;
        pagerAdapter = new TabPagerAdapter(this);
        viewPager.setAdapter(pagerAdapter);
        // 只预加载相邻 1 个 Tab：原 setOffscreenPageLimit(3) 会让 4 个 Tab 同时发请求，
        // 进入首页瞬间 4 并发（叠加轮询）容易触发 WAF 限流。切到未加载 Tab 再即时加载即可。
        viewPager.setOffscreenPageLimit(1);

        // 页面切换时更新 Tab 高亮
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                updateTabHighlight(position);
            }
        });

        // 首页内容栏左右滑动开关：关闭时禁止滑动，只能点击 Tab
        applyTabSwipeEnabled();

        // 默认选中"最新内容"（索引 1）
        viewPager.setCurrentItem(1, false);
        updateTabHighlight(1);
    }

    /**
     * 应用首页内容栏左右滑动开关
     */
    private void applyTabSwipeEnabled() {
        viewPager.setUserInputEnabled(com.forum.MT.ui.widget.HomeTabSwipeManager.isSwipeEnabled());
    }

    /**
     * 更新 Tab 文字高亮
     */
    private void updateTabHighlight(int position) {
        for (int i = 0; i < TAB_VIEWS.length; i++) {
            if (TAB_VIEWS[i] == null) continue;
            if (i == position) {
                TAB_VIEWS[i].setTextColor(com.forum.MT.ui.widget.AccentColorManager.resolveAccentColor());
                TAB_VIEWS[i].setTypeface(null, android.graphics.Typeface.BOLD);
            } else {
                TAB_VIEWS[i].setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary));
                TAB_VIEWS[i].setTypeface(null, android.graphics.Typeface.NORMAL);
            }
        }
    }

    /** 双击底部导航栏时触发：刷新当前 Tab 的帖子列表 */
    public void refreshData() {
        if (viewPager == null) return;
        // ViewPager2 的 FragmentStateAdapter 用 "f" + position 作为 tag
        int pos = viewPager.getCurrentItem();
        Fragment current = getChildFragmentManager().findFragmentByTag("f" + pos);
        if (current instanceof TabContentFragment) {
            ((TabContentFragment) current).triggerRefresh();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        com.forum.MT.ui.widget.AccentColorManager.setListener(() -> {
            if (getView() == null) return;
            updateTabHighlight(viewPager.getCurrentItem());
        });
        com.forum.MT.ui.widget.TitleColorManager.setListener(() -> {
            if (getView() == null) return;
            applyTitleColor();
        });
        com.forum.MT.ui.widget.HomeBarColorManager.setListener(() -> {
            if (getView() == null) return;
            applyHomeBarColors();
        });
        com.forum.MT.ui.widget.HomeTabSwipeManager.setListener(() -> {
            if (getView() == null) return;
            applyTabSwipeEnabled();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        com.forum.MT.ui.widget.AccentColorManager.setListener(null);
        com.forum.MT.ui.widget.TitleColorManager.setListener(null);
        com.forum.MT.ui.widget.HomeBarColorManager.setListener(null);
        com.forum.MT.ui.widget.HomeTabSwipeManager.setListener(null);
        binding = null;
    }

    /**
     * 应用首页「MT论坛」标题颜色
     */
    private void applyTitleColor() {
        if (binding != null && binding.tvHomeTitle != null) {
            binding.tvHomeTitle.setTextColor(com.forum.MT.ui.widget.TitleColorManager.resolveTitleColor());
        }
    }

    /**
     * 应用首页标题栏与分类栏背景颜色
     */
    private void applyHomeBarColors() {
        if (binding == null) return;
        int titleBarBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveTitleBarColor();
        int tabBarBg   = com.forum.MT.ui.widget.HomeBarColorManager.resolveTabBarColor();
        int searchBarBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveSearchBarColor();
        binding.layoutHomeTitleBar.setBackgroundColor(titleBarBg);
        binding.layoutTabBar.setBackgroundColor(tabBarBg);
        // 搜索框背景：用 GradientDrawable 保留圆角
        android.graphics.drawable.Drawable d = binding.searchBar.getBackground();
        if (d instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) d).setColor(searchBarBg);
        } else {
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            gd.setColor(searchBarBg);
            gd.setCornerRadius(24f);
            gd.setStroke(1, 0xFFE0E0E0);
            binding.searchBar.setBackground(gd);
        }
    }

    /**
     * ViewPager2 FragmentStateAdapter
     * 每个 Tab 对应一个 TabContentFragment 实例
     */
    private static class TabPagerAdapter extends FragmentStateAdapter {

        public TabPagerAdapter(@NonNull Fragment fragment) {
            super(fragment);
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            return TabContentFragment.newInstance(TAB_TYPES[position]);
        }

        @Override
        public int getItemCount() {
            return TAB_TYPES.length;
        }
    }
}