package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/**
 * 首页标题栏与分类栏背景颜色管理。
 *
 * 颜色为 0 时表示使用默认颜色（背景色）。
 *
 * 偏好键：
 *   home_title_bar_bg_color  (int, 0 表示默认)
 *   home_tab_bar_bg_color    (int, 0 表示默认)
 */
public final class HomeBarColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_TITLE_BAR_BG  = "home_title_bar_bg_color";
    public static final String KEY_TAB_BAR_BG    = "home_tab_bar_bg_color";
    public static final String KEY_SEARCH_BAR_BG = "home_search_bar_bg_color";
    public static final String KEY_SEARCH_PAGE_TOOLBAR_BG = "search_page_toolbar_bg";
    public static final String KEY_SEARCH_PAGE_INPUT_BG   = "search_page_input_bg";
    public static final String KEY_SEARCH_PAGE_SORT_BG    = "search_page_sort_bg";
    public static final String KEY_SEARCH_PAGE_CONTENT_BG = "search_page_content_bg";
    public static final String KEY_SEARCH_PAGE_BUTTON_BG  = "search_page_button_bg";
    public static final String KEY_THREAD_BG               = "thread_bg";
    public static final String KEY_THREAD_TOP_BG            = "thread_top_bg";
    public static final String KEY_REPLY_BAR_BG            = "reply_bar_bg";
    public static final String KEY_THREAD_ACTION_BTN_BG     = "thread_action_btn_bg";
    public static final String KEY_MESSAGE_TITLE_BG           = "message_title_bg";
    public static final String KEY_MESSAGE_TAB_BG             = "message_tab_bg";
    public static final String KEY_UNREAD_BAR_COLOR            = "unread_bar_color";
    public static final String KEY_EDIT_TIME_COLOR             = "edit_time_color";

    /** 默认背景色（极浅蓝） */
    public static final int DEFAULT_BG = 0xFFE3F2FD;
    /** 搜索框默认背景色 */
    public static final int DEFAULT_SEARCH_BG = 0xFFE3F2FD;
    /** 搜索页 Toolbar 默认背景色（极浅蓝） */
    public static final int DEFAULT_SEARCH_TOOLBAR_BG = 0xFFE3F2FD;
    /** 搜索页输入区默认背景色（极浅蓝） */
    public static final int DEFAULT_SEARCH_INPUT_BG = 0xFFE3F2FD;
    /** 搜索页排序栏默认背景色（极浅蓝） */
    public static final int DEFAULT_SEARCH_SORT_BG = 0xFFE3F2FD;

    private static volatile int titleBarColor  = 0;
    private static volatile int tabBarColor    = 0;
    private static volatile int searchBarColor = 0;
    private static volatile int searchToolbarBg = 0;
    private static volatile int searchInputBg   = 0;
    private static volatile int searchSortBg    = 0;
    private static volatile int searchContentBg = 0;
    private static volatile int searchButtonBg  = 0;
    private static volatile int threadBg        = 0;
    private static volatile int threadTopBg     = 0;
    private static volatile int replyBarBg      = 0;
    private static volatile int threadActionBtnBg = 0;
    private static volatile int messageTitleBg = 0;
    private static volatile int messageTabBg = 0;
    private static volatile int unreadBarColor = 0;
    private static volatile int editTimeColor = 0;

    private HomeBarColorManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        titleBarColor = prefs.getInt(KEY_TITLE_BAR_BG, 0);
        tabBarColor   = prefs.getInt(KEY_TAB_BAR_BG, 0);
        searchBarColor = prefs.getInt(KEY_SEARCH_BAR_BG, 0);
        searchToolbarBg = prefs.getInt(KEY_SEARCH_PAGE_TOOLBAR_BG, 0);
        searchInputBg   = prefs.getInt(KEY_SEARCH_PAGE_INPUT_BG, 0);
        searchSortBg    = prefs.getInt(KEY_SEARCH_PAGE_SORT_BG, 0);
        searchContentBg = prefs.getInt(KEY_SEARCH_PAGE_CONTENT_BG, 0);
        searchButtonBg  = prefs.getInt(KEY_SEARCH_PAGE_BUTTON_BG, 0);
        threadBg        = prefs.getInt(KEY_THREAD_BG, 0);
        threadTopBg     = prefs.getInt(KEY_THREAD_TOP_BG, 0);
        replyBarBg      = prefs.getInt(KEY_REPLY_BAR_BG, 0);
        threadActionBtnBg = prefs.getInt(KEY_THREAD_ACTION_BTN_BG, 0);
        messageTitleBg = prefs.getInt(KEY_MESSAGE_TITLE_BG, 0);
        messageTabBg = prefs.getInt(KEY_MESSAGE_TAB_BG, 0);
        unreadBarColor = prefs.getInt(KEY_UNREAD_BAR_COLOR, 0);
        editTimeColor = prefs.getInt(KEY_EDIT_TIME_COLOR, 0);
    }

    // ---- 标题栏 ----
    public static int getTitleBarCustomColor() { return titleBarColor; }

    public static void setTitleBarColor(Context context, int color) {
        titleBarColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_TITLE_BAR_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveTitleBarColor() {
        return titleBarColor != 0 ? titleBarColor : DEFAULT_BG;
    }

    // ---- 分类栏 ----
    public static int getTabBarCustomColor() { return tabBarColor; }

    public static void setTabBarColor(Context context, int color) {
        tabBarColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_TAB_BAR_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveTabBarColor() {
        return tabBarColor != 0 ? tabBarColor : DEFAULT_BG;
    }

    // ---- 搜索框 ----
    public static int getSearchBarCustomColor() { return searchBarColor; }

    public static void setSearchBarColor(Context context, int color) {
        searchBarColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_SEARCH_BAR_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveSearchBarColor() {
        return searchBarColor != 0 ? searchBarColor : DEFAULT_SEARCH_BG;
    }

    // ---- 搜索页 Toolbar ----
    public static int getSearchToolbarBg() { return searchToolbarBg; }

    public static void setSearchToolbarBg(Context context, int color) {
        searchToolbarBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_SEARCH_PAGE_TOOLBAR_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveSearchToolbarBg() {
        return searchToolbarBg != 0 ? searchToolbarBg : DEFAULT_SEARCH_TOOLBAR_BG;
    }

    // ---- 搜索页输入区 ----
    public static int getSearchInputBg() { return searchInputBg; }

    public static void setSearchInputBg(Context context, int color) {
        searchInputBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_SEARCH_PAGE_INPUT_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveSearchInputBg() {
        return searchInputBg != 0 ? searchInputBg : DEFAULT_SEARCH_INPUT_BG;
    }

    // ---- 搜索页排序栏 ----
    public static int getSearchSortBg() { return searchSortBg; }

    public static void setSearchSortBg(Context context, int color) {
        searchSortBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_SEARCH_PAGE_SORT_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveSearchSortBg() {
        return searchSortBg != 0 ? searchSortBg : DEFAULT_SEARCH_SORT_BG;
    }

    // ---- 搜索页内容区 ----
    public static int getSearchContentBg() { return searchContentBg; }

    public static void setSearchContentBg(Context context, int color) {
        searchContentBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_SEARCH_PAGE_CONTENT_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveSearchContentBg() {
        return searchContentBg != 0 ? searchContentBg : DEFAULT_SEARCH_SORT_BG;
    }

    // ---- 搜索页按钮 ----
    public static int getSearchButtonBg() { return searchButtonBg; }

    public static void setSearchButtonBg(Context context, int color) {
        searchButtonBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_SEARCH_PAGE_BUTTON_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveSearchButtonBg() {
        return searchButtonBg != 0 ? searchButtonBg : 0xFF607D8B;
    }

    // ---- 帖子背景 ----
    public static int getThreadBg() { return threadBg; }

    public static void setThreadBg(Context context, int color) {
        threadBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_THREAD_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveThreadBg() {
        return threadBg != 0 ? threadBg : 0xFFE3F2FD;
    }

    // ---- 帖子顶部背景 ----
    public static int getThreadTopBg() { return threadTopBg; }

    public static void setThreadTopBg(Context context, int color) {
        threadTopBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_THREAD_TOP_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveThreadTopBg() {
        return threadTopBg != 0 ? threadTopBg : 0xFFE3F2FD;
    }

    // ---- 底部输入栏背景 ----
    public static int getReplyBarBg() { return replyBarBg; }

    public static void setReplyBarBg(Context context, int color) {
        replyBarBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_REPLY_BAR_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveReplyBarBg() {
        return replyBarBg != 0 ? replyBarBg : 0xFF575996;
    }

    // ---- 帖子操作按钮背景 ----
    public static int getThreadActionBtnBg() { return threadActionBtnBg; }

    public static void setThreadActionBtnBg(Context context, int color) {
        threadActionBtnBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_THREAD_ACTION_BTN_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveThreadActionBtnBg() {
        return threadActionBtnBg != 0 ? threadActionBtnBg : 0xFF607D8B;
    }

    // ---- 消息页标题栏背景 ----
    public static int getMessageTitleBg() { return messageTitleBg; }

    public static void setMessageTitleBg(Context context, int color) {
        messageTitleBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_MESSAGE_TITLE_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveMessageTitleBg() {
        return messageTitleBg != 0 ? messageTitleBg : 0xFFE3F2FD;
    }

    // ---- 消息页Tab栏背景 ----
    public static int getMessageTabBg() { return messageTabBg; }

    public static void setMessageTabBg(Context context, int color) {
        messageTabBg = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_MESSAGE_TAB_BG, color).apply();
        }
        notifyChanged();
    }

    public static int resolveMessageTabBg() {
        return messageTabBg != 0 ? messageTabBg : 0xFFE3F2FD;
    }

    // ---- 未读高亮色条颜色 ----
    public static int getUnreadBarColor() { return unreadBarColor; }

    public static void setUnreadBarColor(Context context, int color) {
        unreadBarColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_UNREAD_BAR_COLOR, color).apply();
        }
        notifyChanged();
    }

    public static int resolveUnreadBarColor() {
        return unreadBarColor != 0 ? unreadBarColor : 0xFF707646;
    }

    // ---- 编辑时间文字颜色 ----
    public static int getEditTimeColor() { return editTimeColor; }

    public static void setEditTimeColor(Context context, int color) {
        editTimeColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_EDIT_TIME_COLOR, color).apply();
        }
        notifyChanged();
    }

    public static int resolveEditTimeColor() {
        return editTimeColor != 0 ? editTimeColor : 0xFF888888;
    }

    // ---- 监听器 ----
    public interface OnHomeBarColorChangedListener {
        void onHomeBarColorChanged();
    }

    private static volatile OnHomeBarColorChangedListener listener;

    public static void setListener(OnHomeBarColorChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnHomeBarColorChangedListener l = listener;
        if (l != null) l.onHomeBarColorChanged();
    }
}
