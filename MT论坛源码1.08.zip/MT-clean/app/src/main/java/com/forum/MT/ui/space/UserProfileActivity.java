package com.forum.MT.ui.space;
import com.forum.MT.ui.BaseActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.adapter.WallMessageAdapter;
import com.forum.MT.databinding.ActivityUserProfileBinding;
import com.forum.MT.model.Message;
import com.forum.MT.model.UserProfile;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.ui.message.ChatActivity;
import com.forum.MT.ui.widget.BackgroundColorManager;
import com.forum.MT.ui.widget.RainbowBorderHelper;
import com.forum.MT.session.DiscuzUserActionManager;
import com.forum.MT.session.FollowStateManager;
import com.forum.MT.session.UserSessionManager;

import java.util.List;

/**
 * 用户个人资料页（原生 Activity）
 * 通过 Intent 接收 uid 参数，从服务端加载目标用户的资料并展示
 * 可从好友列表、关注列表、粉丝列表、帖子详情、评论区等入口跳转
 */
public class UserProfileActivity extends BaseActivity {

    /** 启动后自动打开留言板覆盖层（用于"留言板"入口直接进入留言）。 */
    public static final String EXTRA_AUTO_OPEN_WALL = "auto_open_wall";

    private ActivityUserProfileBinding binding;
    private HttpClient httpClient;
    private WallMessageAdapter wallAdapter;
    private boolean wallSending;
    private boolean wallLoading;
    private int wallCurrentPage = 1;
    private int wallMaxPage = 1;
    private int wallRequestGeneration;
    private String targetUid;
    private boolean autoOpenWall;
    // 仅保存本次网页端响应的状态，禁止从本地缓存推导按钮状态。
    private boolean serverFollowed;
    private boolean serverFollowStateKnown;
    private boolean requestInFlight;
    private volatile boolean destroyed = false;
    // 好友状态: 0=非好友, 1=已是好友, 2=申请待验证, -1=未知
    private int serverFriendStatus = -1;
    // 是否已拉黑该用户（Comiis 黑名单，服务端主页判定）
    private boolean serverBlocked;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setupWallImeInsets();

        RainbowBorderHelper.applyToCardViews(binding.getRoot(), this);

        httpClient = HttpClient.getInstance();

        targetUid = getIntent().getStringExtra("uid");
        String username = getIntent().getStringExtra("username");
        autoOpenWall = getIntent().getBooleanExtra(EXTRA_AUTO_OPEN_WALL, false);

        // 设置 Toolbar
        binding.toolbar.setTitle(username != null ? username : "用户资料");
        // ★ 移除返回箭头图标（仅保留点击返回功能）
        binding.toolbar.setNavigationIcon(null);
        binding.toolbar.setNavigationOnClickListener(v -> {
            if (binding.layoutWallOverlay.getVisibility() == View.VISIBLE) {
                closeWallOverlay();
            } else {
                finish();
            }
        });

        if (targetUid == null) {
            Toast.makeText(this, "缺少用户ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 用户操作按钮与网页端空间页底部的\"加好友/打招呼/聊天\"对应。
        setupProfileActions();
        if (autoOpenWall) {
            // 留言板入口：只弹留言弹窗，不加载/显示主页
            showWallDialog();
        } else {
            loadUserProfile();
        }
    }

    private boolean canUpdateUi() {
        return !destroyed && !isFinishing()
                && (android.os.Build.VERSION.SDK_INT < 17 || !isDestroyed());
    }

    private void loadUserProfile() {
        if (!canUpdateUi() || requestInFlight || TextUtils.isEmpty(targetUid)) return;
        requestInFlight = true;
        binding.progressBar.setVisibility(View.VISIBLE);

        new Thread(() -> {
            UserProfile profile = null;
            String error = null;
            try {
                httpClient.syncFromCookieManager();
                String cacheBust = "&_ts=" + System.currentTimeMillis();
                String profileUrl = HttpClient.BASE_URL
                        + "home.php?mod=space&uid=" + targetUid + "&mobile=2" + cacheBust;
                String html = httpClient.get(profileUrl);

                if (ForumParser.isLoginPage(html)) {
                    error = "登录已过期，请重新登录";
                } else {
                    profile = ForumParser.parseUserProfile(html);
                    if (profile == null || profile.getUsername() == null) {
                        String altUrl = HttpClient.BASE_URL
                                + "home.php?mod=space&uid=" + targetUid
                                + "&do=profile&mobile=2" + cacheBust;
                        String altHtml = httpClient.get(altUrl);
                        if (ForumParser.isLoginPage(altHtml)) {
                            error = "登录已过期";
                        } else {
                            profile = ForumParser.parseUserProfile(altHtml);
                        }
                    }

                    if (error == null && profile != null) {
                        int followState = isOwnProfile()
                                ? -1 : FollowStateManager.queryServerFollowState(
                                getApplicationContext(), targetUid);
                        if (followState >= 0) {
                            profile.setFollowed(followState == 1);
                            profile.setFollowStateKnown(true);
                        }
                    }
                }
            } catch (Exception e) {
                error = "加载失败，请稍后重试";
            }

            final UserProfile resultProfile = profile;
            final String resultError = error;
            runOnUiThread(() -> {
                if (!canUpdateUi()) return;
                requestInFlight = false;
                binding.progressBar.setVisibility(View.GONE);
                if (resultError != null) {
                    Toast.makeText(this, resultError, Toast.LENGTH_SHORT).show();
                    if (resultError.contains("登录已过期")) finish();
                } else if (resultProfile != null && resultProfile.getUsername() != null) {
                    serverFollowStateKnown = resultProfile.isFollowStateKnown();
                    if (serverFollowStateKnown) serverFollowed = resultProfile.isFollowed();
                    serverFriendStatus = resultProfile.getFriendStatus();
                    serverBlocked = resultProfile.isBlocked();
                    displayProfile(resultProfile);
                    if (autoOpenWall) {
                        autoOpenWall = false;
                        showWallDialog();
                    }
                } else {
                    Toast.makeText(this, "无法加载用户资料", Toast.LENGTH_SHORT).show();
                }
            });
        }, "user-profile-load").start();
    }

    /** 当前资料是否属于当前登录账号本人。 */
    private boolean isOwnProfile() {
        if (TextUtils.isEmpty(targetUid)) return false;
        String currentUid = UserSessionManager.getInstance().getUid(this);
        return !TextUtils.isEmpty(currentUid)
                && !"0".equals(currentUid)
                && currentUid.equals(targetUid);
    }
    private void setupProfileActions() {
        binding.layoutProfileActions.setVisibility(View.GONE);
        binding.btnProfileFriend.setOnClickListener(v -> showFriendDialog());
        binding.btnProfilePoke.setOnClickListener(v -> showPokeDialog());
        binding.btnProfileMessage.setOnClickListener(v -> openChat());
        binding.btnProfileBlock.setOnClickListener(v -> showBlockDialog());
        binding.fabWall.setOnClickListener(v -> showWallDialog());
    }

    /**
     * 根据服务端好友状态更新"加好友"按钮：
     *   0 = 非好友 → 显示"加好友"，可点击
     *   1 = 已是好友 → 显示"已是好友"，禁用点击
     *   2 = 申请待验证 → 显示"等待验证"，禁用点击
     *  -1 = 未知 → 默认显示"加好友"（向后兼容）
     */
    private void updateFriendButton() {
        if (binding == null) return;
        switch (serverFriendStatus) {
            case 1:
                binding.btnProfileFriend.setText("解除好友");
                binding.btnProfileFriend.setEnabled(true);
                binding.btnProfileFriend.setOnClickListener(v -> showRemoveFriendDialog());
                break;
            case 2:
                binding.btnProfileFriend.setText("等待验证");
                binding.btnProfileFriend.setEnabled(false);
                binding.btnProfileFriend.setOnClickListener(null);
                break;
            default:
                // 0 或 -1（未知）：显示"加好友"，可点击
                binding.btnProfileFriend.setText("加好友");
                binding.btnProfileFriend.setEnabled(true);
                binding.btnProfileFriend.setOnClickListener(v -> showFriendDialog());
                break;
        }
    }

    /** 打开与当前资料用户的原生聊天页面，不再弹出\"发私信\"输入框。 */
    /** 拉黑按钮：已拉黑→"解除拉黑"（可点击解除），未拉黑→"拉黑"（可点击拉黑） */
    private void updateBlockButton() {
        if (binding == null) return;
        if (serverBlocked) {
            binding.btnProfileBlock.setText("解除拉黑");
        } else {
            binding.btnProfileBlock.setText("拉黑");
        }
        binding.btnProfileBlock.setEnabled(true);
        binding.btnProfileBlock.setOnClickListener(v -> showBlockDialog());
    }

    private void openChat() {
        if (!canUseProfileAction()) return;

        String chatName = binding.tvUsername.getText() == null
                ? "用户"
                : binding.tvUsername.getText().toString().trim();
        if (TextUtils.isEmpty(chatName)) chatName = "用户";

        Intent intent = new Intent(this, ChatActivity.class);
        // Comiis 模板使用 touid 作为会话标识，ChatActivity.EXTRA_PMID 实际传入目标 UID。
        intent.putExtra(ChatActivity.EXTRA_PMID, targetUid);
        intent.putExtra(ChatActivity.EXTRA_UID, targetUid);
        intent.putExtra(ChatActivity.EXTRA_NAME, chatName);
        startActivity(intent);
    }


    private boolean canUseProfileAction() {
        if (TextUtils.isEmpty(targetUid)) return false;
        if (!FollowStateManager.isLoggedIn(this)) {
            Toast.makeText(this, "请先登录", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private EditText makeInput(String hint, boolean multiLine) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(!multiLine);
        if (multiLine) {
            input.setMinLines(3);
            input.setGravity(android.view.Gravity.TOP);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        }
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad / 2, pad, pad / 2);
        return input;
    }

    private void showFriendDialog() {
        if (!canUseProfileAction()) return;
        EditText input = makeInput("附加留言（可选）", true);
        new AlertDialog.Builder(this)
                .setTitle("添加好友")
                .setView(input)
                .setPositiveButton("发送申请", (dialog, which) -> {
                    String note = input.getText().toString().trim();
                    runUserAction("正在发送好友申请…", () ->
                            DiscuzUserActionManager.addFriend(this, targetUid, note),
                            "好友申请已发送", "好友申请发送失败");
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showPokeDialog() {
        if (!canUseProfileAction()) return;
        EditText input = makeInput("招呼内容，例如：你好！", false);
        input.setText("你好！");
        new AlertDialog.Builder(this)
                .setTitle("打招呼")
                .setView(input)
                .setPositiveButton("发送", (dialog, which) -> {
                    String message = input.getText().toString().trim();
                    if (TextUtils.isEmpty(message)) {
                        Toast.makeText(this, "请输入招呼内容", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    runUserAction("正在发送招呼…", () ->
                            DiscuzUserActionManager.sendPoke(this, targetUid, message),
                            "打招呼成功", "打招呼失败");
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showWallDialog() {
        if (!canUseProfileAction()) return;

        // 竖屏从底部显示半屏，横屏显示满屏。
        applyWallOverlaySize();
        binding.layoutWallOverlay.setVisibility(View.VISIBLE);
        binding.fabWall.setVisibility(View.GONE);
        String wallName = binding.tvUsername.getText() == null ? ""
                : binding.tvUsername.getText().toString().trim();
        binding.tvWallTitle.setText(TextUtils.isEmpty(wallName)
                ? "留言" : wallName + " 的留言");
        binding.tvWallBack.setOnClickListener(v -> closeWallOverlay());

        binding.wallEmpty.setVisibility(View.GONE);
        binding.wallSend.setEnabled(false);

        if (wallAdapter == null) {
            wallAdapter = new WallMessageAdapter(this);
            wallAdapter.setListener((message, position) -> openWallAuthorProfile(message));
            wallAdapter.setActionListener(new WallMessageAdapter.OnActionClickListener() {
                @Override
                public void onEdit(Message message, int position) {
                    showEditWallMessageDialog(message);
                }

                @Override
                public void onDelete(Message message, int position) {
                    confirmDeleteWallMessage(message);
                }

                @Override
                public void onReply(Message message, int position) {
                    showReplyWallMessageDialog(message);
                }
            });
            binding.wallRecycler.setLayoutManager(new LinearLayoutManager(this));
            binding.wallRecycler.setAdapter(wallAdapter);
        }

        binding.wallInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (wallSending) return;
                binding.wallSend.setEnabled(!TextUtils.isEmpty(s.toString().trim()));
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
            }
        });

        binding.wallSend.setOnClickListener(v -> sendWallMessage());
        binding.wallPreviousPage.setOnClickListener(v -> {
            if (!wallLoading && wallCurrentPage > 1) {
                loadWallMessages(wallCurrentPage - 1);
            }
        });
        binding.wallNextPage.setOnClickListener(v -> {
            if (!wallLoading && wallCurrentPage < wallMaxPage) {
                loadWallMessages(wallCurrentPage + 1);
            }
        });
        wallCurrentPage = 1;
        wallMaxPage = 1;
        updateWallPagination();
        loadWallMessages(1);
    }

    /**
     * 使用 adjustNothing 保持留言层位置不变，并仅将底部输入栏抬到软键盘上方。
     * IME 关闭时 translationY 自动恢复为 0。
     */
    private void setupWallImeInsets() {
        // IME Insets 需要从窗口 DecorView 获取。普通内容根布局在 adjustNothing 下
        // 可能收不到键盘显示过程中的 Insets 更新，导致输入栏位移始终为 0。
        View decorView = getWindow().getDecorView();
        ViewCompat.setOnApplyWindowInsetsListener(decorView, (view, windowInsets) -> {
            Insets imeInsets = windowInsets.getInsets(WindowInsetsCompat.Type.ime());
            Insets systemBarInsets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            boolean imeVisible = windowInsets.isVisible(WindowInsetsCompat.Type.ime());
            int imeOffset = imeVisible
                    ? Math.max(0, imeInsets.bottom - systemBarInsets.bottom)
                    : 0;

            if (binding != null) {
                binding.wallInputBar.setTranslationY(-imeOffset);
            }
            return windowInsets;
        });
        decorView.post(() -> ViewCompat.requestApplyInsets(decorView));
    }

    /** 根据当前方向调整留言层：竖屏底部 2/3，横屏满屏。 */
    private void applyWallOverlaySize() {
        ViewGroup.LayoutParams params = binding.layoutWallOverlay.getLayoutParams();
        boolean landscape = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = landscape
                ? ViewGroup.LayoutParams.MATCH_PARENT
                : Math.max(1, getResources().getDisplayMetrics().heightPixels * 2 / 3);
        binding.layoutWallOverlay.setLayoutParams(params);
        binding.layoutWallOverlay.setBackgroundColor(BackgroundColorManager.resolveColor());
    }

    /** 关闭留言覆盖层，返回资料页并恢复悬浮留言按钮。 */
    private void closeWallOverlay() {
        // 留言板入口模式：关闭弹窗即返回，不留在主页
        if (autoOpenWall) {
            finish();
            return;
        }
        binding.layoutWallOverlay.setVisibility(View.GONE);
        binding.fabWall.setVisibility(View.VISIBLE);
        binding.wallInputBar.setTranslationY(0f);
        binding.wallInput.setText("");
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (binding.layoutWallOverlay.getVisibility() == View.VISIBLE) {
            applyWallOverlaySize();
            binding.fabWall.setVisibility(View.GONE);
        }
    }

    @Override
    public void onBackPressed() {
        if (binding.layoutWallOverlay.getVisibility() == View.VISIBLE) {
            closeWallOverlay();
            return;
        }
        super.onBackPressed();
    }

    /** 点击留言头像或用户名，打开留言者的资料主页。 */
    private void openWallAuthorProfile(Message message) {
        if (message == null) return;
        String authorUid = message.getAuthorUid();
        if (TextUtils.isEmpty(authorUid) || "0".equals(authorUid)) {
            Toast.makeText(this, "无法获取该用户的UID", Toast.LENGTH_SHORT).show();
            return;
        }

        if (authorUid.equals(targetUid)) {
            closeWallOverlay();
            return;
        }

        Intent intent = new Intent(this, UserProfileActivity.class);
        intent.putExtra("uid", authorUid);
        intent.putExtra("username", message.getAuthor());
        startActivity(intent);
    }

    /** 从服务端拉取指定页的留言板内容并刷新覆盖层列表。 */
    private void loadWallMessages() {
        loadWallMessages(wallCurrentPage);
    }

    private void loadWallMessages(int requestedPage) {
        if (wallLoading || requestedPage < 1) return;
        final int generation = ++wallRequestGeneration;
        wallLoading = true;
        binding.wallProgress.setVisibility(View.VISIBLE);
        binding.wallEmpty.setVisibility(View.GONE);
        updateWallPagination();

        new Thread(() -> {
            String html = null;
            String error = null;
            try {
                if (httpClient == null) httpClient = HttpClient.getInstance();
                if (!httpClient.isLoggedIn()) httpClient.syncFromCookieManager();
                html = httpClient.get(HttpClient.BASE_URL
                        + "home.php?mod=space&uid=" + targetUid
                        + "&do=wall&mobile=2&page=" + requestedPage);
                if (ForumParser.isLoginPage(html)) error = "登录已过期，请重新登录";
            } catch (Exception e) {
                error = "留言加载失败";
            }

            final String resultHtml = html;
            final String resultError = error;
            runOnUiThread(() -> {
                if (destroyed || generation != wallRequestGeneration) return;
                wallLoading = false;
                binding.wallProgress.setVisibility(View.GONE);
                if (resultError != null) {
                    binding.wallEmpty.setVisibility(View.VISIBLE);
                    binding.wallEmpty.setText(resultError);
                    updateWallPagination();
                    Toast.makeText(this, resultError, Toast.LENGTH_SHORT).show();
                    return;
                }

                List<Message> messages = ForumParser.parseWallMessages(resultHtml);
                wallCurrentPage = requestedPage;
                wallMaxPage = Math.max(wallCurrentPage,
                        ForumParser.parseWallMaxPage(resultHtml));
                if (wallAdapter != null) wallAdapter.setList(messages);
                binding.wallEmpty.setText("暂无留言，来抢沙发吧～");
                binding.wallEmpty.setVisibility(messages.isEmpty() ? View.VISIBLE : View.GONE);
                if (!messages.isEmpty()) binding.wallRecycler.scrollToPosition(0);
                updateWallPagination();
            });
        }, "wall-load-" + requestedPage).start();
    }

    private void updateWallPagination() {
        if (binding == null) return;
        boolean hasMultiplePages = wallMaxPage > 1;
        binding.wallPagination.setVisibility(hasMultiplePages ? View.VISIBLE : View.GONE);
        binding.wallPageStatus.setText("第 " + wallCurrentPage + " / " + wallMaxPage + " 页");

        boolean previousEnabled = !wallLoading && wallCurrentPage > 1;
        boolean nextEnabled = !wallLoading && wallCurrentPage < wallMaxPage;
        binding.wallPreviousPage.setEnabled(previousEnabled);
        binding.wallPreviousPage.setAlpha(previousEnabled ? 1f : 0.38f);
        binding.wallNextPage.setEnabled(nextEnabled);
        binding.wallNextPage.setAlpha(nextEnabled ? 1f : 0.38f);
    }

    /** 提交留言，成功后重新拉取列表。 */
    private void sendWallMessage() {
        if (wallSending) return;
        String msg = binding.wallInput.getText() == null ? ""
                : binding.wallInput.getText().toString().trim();
        if (TextUtils.isEmpty(msg)) {
            Toast.makeText(this, "请输入留言内容", Toast.LENGTH_SHORT).show();
            return;
        }

        wallSending = true;
        binding.wallSend.setEnabled(false);
        new Thread(() -> {
            boolean success = false;
            try {
                if (httpClient == null) httpClient = HttpClient.getInstance();
                if (!httpClient.isLoggedIn()) httpClient.syncFromCookieManager();
                success = DiscuzUserActionManager.postWallMessage(
                        getApplicationContext(), targetUid, msg);
            } catch (Exception ignored) {
            }

            final boolean ok = success;
            runOnUiThread(() -> {
                if (destroyed) return;
                wallSending = false;
                binding.wallSend.setEnabled(false);
                if (ok) {
                    binding.wallInput.setText("");
                    binding.wallEmpty.setVisibility(View.GONE);
                    loadWallMessages();
                    Toast.makeText(this, "留言成功", Toast.LENGTH_SHORT).show();
                } else {
                    binding.wallSend.setEnabled(true);
                    Toast.makeText(this, "留言失败", Toast.LENGTH_SHORT).show();
                }
            });
        }, "wall-send").start();
    }

    /** 弹出编辑留言对话框，提交成功后刷新列表。 */
    private void showEditWallMessageDialog(Message message) {
        if (message == null || TextUtils.isEmpty(message.getWallEditUrl())) return;
        EditText input = makeInput("编辑留言内容", true);
        String oldContent = message.getSummary() != null ? message.getSummary() : "";
        input.setText(oldContent);
        input.setSelection(oldContent.length());

        new AlertDialog.Builder(this)
                .setTitle("编辑留言")
                .setView(input)
                .setPositiveButton("保存", (dialog, which) -> {
                    String newContent = input.getText().toString().trim();
                    if (TextUtils.isEmpty(newContent)) {
                        Toast.makeText(this, "留言内容不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.equals(newContent, oldContent)) {
                        Toast.makeText(this, "内容未修改", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    final String cid = extractWallCid(message.getWallEditUrl());
                    if (TextUtils.isEmpty(cid)) {
                        Toast.makeText(this, "无法获取留言ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(this, "正在保存…", Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        boolean success = DiscuzUserActionManager.editWallMessage(
                                getApplicationContext(), cid, newContent);
                        runOnUiThread(() -> {
                            if (destroyed) return;
                            if (success) {
                                Toast.makeText(this, "编辑成功", Toast.LENGTH_SHORT).show();
                                loadWallMessages();
                            } else {
                                Toast.makeText(this, "编辑失败", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }, "wall-edit").start();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 确认删除留言，成功后刷新列表。 */
    private void confirmDeleteWallMessage(Message message) {
        if (message == null || TextUtils.isEmpty(message.getWallDeleteUrl())) return;
        new AlertDialog.Builder(this)
                .setTitle("删除留言")
                .setMessage("确定删除这条留言吗？删除后不可恢复。")
                .setPositiveButton("删除", (dialog, which) -> {
                    final String cid = extractWallCid(message.getWallDeleteUrl());
                    if (TextUtils.isEmpty(cid)) {
                        Toast.makeText(this, "无法获取留言ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(this, "正在删除…", Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        boolean success = DiscuzUserActionManager.deleteWallMessage(
                                getApplicationContext(), cid);
                        runOnUiThread(() -> {
                            if (destroyed) return;
                            if (success) {
                                Toast.makeText(this, "删除成功", Toast.LENGTH_SHORT).show();
                                loadWallMessages();
                            } else {
                                Toast.makeText(this, "删除失败", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }, "wall-delete").start();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showReplyWallMessageDialog(Message message) {
        if (message == null || TextUtils.isEmpty(message.getWallReplyUrl())) return;
        EditText input = new EditText(this);
        input.setHint("回复 @" + (TextUtils.isEmpty(message.getAuthor()) ? "该用户" : message.getAuthor()));
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setGravity(android.view.Gravity.TOP);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad / 2, pad, pad / 2);
        new AlertDialog.Builder(this)
                .setTitle("回复留言")
                .setView(input)
                .setPositiveButton("回复", (dialog, which) -> {
                    String content = input.getText().toString().trim();
                    if (TextUtils.isEmpty(content)) {
                        Toast.makeText(this, "回复内容不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    final String cid = extractWallCid(message.getWallReplyUrl());
                    if (TextUtils.isEmpty(cid)) {
                        Toast.makeText(this, "无法获取留言ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(this, "正在回复…", Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        boolean success = DiscuzUserActionManager.replyWallMessage(
                                getApplicationContext(), cid, content);
                        runOnUiThread(() -> {
                            if (destroyed) return;
                            if (success) {
                                Toast.makeText(this, "回复成功", Toast.LENGTH_SHORT).show();
                                loadWallMessages(wallCurrentPage);
                            } else {
                                Toast.makeText(this, "回复失败", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }, "wall-reply").start();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 从留言编辑/删除/回复链接中提取 cid。 */
    private static String extractWallCid(String url) {
        if (TextUtils.isEmpty(url)) return null;
        try {
            android.net.Uri uri = android.net.Uri.parse(url);
            String cid = uri.getQueryParameter("cid");
            if (!TextUtils.isEmpty(cid)) return cid;
        } catch (Exception ignored) {
        }
        // 兜底：正则提取 cid=
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("[?&]cid=(\\d+)").matcher(url);
        if (m.find()) return m.group(1);
        return null;
    }

    private void showRemoveFriendDialog() {
        if (!canUseProfileAction()) return;
        String name = binding.tvUsername.getText() == null ? "该用户"
                : binding.tvUsername.getText().toString();
        new AlertDialog.Builder(this)
                .setTitle("解除好友")
                .setMessage("确定解除与 " + name + " 的好友关系吗？")
                .setPositiveButton("解除", (dialog, which) ->
                        runUserAction("正在解除好友…", () ->
                                DiscuzUserActionManager.removeFriend(this, targetUid),
                                "已解除好友关系", "解除好友失败", () -> {
                                    serverFriendStatus = 0;
                                    updateFriendButton();
                                }))
                .setNegativeButton("取消", null)
                .show();
    }

    private void showBlockDialog() {
        if (!canUseProfileAction()) return;
        String name = binding.tvUsername.getText() == null ? "该用户"
                : binding.tvUsername.getText().toString();
        if (serverBlocked) {
            // 已拉黑 → 解除拉黑
            new AlertDialog.Builder(this)
                    .setTitle("解除拉黑")
                    .setMessage("确定解除对\"" + name + "\"的拉黑吗？")
                    .setPositiveButton("解除拉黑", (dialog, which) ->
                            runUserAction("正在解除拉黑…", () ->
                                    DiscuzUserActionManager.unblockUser(this, targetUid),
                                    "已解除拉黑", "解除拉黑失败", () -> {
                                        serverBlocked = false;
                                        updateBlockButton();
                                    }))
                    .setNegativeButton("取消", null)
                    .show();
        } else {
            // 未拉黑 → 拉黑
            new AlertDialog.Builder(this)
                    .setTitle("拉黑用户")
                    .setMessage("确定拉黑\"" + name + "\"吗？拉黑后将不再看到该用户发布的内容。")
                    .setPositiveButton("拉黑", (dialog, which) ->
                            runUserAction("正在拉黑用户…", () ->
                                    DiscuzUserActionManager.blockUser(this, targetUid, name),
                                    "已拉黑该用户", "拉黑失败", () -> {
                                        serverBlocked = true;
                                        updateBlockButton();
                                    }))
                    .setNegativeButton("取消", null)
                    .show();
        }
    }

    private interface UserAction {
        boolean run();
    }

    private void runUserAction(String loadingText, UserAction action,
                               String successText, String failureText) {
        runUserAction(loadingText, action, successText, failureText, null);
    }

    private void runUserAction(String loadingText, UserAction action,
                               String successText, String failureText,
                               Runnable onSuccess) {
        binding.layoutProfileActions.setEnabled(false);
        Toast.makeText(this, loadingText, Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            boolean success = action.run();
            runOnUiThread(() -> {
                binding.layoutProfileActions.setEnabled(true);
                Toast.makeText(this, success ? successText : failureText,
                        Toast.LENGTH_SHORT).show();
                // 好友申请成功后立即更新按钮为\"等待验证\"
                if (success && successText.contains("好友") && !successText.contains("解除")) {
                    serverFriendStatus = 2;
                    updateFriendButton();
                }
                if (success && onSuccess != null) onSuccess.run();
            });
        }).start();
    }
    private void displayProfile(UserProfile profile) {
        // 自己的资料不显示\"关注\"以及加好友、打招呼、发私信、拉黑用户等针对他人的操作。
        boolean ownProfile = isOwnProfile();
        boolean loggedIn = !ownProfile
                && FollowStateManager.isLoggedIn(this)
                && !TextUtils.isEmpty(targetUid);
        binding.layoutProfileActions.setVisibility(loggedIn ? View.VISIBLE : View.GONE);
        binding.btnProfileFollow.setVisibility(loggedIn ? View.VISIBLE : View.GONE);
        if (loggedIn) {
            if (serverFollowStateKnown) {
                binding.btnProfileFollow.setEnabled(!requestInFlight);
                binding.btnProfileFollow.setText(serverFollowed
                        ? R.string.action_followed : R.string.action_follow);
                binding.btnProfileFollow.setOnClickListener(v -> toggleFollowProfile());
            } else {
                binding.btnProfileFollow.setEnabled(false);
                binding.btnProfileFollow.setText("状态同步中");
                binding.btnProfileFollow.setOnClickListener(null);
            }
            // 好友按钮：根据服务端好友状态切换
            updateFriendButton();
            // 拉黑按钮：根据服务端黑名单状态切换
            updateBlockButton();
        } else {
            binding.btnProfileFollow.setOnClickListener(null);
            binding.btnProfileFollow.setEnabled(false);
        }

        // 更新标题
        if (profile.getUsername() != null) {
            binding.toolbar.setTitle(profile.getUsername());
        }

        // 头像
        String avatarUrl = profile.getAvatarUrl();
        if (avatarUrl != null && !avatarUrl.isEmpty()) {
            Glide.with(this)
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(binding.ivAvatar);
        } else {
            binding.ivAvatar.setImageResource(R.drawable.ic_account);
        }

        // 用户名
        binding.tvUsername.setText(profile.getUsername() != null ? profile.getUsername() : "未知用户");

        // UID
        binding.tvUid.setText("UID: " + (profile.getUid() != null ? profile.getUid() : "—"));

        // 等级
        binding.tvLevel.setText(profile.getLevel() != null ? profile.getLevel() : "");

        // 用户组
        binding.tvGroup.setText(profile.getGroupName() != null ? profile.getGroupName() : "");

        // 五列统计
        binding.tvThreads.setText(String.valueOf(profile.getThreads()));
        binding.tvReplies.setText(String.valueOf(profile.getPosts()));
        binding.tvFriends.setText(String.valueOf(profile.getFriends()));
        // 目标用户资料页必须显示目标用户自己的服务端关注数，不能套用当前账号的本地关注集合。
        binding.tvFollowing.setText(String.valueOf(profile.getFollowing()));
        binding.tvFollowers.setText(String.valueOf(profile.getFollowers()));

        // 积分/金币/在线时长
        binding.tvCredits.setText(String.valueOf(profile.getCredits()));
        binding.tvGold.setText(String.valueOf(profile.getGold()));
        binding.tvOnlineTime.setText(profile.getOnlineTime() != null ? profile.getOnlineTime() : "0小时");

        // 账号信息
        binding.tvRegDate.setText(profile.getRegDate() != null ? profile.getRegDate() : "—");
        binding.tvLastVisit.setText(profile.getLastVisit() != null ? profile.getLastVisit() : "—");

        // 帖子统计项：查看该用户发布的全部帖子
        binding.layoutThreads.setOnClickListener(v -> {
            Intent intent = new Intent(this, SpaceThreadListActivity.class);
            intent.putExtra("mode", "uid_threads");
            intent.putExtra("uid", targetUid);
            intent.putExtra("username", binding.tvUsername.getText().toString());
            startActivity(intent);
        });

        // 回复统计项：查看该用户参与回复的帖子。
        binding.layoutReplies.setOnClickListener(v -> {
            Intent intent = new Intent(this, SpaceThreadListActivity.class);
            intent.putExtra("mode", "uid_replies");
            intent.putExtra("uid", targetUid);
            intent.putExtra("username", binding.tvUsername.getText().toString());
            startActivity(intent);
        });

        // 粉丝统计项：查看目标用户的粉丝，而不是当前登录账号的粉丝。
        binding.layoutFollowers.setOnClickListener(v -> {
            Intent intent = new Intent(this, FriendListActivity.class);
            intent.putExtra("mode", "followers");
            intent.putExtra("uid", targetUid);
            intent.putExtra("username", binding.tvUsername.getText().toString());
            startActivity(intent);
        });

        // 性别
        String genderText = "保密";
        if ("boy".equals(profile.getGender())) {
            genderText = "男 ♂";
        } else if ("girl".equals(profile.getGender())) {
            genderText = "女 ♀";
        }
        binding.tvGender.setText(genderText);
    }

    private void toggleFollowProfile() {
        if (TextUtils.isEmpty(targetUid) || requestInFlight || !serverFollowStateKnown) return;
        // 切换目标状态只能基于当前网页端刚返回的状态，不能读取本地 SharedPreferences。
        final boolean targetState = !serverFollowed;
        requestInFlight = true;
        binding.btnProfileFollow.setEnabled(false);
        new Thread(() -> {
            boolean success = FollowStateManager.syncFollow(UserProfileActivity.this, targetUid, targetState);
            if (success) {
                // 操作后立即从网页端读取并确认，确认前不直接修改按钮状态。
                runOnUiThread(() -> {
                    Toast.makeText(this, targetState
                            ? R.string.action_follow_success
                            : R.string.action_unfollow_success, Toast.LENGTH_SHORT).show();
                    requestInFlight = false;
                    loadUserProfile();
                });
            } else {
                runOnUiThread(() -> {
                    requestInFlight = false;
                    binding.btnProfileFollow.setEnabled(serverFollowStateKnown);
                    Toast.makeText(this, "关注操作失败，请稍后重试", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        requestInFlight = false;
        binding = null;
        super.onDestroy();
    }
}