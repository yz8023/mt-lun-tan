package com.forum.MT.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.ForumCategory;
import com.forum.MT.ui.widget.CardBorderManager;
import com.forum.MT.ui.widget.ForumCardColorManager;
import com.forum.MT.ui.widget.RainbowBorderDrawable;

import java.util.ArrayList;
import java.util.List;

/**
 * 板块网格适配器 — 2列网格展示所有子版块
 */
public class ForumGridAdapter extends RecyclerView.Adapter<ForumGridAdapter.ViewHolder> {

    private final List<ForumCategory.Forum> forumList = new ArrayList<>();
    private final Context context;
    private OnForumClickListener listener;

    public interface OnForumClickListener {
        void onForumClick(ForumCategory.Forum forum, int position);
    }

    public ForumGridAdapter(Context context) {
        this.context = context;
    }

    public void setForumList(List<ForumCategory.Forum> list) {
        forumList.clear();
        if (list != null) forumList.addAll(list);
        notifyDataSetChanged();
    }

    public void setOnForumClickListener(OnForumClickListener listener) {
        this.listener = listener;
    }

    /**
     * 更新单个版块的描述文本并刷新对应项
     * @param forum 要更新的版块对象
     * @param description 新描述文本
     */
    public void updateDescription(ForumCategory.Forum forum, String description) {
        int index = forumList.indexOf(forum);
        if (index >= 0) {
            forum.setDescription(description);
            notifyItemChanged(index);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_forum_grid, parent, false);
        float density = context.getResources().getDisplayMetrics().density;
        // 若设置了自定义板块颜色，使用纯色背景（覆盖所有边框设置）
        if (ForumCardColorManager.getCustomColor() != 0) {
            view.setBackground(ForumCardColorManager.createCardBackground(context));
        } else if (CardBorderManager.isEnabled()) {
            // 卡片边框效果开启时使用静态描边
            CardBorderManager.applyBorder(view, 14f);
        } else {
            view.setBackground(new RainbowBorderDrawable(0xFFFFFFFF, 14f * density, density));
        }
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ForumCategory.Forum forum = forumList.get(position);
        holder.tvName.setText(forum.getName());

        // 自定义板块颜色时调整文字颜色以保证可读性
        if (ForumCardColorManager.getCustomColor() != 0) {
            int textColor = ForumCardColorManager.isDarkText()
                    ? 0xFF212121 : 0xFFFFFFFF;
            holder.tvName.setTextColor(textColor);
            holder.tvDesc.setTextColor(ForumCardColorManager.isDarkText()
                    ? 0xFF757575 : 0xCCFFFFFF);
            holder.tvPosts.setTextColor(ForumCardColorManager.isDarkText()
                    ? 0xFFE91E63 : 0xFFFFFFFF);
        } else {
            holder.tvName.setTextColor(0xFF212121);
            holder.tvDesc.setTextColor(0xFF757575);
            holder.tvPosts.setTextColor(0xFFE91E63);
        }

        // 描述：优先使用已有 description，否则显示空（等待异步加载）
        String desc = forum.getDescription();
        if (desc == null || desc.isEmpty()) {
            desc = "";
        }
        holder.tvDesc.setText(desc);

        // 今日新帖数（来自版块列表页徽章）
        int newPosts = forum.getTodayPosts();
        holder.tvPosts.setText("今日" + newPosts);

        // 图标
        String iconUrl = forum.getIconUrl();
        if (iconUrl != null && !iconUrl.isEmpty()) {
            Glide.with(context)
                    .load(iconUrl)
                    .placeholder(R.drawable.ic_circle)
                    .circleCrop()
                    .into(holder.ivIcon);
        } else {
            holder.ivIcon.setImageResource(R.drawable.ic_circle);
        }

        // 点击事件
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onForumClick(forum, position);
            }
        });
    }

    private String formatForumCount(int count) {
        if (count >= 10000) {
            return String.format(java.util.Locale.getDefault(), "%.2f万", count / 10000.0);
        }
        return String.valueOf(count);
    }

    @Override
    public int getItemCount() {
        return forumList.size();
    }

    @Override
    public void onViewAttachedToWindow(@NonNull ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        holder.itemView.getBackground().setVisible(true, false);
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull ViewHolder holder) {
        holder.itemView.getBackground().setVisible(false, false);
        super.onViewDetachedFromWindow(holder);
    }

    @Override
    public void onViewRecycled(@NonNull ViewHolder holder) {
        holder.itemView.getBackground().setVisible(false, false);
        super.onViewRecycled(holder);
    }



    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivIcon;
        final TextView tvName;
        final TextView tvDesc;
        final TextView tvPosts;

        ViewHolder(View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.iv_forum_icon);
            tvName = itemView.findViewById(R.id.tv_forum_name);
            tvDesc = itemView.findViewById(R.id.tv_forum_desc);
            tvPosts = itemView.findViewById(R.id.tv_forum_posts);
        }
    }
}
