package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理"显示大小"设置：帖子正文、隐藏内容、评论文字三种字号分别存储。
 * 存储单位为 0.1sp（避免整数 sp 粒度太粗），默认 15.0sp。
 */
public class ThreadTextSizeManager {

    private static final String PREFS_NAME = "mt_forum_prefs";
    private static final String KEY_THREAD_TEXT_SIZE = "thread_text_size";
    private static final String KEY_HIDDEN_TEXT_SIZE = "hidden_text_size";
    private static final String KEY_REPLY_TEXT_SIZE = "reply_text_size";
    private static final String KEY_EDIT_TIME_TEXT_SIZE = "edit_time_text_size";
    private static final String KEY_LIST_TEXT_SIZE = "list_text_size";
    private static final String KEY_CARD_TEXT_SIZE = "card_text_size";
    private static final String KEY_CARD_SCALE_PERCENT = "card_size_percent";

    /** 最小字号：10.0sp */
    public static final int MIN_TEXT_SIZE_TENTH = 100;
    /** 最大字号：32.0sp */
    public static final int MAX_TEXT_SIZE_TENTH = 320;
    /** 默认字号：15.0sp（帖子正文 / 帖子列表） */
    public static final int DEFAULT_TEXT_SIZE_TENTH = 150;
    /** 隐藏内容原本字号：14.0sp */
    public static final int DEFAULT_HIDDEN_TEXT_SIZE_TENTH = 140;
    /** 评论文字原本字号：14.0sp */
    public static final int DEFAULT_REPLY_TEXT_SIZE_TENTH = 140;
    /** 编辑时间原本字号：无独立默认（跟随所在容器），用 0 表示“跟随容器” */
    public static final int DEFAULT_EDIT_TIME_TEXT_SIZE_TENTH = 0;

    /** 作用域：帖子正文 */
    public static final int MODE_THREAD = 0;
    /** 作用域：隐藏内容 */
    public static final int MODE_HIDDEN = 1;
    /** 作用域：评论文字 */
    public static final int MODE_REPLY = 2;
    /** 作用域：编辑时间文字（"本帖最后由…编辑"） */
    public static final int MODE_EDIT_TIME = 3;
    /** 作用域：帖子列表（标题/摘要） */
    public static final int MODE_LIST = 4;
    /** 作用域：帖子列表卡片大小（内边距/外边距/头像） */
    public static final int MODE_CARD = 5;

    private static String keyFor(int mode) {
        switch (mode) {
            case MODE_HIDDEN: return KEY_HIDDEN_TEXT_SIZE;
            case MODE_REPLY: return KEY_REPLY_TEXT_SIZE;
            case MODE_EDIT_TIME: return KEY_EDIT_TIME_TEXT_SIZE;
            case MODE_LIST: return KEY_LIST_TEXT_SIZE;
            case MODE_CARD: return KEY_CARD_TEXT_SIZE;
            case MODE_THREAD:
            default: return KEY_THREAD_TEXT_SIZE;
        }
    }

    private static int getTenth(Context context, int mode) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int def = defaultTenthFor(mode);
        int v = prefs.getInt(keyFor(mode), def);
        if (v < MIN_TEXT_SIZE_TENTH || v > MAX_TEXT_SIZE_TENTH) {
            v = def;
        }
        return v;
    }

    private static int defaultTenthFor(int mode) {
        switch (mode) {
            case MODE_HIDDEN: return DEFAULT_HIDDEN_TEXT_SIZE_TENTH;
            case MODE_REPLY: return DEFAULT_REPLY_TEXT_SIZE_TENTH;
            case MODE_EDIT_TIME: return DEFAULT_EDIT_TIME_TEXT_SIZE_TENTH;
            case MODE_CARD: return 100;
            case MODE_THREAD:
            case MODE_LIST:
            default: return DEFAULT_TEXT_SIZE_TENTH;
        }
    }

    /**
     * 获取指定作用域的字号（sp）
     */
    public static float getTextSizeSp(Context context, int mode) {
        return getTenth(context, mode) / 10f;
    }

    /**
     * 获取帖子正文字号（sp）[兼容旧调用]
     */
    public static float getTextSizeSp(Context context) {
        return getTextSizeSp(context, MODE_THREAD);
    }

    /**
     * 获取指定作用域的存储值（0.1sp）
     */
    public static int getTextSizeTenth(Context context, int mode) {
        return getTenth(context, mode);
    }

    /**
     * 保存指定作用域的字号（0.1sp，自动钳制在 [MIN, MAX]）
     */
    public static void setTextSizeTenth(Context context, int mode, int tenthSp) {
        if (tenthSp < MIN_TEXT_SIZE_TENTH) tenthSp = MIN_TEXT_SIZE_TENTH;
        if (tenthSp > MAX_TEXT_SIZE_TENTH) tenthSp = MAX_TEXT_SIZE_TENTH;
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(keyFor(mode), tenthSp).apply();
        notifyTextSizeChanged();
    }

    /**
     * 保存帖子正文字号（0.1sp）[兼容旧调用]
     */
    public static void setTextSizeTenth(Context context, int tenthSp) {
        setTextSizeTenth(context, MODE_THREAD, tenthSp);
    }

    /**
     * 将所有"显示大小"恢复默认值（清除全部相关 key）
     */
    public static void resetAll(Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_THREAD_TEXT_SIZE)
                .remove(KEY_HIDDEN_TEXT_SIZE)
                .remove(KEY_REPLY_TEXT_SIZE)
                .remove(KEY_EDIT_TIME_TEXT_SIZE)
                .remove(KEY_LIST_TEXT_SIZE)
                .remove(KEY_CARD_TEXT_SIZE)
                .remove(KEY_CARD_SCALE_PERCENT)
                .apply();
        notifyTextSizeChanged();
    }

    /**
     * 获取帖子卡片缩放百分比（100 = 原本布局大小）
     */
    public static int getCardScalePercent(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int v = prefs.getInt(KEY_CARD_SCALE_PERCENT, 170);
        if (v < 50) v = 50;
        if (v > 250) v = 250;
        return v;
    }

    /**
     * 保存帖子卡片缩放百分比（50~250，默认100）
     */
    public static void setCardScalePercent(Context context, int percent) {
        if (percent < 50) percent = 50;
        if (percent > 250) percent = 250;
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_CARD_SCALE_PERCENT, percent).apply();
        notifyTextSizeChanged();
    }

    // ================= 全局变更监听（用于列表即时刷新） =================
    private static Runnable textSizeChangeListener;

    /** 注册全局字号变更监听器（同一时刻仅保留一个，调用方负责管理生命周期） */
    public static void setTextSizeChangeListener(Runnable listener) {
        textSizeChangeListener = listener;
    }

    public static void unregisterTextSizeChangeListener() {
        textSizeChangeListener = null;
    }

    private static void notifyTextSizeChanged() {
        Runnable l = textSizeChangeListener;
        if (l != null) {
            try {
                l.run();
            } catch (Throwable ignored) {
            }
        }
    }
}