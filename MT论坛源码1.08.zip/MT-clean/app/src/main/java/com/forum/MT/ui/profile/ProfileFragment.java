package com.forum.MT.ui.profile;
import com.forum.MT.ui.BaseFragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.databinding.FragmentProfileBinding;
import com.forum.MT.model.UserProfile;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.session.UserSessionManager;
import com.forum.MT.ui.space.UserProfileActivity;
import android.widget.EditText;
import android.widget.Toast;
import com.forum.MT.adapter.WallMessageAdapter;
import com.forum.MT.model.Message;
import com.forum.MT.session.DiscuzUserActionManager;
import com.forum.MT.ui.widget.BackgroundColorManager;
import com.forum.MT.ui.widget.RainbowBorderHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.appcompat.app.AlertDialog;
import android.content.res.Configuration;
import androidx.activity.OnBackPressedCallback;
import android.view.WindowManager;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.forum.MT.ui.login.LoginActivity;
import com.forum.MT.ui.space.SpaceThreadListActivity;
import com.forum.MT.ui.space.FriendListActivity;
import com.forum.MT.ui.space.CreditDetailActivity;
import com.forum.MT.ui.space.EditProfileActivity;
import com.forum.MT.ui.space.SettingsActivity;
import com.forum.MT.ui.blackhouse.BlackHouseActivity;
import com.forum.MT.ui.history.BrowseHistoryActivity;
import java.util.List;

/**
 * 个人中心 Fragment（全新 UI）
 * 展示用户完整资料信息：头像、用户名、UID、等级、用户组、
 * 帖子/回复/好友/粉丝统计、积分/金币/在线时长、注册信息、
 * 功能菜单（我的帖子、收藏、好友、积分详情、编辑资料、设置）
 */
public class ProfileFragment extends BaseFragment {

    private FragmentProfileBinding binding;
    private HttpClient httpClient;
    private static final int REQUEST_CODE_LOGIN = 100;

    // 留言板覆盖层
    private WallMessageAdapter wallAdapter;
    private boolean wallSending;
    private boolean wallLoading;
    private int wallCurrentPage = 1;
    private int wallMaxPage = 1;
    private int wallRequestGeneration;
    private String ownUid;
    private boolean destroyed;
    private OnBackPressedCallback wallBackCallback;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RainbowBorderHelper.applyToCardViews(view, requireContext());

        // 留言覆盖层打开时，返回键关闭弹窗而非退出 Fragment
        wallBackCallback = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                closeWallOverlay();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(
                getViewLifecycleOwner(), wallBackCallback);

        httpClient = HttpClient.getInstance();

        // === 点击统计项：跳转到对应原生列表页 ===
        binding.layoutThreads.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), SpaceThreadListActivity.class);
            intent.putExtra("mode", "my_threads");
            startActivity(intent);
        });
        binding.layoutReplies.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), SpaceThreadListActivity.class);
            intent.putExtra("mode", "my_replies");
            startActivity(intent);
        });
        binding.layoutFriends.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), FriendListActivity.class);
            intent.putExtra("mode", "friends");
            startActivity(intent);
        });
        binding.btnWallBoard.setOnClickListener(v -> showWallOverlay());
        binding.layoutFollowing.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), FriendListActivity.class);
            intent.putExtra("mode", "following");
            startActivity(intent);
        });
        binding.layoutFollowers.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), FriendListActivity.class);
            intent.putExtra("mode", "followers");
            startActivity(intent);
        });

        // === 功能菜单 ===
        binding.layoutMyFavorites.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), SpaceThreadListActivity.class);
            intent.putExtra("mode", "favorites");
            startActivity(intent);
        });

        // 积分/金币/在线 点击进入积分详情
        View.OnClickListener creditDetailListener = v -> {
            Intent intent = new Intent(requireContext(), CreditDetailActivity.class);
            startActivity(intent);
        };
        binding.layoutCredits.setOnClickListener(creditDetailListener);
        binding.layoutGold.setOnClickListener(creditDetailListener);
        binding.layoutOnlineTime.setOnClickListener(creditDetailListener);

        binding.btnEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), EditProfileActivity.class);
            startActivity(intent);
        });

        binding.layoutSettings.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), SettingsActivity.class);
            startActivity(intent);
        });

        binding.layoutBlackHouse.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), BlackHouseActivity.class);
            startActivity(intent);
        });

        binding.layoutBrowseHistory.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), BrowseHistoryActivity.class);
            startActivity(intent);
        });

    // 退出登录/登录按钮
        binding.btnLogout.setOnClickListener(v -> {
            if (!isActuallyLoggedIn()) {
                startLogin();
                return;
            }
            httpClient.clearCookies(requireContext());
            UserSessionManager.getInstance().clearLoginInfo(requireContext());
            updateLoginState();
            android.widget.Toast.makeText(requireContext(),
                    "已退出登录", android.widget.Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        updateLoginState();
    }

    /**
     * 根据登录状态切换 UI
     */
    private boolean isActuallyLoggedIn() {
        return httpClient.isLoggedIn()
                && UserSessionManager.getInstance().isLoggedIn(requireContext());
    }

    private void startLogin() {
        if (!isAdded()) return;
        Intent intent = new Intent(requireContext(), LoginActivity.class);
        startActivityForResult(intent, REQUEST_CODE_LOGIN);
    }

    private void updateLoginState() {
        if (!isActuallyLoggedIn()) {
            // 未登录时保留个人中心页面，只显示登录入口；不要在 onResume 中反复启动 LoginActivity。
            binding.getRoot().setVisibility(View.VISIBLE);
            binding.tvUsername.setText("未登录");
            binding.tvUid.setText("登录后查看个人资料");
            binding.tvLevel.setText("");
            binding.tvGroup.setText("");
            binding.ivAvatar.setImageResource(R.drawable.ic_account);
            binding.ivAvatar.setOnClickListener(v -> startLogin());
            binding.tvUsername.setOnClickListener(v -> startLogin());
            binding.tvUid.setOnClickListener(v -> startLogin());
            binding.btnLogout.setText("登录账号");
            // 未登录时这颗按钮的语义是"去登录"，用主题色描边而不是红色警示色。
            binding.btnLogout.setBackgroundResource(R.drawable.rounded_btn_outline);
            binding.btnLogout.setTextColor(androidx.core.content.ContextCompat.getColor(
                    requireContext(), R.color.primary));
            return;
        }
        binding.getRoot().setVisibility(View.VISIBLE);
        binding.btnLogout.setText(getString(R.string.action_logout));
        binding.btnLogout.setBackgroundResource(R.drawable.bg_logout_outline);
        binding.btnLogout.setTextColor(0xFFF44336);
        loadProfile();
    }

    /**
     * 加载用户资料
     * 先请求服务端；如果服务端返回登录页（Cookie 过期），清除 Cookie 并跳转登录页
     */
    /** 双击底部导航栏时触发：重新加载个人页数据 */
    public void refreshData() {
        loadProfile();
    }

    private void loadProfile() {
        new Thread(() -> {
            try {
                // ★ 修复：使用空间首页 URL 并附加当前 uid 参数（确保获取到完整的个人空间主页）
                // 单纯 home.php?mod=space&mobile=2 可能不展示完整统计数据
                String loginUid = UserSessionManager.getInstance().getUid(requireContext());
                String profileUrl;
                if (!TextUtils.isEmpty(loginUid)) {
                    profileUrl = HttpClient.BASE_URL + "home.php?mod=space&uid=" + loginUid + "&mobile=2";
                } else {
                    profileUrl = HttpClient.BASE_URL + "home.php?mod=space&mobile=2";
                }
                String html = httpClient.get(profileUrl);

                // === 关键修复：检测服务器是否返回了登录页（Cookie 过期） ===
                if (ForumParser.isLoginPage(html)) {
                    // Cookie 已过期/无效，清除所有 Cookie 并跳转登录
                    if (!isAdded()) return;
                    requireActivity().runOnUiThread(() -> {
                        if (!isAdded()) return;
                        httpClient.clearCookies(requireContext());
                        UserSessionManager.getInstance().clearLoginInfo(requireContext());
                        Intent intent = new Intent(requireContext(), LoginActivity.class);
                        startActivityForResult(intent, REQUEST_CODE_LOGIN);
                        android.widget.Toast.makeText(requireContext(),
                                "登录已过期，请重新登录", android.widget.Toast.LENGTH_SHORT).show();
                    });
                    return;
                }

                // === 服务端确认已登录 → 正常解析用户资料 ===
                UserProfile profile = ForumParser.parseUserProfile(html);

                if (profile == null || profile.getUsername() == null) {
                    String altUrl = HttpClient.BASE_URL + "home.php?mod=space&do=profile&mobile=2";
                    String altHtml = httpClient.get(altUrl);
                    if (!isAdded()) return;
                    if (ForumParser.isLoginPage(altHtml)) {
                        requireActivity().runOnUiThread(() -> {
                            if (!isAdded()) return;
                            httpClient.clearCookies(requireContext());
                            UserSessionManager.getInstance().clearLoginInfo(requireContext());
                            Intent intent = new Intent(requireContext(), LoginActivity.class);
                            startActivityForResult(intent, REQUEST_CODE_LOGIN);
                        });
                        return;
                    }
                    profile = ForumParser.parseUserProfile(altHtml);
                }

                if (!isAdded()) return;
                final UserProfile finalProfile = profile;
                requireActivity().runOnUiThread(() -> {
                    if (!isAdded()) return;
                    if (finalProfile != null && finalProfile.getUsername() != null) {
                        displayProfile(finalProfile);
                    } else {
                        android.widget.Toast.makeText(requireContext(),
                                "无法加载用户资料，请确认已登录", android.widget.Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                if (!isAdded()) return;
                requireActivity().runOnUiThread(() -> {
                    if (!isAdded()) return;
                    android.widget.Toast.makeText(requireContext(),
                            "加载资料失败: " + e.getMessage(), android.widget.Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    /**
     * 将 UserProfile 展示到新 UI 控件
     */
    private void displayProfile(UserProfile profile) {
        // 保存登录信息
        java.util.Map<String, String> loginInfo = new java.util.HashMap<>();
        if (profile.getUsername() != null) loginInfo.put("username", profile.getUsername());
        if (profile.getUid() != null) loginInfo.put("uid", profile.getUid());
        if (profile.getAvatarUrl() != null) loginInfo.put("avatarUrl", profile.getAvatarUrl());
        if (profile.getLevel() != null) loginInfo.put("level", profile.getLevel());
        UserSessionManager.getInstance().saveLoginInfo(requireContext(), loginInfo);

        // 头像
        String avatarUrl = profile.getAvatarUrl();
        if (avatarUrl != null && !avatarUrl.isEmpty()) {
            Glide.with(this)
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(binding.ivAvatar);
        } else {
            binding.ivAvatar.setImageResource(R.drawable.ic_account);
        }

        // 用户名
        binding.tvUsername.setText(profile.getUsername() != null ? profile.getUsername() : "未知用户");

        // UID
        binding.tvUid.setText("UID: " + (profile.getUid() != null ? profile.getUid() : "—"));

        // 等级（绿色小徽章）
        binding.tvLevel.setText(profile.getLevel() != null ? profile.getLevel() : "");

        // 用户组
        binding.tvGroup.setText(profile.getGroupName() != null ? profile.getGroupName() : "");

        // 五列统计
        binding.tvThreads.setText(String.valueOf(profile.getThreads()));
        binding.tvReplies.setText(String.valueOf(profile.getPosts()));
        binding.tvFriends.setText(String.valueOf(profile.getFriends()));
        // 关注数以服务端个人资料为准，避免本地操作缓存与网页端实际关注关系不一致。
        // FollowStateManager 只记录本 App 操作过的 UID，不能代表账号的完整关注数。
        binding.tvFollowing.setText(String.valueOf(profile.getFollowing()));
        binding.tvFollowers.setText(String.valueOf(profile.getFollowers()));

        // 积分/金币/在线时长
        binding.tvCredits.setText(String.valueOf(profile.getCredits()));
        binding.tvGold.setText(String.valueOf(profile.getGold()));
        binding.tvOnlineTime.setText(profile.getOnlineTime() != null ? profile.getOnlineTime() : "0小时");

        // 账号信息
        binding.tvRegDate.setText(profile.getRegDate() != null ? profile.getRegDate() : "—");
        binding.tvLastVisit.setText(profile.getLastVisit() != null ? profile.getLastVisit() : "—");

        // 性别
        String genderText = "保密";
        if ("boy".equals(profile.getGender())) {
            genderText = "男 ♂";
        } else if ("girl".equals(profile.getGender())) {
            genderText = "女 ♀";
        }
        binding.tvGender.setText(genderText);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_LOGIN && resultCode == android.app.Activity.RESULT_OK) {
            updateLoginState();
        }
    }

    // ===================== 留言板覆盖层 =====================

    private void showWallOverlay() {
        if (binding == null) return;
        ownUid = UserSessionManager.getInstance().getUid(requireContext());
        if (TextUtils.isEmpty(ownUid) || "0".equals(ownUid)) {
            Toast.makeText(requireContext(), "请先登录", Toast.LENGTH_SHORT).show();
            return;
        }

        // 切到 adjustNothing，键盘弹出时只位移输入栏，不动整个弹窗
        requireActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        setupWallImeInsets();

        applyWallOverlaySize();
        binding.layoutWallOverlay.setVisibility(View.VISIBLE);
        // 隐藏底部导航栏，避免覆盖弹窗
        View navBar = requireActivity().findViewById(R.id.bottom_nav_container);
        if (navBar != null) navBar.setVisibility(View.GONE);
        binding.tvWallTitle.setText("我的留言");
        binding.tvWallBack.setOnClickListener(v -> closeWallOverlay());
        binding.wallEmpty.setVisibility(View.GONE);
        binding.wallSend.setEnabled(false);

        if (wallAdapter == null) {
            wallAdapter = new WallMessageAdapter(requireContext());
            wallAdapter.setListener((message, position) -> openWallAuthorProfile(message));
            wallAdapter.setActionListener(new WallMessageAdapter.OnActionClickListener() {
                @Override
                public void onEdit(Message message, int position) {
                    showEditWallMessageDialog(message);
                }
                @Override
                public void onDelete(Message message, int position) {
                    confirmDeleteWallMessage(message);
                }
                @Override
                public void onReply(Message message, int position) {
                    showReplyWallMessageDialog(message);
                }
            });
            binding.wallRecycler.setLayoutManager(new LinearLayoutManager(requireContext()));
            binding.wallRecycler.setAdapter(wallAdapter);
        }

        binding.wallInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (wallSending) return;
                binding.wallSend.setEnabled(!TextUtils.isEmpty(s.toString().trim()));
            }
            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });

        binding.wallSend.setOnClickListener(v -> sendWallMessage());
        binding.wallPreviousPage.setOnClickListener(v -> {
            if (!wallLoading && wallCurrentPage > 1) loadWallMessages(wallCurrentPage - 1);
        });
        binding.wallNextPage.setOnClickListener(v -> {
            if (!wallLoading && wallCurrentPage < wallMaxPage) loadWallMessages(wallCurrentPage + 1);
        });
        wallCurrentPage = 1;
        wallMaxPage = 1;
        updateWallPagination();
        loadWallMessages(1);
        if (wallBackCallback != null) wallBackCallback.setEnabled(true);
    }

    private void closeWallOverlay() {
        if (binding == null) return;
        // 恢复 adjustResize，清理 IME insets 监听
        requireActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        View decorView = requireActivity().getWindow().getDecorView();
        ViewCompat.setOnApplyWindowInsetsListener(decorView, null);
        binding.layoutWallOverlay.setVisibility(View.GONE);
        // 恢复底部导航栏
        View navBar = requireActivity().findViewById(R.id.bottom_nav_container);
        if (navBar != null) navBar.setVisibility(View.VISIBLE);
        binding.wallInputBar.setTranslationY(0f);
        binding.wallInput.setText("");
        if (wallBackCallback != null) wallBackCallback.setEnabled(false);
    }

    /** adjustNothing 下，手动监听 IME insets，仅将输入栏抬到软键盘上方。 */
    private void setupWallImeInsets() {
        View decorView = requireActivity().getWindow().getDecorView();
        ViewCompat.setOnApplyWindowInsetsListener(decorView, (view, windowInsets) -> {
            Insets imeInsets = windowInsets.getInsets(WindowInsetsCompat.Type.ime());
            Insets systemBarInsets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            boolean imeVisible = windowInsets.isVisible(WindowInsetsCompat.Type.ime());
            int imeOffset = imeVisible
                    ? Math.max(0, imeInsets.bottom - systemBarInsets.bottom)
                    : 0;
            if (binding != null) {
                binding.wallInputBar.setTranslationY(-imeOffset);
            }
            return windowInsets;
        });
        decorView.post(() -> ViewCompat.requestApplyInsets(decorView));
    }

    private void applyWallOverlaySize() {
        if (binding == null) return;
        ViewGroup.LayoutParams params = binding.layoutWallOverlay.getLayoutParams();
        boolean landscape = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = landscape
                ? ViewGroup.LayoutParams.MATCH_PARENT
                : Math.max(1, getResources().getDisplayMetrics().heightPixels * 2 / 3);
        binding.layoutWallOverlay.setLayoutParams(params);
        binding.layoutWallOverlay.setBackgroundColor(BackgroundColorManager.resolveColor());
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (binding != null && binding.layoutWallOverlay.getVisibility() == View.VISIBLE) {
            applyWallOverlaySize();
        }
    }

    private void openWallAuthorProfile(Message message) {
        if (message == null || binding == null) return;
        String authorUid = message.getAuthorUid();
        if (TextUtils.isEmpty(authorUid) || "0".equals(authorUid)) {
            Toast.makeText(requireContext(), "无法获取该用户的UID", Toast.LENGTH_SHORT).show();
            return;
        }
        if (authorUid.equals(ownUid)) {
            closeWallOverlay();
            return;
        }
        Intent intent = new Intent(requireContext(), UserProfileActivity.class);
        intent.putExtra("uid", authorUid);
        intent.putExtra("username", message.getAuthor());
        startActivity(intent);
    }

    private void loadWallMessages(int requestedPage) {
        if (binding == null || wallLoading || requestedPage < 1) return;
        final int generation = ++wallRequestGeneration;
        wallLoading = true;
        binding.wallProgress.setVisibility(View.VISIBLE);
        binding.wallEmpty.setVisibility(View.GONE);
        updateWallPagination();

        new Thread(() -> {
            String html = null;
            String error = null;
            try {
                if (httpClient == null) httpClient = HttpClient.getInstance();
                if (!httpClient.isLoggedIn()) httpClient.syncFromCookieManager();
                html = httpClient.get(HttpClient.BASE_URL
                        + "home.php?mod=space&uid=" + ownUid
                        + "&do=wall&mobile=2&page=" + requestedPage);
                if (ForumParser.isLoginPage(html)) error = "登录已过期，请重新登录";
            } catch (Exception e) {
                error = "留言加载失败";
            }
            final String resultHtml = html;
            final String resultError = error;
            requireActivity().runOnUiThread(() -> {
                if (binding == null || destroyed || generation != wallRequestGeneration) return;
                wallLoading = false;
                binding.wallProgress.setVisibility(View.GONE);
                if (resultError != null) {
                    binding.wallEmpty.setVisibility(View.VISIBLE);
                    binding.wallEmpty.setText(resultError);
                    updateWallPagination();
                    Toast.makeText(requireContext(), resultError, Toast.LENGTH_SHORT).show();
                    return;
                }
                List<Message> messages = ForumParser.parseWallMessages(resultHtml);
                wallCurrentPage = requestedPage;
                wallMaxPage = Math.max(wallCurrentPage, ForumParser.parseWallMaxPage(resultHtml));
                if (wallAdapter != null) wallAdapter.setList(messages);
                binding.wallEmpty.setText("暂无留言，来抢沙发吧～");
                binding.wallEmpty.setVisibility(messages.isEmpty() ? View.VISIBLE : View.GONE);
                if (!messages.isEmpty()) binding.wallRecycler.scrollToPosition(0);
                updateWallPagination();
            });
        }, "wall-load-" + requestedPage).start();
    }

    private void updateWallPagination() {
        if (binding == null) return;
        boolean hasMultiplePages = wallMaxPage > 1;
        binding.wallPagination.setVisibility(hasMultiplePages ? View.VISIBLE : View.GONE);
        binding.wallPageStatus.setText("第 " + wallCurrentPage + " / " + wallMaxPage + " 页");
        boolean previousEnabled = !wallLoading && wallCurrentPage > 1;
        boolean nextEnabled = !wallLoading && wallCurrentPage < wallMaxPage;
        binding.wallPreviousPage.setEnabled(previousEnabled);
        binding.wallPreviousPage.setAlpha(previousEnabled ? 1f : 0.38f);
        binding.wallNextPage.setEnabled(nextEnabled);
        binding.wallNextPage.setAlpha(nextEnabled ? 1f : 0.38f);
    }

    private void sendWallMessage() {
        if (binding == null || wallSending) return;
        String msg = binding.wallInput.getText() == null ? ""
                : binding.wallInput.getText().toString().trim();
        if (TextUtils.isEmpty(msg)) {
            Toast.makeText(requireContext(), "请输入留言内容", Toast.LENGTH_SHORT).show();
            return;
        }
        wallSending = true;
        binding.wallSend.setEnabled(false);
        new Thread(() -> {
            boolean success = false;
            try {
                if (httpClient == null) httpClient = HttpClient.getInstance();
                if (!httpClient.isLoggedIn()) httpClient.syncFromCookieManager();
                success = DiscuzUserActionManager.postWallMessage(
                        requireContext().getApplicationContext(), ownUid, msg);
            } catch (Exception ignored) {}
            final boolean ok = success;
            requireActivity().runOnUiThread(() -> {
                if (binding == null || destroyed) return;
                wallSending = false;
                binding.wallSend.setEnabled(false);
                if (ok) {
                    binding.wallInput.setText("");
                    binding.wallEmpty.setVisibility(View.GONE);
                    loadWallMessages(1);
                    Toast.makeText(requireContext(), "留言成功", Toast.LENGTH_SHORT).show();
                } else {
                    binding.wallSend.setEnabled(true);
                    Toast.makeText(requireContext(), "留言失败", Toast.LENGTH_SHORT).show();
                }
            });
        }, "wall-send").start();
    }

    private void showEditWallMessageDialog(Message message) {
        if (binding == null || message == null || TextUtils.isEmpty(message.getWallEditUrl())) return;
        EditText input = new EditText(requireContext());
        input.setHint("编辑留言内容");
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setGravity(android.view.Gravity.TOP);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad / 2, pad, pad / 2);
        String oldContent = message.getSummary() != null ? message.getSummary() : "";
        input.setText(oldContent);
        input.setSelection(oldContent.length());
        new AlertDialog.Builder(requireContext())
                .setTitle("编辑留言")
                .setView(input)
                .setPositiveButton("保存", (dialog, which) -> {
                    String newContent = input.getText().toString().trim();
                    if (TextUtils.isEmpty(newContent)) {
                        Toast.makeText(requireContext(), "留言内容不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.equals(newContent, oldContent)) {
                        Toast.makeText(requireContext(), "内容未修改", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    final String cid = extractWallCid(message.getWallEditUrl());
                    if (TextUtils.isEmpty(cid)) {
                        Toast.makeText(requireContext(), "无法获取留言ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(requireContext(), "正在保存…", Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        boolean success = DiscuzUserActionManager.editWallMessage(
                                requireContext().getApplicationContext(), cid, newContent);
                        requireActivity().runOnUiThread(() -> {
                            if (binding == null || destroyed) return;
                            if (success) {
                                Toast.makeText(requireContext(), "编辑成功", Toast.LENGTH_SHORT).show();
                                loadWallMessages(wallCurrentPage);
                            } else {
                                Toast.makeText(requireContext(), "编辑失败", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }, "wall-edit").start();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmDeleteWallMessage(Message message) {
        if (binding == null || message == null || TextUtils.isEmpty(message.getWallDeleteUrl())) return;
        new AlertDialog.Builder(requireContext())
                .setTitle("删除留言")
                .setMessage("确定删除这条留言吗？删除后不可恢复。")
                .setPositiveButton("删除", (dialog, which) -> {
                    final String cid = extractWallCid(message.getWallDeleteUrl());
                    if (TextUtils.isEmpty(cid)) {
                        Toast.makeText(requireContext(), "无法获取留言ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(requireContext(), "正在删除…", Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        boolean success = DiscuzUserActionManager.deleteWallMessage(
                                requireContext().getApplicationContext(), cid);
                        requireActivity().runOnUiThread(() -> {
                            if (binding == null || destroyed) return;
                            if (success) {
                                Toast.makeText(requireContext(), "删除成功", Toast.LENGTH_SHORT).show();
                                loadWallMessages(wallCurrentPage);
                            } else {
                                Toast.makeText(requireContext(), "删除失败", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }, "wall-delete").start();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showReplyWallMessageDialog(Message message) {
        if (binding == null || message == null || TextUtils.isEmpty(message.getWallReplyUrl())) return;
        EditText input = new EditText(requireContext());
        input.setHint("回复 @" + (TextUtils.isEmpty(message.getAuthor()) ? "该用户" : message.getAuthor()));
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setGravity(android.view.Gravity.TOP);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad / 2, pad, pad / 2);
        new AlertDialog.Builder(requireContext())
                .setTitle("回复留言")
                .setView(input)
                .setPositiveButton("回复", (dialog, which) -> {
                    String content = input.getText().toString().trim();
                    if (TextUtils.isEmpty(content)) {
                        Toast.makeText(requireContext(), "回复内容不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    final String cid = extractWallCid(message.getWallReplyUrl());
                    if (TextUtils.isEmpty(cid)) {
                        Toast.makeText(requireContext(), "无法获取留言ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(requireContext(), "正在回复…", Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        boolean success = DiscuzUserActionManager.replyWallMessage(
                                requireContext().getApplicationContext(), cid, content);
                        requireActivity().runOnUiThread(() -> {
                            if (binding == null || destroyed) return;
                            if (success) {
                                Toast.makeText(requireContext(), "回复成功", Toast.LENGTH_SHORT).show();
                                loadWallMessages(wallCurrentPage);
                            } else {
                                Toast.makeText(requireContext(), "回复失败", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }, "wall-reply").start();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private static String extractWallCid(String url) {
        if (TextUtils.isEmpty(url)) return null;
        try {
            android.net.Uri uri = android.net.Uri.parse(url);
            String cid = uri.getQueryParameter("cid");
            if (!TextUtils.isEmpty(cid)) return cid;
        } catch (Exception ignored) {}
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("[?&]cid=(\\d+)").matcher(url);
        if (m.find()) return m.group(1);
        return null;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        destroyed = true;
        binding = null;
    }
}