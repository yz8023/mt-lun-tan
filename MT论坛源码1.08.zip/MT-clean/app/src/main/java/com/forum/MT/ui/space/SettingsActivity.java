package com.forum.MT.ui.space;
import com.forum.MT.ui.BaseActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.forum.MT.R;
import com.forum.MT.databinding.ActivitySettingsBinding;
import com.forum.MT.ui.widget.RainbowBorderHelper;
import com.forum.MT.mcp.McpServerManager;

/**
 * 设置页（原生）
 * 展示应用信息和缓存清理功能
 */
public class SettingsActivity extends BaseActivity {

    private ActivitySettingsBinding binding;

    /**
     * 私信备份导出：SAF 创建文档。必须在字段初始化阶段注册（onCreate 之后
     * 调用 registerForActivityResult 会抛 IllegalStateException）。
     */
    private final androidx.activity.result.ActivityResultLauncher<String> exportLauncher =
            registerForActivityResult(
                    new androidx.activity.result.contract.ActivityResultContracts.CreateDocument(
                            "application/json"),
                    this::writeChatBackup);

    /** 私信备份导入：SAF 打开文档。 */
    private final androidx.activity.result.ActivityResultLauncher<String[]> importLauncher =
            registerForActivityResult(
                    new androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
                    this::readChatBackup);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        RainbowBorderHelper.applyToCardViews(binding.getRoot(), this);

        // 主题设置 — 点击进入子设置页
        binding.cardTheme.setOnClickListener(v ->
                startActivity(new Intent(this, ThemeSettingsActivity.class)));

        // 功能与关于分别进入子设置页
        binding.cardFunction.setOnClickListener(v ->
                startActivity(new Intent(this, FunctionSettingsActivity.class)));

        // MCP 服务：默认关闭，只允许本机令牌访问；工具层不读取任何登录态。
        McpServerManager mcp = McpServerManager.getInstance(getApplicationContext());
        updateMcpInfo(mcp);
        binding.switchMcp.setOnCheckedChangeListener((button, checked) -> {
            mcp.setEnabled(checked);
            updateMcpInfo(mcp);
            Toast.makeText(this, checked ? "MCP 服务已开启" : "MCP 服务已关闭", Toast.LENGTH_SHORT).show();
        });
        binding.btnMcpToken.setOnClickListener(v -> {
            mcp.regenerateToken();
            updateMcpInfo(mcp);
            Toast.makeText(this, "访问令牌已重新生成", Toast.LENGTH_SHORT).show();
        });
        binding.btnMcpCopy.setOnClickListener(v -> {
            mcp.copyTokenToClipboard(this);
            Toast.makeText(this, "令牌已复制到剪贴板", Toast.LENGTH_SHORT).show();
        });

        // 关于 — 点击进入子设置页
        binding.cardAbout.setOnClickListener(v ->
                startActivity(new Intent(this, AboutSettingsActivity.class)));

        // 清除本地私信记录
        updateChatHistoryInfo();
        binding.cardChatHistory.setOnClickListener(v -> confirmClearChatHistory());

        // 私信备份 / 恢复
        binding.btnChatExport.setOnClickListener(v -> startChatExport());
        binding.btnChatImport.setOnClickListener(v -> startChatImport());

        binding.toolbar.setNavigationOnClickListener(v -> finish());
        binding.toolbar.setNavigationIcon(null);

        // 缓存清除 — 点击显示缓存大小并清除
        updateCacheSize();
        binding.cardCache.setOnClickListener(v -> clearCache());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (binding != null) updateChatHistoryInfo();
    }

    /** 读库统计放子线程，避免设置页首帧被磁盘 IO 拖慢。 */
    private void updateChatHistoryInfo() {
        new Thread(() -> {
            long messages;
            long conversations;
            try {
                com.forum.MT.storage.ChatHistoryStore store =
                        com.forum.MT.storage.ChatHistoryStore.getInstance(this);
                messages = store.countMessages();
                conversations = store.countConversations();
            } catch (Exception e) {
                return;
            }
            final String text = messages == 0
                    ? "暂无本地记录"
                    : String.format(java.util.Locale.ROOT,
                            "已保存 %d 个会话、%d 条私信", conversations, messages);
            runOnUiThread(() -> {
                if (binding == null || isFinishing() || isDestroyed()) return;
                binding.tvChatHistoryInfo.setText(text);
            });
        }, "chat-history-info").start();
    }

    /**
     * 导出私信备份。用 SAF 让用户自选保存位置，避免申请存储权限，
     * 也便于直接存到网盘/下载目录再转移到别的设备。
     */
    private void startChatExport() {
        new Thread(() -> {
            long count;
            try {
                count = com.forum.MT.storage.ChatHistoryStore
                        .getInstance(getApplicationContext()).countMessages();
            } catch (Exception e) {
                count = -1;
            }
            final long total = count;
            runOnUiThread(() -> {
                if (binding == null || isFinishing() || isDestroyed()) return;
                if (total == 0) {
                    Toast.makeText(this, "暂无本地私信可导出", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    exportLauncher.launch(buildBackupFileName());
                } catch (Exception e) {
                    Toast.makeText(this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
                }
            });
        }, "chat-export-precheck").start();
    }

    private static String buildBackupFileName() {
        String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.ROOT)
                .format(new java.util.Date());
        return "MT_private_messages_" + stamp + ".json";
    }

    /** 写盘在子线程做：会话多时 JSON 序列化 + IO 可能达到数百毫秒。 */
    private void writeChatBackup(@Nullable android.net.Uri uri) {
        if (uri == null) return;
        Toast.makeText(this, "正在导出…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String error = null;
            long messages = 0;
            long conversations = 0;
            try {
                com.forum.MT.storage.ChatHistoryStore store =
                        com.forum.MT.storage.ChatHistoryStore.getInstance(getApplicationContext());
                messages = store.countMessages();
                conversations = store.countConversations();
                String json = store.exportToJson();
                java.io.OutputStream os = getContentResolver().openOutputStream(uri, "wt");
                if (os == null) throw new java.io.IOException("无法写入所选位置");
                try {
                    os.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    os.flush();
                } finally {
                    try { os.close(); } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String err = error;
            final long m = messages;
            final long c = conversations;
            runOnUiThread(() -> {
                if (binding == null || isFinishing() || isDestroyed()) return;
                if (err != null) {
                    Toast.makeText(this, "导出失败：" + err, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, String.format(java.util.Locale.ROOT,
                            "已导出 %d 个会话、%d 条私信", c, m), Toast.LENGTH_LONG).show();
                }
            });
        }, "chat-export").start();
    }

    /** 文件选择器用 * / * 过滤：部分文件管理器会把 .json 标成 octet-stream，限定 mime 会导致文件不可选。 */
    private void startChatImport() {
        try {
            importLauncher.launch(new String[]{"*/*"});
        } catch (Exception e) {
            Toast.makeText(this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
        }
    }

    private void readChatBackup(@Nullable android.net.Uri uri) {
        if (uri == null) return;
        Toast.makeText(this, "正在导入…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String error = null;
            int added = 0;
            int skipped = 0;
            try {
                java.io.InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new java.io.IOException("无法读取所选文件");
                String json;
                try {
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                    json = new String(bos.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
                } finally {
                    try { is.close(); } catch (Exception ignored) {}
                }
                int[] result = com.forum.MT.storage.ChatHistoryStore
                        .getInstance(getApplicationContext()).importFromJson(json);
                added = result[0];
                skipped = result[1];
            } catch (Exception e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String err = error;
            final int a = added;
            final int s = skipped;
            runOnUiThread(() -> {
                if (binding == null || isFinishing() || isDestroyed()) return;
                if (err != null) {
                    Toast.makeText(this, "导入失败：" + err, Toast.LENGTH_LONG).show();
                    return;
                }
                String msg = "已导入 " + a + " 条私信";
                if (s > 0) msg += "（跳过 " + s + " 条已存在）";
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                updateChatHistoryInfo();
            });
        }, "chat-import").start();
    }

    private void confirmClearChatHistory() {

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("清除本地私信记录")
                .setMessage("将删除本机保存的全部私信历史，此操作不可撤销。论坛服务器上未过期的私信不受影响。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清除", (dialog, which) -> clearChatHistory())
                .show();
    }

    private void clearChatHistory() {
        binding.cardChatHistory.setEnabled(false);
        new Thread(() -> {
            try {
                com.forum.MT.storage.ChatHistoryStore.getInstance(this).clearAll();
            } catch (Exception ignored) {}
            runOnUiThread(() -> {
                if (binding == null || isFinishing() || isDestroyed()) return;
                binding.cardChatHistory.setEnabled(true);
                Toast.makeText(this, "本地私信记录已清除", Toast.LENGTH_SHORT).show();
                updateChatHistoryInfo();
            });
        }, "chat-history-clear").start();
    }

    private void updateMcpInfo(McpServerManager mcp) {
        boolean enabled = mcp.isEnabled();
        binding.switchMcp.setChecked(enabled);
        binding.tvMcpSummary.setText(enabled
                ? "已开启；仅本机访问，9 个只读工具，认证信息永不输出"
                : "已关闭；默认禁止访问认证信息");
        binding.tvMcpEndpoint.setVisibility(enabled ? View.VISIBLE : View.GONE);
        binding.layoutMcpToken.setVisibility(enabled ? View.VISIBLE : View.GONE);
        if (enabled) {
            binding.tvMcpEndpoint.setText("端点：" + mcp.getEndpoint());
            binding.tvMcpTokenValue.setText(mcp.getToken());
        }
    }

    private void updateCacheSize() {
        try {
            java.io.File cacheDir = new java.io.File(getCacheDir(), "image_manager_disk_cache");
            if (!cacheDir.exists()) {
                binding.tvCacheSize.setText("0 B");
                return;
            }
            long size = getDirSize(cacheDir);
            binding.tvCacheSize.setText(formatSize(size));
        } catch (Exception e) {
            binding.tvCacheSize.setText("未知");
        }
    }

    private long getDirSize(java.io.File dir) {
        long size = 0;
        java.io.File[] files = dir.listFiles();
        if (files != null) {
            for (java.io.File f : files) {
                if (f.isDirectory()) {
                    size += getDirSize(f);
                } else {
                    size += f.length();
                }
            }
        }
        return size;
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    private void clearCache() {
        try {
            binding.cardCache.setEnabled(false);
            binding.tvCacheSize.setText("清除中…");
            new Thread(() -> {
                com.bumptech.glide.Glide.get(this).clearDiskCache();
                runOnUiThread(() -> {
                    com.bumptech.glide.Glide.get(this).clearMemory();
                    binding.cardCache.setEnabled(true);
                    Toast.makeText(this, "缓存已清除", Toast.LENGTH_SHORT).show();
                    updateCacheSize();
                });
            }).start();
        } catch (Exception e) {
            binding.cardCache.setEnabled(true);
            Toast.makeText(this, "清除失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}