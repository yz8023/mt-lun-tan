package com.forum.MT.ui.widget;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import androidx.cardview.widget.CardView;

/**
 * 为页面中的 CardView/MaterialCardView 统一挂载边框（流水灯或静态描边），
 * 并负责 RecyclerView 回收时的动画状态切换。
 *
 * 当 {@link CardBorderManager} 开启时使用静态描边，否则使用流水灯。
 */
public final class RainbowBorderHelper {

    private RainbowBorderHelper() {
    }

    /** 递归处理 root 下的所有 CardView（包含 root 自身）。 */
    public static void applyToCardViews(View root, Context context) {
        if (root == null || context == null) return;
        if (root instanceof CardView) {
            applyToCard((CardView) root, context);
        }
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = 0; i < group.getChildCount(); i++) {
                applyToCardViews(group.getChildAt(i), context);
            }
        }
    }

    /** 给单个卡片设置边框（卡片边框效果开启时用静态描边，否则用流水灯）。 */
    public static void applyToCard(CardView card, Context context) {
        if (card == null || context == null) return;
        float density = context.getResources().getDisplayMetrics().density;
        float radius = card.getRadius();
        if (radius <= 0f) radius = 12f * density;
        if (CardBorderManager.isEnabled()) {
            CardBorderManager.applyBorder(card, radius / density);
        } else {
            // 填充色沿用内容卡片自定义颜色（默认白色）
            card.setBackground(new RainbowBorderDrawable(
                    CardColorManager.resolveCardColor(), radius, density));
        }
    }

    /** RecyclerView 卡片创建时使用；root 可以是 CardView，也可以是包裹 CardView 的布局。 */
    public static void applyToItem(View root, Context context) {
        applyToCardViews(root, context);
    }

    /** 暂停/恢复 root 下所有流水灯 Drawable。 */
    public static void setVisible(View root, boolean visible) {
        if (root == null) return;
        if (root.getBackground() instanceof RainbowBorderDrawable) {
            root.getBackground().setVisible(visible, false);
        }
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = 0; i < group.getChildCount(); i++) {
                setVisible(group.getChildAt(i), visible);
            }
        }
    }
}