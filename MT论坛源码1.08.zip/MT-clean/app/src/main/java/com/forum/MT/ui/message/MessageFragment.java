package com.forum.MT.ui.message;
import com.forum.MT.ui.BaseFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.widget.ViewPager2;

import com.forum.MT.R;
import com.forum.MT.model.MessageTab;
import com.forum.MT.network.NoticeBadgeManager;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

/**
 * 消息主页面 Fragment — 嵌入在导航栏中，不跳转Activity
 * 对应官方APK的4Tab设计：私信/@我/帖子/系统通知
 *
 * 角标规则：
 *  - 进入本页不自动清零，各 Tab 显示「上次查看后新增」数量；
 *  - 点进某条后该条计为已读，对应 Tab 角标数字减少；
 *  - 标题栏右侧「全部已读」一键清零所有分类，且不影响下次新消息计数。
 */
public class MessageFragment extends BaseFragment implements NoticeBadgeHost {

    private MessageViewModel viewModel;
    private ViewPager2 viewPager;
    private TabLayout tabLayout;
    private NoticePagerAdapter pagerAdapter;
    private TextView tvClearAll;

    /** Tab 下标 → 分类 key（与 MainActivity/NoticeBadgeManager 一致） */
    private static final String[] TAB_VIEW_TYPES = {
            "pm", "mypost_at", "mypost_post", "other"
    };

    public String getViewTypeForTab(int tabIndex) {
        if (tabIndex < 0 || tabIndex >= TAB_VIEW_TYPES.length) return "";
        return TAB_VIEW_TYPES[tabIndex];
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_message, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(MessageViewModel.class);

        tabLayout = view.findViewById(R.id.tab_layout);
        viewPager = view.findViewById(R.id.view_pager);
        tvClearAll = view.findViewById(R.id.tv_clear_all);

        // 设置ViewPager2适配器 — 只预加载相邻1个Tab，避免一次性创建全部4个Fragment
        pagerAdapter = new NoticePagerAdapter(this);
        viewPager.setAdapter(pagerAdapter);
        viewPager.setOffscreenPageLimit(1); // 只预加载左右各1个，避免卡顿

        // 关联TabLayout和ViewPager2
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            tab.setText(MessageTab.fromIndex(position).getDisplayName());
        }).attach();

        // Tab切换时更新ViewModel的currentTab，并惰性加载数据
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                viewModel.setCurrentTab(MessageTab.fromIndex(position));
            }
        });

        // 显示各分类角标（进入不自动清零；保留直到逐条已读或点“全部已读”）
        updateTabBadges();
        viewModel.getOtherMessagesBadgesUpdated().observe(getViewLifecycleOwner(), value -> updateTabBadges());

        // 全部已读：清零所有分类角标并重置基线（不影响下次新消息统计）
        tvClearAll.setOnClickListener(v -> {
            // 先统计清除前各分类的未读数，用于反馈
            int totalBefore = 0;
            for (int i = 0; i < TAB_VIEW_TYPES.length; i++) {
                totalBefore += NoticeBadgeManager.getNewCount(requireContext(), TAB_VIEW_TYPES[i]);
            }
            NoticeBadgeManager.markAllViewed(requireContext());
            clearTabBadges();
            // ★ 立即同步底部导航栏角标（等 5 秒轮询会显得"没清除"）
            android.app.Activity activity = getActivity();
            if (activity instanceof com.forum.MT.MainActivity) {
                ((com.forum.MT.MainActivity) activity).refreshBottomBadgeNow();
            }
            if (totalBefore > 0) {
                android.widget.Toast.makeText(requireContext(),
                        "已全部标记为已读（" + totalBefore + " 条）", android.widget.Toast.LENGTH_SHORT).show();
            } else {
                android.widget.Toast.makeText(requireContext(),
                        "暂无未读消息", android.widget.Toast.LENGTH_SHORT).show();
            }
        });

        // 进入消息页时同步一次角标（从主界面轮询结果读取）
        viewModel.loadAll();

        // 应用消息页自定义背景颜色
        applyMessageColors();
        com.forum.MT.ui.widget.HomeBarColorManager.setListener(this::applyMessageColors);

        // 应用全局强调色到「全部已读」与 TabLayout
        applyAccentColors();
        com.forum.MT.ui.widget.AccentColorManager.setListener(this::applyAccentColors);
    }

    /**
     * 将「全部已读」链接与 TabLayout 选中色/指示条统一为全局强调色。
     */
    private void applyAccentColors() {
        if (getView() == null) return;
        int accent = com.forum.MT.ui.widget.AccentColorManager.resolveAccentColor();
        if (tvClearAll != null) tvClearAll.setTextColor(accent);
        if (tabLayout != null) {
            tabLayout.setTabTextColors(
                    getResources().getColor(R.color.text_secondary, null), accent);
            tabLayout.setSelectedTabIndicatorColor(accent);
        }
    }

    /** 应用消息页标题栏和Tab栏自定义背景颜色 */
    private void applyMessageColors() {
        if (getView() == null) return;
        int titleBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveMessageTitleBg();
        int tabBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveMessageTabBg();
        android.view.View layoutTitleBar = getView().findViewById(R.id.layout_title_bar);
        if (layoutTitleBar != null) {
            layoutTitleBar.setBackgroundColor(titleBg);
        }
        if (tabLayout != null) {
            tabLayout.setBackgroundColor(tabBg);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        com.forum.MT.ui.widget.AccentColorManager.setListener(null);
        com.forum.MT.ui.widget.HomeBarColorManager.setListener(null);
    }

    public MessageViewModel getViewModel() {
        return viewModel;
    }

    /** 双击底部导航栏时触发：重新加载消息列表 */
    public void refreshData() {
        if (viewModel != null) viewModel.loadAll();
    }

    /**
     * 从 NoticeBadgeManager 读取各分类新增数，更新 Tab 角标。
     * 仅在有新增时显示角标；无新增时隐藏。
     * Tab 4 "其它消息" 的角标 = follower + interactive + system + app 之和。
     */
    public void updateTabBadges() {
        if (tabLayout == null) return;
        for (int i = 0; i < TAB_VIEW_TYPES.length && i < tabLayout.getTabCount(); i++) {
            int count;
            if ("other".equals(TAB_VIEW_TYPES[i])) {
                count = NoticeBadgeManager.getNewCount(requireContext(), "follower")
                        + NoticeBadgeManager.getNewCount(requireContext(), "interactive")
                        + NoticeBadgeManager.getNewCount(requireContext(), "system")
                        + NoticeBadgeManager.getNewCount(requireContext(), "app");
            } else {
                count = NoticeBadgeManager.getNewCount(requireContext(), TAB_VIEW_TYPES[i]);
            }
            setTabBadge(i, count);
        }
    }

    private void setTabBadge(int tabIndex, int count) {
        TabLayout.Tab tab = tabLayout.getTabAt(tabIndex);
        if (tab == null) return;
        BadgeDrawable badge = tab.getOrCreateBadge();
        if (count > 0) {
            badge.setVisible(true);
            badge.setNumber(count);
            badge.setBadgeTextColor(getResources().getColor(R.color.white));
            badge.setBackgroundColor(getResources().getColor(R.color.red_500));
        } else {
            badge.setVisible(false);
            badge.clearNumber();
        }
    }

    private void clearTabBadges() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            setTabBadge(i, 0);
        }
    }

    /**
     * 某分类下的一条内容被标记已读后调用，刷新对应 Tab 角标。
     *
     * @param viewType 与 TAB_VIEW_TYPES 对应的分类 key，或子分类 key（follower/interactive/system/app）
     */
    @Override
    public void refreshTabBadge(String viewType) {
        if (tabLayout == null || viewType == null) return;
        // 子分类刷新时，刷新 Tab 4 "其它消息"
        if ("follower".equals(viewType) || "interactive".equals(viewType)
                || "system".equals(viewType) || "app".equals(viewType)) {
            int count = NoticeBadgeManager.getNewCount(requireContext(), "follower")
                    + NoticeBadgeManager.getNewCount(requireContext(), "interactive")
                    + NoticeBadgeManager.getNewCount(requireContext(), "system")
                    + NoticeBadgeManager.getNewCount(requireContext(), "app");
            setTabBadge(3, count);
        } else {
            for (int i = 0; i < TAB_VIEW_TYPES.length; i++) {
                if (TAB_VIEW_TYPES[i].equals(viewType)) {
                    int count = NoticeBadgeManager.getNewCount(requireContext(), viewType);
                    setTabBadge(i, count);
                    break;
                }
            }
        }

        // 条目已在本地标记为已读后，立即同步底部导航角标。
        // 网络轮询仍保留用于后续校准，但不再阻塞当前交互反馈。
        android.app.Activity activity = getActivity();
        if (activity instanceof com.forum.MT.MainActivity) {
            ((com.forum.MT.MainActivity) activity).refreshBottomBadgeNow();
        }
    }

    /** 供 Fragment 数据加载完成后刷新对应 Tab 角标（可选）。 */
    public void refreshTabBadge(int tabIndex) {
        if (tabIndex < 0 || tabIndex >= TAB_VIEW_TYPES.length || tabLayout == null) return;
        int count = NoticeBadgeManager.getNewCount(requireContext(), TAB_VIEW_TYPES[tabIndex]);
        setTabBadge(tabIndex, count);
    }
}