package com.forum.MT.ui.blackhouse;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.forum.MT.R;
import com.forum.MT.adapter.BlackHouseAdapter;
import com.forum.MT.databinding.ActivityBlackHouseBinding;
import com.forum.MT.model.BannedUser;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.ui.BaseActivity;
import com.forum.MT.ui.space.UserProfileActivity;
import com.forum.MT.ui.widget.AccentColorManager;

import java.util.List;

/**
 * 小黑屋页面。
 *
 * <p>数据来自 JSON API：
 * {@code forum.php?mod=misc&action=showdarkroom&cid={cid}&ajaxdata=json}
 *
 * <p>JSON 返回包含操作人（operator / operatorid）字段。
 * 支持分页加载：message 字段含下一页 cid。
 */
public class BlackHouseActivity extends BaseActivity {

    private static final String DARKROOM_API = "forum.php?mod=misc&action=showdarkroom&cid=%s&ajaxdata=json";

    private ActivityBlackHouseBinding binding;
    private HttpClient httpClient;
    private BlackHouseAdapter adapter;
    private String nextCid = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBlackHouseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        binding.toolbar.setTitle("小黑屋");

        // 强调色 Toolbar
        try {
            int accent = AccentColorManager.resolveAccentColor();
            binding.toolbar.setBackgroundColor(accent);
            binding.toolbar.setTitleTextColor(0xFFFFFFFF);
            binding.toolbar.setNavigationIconTint(0xFFFFFFFF);
        } catch (Exception ignored) {
        }

        // RecyclerView
        adapter = new BlackHouseAdapter(this);
        adapter.setOnUserClickListener(user -> {
            if (user.getUid() != null) {
                Intent intent = new Intent(this, UserProfileActivity.class);
                intent.putExtra("uid", user.getUid());
                startActivity(intent);
            }
        });
        adapter.setOnLoadMoreListener(this::loadMore);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);

        // SwipeRefresh
        binding.swipeRefresh.setOnRefreshListener(this::loadData);
        binding.swipeRefresh.setColorSchemeResources(R.color.primary);

        httpClient = HttpClient.getInstance();

        loadData();
    }

    private void loadData() {
        nextCid = "";
        binding.tvEmpty.setVisibility(View.GONE);
        if (!binding.swipeRefresh.isRefreshing()) {
            binding.progressBar.setVisibility(View.VISIBLE);
        }

        new Thread(() -> {
            ForumParser.DarkroomResult result = null;
            String errorMsg = null;
            try {
                String url = ForumParser.getBaseDomain() + String.format(DARKROOM_API, "");
                String json = httpClient.get(url);
                result = ForumParser.parseDarkroomJson(json);
            } catch (Exception e) {
                errorMsg = e != null ? e.getMessage() : "网络错误";
            }

            final ForumParser.DarkroomResult res = result;
            final String err = errorMsg;
            runOnUiThread(() -> {
                if (isDestroyed() || isFinishing()) return;
                binding.progressBar.setVisibility(View.GONE);
                binding.swipeRefresh.setRefreshing(false);

                if (res != null && !res.users.isEmpty()) {
                    nextCid = res.nextCid;
                    adapter.setItems(res.users);
                    binding.tvEmpty.setVisibility(View.GONE);
                    binding.recyclerView.scrollToPosition(0);
                } else {
                    adapter.setItems(null);
                    binding.tvEmpty.setVisibility(View.VISIBLE);
                    if (err != null) {
                        Toast.makeText(this, "加载失败: " + err, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }).start();
    }

    private void loadMore() {
        if (nextCid == null || nextCid.isEmpty() || nextCid.equals("0")) {
            adapter.setLoadingMore(false);
            return;
        }

        new Thread(() -> {
            ForumParser.DarkroomResult result = null;
            try {
                String url = ForumParser.getBaseDomain() + String.format(DARKROOM_API, nextCid);
                String json = httpClient.get(url);
                result = ForumParser.parseDarkroomJson(json);
            } catch (Exception e) {
                e.printStackTrace();
            }

            final ForumParser.DarkroomResult res = result;
            runOnUiThread(() -> {
                if (isDestroyed() || isFinishing()) return;
                if (res != null && !res.users.isEmpty()) {
                    nextCid = res.nextCid;
                    adapter.appendItems(res.users);
                } else {
                    // 没有更多数据
                    nextCid = "";
                    adapter.setLoadingMore(false);
                }
            });
        }).start();
    }
}
