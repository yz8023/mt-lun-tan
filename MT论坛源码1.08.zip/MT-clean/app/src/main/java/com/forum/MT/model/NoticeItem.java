package com.forum.MT.model;

/**
 * 通知条目 - 对应官方APK的NoticeItem
 * 适用于@我、帖子、系统通知等所有通知类型
 */
public class NoticeItem {
    private String noticeId;
    private String avatarUrl;
    private String username;
    private String uid;
    private String content;
    private String quote;
    private String threadTitle;
    private String threadUrl;
    private String pid;        // 回复ID（用于定位到具体楼层）
    private String time;
    private String type;       // reply/quote/at/post/comment/system
    private boolean isBold;    // 未读加粗

    public NoticeItem() {}

    public String getNoticeId() { return noticeId; }
    public void setNoticeId(String noticeId) { this.noticeId = noticeId; }

    public String getAvatarUrl() { return avatarUrl; }
    public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getQuote() { return quote; }
    public void setQuote(String quote) { this.quote = quote; }

    public String getThreadTitle() { return threadTitle; }
    public void setThreadTitle(String threadTitle) { this.threadTitle = threadTitle; }

    public String getThreadUrl() { return threadUrl; }
    public void setThreadUrl(String threadUrl) { this.threadUrl = threadUrl; }

    public String getPid() { return pid; }
    public void setPid(String pid) { this.pid = pid; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public boolean isBold() { return isBold; }
    public void setBold(boolean bold) { isBold = bold; }
}