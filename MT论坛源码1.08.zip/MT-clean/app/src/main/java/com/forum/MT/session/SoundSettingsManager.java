package com.forum.MT.session;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 提示音全局开关管理器。
 * 控制签到成功音效、私信消息音效、通知消息音效的统一开关。
 */
public final class SoundSettingsManager {

    private static final String PREF_NAME = "sound_settings";
    private static final String KEY_SOUND_ENABLED = "sound_enabled";
    private static final boolean DEFAULT_ENABLED = true;

    private SoundSettingsManager() {}

    /**
     * 判断提示音是否全局开启。
     */
    public static boolean isSoundEnabled(Context context) {
        if (context == null) return DEFAULT_ENABLED;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_SOUND_ENABLED, DEFAULT_ENABLED);
    }

    /**
     * 设置提示音全局开关。
     */
    public static void setSoundEnabled(Context context, boolean enabled) {
        if (context == null) return;
        context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SOUND_ENABLED, enabled)
                .apply();
    }
}