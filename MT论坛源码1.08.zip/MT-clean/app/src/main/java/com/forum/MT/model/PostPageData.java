package com.forum.MT.model;

import java.util.List;

/**
 * 发帖页面数据（对应官方APK PostPageData）
 * 从 form#postform 解析
 */
public class PostPageData {
    private final String fid;
    private final String forumName;
    private final String formhash;
    private final String postUrl;
    private final List<PostType> postTypes;
    private final boolean isLoading;
    private final String error;

    public PostPageData(String fid, String forumName, String formhash, String postUrl,
                        List<PostType> postTypes, boolean isLoading, String error) {
        this.fid = fid;
        this.forumName = forumName;
        this.formhash = formhash;
        this.postUrl = postUrl;
        this.postTypes = postTypes;
        this.isLoading = isLoading;
        this.error = error;
    }

    public String getFid() {
        return fid;
    }

    public String getForumName() {
        return forumName;
    }

    public String getFormhash() {
        return formhash;
    }

    public String getPostUrl() {
        return postUrl;
    }

    public List<PostType> getPostTypes() {
        return postTypes;
    }

    public boolean isLoading() {
        return isLoading;
    }

    public String getError() {
        return error;
    }
}
