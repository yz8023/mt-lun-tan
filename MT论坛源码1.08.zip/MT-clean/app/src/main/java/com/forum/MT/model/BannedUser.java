package com.forum.MT.model;

/**
 * 小黑屋（封禁用户）条目。
 *
 * <p>数据来自 {@code forum.php?mod=misc&action=showdarkroom&ajaxdata=json}，
 * 返回 JSON 包含操作人信息（operator / operatorid）。
 */
public class BannedUser {

    private String uid;           // 用户UID
    private String username;      // 用户名
    private String action;        // 封禁类型：禁止访问 / 禁止发言
    private String groupexpiry;   // 到期时间：永不过期 / 日期
    private String dateline;      // 操作时间
    private String reason;        // 封禁原因
    private String operator;      // 操作人（谁封的）
    private String operatorid;    // 操作人UID
    private String cid;           // 记录ID，用于分页

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getGroupexpiry() { return groupexpiry; }
    public void setGroupexpiry(String groupexpiry) { this.groupexpiry = groupexpiry; }

    public String getDateline() { return dateline; }
    public void setDateline(String dateline) { this.dateline = dateline; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getOperator() { return operator; }
    public void setOperator(String operator) { this.operator = operator; }

    public String getOperatorid() { return operatorid; }
    public void setOperatorid(String operatorid) { this.operatorid = operatorid; }

    public String getCid() { return cid; }
    public void setCid(String cid) { this.cid = cid; }

    /** 是否永久封禁 */
    public boolean isPermanent() {
        return "永不过期".equals(groupexpiry);
    }
}
