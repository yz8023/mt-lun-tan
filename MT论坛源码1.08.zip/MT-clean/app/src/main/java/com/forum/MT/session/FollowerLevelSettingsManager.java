package com.forum.MT.session;

import android.content.Context;

/** 控制“我的关注”和“我的粉丝”列表是否显示用户等级，默认显示。 */
public final class FollowerLevelSettingsManager {
    private static final String PREFS_NAME = "function_settings";
    private static final String KEY_SHOW_FOLLOWER_LEVEL = "show_follower_level";

    private FollowerLevelSettingsManager() {}

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_SHOW_FOLLOWER_LEVEL, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SHOW_FOLLOWER_LEVEL, enabled)
                .apply();
    }
}
