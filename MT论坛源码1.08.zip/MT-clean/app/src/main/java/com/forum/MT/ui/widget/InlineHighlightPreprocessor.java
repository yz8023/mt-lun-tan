package com.forum.MT.ui.widget;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 预处理 HTML：把带 background-color 内联样式的高亮元素（#f4f4f4 等技术名词背景）
 * 统一替换为 <hl>…</hl> 自定义标签，供 Html.TagHandler 渲染成可自定义颜色的行内高亮。
 *
 * <p>Discuz 实际生成的行内代码/技术名词通常为两层嵌套：
 * <pre>&lt;font color="#333333"&gt;&lt;font style="background-color:#f4f4f4"&gt;MTForum&lt;/font&gt;&lt;/font&gt;</pre>
 * 因此本类同时剥掉<b>外层 color font</b>，避免外层 ForegroundColorSpan 覆盖用户自定义文字色。
 *
 * <p>使用正则而非 Jsoup 整树解析，避免破坏表格占位符 &lt;img src="table://N"&gt;、
 * 图片、链接等其他标签结构。
 */
public class InlineHighlightPreprocessor {

    /**
     * 匹配「内层带 background-color 的 font/span（内容只含纯文本）」，外层可选地
     * 包一层 &lt;font color="..."&gt;。整组替换为 &lt;hl&gt;…&lt;/hl&gt;。
     *
     * <p>group 1 = 内层标签名(font|span)；group 4 = 内容（纯文本）。
     */
    private static final Pattern HIGHLIGHT_BLOCK = Pattern.compile(
            "(?:<font\\b[^>]*\\bcolor\\s*=\\s*\"[^\"]*\"[^>]*>\\s*)?"
                    + "<(font|span)\\b([^>]*\\bstyle\\s*=\\s*\"([^\"]*background-color[^\"]*)\"[^>]*)>"
                    + "([^<]*?)"           // 内容：纯文本（不含 <）
                    + "</\\1\\s*>"
                    + "(?:\\s*</font\\s*>)?",
            Pattern.CASE_INSENSITIVE);

    private InlineHighlightPreprocessor() {}

    /**
     * 将带背景色的行内高亮替换为 <hl> 标签。
     * @return 处理后的 HTML
     */
    public static String convert(String html) {
        if (html == null || html.isEmpty()) return html;

        Matcher m = HIGHLIGHT_BLOCK.matcher(html);
        StringBuffer sb = new StringBuffer(html.length() + 128);
        while (m.find()) {
            String content = m.group(4);
            // 只处理非空纯文本内容
            if (content == null || content.trim().isEmpty()) {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
                continue;
            }
            // 保留内容原样，整组替换为 <hl>...</hl>（同时剥掉外层 color font）
            m.appendReplacement(sb,
                    "<hl>" + Matcher.quoteReplacement(content) + "</hl>");
        }
        m.appendTail(sb);
        return sb.toString();
    }
}