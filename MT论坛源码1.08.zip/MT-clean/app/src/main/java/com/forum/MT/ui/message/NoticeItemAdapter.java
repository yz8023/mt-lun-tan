package com.forum.MT.ui.message;

import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.NoticeItem;
import com.forum.MT.network.NoticeBadgeManager;
import com.forum.MT.session.UnreadHighlightManager;
import com.forum.MT.session.SameThreadReadManager;
import com.forum.MT.ui.widget.RainbowBorderDrawable;
import com.forum.MT.ui.widget.RainbowBorderHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 通知列表适配器 - 适用于@我、帖子、系统通知Tab
 * 显示头像、用户名、内容、时间，点击跳转到帖子详情
 */
public class NoticeItemAdapter extends RecyclerView.Adapter<NoticeItemAdapter.ViewHolder> {

    private List<NoticeItem> items = new ArrayList<>();
    private String viewType = "";
    private NoticeBadgeHost badgeHost;
    private android.content.Context context;

    public void setItems(List<NoticeItem> items) {
        this.items = items != null ? items : new ArrayList<>();
        notifyDataSetChanged();
    }

    /** 全部已读/点击单条后刷新未读条显示（不改数据，仅重绘）。 */
    public void refreshUnreadBars() {
        notifyDataSetChanged();
    }

    /** 设置当前 Tab 的分类 key（用于本地已读标记与角标刷新）。 */
    public void setViewType(String viewType) {
        this.viewType = viewType != null ? viewType : "";
    }

    /** 绑定角标宿主（用于点击后刷新 Tab 角标）。 */
    public void setBadgeHost(NoticeBadgeHost host) {
        this.badgeHost = host;
    }

    /** 设置 Context（Activity 绑定之前的数据刷新场景使用）。 */
    public void setContext(android.content.Context context) {
        this.context = context != null ? context.getApplicationContext() : null;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notice, parent, false);
        if (context == null) context = parent.getContext().getApplicationContext();
        RainbowBorderHelper.applyToItem(view, parent.getContext());
        // 通知用户名高亮跟随全局强调色
        ((TextView) view.findViewById(R.id.tv_user)).setTextColor(
                com.forum.MT.ui.widget.AccentColorManager.resolveAccentColor());
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NoticeItem item = items.get(position);
        // 显示帖子标题，去掉末尾的 "tid=xxx" 隐藏信息
        String displayTitle = item.getThreadTitle();
        if (displayTitle != null) {
            displayTitle = displayTitle.replaceAll("\\s*tid=\\d+\\s*", "").trim();
        }
        holder.tvTitle.setText(displayTitle != null && !displayTitle.isEmpty() ? displayTitle : "通知");
        holder.tvContent.setText(item.getContent() != null ? item.getContent().replaceAll("\\s*tid=\\d+\\s*", "").trim() : "");
        holder.tvTime.setText(item.getTime() != null ? item.getTime() : "");

        if (item.getUsername() != null) {
            holder.tvUser.setText(item.getUsername());
            holder.tvUser.setVisibility(View.VISIBLE);
        } else {
            holder.tvUser.setVisibility(View.GONE);
        }

        // 未读：服务端未读(ntc_l)→isBold 且 未被用户点击过。
        // 注意不能用 isItemRead（基于 baseline），否则 markViewed 会把整批
        // 未点击条目误判为已读，导致左侧条全部消失。
        boolean unread = isUnreadItem(item);
        boolean highlightEnabled = UnreadHighlightManager.isEnabled(context);
        holder.tvTitle.getPaint().setFakeBoldText(unread);
        holder.tvTitle.setAlpha(unread ? 1.0f : 0.7f);
        // 仅左侧色条高亮显示，卡片背景和标题颜色不变
        if (holder.viewUnreadBar != null) {
            boolean showBar = unread && highlightEnabled;
            // 保持左侧条始终参与布局，避免 match_parent + RecyclerView 复用时测量为 0；
            // 未读时显示颜色，已读/关闭高亮时仅透明隐藏。
            holder.viewUnreadBar.setVisibility(View.VISIBLE);
            holder.viewUnreadBar.setAlpha(showBar ? 1f : 0f);
            // 清除旧监听器
            if (holder.breathListener != null) {
                RainbowBorderDrawable.removeBreathListener(holder.breathListener);
                holder.breathListener = null;
            }
            holder.viewUnreadBar.setScaleX(1f);
        }
        if (!unread) {
            holder.tvTitle.setTextColor(
                    holder.itemView.getContext().getColor(R.color.text_primary));
        }

        // 加载头像
        String avatarUrl = item.getAvatarUrl();
        if (avatarUrl != null && !avatarUrl.isEmpty()) {
            Glide.with(holder.ivAvatar.getContext())
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(holder.ivAvatar);
        } else {
            holder.ivAvatar.setImageResource(R.drawable.ic_account);
        }

        // 点击跳转到帖子详情，如有 pid 则定位到具体楼层；同时按设置推进本地已读状态
        holder.itemView.setOnClickListener(v -> {
            String tid = extractThreadId(item);

            if (!TextUtils.isEmpty(viewType) && v.getContext() != null) {
                if (SameThreadReadManager.isEnabled(v.getContext()) && !TextUtils.isEmpty(tid)) {
                    // 开关开启时，仅处理当前消息页中可识别为同一 tid 的通知。
                    for (NoticeItem candidate : items) {
                        if (tid.equals(extractThreadId(candidate))) {
                            String candidateKey = NoticeBadgeManager.stableKeyFor(candidate);
                            NoticeBadgeManager.markItemRead(v.getContext(), viewType, candidateKey);
                            NoticeBadgeManager.markNoticeClicked(v.getContext(), viewType, candidateKey);
                        }
                    }
                    notifyDataSetChanged();
                } else {
                    String key = NoticeBadgeManager.stableKeyFor(item);
                    NoticeBadgeManager.markItemRead(v.getContext(), viewType, key);
                    NoticeBadgeManager.markNoticeClicked(v.getContext(), viewType, key);
                    int adapterPosition = holder.getBindingAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) notifyItemChanged(adapterPosition);
                }
                if (badgeHost != null) badgeHost.refreshTabBadge(viewType);
            }

            if (tid != null) {
                Intent intent = new Intent(v.getContext(), com.forum.MT.ui.detail.ThreadDetailActivity.class);
                intent.putExtra("tid", tid);
                // 传递 pid 用于定位到具体回复楼层
                String pid = item.getPid();
                if (pid != null && !pid.isEmpty()) {
                    intent.putExtra("pid", pid);
                }
                v.getContext().startActivity(intent);
            }
        });
    }

    /** 从通知条目的隐藏标题、链接或正文中提取帖子 tid。 */
    private String extractThreadId(NoticeItem item) {
        if (item == null) return null;
        String[] sources = {item.getThreadTitle(), item.getThreadUrl(), item.getContent()};
        Pattern[] patterns = {
                Pattern.compile("tid=(\\d+)"),
                Pattern.compile("thread-(\\d+)")
        };
        for (String source : sources) {
            if (TextUtils.isEmpty(source)) continue;
            for (Pattern pattern : patterns) {
                Matcher matcher = pattern.matcher(source);
                if (matcher.find()) return matcher.group(1);
            }
        }
        return null;
    }

    /**
     * 判断某条目是否未读。
     *
     * ★ v3：统一为 readSet 单一判据，与底部/Tab 角标完全同源。
     *   旧实现"isBold(服务端) || isNoticeRelativeNew(baseline 差值)"有两个漏报：
     *   1) markViewed 整批前移 baseline → 未点开的条目 relativeNew 恒为 false；
     *   2) 后台轮询会请求通知页，服务端 ntc_l 可能在用户看到前就被清掉 → isBold 恒 false。
     *   现在只要条目不在 readSet 就显示未读，点击后由 markItemRead 推进。
     */
    private boolean isUnreadItem(NoticeItem item) {
        if (item == null) return false;
        if (TextUtils.isEmpty(viewType)) return item.isBold();
        String key = NoticeBadgeManager.stableKeyFor(item);
        // 用户已明确点击过 → 立即已读（本地优先，不受服务端标记影响）
        if (NoticeBadgeManager.isNoticeClicked(context, viewType, key)) return false;
        // readSet 判据：不在已读集合即未读
        if (NoticeBadgeManager.isNoticeUnread(context, viewType, key)) return true;
        // readSet 已包含该条目时仍尊重服务端未读标记（服务端说未读则未读）
        return item.isBold();
    }

    /** 判断某条目是否已在本地标记为已读。 */
    private boolean isLocallyRead(NoticeItem item) {
        if (item == null) return true;
        if (TextUtils.isEmpty(viewType)) {
            // 未设置分类时退回到服务端未读标记
            return !item.isBold();
        }
        String key = NoticeBadgeManager.stableKeyFor(item);
        return NoticeBadgeManager.isItemRead(context, viewType, key);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public void onViewAttachedToWindow(@NonNull ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(true, false);
        }
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull ViewHolder holder) {
        if (holder.breathListener != null) {
            RainbowBorderDrawable.removeBreathListener(holder.breathListener);
            holder.breathListener = null;
        }
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(false, false);
        }
        super.onViewDetachedFromWindow(holder);
    }

    @Override
    public void onViewRecycled(@NonNull ViewHolder holder) {
        if (holder.breathListener != null) {
            RainbowBorderDrawable.removeBreathListener(holder.breathListener);
            holder.breathListener = null;
        }
        if (holder.itemView.getBackground() instanceof RainbowBorderDrawable) {
            holder.itemView.getBackground().setVisible(false, false);
        }
        super.onViewRecycled(holder);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        androidx.cardview.widget.CardView cardRoot;
        ImageView ivAvatar;
        TextView tvTitle, tvContent, tvTime, tvUser;
        View viewUnreadBar;
        RainbowBorderDrawable.BreathListener breathListener;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardRoot = itemView.findViewById(R.id.card_root);
            ivAvatar = itemView.findViewById(R.id.iv_avatar);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvContent = itemView.findViewById(R.id.tv_content);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvUser = itemView.findViewById(R.id.tv_user);
            viewUnreadBar = itemView.findViewById(R.id.view_unread_bar);
            if (viewUnreadBar != null) {
                float density = itemView.getResources().getDisplayMetrics().density;
                float cardRadius = cardRoot != null ? cardRoot.getRadius() : 8f * density;
                if (cardRadius <= 0f) cardRadius = 8f * density;
                boolean rainbowOn = RainbowBorderDrawable.isGloballyEnabled();
                android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
                gd.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                gd.setColor(com.forum.MT.ui.widget.HomeBarColorManager.resolveUnreadBarColor());
                android.widget.LinearLayout.LayoutParams lp = (android.widget.LinearLayout.LayoutParams) viewUnreadBar.getLayoutParams();
                if (rainbowOn) {
                    // 流水灯开启：色条移到边框内侧紧贴，长度匹配边框直线段，圆角与边框一致
                    float inset = 2.5f * density;
                    gd.setCornerRadii(new float[]{cardRadius, cardRadius, 0, 0, 0, 0, cardRadius, cardRadius});
                    lp.topMargin = Math.round(inset);
                    lp.bottomMargin = Math.round(inset);
                    lp.setMarginStart(Math.round(inset));
                    // 在 CardView overlay 上添加 borderOnly 副本，使边框绘制在色条之上
                    if (cardRoot != null) {
                        final RainbowBorderDrawable overlayBorder = new RainbowBorderDrawable(
                                com.forum.MT.ui.widget.CardColorManager.resolveCardColor(),
                                cardRadius, density, true);
                        cardRoot.getOverlay().add(overlayBorder);
                        cardRoot.addOnLayoutChangeListener(new android.view.View.OnLayoutChangeListener() {
                            @Override
                            public void onLayoutChange(View v, int left, int top, int right, int bottom,
                                                       int oldLeft, int oldTop, int oldRight, int oldBottom) {
                                overlayBorder.setBounds(0, 0, v.getWidth(), v.getHeight());
                            }
                        });
                        overlayBorder.setCallback(cardRoot);
                    }
                } else {
                    // 流水灯关闭：色条在卡片最外缘，占满全高
                    gd.setCornerRadii(new float[]{cardRadius, cardRadius, 0, 0, 0, 0, cardRadius, cardRadius});
                    lp.topMargin = 0;
                    lp.bottomMargin = 0;
                    lp.setMarginStart(0);
                }
                viewUnreadBar.setBackground(gd);
                viewUnreadBar.setLayoutParams(lp);
            }
        }
    }
}