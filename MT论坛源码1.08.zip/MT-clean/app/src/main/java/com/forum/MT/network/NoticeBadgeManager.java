package com.forum.MT.network;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.forum.MT.model.ChatMessage;
import com.forum.MT.model.Message;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * 消息角标快照管理器。
 *
 * Comiis 页面不提供可靠的 unread 标记，因此不再依赖 Message.isRead()。
 * 角标含义为：当前服务器列表相对于用户上次进入该分类时，新增的内容数量。
 *
 * PM 使用“会话内消息总数”计算差值；粉丝使用新增 UID 数量；
 * 其它通知使用通知内容指纹计算新增条目数量。
 */
public final class NoticeBadgeManager {
    // ★ v3：通知类未读判定统一改为 readSet 单一判据（角标与左侧未读条共用）。
    //   必须升版本重建基线，否则旧库中 readset_* 缺失会让 countNotInSet 把
    //   整页历史通知全部算成未读，角标瞬间爆表。
    private static final String PREF_NAME = "notice_badge_snapshot_v3";
    private static final String KEY_BASELINE_PREFIX = "baseline_";
    private static final String KEY_CURRENT_PREFIX = "current_";
    private static final String KEY_PENDING_PREFIX = "pending_";
    private static final String KEY_NEW_COUNT_PREFIX = "new_count_";
    // ★ PM 专用"已点击"集合：只有用户明确点击某会话时才加入，
    //   不受 markViewed（进入 Tab 时 baseline=current）影响。
    private static final String KEY_CLICKED_PM = "clicked_pm_set";
    // ★ 通知类"已点击"集合：只有用户真正点击某条通知时才加入。
    //   左侧未读条只信任"服务端未读 + 本地点击集合"，不信任 baseline，
    //   避免 markViewed（进入分类详情）把未点击的条目一并标记为已读。
    private static final String KEY_CLICKED_NOTICE_PREFIX = "clicked_notice_";
    // ★ 通知类"已读集合"：用户点击过的条目 + "全部已读"时批量加入。
    //   列表左条 & 角标共用此集合，不受 markViewed 影响。
    private static final String KEY_READSET_PREFIX = "readset_";

    private NoticeBadgeManager() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    /**
     * 根据当前 HTML 建立规范化快照。
     * PM 会继续请求每个会话的详情页，统计当前可见聊天消息总数。
     */
    public static String buildSnapshot(String viewType, String html, HttpClient client) {
        if (TextUtils.isEmpty(html)) return "";

        List<Message> items;
        if ("pm".equals(viewType)) items = ForumParser.parsePmList(html);
        else if ("follower".equals(viewType)) items = ForumParser.parseFollowerList(html);
        else items = ForumParser.parseNoticeList(html);
        if (items == null) items = new ArrayList<>();

        if ("pm".equals(viewType)) return buildPmSnapshot(items, client);
        if ("follower".equals(viewType)) return buildFollowerSnapshot(items);
        return buildNoticeSnapshot(items);
    }

    private static String buildPmSnapshot(List<Message> items, HttpClient client) {
        Map<String, Integer> totals = new TreeMap<>();
        Set<String> seen = new HashSet<>();
        for (Message item : items) {
            // ★ 与 adapter 的 key 优先级保持一致：pmid → authorUid → author
            String uid = firstNonEmpty(item.getPmid(), item.getAuthorUid(), item.getAuthor());
            if (TextUtils.isEmpty(uid)) continue;
            String key = sha256(uid);
            if (!seen.add(key)) continue;

            // 列表页通常只有会话预览，详情页才包含实际消息条数。
            int total = 1;
            if (client != null && !TextUtils.isEmpty(item.getPmid())) {
                try {
                    String url = HttpClient.BASE_URL
                            + "home.php?mod=space&do=pm&subop=view&touid="
                            + item.getPmid() + "&mobile=2&_badge_ts="
                            + System.currentTimeMillis();
                    String detail = client.get(url);
                    List<ChatMessage> chat = ForumParser.parseChatMessages(
                            detail, "", item.getAvatarUrl());
                    if (chat != null && !chat.isEmpty()) {
                        int incoming = 0;
                        for (ChatMessage message : chat) {
                            if (!message.isOutgoing()) incoming++;
                        }
                        // 只统计对方发来的消息；用户自己的回复不应增加未读角标。
                        total = incoming;
                    }
                } catch (Exception ignored) {
                    // 详情请求失败时保留列表中的一条会话消息，避免将该会话丢失。
                }
            }
            totals.put(key, total);
        }

        StringBuilder result = new StringBuilder();
        for (Map.Entry<String, Integer> entry : totals.entrySet()) {
            result.append(entry.getKey()).append('=').append(entry.getValue()).append(';');
        }
        return result.toString();
    }

    private static String buildFollowerSnapshot(List<Message> items) {
        Set<String> ids = new HashSet<>();
        for (Message item : items) {
            String uid = firstNonEmpty(item.getAuthorUid(), item.getAuthor(), item.getTitle());
            if (!TextUtils.isEmpty(uid)) ids.add(sha256(uid));
        }
        List<String> sorted = new ArrayList<>(ids);
        Collections.sort(sorted);
        return join(sorted);
    }

    private static String buildNoticeSnapshot(List<Message> items) {
        // ★ v3 修复：原实现直接用 Set 去重，两条通知只要 stableNoticeKey 碰撞
        //   （缺 notice 属性时 fallback 键区分度有限，title 还被截断到 200 字符）
        //   就会合并成一条 → 角标少算，且两条的已读状态被绑在一起。
        //   现在保留重复项：首次出现用原始 key（渲染侧 stableKeyFor 能对上），
        //   第 n 次重复追加 "#n" 后缀，保证计数不丢条目。
        Map<String, Integer> seen = new HashMap<>();
        List<String> ids = new ArrayList<>();
        for (Message item : items) {
            if (isCompletedFriendNotice(item)) continue;
            String key = sha256(stableNoticeKey(item));
            Integer times = seen.get(key);
            int n = times == null ? 0 : times;
            seen.put(key, n + 1);
            ids.add(n == 0 ? key : key + "#" + n);
        }
        Collections.sort(ids);
        return join(ids);
    }

    private static String stableNoticeKey(Message item) {
        String id = firstNonEmpty(item.getPmid(), "");
        if (!TextUtils.isEmpty(id)) {
            // 同一通知 ID 在部分模板中可能对应不同回复楼层；保留 pid 让每条回复独立记录已读状态。
            String pid = firstNonEmpty(item.getPid(), "");
            return "id|" + id + "|pid|" + pid;
        }
        // ★ fallback 键必须包含 pid（楼层回复ID）与 time，否则同用户同帖的
        // 多条通知会生成相同 key；点开一条会把其它未读回复一并误判为已读，导致
        // 部分新消息左侧高亮条不显示。
        // ★ 注意：不能使用 System.identityHashCode，因为每次解析 HTML 都会创建新对象，
        //   同一通知在快照与列表渲染时 hash 会不一致，反而导致所有条目都被误判为新增。
        return "content|" + firstNonEmpty(item.getAuthorUid(), "") + "|"
                + firstNonEmpty(item.getAuthor(), "") + "|"
                + firstNonEmpty(item.getTitle(), "") + "|"
                + firstNonEmpty(item.getSummary(), "") + "|"
                + firstNonEmpty(item.getPid(), "") + "|"
                + normalizeKeyTime(item.getTime());
    }

    /**
     * ★ v3 修复：规范化参与 key 的时间文本。
     *
     * 移动版模板（parseComiisNoticeItems 取 h2.f_d）常给出"3 天前""昨天 10:23"
     * 这类相对时间，桌面版 span[title] 缺失时也会回退到相对时间文本。
     * 相对时间会随时间推移变化 → 同一条通知的 key 发生漂移 → readSet 里存的
     * 旧 key 对不上新 key → 已读条目重新变未读，或未读条目判定失效。
     *
     * 处理：仅当时间文本形如绝对时间（含年月日或完整日期分隔符）时才纳入 key，
     * 相对时间统一折叠为空串，靠 author/title/summary/pid 维持区分度。
     */
    private static String normalizeKeyTime(String time) {
        if (TextUtils.isEmpty(time)) return "";
        String t = time.replace('\u00a0', ' ').trim();
        // 绝对时间：2026-08-18 10:23 / 2026/8/18 / 2026年8月18日 / 08-18 10:23
        if (t.matches(".*\\d{4}[-/年]\\d{1,2}[-/月]\\d{1,2}.*")
                || t.matches("^\\d{1,2}[-/]\\d{1,2}\\s+\\d{1,2}:\\d{2}.*")) {
            return t;
        }
        // 相对时间（N 分钟前 / N 小时前 / N 天前 / 昨天 / 前天 / 刚刚）→ 不参与 key
        return "";
    }

    /**
     * 保存当前快照并返回相对于上次查看基线的新增数量。
     * 首次运行只建立基线，返回 0。
     */
    public static synchronized int saveCurrentAndGetNewCount(Context context,
                                                               String viewType,
                                                               String snapshot) {
        if (context == null || TextUtils.isEmpty(viewType)) return 0;
        SharedPreferences p = prefs(context);
        String baselineKey = KEY_BASELINE_PREFIX + viewType;
        String currentKey = KEY_CURRENT_PREFIX + viewType;
        String pendingKey = KEY_PENDING_PREFIX + viewType;
        String readSetKey = KEY_READSET_PREFIX + viewType;
        String oldBaseline = p.getString(baselineKey, null);

        if (p.getBoolean(pendingKey, false) || oldBaseline == null) {
            // ★ 首次运行：建立基线，readSet 同步为当前快照，避免把历史通知整页都当成未读。
            // ★ v3：快照可能含 "#n" 后缀的重复项，readSet 只存基础 key。
            Set<String> initialReadSet = new HashSet<>();
            for (String k : parseSet(snapshot)) initialReadSet.add(baseKey(k));
            p.edit().putString(baselineKey, snapshot == null ? "" : snapshot)
                    .putString(currentKey, snapshot == null ? "" : snapshot)
                    .putStringSet(readSetKey, initialReadSet)
                    .putBoolean(pendingKey, false)
                    .putInt(KEY_NEW_COUNT_PREFIX + viewType, 0)
                    .apply();
            return 0;
        }

        int count;
        if ("pm".equals(viewType) || "follower".equals(viewType)) {
            // PM / 粉丝：仍按快照差值（PM 是 uid=条数，粉丝是 uid 集合）。
            count = calculateNewCount(viewType, oldBaseline, snapshot);
        } else {
            // ★ v3 修复：通知类角标改为 readSet 单一判据。
            //   旧逻辑用 baseline 差值，而 markViewed 会把整批 baseline=current，
            //   导致"进入分类但只点开一条"时其余未读被永久吞掉（左条与角标同时消失）。
            //   现在角标 = 当前快照中不在 readSet 的条数，与左侧未读条完全同源。
            Set<String> readSet = p.getStringSet(readSetKey, null);
            if (readSet == null) readSet = parseSet(oldBaseline);
            count = countNotInSet(snapshot, readSet);
        }
        p.edit().putString(currentKey, snapshot == null ? "" : snapshot)
                .putInt(KEY_NEW_COUNT_PREFIX + viewType, count)
                .apply();
        return count;
    }

    /**
     * 读取某分类最近一次计算出的新增数量（Tab 角标用）。
     */
    public static synchronized int getNewCount(Context context, String viewType) {
        if (context == null || TextUtils.isEmpty(viewType)) return 0;
        return prefs(context).getInt(KEY_NEW_COUNT_PREFIX + viewType, 0);
    }

    /**
     * 汇总互动子分类的未读通知。相同通知可能被多个 type 页面返回，按稳定快照键去重。
     */
    public static synchronized int getInteractiveAggregate(Context context, String[] types) {
        if (context == null || types == null) return 0;
        Set<String> unread = new HashSet<>();
        SharedPreferences p = prefs(context);
        for (String type : types) {
            if (TextUtils.isEmpty(type)) continue;
            String viewType = "interactive_" + type;
            Set<String> read = p.getStringSet(KEY_READSET_PREFIX + viewType, null);
            if (read == null) read = new HashSet<>();
            String current = p.getString(KEY_CURRENT_PREFIX + viewType, "");
            for (String key : parseSet(current)) {
                String base = baseKey(key);
                if (!read.contains(base)) unread.add(base);
            }
        }
        return unread.size();
    }

    /** 更新由多个子分类组成的汇总角标，不改变各子分类的已读集合。 */
    public static synchronized void setNewCount(Context context, String viewType, int count) {
        if (context == null || TextUtils.isEmpty(viewType)) return;
        prefs(context).edit().putInt(KEY_NEW_COUNT_PREFIX + viewType, Math.max(0, count)).apply();
    }

    /**
     * 点击进入某分类时的处理。
     *
     * ★ v3 修复：通知类不再执行 baseline=current，也不再把角标硬清零。
     *   旧行为是"整个分类"粒度的批量吞并：进入详情页（甚至只是加载成功）
     *   就把当页所有条目并入 baseline，未点开的条目从此永远不算未读。
     *   现在通知类的已读只由 markItemRead / markAllViewed 逐条或显式推进，
     *   角标按 readSet 重算，未点击的条目继续保持未读。
     */
    public static synchronized void markViewed(Context context, String viewType) {
        if (context == null || TextUtils.isEmpty(viewType)) return;
        SharedPreferences p = prefs(context);
        String current = p.getString(KEY_CURRENT_PREFIX + viewType, null);
        SharedPreferences.Editor editor = p.edit();

        if ("pm".equals(viewType) || "follower".equals(viewType)) {
            // PM / 粉丝：沿用基线快照语义（无逐条 readSet 模型）。
            if (current == null) {
                editor.putBoolean(KEY_PENDING_PREFIX + viewType, true);
            } else {
                editor.putString(KEY_BASELINE_PREFIX + viewType, current)
                        .putBoolean(KEY_PENDING_PREFIX + viewType, false);
            }
            editor.putInt(KEY_NEW_COUNT_PREFIX + viewType, 0);
            editor.apply();
            return;
        }

        // 通知类：仅在从未加载过时置 pending（首次建基线，避免历史通知整页标红）。
        if (current == null) {
            editor.putBoolean(KEY_PENDING_PREFIX + viewType, true);
            editor.putInt(KEY_NEW_COUNT_PREFIX + viewType, 0);
            editor.apply();
            return;
        }
        // 已有快照：不动 baseline / readSet，只按 readSet 重算角标。
        Set<String> readSet = p.getStringSet(KEY_READSET_PREFIX + viewType, null);
        if (readSet == null) readSet = parseSet(p.getString(KEY_BASELINE_PREFIX + viewType, ""));
        editor.putBoolean(KEY_PENDING_PREFIX + viewType, false)
                .putInt(KEY_NEW_COUNT_PREFIX + viewType, countNotInSet(current, readSet));
        editor.apply();
    }

    /**
     * 标记某分类下的单条内容为已读（本地记录）。
     * 通知类：把该条目稳定键并入 readSet（左条消失）和基线集合（兼容）。
     * PM 类：把该会话的"对方消息数"并入基线，使角标计数减一。
     *
     * @param itemKey pm 传会话 uid；其余传 stableNoticeKey（由调用方用 stableKeyFor() 生成）
     */
    public static synchronized void markItemRead(Context context, String viewType, String itemKey) {
        if (context == null || TextUtils.isEmpty(viewType) || TextUtils.isEmpty(itemKey)) return;

        SharedPreferences p = prefs(context);
        String baseline = p.getString(KEY_BASELINE_PREFIX + viewType, "");
        String current = p.getString(KEY_CURRENT_PREFIX + viewType, "");

        String newBaseline;
        int newCount;
        if ("pm".equals(viewType)) {
            // 基线是 uid=count 形式，把该会话的已读条数并入基线（吃掉的条数）
            Map<String, Integer> baselineMap = parsePmMap(baseline);
            Map<String, Integer> currentMap = parsePmMap(current);
            String key = sha256(itemKey);
            if (currentMap.containsKey(key)) {
                baselineMap.put(key, currentMap.get(key));
            }
            newBaseline = serializePmMap(baselineMap);
            // ★ PM 专用：同时加入"已点击"集合，供 isItemRead 判断
            Set<String> clicked = p.getStringSet(KEY_CLICKED_PM, new HashSet<>());
            clicked.add(key);
            p.edit().putStringSet(KEY_CLICKED_PM, clicked).apply();
            newCount = calculateNewCount(viewType, newBaseline, current);
        } else {
            // ★ v3：通知类已读只推进 readSet + clicked，不再把整批 baseline 前移。
            //   baseline 仍同步该条（兼容 isNoticeRelativeNew 的历史判定），
            //   但角标一律按 readSet 重算，保证与左侧未读条同源。
            String key = sha256(itemKey);
            Set<String> baselineSet = parseSet(baseline);
            baselineSet.add(key);
            newBaseline = join(new ArrayList<>(baselineSet));
            Set<String> readSet = new HashSet<>(p.getStringSet(
                    KEY_READSET_PREFIX + viewType, new HashSet<>(parseSet(baseline))));
            readSet.add(key);
            p.edit().putStringSet(KEY_READSET_PREFIX + viewType, readSet).apply();
            newCount = countNotInSet(current, readSet);
        }

        p.edit()
                .putString(KEY_BASELINE_PREFIX + viewType, newBaseline)
                .putBoolean(KEY_PENDING_PREFIX + viewType, false)
                .putInt(KEY_NEW_COUNT_PREFIX + viewType, newCount)
                .apply();
    }

    /** 供调用方生成通知条目的稳定键（与服务端快照所用键一致）。 */
    public static String stableKeyFor(com.forum.MT.model.Message item) {
        return stableNoticeKey(item);
    }

    /** 供调用方生成通知条目的稳定键（NoticeItem 版）。 */
    public static String stableKeyFor(com.forum.MT.model.NoticeItem item) {
        String id = firstNonEmpty(item.getNoticeId(), "");
        if (!TextUtils.isEmpty(id)) {
            // 与 Message 版本保持一致，避免同一通知 ID 的不同回复共享已读状态。
            String pid = firstNonEmpty(item.getPid(), "");
            return "id|" + id + "|pid|" + pid;
        }
        // ★ 必须与 stableNoticeKey(Message) 字段顺序完全一致：
        //   Message: authorUid | author | title | summary | pid | time
        //   NoticeItem: uid(=authorUid) | username(=author) | content(=title) | threadTitle(=summary) | pid | time
        return "content|" + firstNonEmpty(item.getUid(), "") + "|"
                + firstNonEmpty(item.getUsername(), "") + "|"
                + firstNonEmpty(item.getContent(), "") + "|"
                + firstNonEmpty(item.getThreadTitle(), "") + "|"
                + firstNonEmpty(item.getPid(), "") + "|"
                + normalizeKeyTime(item.getTime());
    }

    /**
     * 返回某个 PM 会话当前还有多少条“相对基线新增”的未读消息。
     *
     * 说明：
     * 1) PM 列表左侧高亮条必须与底部角标使用同一套快照差值算法；
     * 2) 不能只看 clicked_pm_set，否则一个会话点开过一次后，后续再来新消息
     *    仍会被永久误判为已读；
     * 3) 因此这里统一比较 baseline_pm 与 current_pm 中该会话的消息数差值。
     */
    public static synchronized int getPmUnreadDelta(Context context, String itemKey) {
        if (context == null || TextUtils.isEmpty(itemKey)) return 0;
        SharedPreferences p = prefs(context);
        String key = sha256(itemKey);
        Map<String, Integer> baselineMap = parsePmMap(p.getString(KEY_BASELINE_PREFIX + "pm", ""));
        Map<String, Integer> currentMap = parsePmMap(p.getString(KEY_CURRENT_PREFIX + "pm", ""));
        int oldCount = baselineMap.containsKey(key) ? baselineMap.get(key) : 0;
        int currentCount = currentMap.containsKey(key) ? currentMap.get(key) : 0;
        return Math.max(0, currentCount - oldCount);
    }

    /** 某个 PM 会话是否仍存在未读。 */
    public static synchronized boolean hasPmUnread(Context context, String itemKey) {
        return getPmUnreadDelta(context, itemKey) > 0;
    }

    /**
     * 某个 PM 会话是否已被用户在本 App 内点击过。
     *
     * ★ 用途：私信列表左侧未读色条不能只看 baseline/current 快照差值。
     *   首次建基线（baseline=current）与"全部已读"都会把差值抹平，
     *   此时服务端仍标记未读（newpm / 加粗）的会话会被误判成已读，
     *   表现为色条与红点完全不显示，像是已经点进去过。
     *   因此渲染侧改用「本地新增 OR (服务端未读 AND 未被本地点击)」，
     *   本方法提供后半段的"本地点击"覆盖判据。
     */
    public static synchronized boolean isPmClicked(Context context, String itemKey) {
        if (context == null || TextUtils.isEmpty(itemKey)) return false;
        Set<String> clicked = prefs(context).getStringSet(KEY_CLICKED_PM, new HashSet<>());
        return clicked.contains(sha256(itemKey));
    }

    /**
     * 服务端已把该会话标记为已读时，清除本地"已点击"标记。
     *
     * ★ 为什么必须有这一步（闭环的最后一环）：
     *   clicked_pm_set 只是为了掩盖"用户刚点开会话 → 列表还没重新拉取"这段窗口。
     *   若只写入从不清除，集合会永久累积，于是：
     *     点开过一次的会话，之后对方再发新私信时，
     *     服务端 span.kmnums 虽然重新出现，但 isPmClicked 仍为 true，
     *     渲染判据「服务端未读 AND 未被点击」被压制 → 色条与红点永远不再亮。
     *   实际上打开会话（ChatActivity 请求 do=pm&subop=view&touid=）会让服务端清除未读，
     *   因此"服务端已读"就是本地点击标记可以安全丢弃的确证信号。
     *   在列表数据刷新时对每条服务端已读的会话调用本方法，即可让下一条新消息重新亮起。
     */
    public static synchronized void clearPmClickedIfServerRead(Context context, String itemKey) {
        if (context == null || TextUtils.isEmpty(itemKey)) return;
        SharedPreferences p = prefs(context);
        Set<String> clicked = p.getStringSet(KEY_CLICKED_PM, null);
        if (clicked == null || clicked.isEmpty()) return;
        String key = sha256(itemKey);
        if (!clicked.contains(key)) return;
        Set<String> updated = new HashSet<>(clicked);
        updated.remove(key);
        p.edit().putStringSet(KEY_CLICKED_PM, updated).apply();
    }

    /**
     * 判断某条内容是否已被本地标记为已读。
     * 通知类：键是否已在基线集合；PM 类：按 baseline/current 快照差值判断。
     */
    public static synchronized boolean isItemRead(Context context, String viewType, String itemKey) {
        if (context == null || TextUtils.isEmpty(viewType) || TextUtils.isEmpty(itemKey)) return true;
        SharedPreferences p = prefs(context);
        String key = sha256(itemKey);
        if ("pm".equals(viewType)) {
            return getPmUnreadDelta(context, itemKey) <= 0;
        }
        Set<String> readSet = p.getStringSet(KEY_READSET_PREFIX + viewType, null);
        if (readSet != null) {
            return readSet.contains(key);
        }
        String baseline = p.getString(KEY_BASELINE_PREFIX + viewType, "");
        return parseSet(baseline).contains(key);
    }

    /** 手动“全部已读”时：将当前快照整体标记为已读（baseline=current、readSet=current、clicked=current），
     * 并把所有分类角标清零。
     * 关键：不能清空 readSet/clicked，否则下次刷新会把全部条目当未读。 */
    public static synchronized void markAllViewed(Context context) {
        if (context == null) return;
        String[] types = {"pm", "follower", "mypost_at", "mypost_post", "interactive",
                "interactive_poke", "interactive_friend", "interactive_click",
                "interactive_wall", "interactive_comment", "system", "app"};
        SharedPreferences p = prefs(context);
        SharedPreferences.Editor editor = p.edit();

        for (String type : types) {
            String current = p.getString(KEY_CURRENT_PREFIX + type, null);
            // ★ 修复：current 为 null（从未加载过）时不能把 baseline 设为 ""。
            //   否则 saveCurrentAndGetNewCount 会把 oldBaseline="" 当作非 null，
            //   不走首次基线逻辑，calculateNewCount("", snapshot) 返回全部条目数，
            //   导致"全部已读"后底部角标反而显示全部数量。
            if (current == null) {
                // 标记为 pending，下次 saveCurrentAndGetNewCount 走首次基线逻辑
                editor.putBoolean(KEY_PENDING_PREFIX + type, true);
                editor.putInt(KEY_NEW_COUNT_PREFIX + type, 0);
                continue;
            }
            Set<String> currentSet = parseSet(current);

            // baseline = current → 无相对新增
            editor.putString(KEY_BASELINE_PREFIX + type, current);
            editor.putBoolean(KEY_PENDING_PREFIX + type, false);
            // 角标清零
            editor.putInt(KEY_NEW_COUNT_PREFIX + type, 0);

            if (!"pm".equals(type) && !"follower".equals(type)) {
                // ★ v3：快照中可能含 "#n" 后缀的重复项，写入 readSet / clicked 前
                //   必须折叠成基础 key，否则 countNotInSet / isNoticeClicked 对不上。
                Set<String> baseSet = new HashSet<>();
                for (String k : currentSet) baseSet.add(baseKey(k));
                // 通知类：readSet = current（所有当前条目已读）
                editor.putStringSet(KEY_READSET_PREFIX + type, baseSet);
                // clicked = current（isNoticeClicked 命中 → 左侧条消失）
                editor.putStringSet(KEY_CLICKED_NOTICE_PREFIX + type, baseSet);
            } else if ("pm".equals(type)) {
                // ★ PM："全部已读"必须把当前所有会话并入 clicked 集合。
                //   旧实现在循环后 remove(KEY_CLICKED_PM) 清空该集合，配合
                //   "服务端未读且未点击才算未读" 的渲染判据会让所有服务端未读会话
                //   在下一次刷新时重新亮起，等于"全部已读"无效。
                //   注意 PM 快照是 hash=count 形式，必须用 parsePmMap 取键。
                Set<String> clickedPm = new HashSet<>(
                        p.getStringSet(KEY_CLICKED_PM, new HashSet<>()));
                clickedPm.addAll(parsePmMap(current).keySet());
                editor.putStringSet(KEY_CLICKED_PM, clickedPm);
            }
        }
        editor.apply();
    }

    /** 通知条目是否已被用户真正点击过（独立于基线，用于左侧未读条判定）。 */
    public static synchronized boolean isNoticeClicked(Context context, String viewType, String itemKey) {
        if (context == null || TextUtils.isEmpty(viewType) || TextUtils.isEmpty(itemKey)) return false;
        Set<String> clicked = prefs(context).getStringSet(
                KEY_CLICKED_NOTICE_PREFIX + viewType, new HashSet<>());
        return clicked.contains(sha256(itemKey));
    }

    /** 记录某条通知已被用户点击。 */
    public static synchronized void markNoticeClicked(Context context, String viewType, String itemKey) {
        if (context == null || TextUtils.isEmpty(viewType) || TextUtils.isEmpty(itemKey)) return;
        Set<String> clicked = new HashSet<>(prefs(context).getStringSet(
                KEY_CLICKED_NOTICE_PREFIX + viewType, new HashSet<>()));
        clicked.add(sha256(itemKey));
        prefs(context).edit().putStringSet(
                KEY_CLICKED_NOTICE_PREFIX + viewType, clicked).apply();
    }

    /** ★ 判断某条通知是否在"已读集合"(readSet) 中（用于左侧未读条判定）。 */
    public static synchronized boolean isItemInReadSet(Context context, String viewType, String itemKey) {
        if (context == null || TextUtils.isEmpty(viewType) || TextUtils.isEmpty(itemKey)) return false;
        if ("pm".equals(viewType)) return false; // PM 不使用 readSet
        Set<String> readSet = prefs(context).getStringSet(
                KEY_READSET_PREFIX + viewType, new HashSet<>());
        return readSet.contains(sha256(itemKey));
    }

    /**
     * 某条通知是否属于“相对基线新增”的条目。
     *
     * 用途：移动版/某些模板缺少 ntc_l 等服务端未读类时，
     * 允许列表左侧未读条退回到 baseline/current 快照差值判断，
     * 但只对真正新增的条目生效，避免把整页历史消息都标亮。
     */
    public static synchronized boolean isNoticeRelativeNew(Context context, String viewType, String itemKey) {
        if (context == null || TextUtils.isEmpty(viewType) || TextUtils.isEmpty(itemKey)) return false;
        if ("pm".equals(viewType)) return false;
        SharedPreferences p = prefs(context);
        String key = sha256(itemKey);
        // ★ v3：快照中重复项带 "#n" 后缀，比较前折叠为基础 key。
        Set<String> currentSet = new HashSet<>();
        for (String k : parseSet(p.getString(KEY_CURRENT_PREFIX + viewType, ""))) {
            currentSet.add(baseKey(k));
        }
        if (!currentSet.contains(key)) return false;
        Set<String> baselineSet = new HashSet<>();
        for (String k : parseSet(p.getString(KEY_BASELINE_PREFIX + viewType, ""))) {
            baselineSet.add(baseKey(k));
        }
        return !baselineSet.contains(key);
    }

    /**
     * ★ v3 新增：通知条目未读的唯一判据（左侧未读条与角标共用）。
     *
     * 语义：条目不在 readSet 中即为未读。readSet 只由三处推进：
     *   1) 首次建立基线（历史通知整页视为已读）
     *   2) markItemRead（用户逐条点击）
     *   3) markAllViewed（用户显式"全部已读"）
     * markViewed（进入分类）不再推进 readSet，因此"进列表但没点开"的条目保持未读。
     */
    public static synchronized boolean isNoticeUnread(Context context, String viewType, String itemKey) {
        if (context == null || TextUtils.isEmpty(viewType) || TextUtils.isEmpty(itemKey)) return false;
        if ("pm".equals(viewType)) return false;
        SharedPreferences p = prefs(context);
        String key = sha256(itemKey);
        Set<String> readSet = p.getStringSet(KEY_READSET_PREFIX + viewType, null);
        if (readSet == null) {
            // readSet 尚未建立（该分类从未成功加载）：退回 baseline 集合，
            // 避免在无任何本地状态时把整页历史通知标红。
            readSet = new HashSet<>();
            for (String k : parseSet(p.getString(KEY_BASELINE_PREFIX + viewType, ""))) {
                readSet.add(baseKey(k));
            }
            if (readSet.isEmpty()) return false;
        }
        return !readSet.contains(key);
    }

    private static int calculateNewCount(String viewType, String baseline, String current) {
        if (TextUtils.isEmpty(current)) return 0;
        if ("pm".equals(viewType)) return calculatePmDelta(baseline, current);

        Set<String> oldSet = parseSet(baseline);
        int count = 0;
        for (String key : parseSet(current)) if (!oldSet.contains(key)) count++;
        return count;
    }

    /**
     * 统计快照中不在 readSet 的条目数。
     *
     * ★ v3：buildNoticeSnapshot 对 key 碰撞的重复条目追加 "#n" 后缀以保证计数不丢，
     *   但 readSet / clicked 里只会存基础 key（渲染侧 stableKeyFor 无法区分重复项）。
     *   因此这里按基础 key 判定归属：重复条目仍各自计数，一旦用户点击其中一条，
     *   同 key 的条目一起转为已读，避免出现"左侧已无未读条但角标永远清不掉"。
     */
    private static int countNotInSet(String snapshot, Set<String> readSet) {
        if (TextUtils.isEmpty(snapshot)) return 0;
        int count = 0;
        for (String key : parseSet(snapshot)) {
            if (!readSet.contains(baseKey(key))) count++;
        }
        return count;
    }

    /** 去掉 buildNoticeSnapshot 为重复条目追加的 "#n" 后缀。 */
    private static String baseKey(String key) {
        if (key == null) return "";
        int idx = key.indexOf('#');
        return idx > 0 ? key.substring(0, idx) : key;
    }

    private static int calculatePmDelta(String baseline, String current) {
        Map<String, Integer> oldMap = parsePmMap(baseline);
        Map<String, Integer> currentMap = parsePmMap(current);
        int count = 0;
        for (Map.Entry<String, Integer> entry : currentMap.entrySet()) {
            int old = oldMap.containsKey(entry.getKey()) ? oldMap.get(entry.getKey()) : 0;
            if (entry.getValue() > old) count += entry.getValue() - old;
        }
        return count;
    }

    private static Set<String> parseSet(String value) {
        Set<String> result = new HashSet<>();
        if (TextUtils.isEmpty(value)) return result;
        for (String item : value.split(";")) {
            if (!TextUtils.isEmpty(item)) result.add(item);
        }
        return result;
    }

    private static Map<String, Integer> parsePmMap(String value) {
        Map<String, Integer> result = new HashMap<>();
        if (TextUtils.isEmpty(value)) return result;
        for (String item : value.split(";")) {
            int index = item.lastIndexOf('=');
            if (index <= 0) continue;
            try {
                result.put(item.substring(0, index), Integer.parseInt(item.substring(index + 1)));
            } catch (Exception ignored) {}
        }
        return result;
    }

    private static String serializePmMap(Map<String, Integer> map) {
        Map<String, Integer> sorted = new TreeMap<>(map);
        StringBuilder result = new StringBuilder();
        for (Map.Entry<String, Integer> entry : sorted.entrySet()) {
            result.append(entry.getKey()).append('=').append(entry.getValue()).append(';');
        }
        return result.toString();
    }

    private static String join(List<String> values) {
        StringBuilder result = new StringBuilder();
        for (String value : values) result.append(value).append(';');
        return result.toString();
    }

    private static boolean isCompletedFriendNotice(Message item) {
        if (item == null) return false;
        String text = (firstNonEmpty(item.getTitle(), "") + " "
                + firstNonEmpty(item.getSummary(), "")).toLowerCase(java.util.Locale.ROOT);
        return text.contains("成为了好友") || text.contains("已成为好友")
                || text.contains("已经是好友") || text.contains("好友添加成功")
                || text.contains("添加好友成功");
    }

    private static String firstNonEmpty(String... values) {
        for (String value : values) if (!TextUtils.isEmpty(value)) return value;
        return "";
    }

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest((value == null ? "" : value)
                    .getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : bytes) result.append(String.format("%02x", b & 0xff));
            return result.toString();
        } catch (Exception ignored) {
            return String.valueOf(value == null ? "" : value.hashCode());
        }
    }

    // ========== 已批准好友申请 UID 持久化 ==========
    private static final String KEY_ACCEPTED_FRIENDS = "accepted_friend_uids";

    /** 记录已批准好友申请的 UID，持久化到 SharedPreferences，重启后仍然生效。 */
    public static void markFriendAccepted(Context context, String uid) {
        if (context == null || TextUtils.isEmpty(uid)) return;
        SharedPreferences p = prefs(context);
        String existing = p.getString(KEY_ACCEPTED_FRIENDS, "");
        if (("," + existing + ",").contains("," + uid + ",")) return;
        String updated = existing.isEmpty() ? uid : existing + "," + uid;
        p.edit().putString(KEY_ACCEPTED_FRIENDS, updated).apply();
    }

    /** 检查某个 UID 的好友申请是否已经被批准过。 */
    public static boolean isFriendAccepted(Context context, String uid) {
        if (context == null || TextUtils.isEmpty(uid)) return false;
        String existing = prefs(context).getString(KEY_ACCEPTED_FRIENDS, "");
        return ("," + existing + ",").contains("," + uid + ",");
    }
}
