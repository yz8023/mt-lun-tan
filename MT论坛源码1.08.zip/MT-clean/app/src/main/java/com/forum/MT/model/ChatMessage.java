package com.forum.MT.model;

/** 原生私信会话中的单条聊天消息。 */
public class ChatMessage {
    private String id;
    private String author;
    private String authorUid;
    private String avatarUrl;
    private String content;
    /**
     * 带内联表情的富文本内容（简化 HTML，只保留文本、换行与表情 {@code <img>}）。
     *
     * <p>为什么不直接把表情写进 {@link #content}：content 参与本地回显比对、
     * 去重键与持久化，必须保持稳定的纯文本形态；表情渲染另走这一路，
     * 解析不出内联图时为 null，适配器回落到纯文本快路径。
     */
    private String contentHtml;
    private String time;
    private String date;
    private boolean outgoing;
    /** 本地待确认消息：已提交发送但服务端列表尚未返回，UI 上显示发送中指示。 */
    private boolean pending;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public String getAuthorUid() { return authorUid; }
    public void setAuthorUid(String authorUid) { this.authorUid = authorUid; }
    public String getAvatarUrl() { return avatarUrl; }
    public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public String getContentHtml() { return contentHtml; }
    public void setContentHtml(String contentHtml) { this.contentHtml = contentHtml; }
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public boolean isOutgoing() { return outgoing; }
    public void setOutgoing(boolean outgoing) { this.outgoing = outgoing; }
    public boolean isPending() { return pending; }
    public void setPending(boolean pending) { this.pending = pending; }
}
