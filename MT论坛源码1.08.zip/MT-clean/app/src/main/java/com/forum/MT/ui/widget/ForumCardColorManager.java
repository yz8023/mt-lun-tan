package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

/**
 * 板块卡片自定义颜色管理。
 *
 * 用户可在主题设置页为板块卡片选择背景/描边颜色；
 * 颜色为 0 时表示使用默认样式。
 *
 * 偏好键：
 *   forum_card_color    (int, 0 表示使用默认样式)
 */
public final class ForumCardColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_COLOR = "forum_card_color";

    /** 颜色为 0 时使用的默认卡片背景色 */
    public static final int DEFAULT_CARD_COLOR = Color.parseColor("#FFF9E7");
    /** 默认描边色 */
    public static final int DEFAULT_STROKE_COLOR = Color.parseColor("#F0EAF4");

    private static volatile int customColor = 0;

    private ForumCardColorManager() {}

    /** 应用启动时调用，从磁盘恢复用户设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        customColor = prefs.getInt(KEY_COLOR, 0);
    }

    /** 获取当前自定义颜色，0 表示使用默认样式。 */
    public static int getCustomColor() {
        return customColor;
    }

    /** 设置自定义颜色，0 表示恢复默认样式。持久化。 */
    public static void setCustomColor(Context context, int color) {
        customColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_COLOR, color).apply();
        }
    }

    /** 当前卡片背景色。 */
    public static int resolveCardColor() {
        return customColor != 0 ? customColor : DEFAULT_CARD_COLOR;
    }

    /** 当前卡片描边色。自定义颜色时用其加深变体，否则用默认。 */
    public static int resolveStrokeColor() {
        if (customColor == 0) return DEFAULT_STROKE_COLOR;
        return darkenColor(customColor, 0.25f);
    }

    /** 判断文字应使用深色还是白色（基于自定义色亮度）。 */
    public static boolean isDarkText() {
        if (customColor == 0) return true;
        return isLight(customColor);
    }

    private static boolean isLight(int color) {
        double r = Color.red(color) / 255.0;
        double g = Color.green(color) / 255.0;
        double b = Color.blue(color) / 255.0;
        double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        return luminance > 0.6;
    }

    private static int darkenColor(int color, float factor) {
        int r = Math.max(0, (int) (Color.red(color) * (1 - factor)));
        int g = Math.max(0, (int) (Color.green(color) * (1 - factor)));
        int b = Math.max(0, (int) (Color.blue(color) * (1 - factor)));
        return Color.rgb(r, g, b);
    }

    /**
     * 创建一个板块卡片背景 Drawable（圆角矩形 + 可选描边）。
     */
    public static Drawable createCardBackground(Context context) {
        float density = context.getResources().getDisplayMetrics().density;
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(14f * density);
        drawable.setColor(resolveCardColor());
        drawable.setStroke((int) (1f * density + 0.5f), resolveStrokeColor());
        return drawable;
    }
}