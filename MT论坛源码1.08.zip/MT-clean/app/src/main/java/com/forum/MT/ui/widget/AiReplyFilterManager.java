package com.forum.MT.ui.widget;

import android.content.Context;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * "屏蔽AI回复"开关与检测。
 *
 * 针对 MT 论坛每帖大量出现的模板化灌水回复，实际形态为短句纯填充词，
 * 例如：站楼 / 支持支持 / 打卡学习 / 秒吃 / 大佬牛批感谢分享给力支持 / 沙发 / 第二 等。
 * 这类回复无实质内容（不含问题、具体反馈、图片或对他人回复的引用）。
 *
 * 检测思路：移除回复中所有"填充词"（支持/感谢/试试/打卡/沙发/牛逼…）后，
 * 若剩余内容为空或极短（≤2字），则判定为模板灌水，予以隐藏。
 *
 * 另保留旧的「引号+标题+客套」检测路径作为补充（针对感谢分享「应用名」这类格式）。
 */
public class AiReplyFilterManager {
    private static final String PREF_NAME = "ai_reply_filter_pref";
    private static final String KEY_ENABLED = "enabled";

    /** 移除标点/空白用的正则（白名单方式：只保留中文、字母、数字，去掉所有其他字符）。
     *  ★ 必须用白名单而非黑名单——否则会遗漏 —(em dash)、｜(全角竖线)、/ 等符号，
     *    导致标题简化后中间残留标点，isBracketSpam 的 titleStripped.contains(qStripped)
     *    因中间阻断而匹配失败，"感谢分享「重构假装分享30让A」" 这类自动解锁回复无法被过滤。 */
    private static final Pattern PUNCT_PATTERN = Pattern.compile(
            "[^\\u4e00-\\u9fa5A-Za-z0-9]+");

    /** 旧路径：引号包裹的内容（「」『』【】） */
    private static final Pattern QUOTE_PATTERN =
            Pattern.compile("[「『【（(]\\s*(.+?)\\s*[」』】）)]");

    /**
     * 填充词表（灌水回复常见词汇）。移除后若所剩无几即为模板灌水。
     * 包含：感谢/支持/试用、占楼/抢沙发、赞美、称呼、语气词等。
     * 按长度降序移除，避免短词误吞长词子串（如"支持"吞掉"支持支持"前先移除"支持支持"）。
     */
    private static final String[] FILLER = {
            // 长短语优先
            "感谢分享", "谢谢分享", "多谢分享", "感谢楼主", "谢楼主",
            "给力支持", "支持下", "支持一下", "支持支持", "回复支持", "回复看看", "回复试试", "回复", "一下",
            "下来试试", "下载试试", "试试看", "下来看看", "看看吧",
            "先收下了", "收下了", "需要这个", "正好需要", "正需要",
            "看着不错", "打卡学习", "抢沙发", "占个楼", "站个楼",
            "新版我来啦", "新品来了", "顶一下",
            // 单词/短词
            "感谢", "谢谢", "多谢", "给力", "支持", "试试", "看看", "先马",
            "不错", "牛逼", "牛批", "奈斯", "好家伙", "哇偶", "厉害",
            "打卡", "占楼", "站楼", "前排", "沙发", "第二", "新品", "新版",
            "秒吃", "我来啦", "我来", "学习", "加油", "必须", "真的", "太棒",
            "好棒", "真棒", "赞", "good", "nice", "nb", "牛",
            "大佬", "师傅", "老大", "楼主", "顶"
    };

    /** 按长度降序排列的填充词（静态初始化一次） */
    private static final List<String> FILLER_SORTED;
    static {
        List<String> tmp = new ArrayList<>(Arrays.asList(FILLER));
        Collections.sort(tmp, (a, b) -> Integer.compare(b.length(), a.length()));
        FILLER_SORTED = Collections.unmodifiableList(tmp);
    }

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    /**
     * 判断一条回复是否为模板灌水（"AI自动回复"）。
     *
     * 主判定：移除所有填充词后，剩余实质内容为空或极短（≤2字）。
     * 兜底：旧「引号+标题+客套」格式也判定为灌水。
     *
     * @param contentText 回复纯文本
     * @param threadTitle 当前帖子标题（旧路径使用）
     */
    public static boolean isAiSpamReply(String contentText, String threadTitle) {
        if (contentText == null) return false;
        String content = contentText.trim();
        if (content.isEmpty()) return false;

        // ★ 兜底路径优先：引号引用标题 + 客套（感谢分享「应用名」这类）。
        //   不受长度限制——括号引用标题名的模板回复即使总长超 24 字也要过滤。
        if (isBracketSpam(content, threadTitle)) return true;

        // 主判定：仅对短回复做填充词移除检测
        String stripped = PUNCT_PATTERN.matcher(content).replaceAll("");
        if (stripped.isEmpty() || stripped.length() > 24) return false;

        // 主判定：逐个移除填充词，看剩余
        String work = stripped;
        boolean hasFiller = false;
        for (String f : FILLER_SORTED) {
            if (work.contains(f)) {
                hasFiller = true;
                work = work.replace(f, "");
            }
        }
        if (hasFiller) {
            String remaining = PUNCT_PATTERN.matcher(work).replaceAll("");
            // 严格模式：仅当移除填充词后剩余 0~1 字才判定为灌水，
            // 避免误伤"支持导出"(剩"导出"2字)等短实质回复。
            // 漏网的"看看隐藏"类由回复黑名单兜底。
            if (remaining.length() <= 1) return true;
        }

        return false;
    }

    /** 旧检测路径：引号片段匹配标题 + 含客套短语 */
    private static boolean isBracketSpam(String content, String threadTitle) {
        List<String> quoted = new ArrayList<>();
        Matcher m = QUOTE_PATTERN.matcher(content);
        while (m.find()) quoted.add(m.group(1).trim());
        if (quoted.isEmpty()) return false;

        String title = threadTitle == null ? "" : threadTitle.trim();
        // ★ 匹配前去掉标题中的括号/标点，避免「原创Appxlrth」匹配不到
        //   标题「【原创】Appxlrth1.0.5」的情况（】分隔导致 contains 失败）
        String titleStripped = PUNCT_PATTERN.matcher(title).replaceAll("");
        boolean titleRelated = false;
        String matchedQuotedTitle = null;
        for (String q : quoted) {
            if (q.length() < 2) continue;
            String qStripped = PUNCT_PATTERN.matcher(q).replaceAll("");
            if (qStripped.length() < 2) continue;
            if (!titleStripped.isEmpty()
                    && (titleStripped.contains(qStripped) || qStripped.contains(titleStripped))) {
                titleRelated = true;
                matchedQuotedTitle = q;
                break;
            }
        }
        if (!titleRelated) return false;

        // 实质反馈词只检查标题引用之外的正文。帖子标题自身可能包含“新版”等词，
        // 不能因此让“支持「标题」，感谢分享”这类模板回复绕过过滤。
        String feedbackContent = matchedQuotedTitle == null
                ? content : content.replace(matchedQuotedTitle, "");
        for (String fb : FEEDBACK_WORDS) {
            if (feedbackContent.contains(fb)) return false;
        }

        String[] boilerplate = {"感谢分享", "谢谢分享", "多谢分享", "正需要", "需要这个",
                "回复支持", "回复看看", "回复试试", "不错", "支持下", "支持一下", "支持", "感谢", "试试", "看看", "收下了"};
        for (String p : boilerplate) {
            if (content.contains(p)) return true;
        }
        return false;
    }

    /** 实质反馈词：含这些词的回复有真实反馈内容，即使格式像灌水也不过滤 */
    private static final String[] FEEDBACK_WORDS = {
            "闪退", "崩溃", "卡死", "卡顿", "无响应", "报错", "错误", "bug", "BUG", "Bug",
            "异常", "无法", "不能", "失败", "打不开", "用不了", "黑屏", "白屏", "死机",
            "闪屏", "耗电", "发热", "不兼容", "登录不了", "加载失败", "没反应", "没效果",
            "点不了", "不能用", "无法使用", "不显示", "看不到", "加载不出", "白屏了",
            "建议", "希望", "能否", "可以", "为什么", "怎么", "如何", "请问", "问题",
            "不行", "用不了", "有bug", "有问题", "有bug", "去广告", "不生效",
            "更新后", "升级后", "新版", "上个版本", "之前版本", "恢复不了", "回退",
            "闪退了", "进不去", "点不进", "打不开了", "用不了了", "不好使", "不工作",
            "FC", "fc", "force close", "停止运行", "已停止", "反复", "一直",
            "不识别", "识别不了", "扫描不到", "检测不到", "连接不上", "连不上",
            "失效", "无效", "没用", "没作用", "不起作用", "安装失败",
            "签名", "冲突", "覆盖", "覆盖安装", "数据丢失", "丢失", "找不到"
    };
}
