package com.forum.MT.ui.message;
import com.forum.MT.ui.BaseActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.forum.MT.R;
import com.forum.MT.adapter.MessageAdapter;
import com.forum.MT.model.Message;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.network.NoticeBadgeManager;
import com.forum.MT.session.DiscuzUserActionManager;
import com.forum.MT.session.UserSessionManager;

import java.util.List;

/**
 * 消息详情页（原生 RecyclerView 列表）
 * 支持6个分类：我的消息(pm)、我的粉丝(follower)、我的帖子(mypost)、
 * 坛友互动(interactive)、系统提醒(system)、应用提醒(app)
 * 支持删除和屏蔽操作
 */
public class NoticeDetailActivity extends BaseActivity {

    public static final String EXTRA_VIEW_TYPE = "view_type";
    public static final String EXTRA_TITLE = "title";
    /** 坛友互动初始子类型（poke/friend/click/wall/comment），用于直接进入指定 tab。 */
    public static final String EXTRA_INTERACTIVE_TYPE = "interactive_type";
    public static final String RESULT_CLEARED = "cleared";
    public static final String RESULT_VIEW_TYPE = "result_view_type";

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView tvTitle, tvEmptyHint, tvBack;
    private MessageAdapter adapter;
    private String viewType;
    private String baseUrl;
    private String interactiveType = "poke";
    private String badgeViewType;
    private HorizontalScrollView interactiveTabsScroll;
    private TextView tabInteractivePoke, tabInteractiveFriend, tabInteractiveNotice,
            tabInteractiveWall, tabInteractiveComment, tabInteractiveShare;
    private String cachedFormhash;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private int loadGeneration = 0;
    private static final long PAGE_LOAD_TIMEOUT_MS = 30000L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_detail);

        baseUrl = getIntent().getStringExtra("url");
        viewType = getIntent().getStringExtra(EXTRA_VIEW_TYPE);
        String title = getIntent().getStringExtra(EXTRA_TITLE);

        tvTitle = findViewById(R.id.tv_title);
        tvBack = findViewById(R.id.tv_back);
        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        tvEmptyHint = findViewById(R.id.tv_empty_hint);
        interactiveTabsScroll = findViewById(R.id.interactive_tabs_scroll);
        tabInteractivePoke = findViewById(R.id.tab_interactive_poke);
        tabInteractiveFriend = findViewById(R.id.tab_interactive_friend);
        tabInteractiveNotice = findViewById(R.id.tab_interactive_notice);
        tabInteractiveWall = findViewById(R.id.tab_interactive_wall);
        tabInteractiveComment = findViewById(R.id.tab_interactive_comment);
        tabInteractiveShare = findViewById(R.id.tab_interactive_share);

        if (title != null) tvTitle.setText(title);
        setupInteractiveTabs();

        // 返回按钮
        tvBack.setOnClickListener(v -> {
            setResult(RESULT_OK, getIntent().putExtra(RESULT_CLEARED, true)
                    .putExtra(RESULT_VIEW_TYPE, viewType != null ? viewType : ""));
            finish();
        });

        // 设置 RecyclerView
        adapter = new MessageAdapter(this);
        // 互动页按五个真实子分类分别维护已读集合和角标。
        badgeViewType = getBadgeViewType();
        adapter.setViewType(badgeViewType);
        adapter.setOnItemClickListener((message, position) -> {
            if ("interactive".equals(viewType)) {
                updateInteractiveAggregateBadge();
                updateInteractiveTabState();
                // ★ 留言通知：整行点击只标记已读/更新角标，不跳转主页。
                //   跳转主页由头像/用户名点击(onAvatarClick)处理。
                if ("wall".equals(interactiveType)) {
                    return;
                }
            }
            // 私信必须优先进入原生聊天页，不能因为摘要中偶然包含 tid= 而跳到帖子页。
            if ("pm".equals(viewType)) {
                String pmid = message.getPmid();
                if (pmid != null && !pmid.isEmpty()) {
                    Intent chatIntent = new Intent(this, ChatActivity.class);
                    chatIntent.putExtra(ChatActivity.EXTRA_PMID, pmid);
                    chatIntent.putExtra(ChatActivity.EXTRA_UID, message.getAuthorUid());
                    chatIntent.putExtra(ChatActivity.EXTRA_NAME, message.getAuthor());
                    chatIntent.putExtra(ChatActivity.EXTRA_AVATAR, message.getAvatarUrl());
                    startActivity(chatIntent);
                } else {
                    Toast.makeText(this, "无法打开私信：缺少会话ID", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            String summary = message.getSummary();
            if (summary != null && !summary.isEmpty()) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("tid=(\\d+)").matcher(summary);
                if (m.find()) {
                    String tid = m.group(1);
                    String pid = message.getPid();
                    android.util.Log.e("MT_NOTICE_CLICK", "NoticeDetail click tid=" + tid + " pid=" + pid);
                    Intent intent = new Intent(this, com.forum.MT.ui.detail.ThreadDetailActivity.class);
                    intent.putExtra("tid", tid);
                    if (pid != null && !pid.isEmpty()) {
                        intent.putExtra("pid", pid);
                    }
                    startActivity(intent);
                }
            }
        });

        // ★ 删除/屏蔽按钮回调
        adapter.setOnActionClickListener(new MessageAdapter.OnActionClickListener() {
            @Override
            public void onDelete(Message message, int position) {
                showDeleteConfirmDialog(message, position);
            }

            @Override
            public void onBlock(Message message, int position) {
                showBlockConfirmDialog(message, position);
            }

            @Override
            public void onFriendAction(Message message, int position) {
                acceptFriendRequest(message, position);
            }
        });

        // ★ 头像/用户名点击：留言通知才跳转到留言者主页
        adapter.setOnAvatarClickListener((message, position) -> {
            if ("interactive".equals(viewType) && "wall".equals(interactiveType)) {
                openWallUserProfile(message);
            } else if ("pm".equals(viewType)) {
                String pmid = message.getPmid();
                if (pmid != null && !pmid.isEmpty()) {
                    Intent chatIntent = new Intent(this, ChatActivity.class);
                    chatIntent.putExtra(ChatActivity.EXTRA_PMID, pmid);
                    chatIntent.putExtra(ChatActivity.EXTRA_UID, message.getAuthorUid());
                    chatIntent.putExtra(ChatActivity.EXTRA_NAME, message.getAuthor());
                    chatIntent.putExtra(ChatActivity.EXTRA_AVATAR, message.getAvatarUrl());
                    startActivity(chatIntent);
                }
            }
        });

        // ★ 用户名点击：跳转到用户主页（所有类型通用）
        adapter.setOnUsernameClickListener((message, position) -> {
            String uid = message.getAuthorUid();
            if (!TextUtils.isEmpty(uid) && !"0".equals(uid)) {
                Intent intent = new Intent(this,
                        com.forum.MT.ui.space.UserProfileActivity.class);
                intent.putExtra("uid", uid);
                if (!TextUtils.isEmpty(message.getAuthor())) {
                    intent.putExtra("username", message.getAuthor());
                }
                startActivity(intent);
            } else {
                Toast.makeText(this, "无法获取该用户的UID", Toast.LENGTH_SHORT).show();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // 加载数据
        if (baseUrl != null) {
            loadData(buildCurrentUrl());
        } else {
            showEmpty("参数错误");
        }
    }

    private String getBadgeViewType() {
        if ("interactive".equals(viewType)) {
            String type = TextUtils.isEmpty(interactiveType) ? "poke" : interactiveType;
            return "interactive_" + type;
        }
        return viewType != null ? viewType : "";
    }

    private void updateInteractiveAggregateBadge() {
        if (!"interactive".equals(viewType)) return;
        String[] types = {"poke", "friend", "click", "wall", "comment", "share"};
        int total = NoticeBadgeManager.getInteractiveAggregate(this, types);
        NoticeBadgeManager.setNewCount(this, "interactive", total);
    }

    private void setupInteractiveTabs() {
        if (!"interactive".equals(viewType)) {
            interactiveTabsScroll.setVisibility(View.GONE);
            return;
        }

        interactiveTabsScroll.setVisibility(View.VISIBLE);
        interactiveType = getIntent().getStringExtra(EXTRA_INTERACTIVE_TYPE);
        if (TextUtils.isEmpty(interactiveType)) interactiveType = getQueryParameter(baseUrl, "type");
        if (TextUtils.isEmpty(interactiveType)) interactiveType = "poke";
        updateInteractiveTabState();


        tabInteractivePoke.setOnClickListener(v -> switchInteractiveType("poke"));
        tabInteractiveFriend.setOnClickListener(v -> switchInteractiveType("friend"));
        tabInteractiveNotice.setOnClickListener(v -> switchInteractiveType("click"));
        tabInteractiveWall.setOnClickListener(v -> switchInteractiveType("wall"));
        tabInteractiveComment.setOnClickListener(v -> switchInteractiveType("comment"));
        tabInteractiveShare.setOnClickListener(v -> switchInteractiveType("share"));
    }

    private void switchInteractiveType(String type) {
        String normalizedType = type != null ? type : "";
        if (normalizedType.equals(interactiveType)) return;

        interactiveType = normalizedType;
        badgeViewType = getBadgeViewType();
        adapter.setViewType(badgeViewType);
        updateInteractiveTabState();
        loadData(buildCurrentUrl());
    }

    private void updateInteractiveTabState() {
        int selectedColor = getColor(R.color.text_white);
        int selectedBgColor = getColor(R.color.primary);
        int normalColor = getColor(R.color.text_secondary);

        setInteractiveTabText(tabInteractivePoke, "打招呼", "poke");
        setInteractiveTabText(tabInteractiveFriend, "好友", "friend");
        setInteractiveTabText(tabInteractiveNotice, "挺你", "click");
        setInteractiveTabText(tabInteractiveWall, "留言", "wall");
        setInteractiveTabText(tabInteractiveComment, "评论", "comment");
        setInteractiveTabText(tabInteractiveShare, "分享", "share");

        applyTabStyle(tabInteractivePoke, "poke".equals(interactiveType), selectedColor, selectedBgColor, normalColor);
        applyTabStyle(tabInteractiveFriend, "friend".equals(interactiveType), selectedColor, selectedBgColor, normalColor);
        applyTabStyle(tabInteractiveNotice, "click".equals(interactiveType), selectedColor, selectedBgColor, normalColor);
        applyTabStyle(tabInteractiveWall, "wall".equals(interactiveType), selectedColor, selectedBgColor, normalColor);
        applyTabStyle(tabInteractiveComment, "comment".equals(interactiveType), selectedColor, selectedBgColor, normalColor);
        applyTabStyle(tabInteractiveShare, "share".equals(interactiveType), selectedColor, selectedBgColor, normalColor);
    }

    private void applyTabStyle(TextView tab, boolean selected, int selectedColor, int selectedBgColor, int normalColor) {
        if (tab == null) return;
        if (selected) {
            tab.setBackgroundResource(R.drawable.tab_interactive_selected);
            tab.setTextColor(selectedColor);
            tab.setTypeface(null, android.graphics.Typeface.BOLD);
        } else {
            tab.setBackgroundResource(R.drawable.tab_interactive_transparent);
            tab.setTextColor(normalColor);
            tab.setTypeface(null, android.graphics.Typeface.NORMAL);
        }
    }

    private void setInteractiveTabText(TextView tab, String label, String type) {
        if (tab == null) return;
        int count = NoticeBadgeManager.getNewCount(this, "interactive_" + type);
        String suffix = count > 0 ? " " + (count > 99 ? "99+" : String.valueOf(count)) : "";
        SpannableString text = new SpannableString(label + suffix);
        if (!suffix.isEmpty()) {
            int start = label.length();
            // 选中态用白色角标，未选中态用红色角标
            boolean isSelected = type.equals(interactiveType);
            text.setSpan(new ForegroundColorSpan(isSelected
                    ? getColor(R.color.text_white) : getColor(R.color.red_500)), start,
                    text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            text.setSpan(new RelativeSizeSpan(0.85f), start,
                    text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        tab.setText(text);
    }

    private String buildCurrentUrl() {
        if (TextUtils.isEmpty(baseUrl) || !"interactive".equals(viewType)) return baseUrl;

        String cleanUrl = removeQueryParameter(baseUrl, "type");
        String selectedType = TextUtils.isEmpty(interactiveType) ? "poke" : interactiveType;
        return cleanUrl + (cleanUrl.contains("?") ? "&" : "?") + "type=" + selectedType;
    }

    private static String getQueryParameter(String url, String key) {
        if (TextUtils.isEmpty(url) || TextUtils.isEmpty(key)) return "";
        try {
            String value = android.net.Uri.parse(url).getQueryParameter(key);
            return value != null ? value : "";
        } catch (Exception ignored) {
            return "";
        }
    }

    private static String removeQueryParameter(String url, String key) {
        if (TextUtils.isEmpty(url) || TextUtils.isEmpty(key)) return url;
        try {
            android.net.Uri source = android.net.Uri.parse(url);
            android.net.Uri.Builder builder = source.buildUpon().clearQuery();
            for (String name : source.getQueryParameterNames()) {
                if (key.equals(name)) continue;
                for (String value : source.getQueryParameters(name)) {
                    builder.appendQueryParameter(name, value);
                }
            }
            return builder.build().toString();
        } catch (Exception ignored) {
            return url;
        }
    }

    private void loadData(String url) {
        final int requestGeneration = ++loadGeneration;
        progressBar.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
        tvEmptyHint.setVisibility(View.GONE);
        // ★ 立即清空旧数据，防止切换tab时残留上一分类的通知条目
        adapter.setMessageList(null);

        final Runnable timeoutAction = () -> {
            if (requestGeneration != loadGeneration || isFinishing() || isDestroyed()) return;
            loadGeneration++;
            progressBar.setVisibility(View.GONE);
            showEmpty("加载超时，请检查网络后重试");
        };
        mainHandler.postDelayed(timeoutAction, PAGE_LOAD_TIMEOUT_MS);

        new Thread(() -> {
            try {
                HttpClient httpClient = HttpClient.getInstance();
                httpClient.syncFromCookieManager();

                String html;
                // 私信列表必须请求移动端 home.php?mod=space&do=pm
                if ("pm".equals(viewType)) {
                    html = httpClient.get(url);
                } else if ("follower".equals(viewType)) {
                    html = httpClient.get(url);
                } else {
                    html = httpClient.getDesktop(url);
                }

                if (requestGeneration != loadGeneration) return;

                // 检测是否为登录页
                if (ForumParser.isLoginPage(html)) {
                    runOnUiThread(() -> {
                        if (requestGeneration != loadGeneration) return;
                        mainHandler.removeCallbacks(timeoutAction);
                        progressBar.setVisibility(View.GONE);
                        showEmpty("登录已过期，请重新登录");
                    });
                    return;
                }

                // 缓存 formhash（后续删除/屏蔽需要）
                String parsedFormhash = ForumParser.parseFormhash(html);

                List<Message> items;
                if ("pm".equals(viewType)) {
                    items = ForumParser.parsePmList(html);
                } else if ("follower".equals(viewType)) {
                    items = ForumParser.parseFollowerList(html);
                } else {
                    items = ForumParser.parseNoticeList(html);
                }

                List<Message> finalItems = items;
                final String snapshot = ("pm".equals(viewType) || "follower".equals(viewType))
                        ? null : NoticeBadgeManager.buildSnapshot(badgeViewType, html, null);
                runOnUiThread(() -> {
                    if (requestGeneration != loadGeneration || isFinishing() || isDestroyed()) return;
                    mainHandler.removeCallbacks(timeoutAction);
                    progressBar.setVisibility(View.GONE);
                    cachedFormhash = parsedFormhash;
                    if (snapshot != null) {
                        NoticeBadgeManager.saveCurrentAndGetNewCount(this, badgeViewType, snapshot);
                    }
                    // 进入列表不等于已读；只在用户点击具体条目时推进 readSet。
                    if ("interactive".equals(viewType)) {
                        updateInteractiveAggregateBadge();
                        updateInteractiveTabState();
                    }
                    if (finalItems != null && !finalItems.isEmpty()) {
                        adapter.setMessageList(finalItems);
                        recyclerView.setVisibility(View.VISIBLE);
                        tvEmptyHint.setVisibility(View.GONE);
                    } else {
                        showEmpty("暂无消息内容");
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (requestGeneration != loadGeneration || isFinishing() || isDestroyed()) return;
                    mainHandler.removeCallbacks(timeoutAction);
                    progressBar.setVisibility(View.GONE);
                    String detail = e.getMessage();
                    showEmpty(TextUtils.isEmpty(detail) ? "加载失败，请稍后重试" : "加载失败: " + detail);
                });
            }
        }, "notice-detail-load-" + requestGeneration).start();
    }

    private void showEmpty(String hint) {
        recyclerView.setVisibility(View.GONE);
        tvEmptyHint.setVisibility(View.VISIBLE);
        tvEmptyHint.setText(hint);
    }

    /** 留言通知：提取发送者 UID 并跳转到其主页（排除自己的 UID） */
    private void openWallUserProfile(Message message) {
        if (message == null) return;
        String uid = message.getAuthorUid();
        String myUid = UserSessionManager.getInstance().getUid(this);
        if (!TextUtils.isEmpty(uid) && uid.equals(myUid)) {
            uid = null;
        }
        if (TextUtils.isEmpty(uid)) {
            String text = message.getTitle();
            if (TextUtils.isEmpty(text)) text = message.getSummary();
            if (text != null) {
                java.util.regex.Matcher um = java.util.regex.Pattern.compile(
                        "(?:space-uid-|uid=|authorid=|touid=)(\\d+)").matcher(text);
                while (um.find()) {
                    String candidate = um.group(1);
                    if (!candidate.equals(myUid) && !"0".equals(candidate)) {
                        uid = candidate;
                        break;
                    }
                }
            }
        }
        if (TextUtils.isEmpty(uid) && message.getAvatarUrl() != null) {
            java.util.regex.Matcher am = java.util.regex.Pattern.compile(
                    "(?:uid=)(\\d+)", java.util.regex.Pattern.CASE_INSENSITIVE)
                    .matcher(message.getAvatarUrl());
            if (am.find()) {
                String candidate = am.group(1);
                if (!candidate.equals(myUid) && !"0".equals(candidate)) {
                    uid = candidate;
                }
            }
        }
        if (!TextUtils.isEmpty(uid) && !"0".equals(uid)) {
            Intent intent = new Intent(this,
                    com.forum.MT.ui.space.UserProfileActivity.class);
            intent.putExtra("uid", uid);
            if (!TextUtils.isEmpty(message.getAuthor())) {
                intent.putExtra("username", message.getAuthor());
            }
            startActivity(intent);
        } else {
            Toast.makeText(this, "无法获取该用户的UID", Toast.LENGTH_SHORT).show();
        }
    }

    private void acceptFriendRequest(Message message, int position) {
        String uid = message != null ? message.getAuthorUid() : null;
        if (TextUtils.isEmpty(uid)) {
            Toast.makeText(this, "无法处理好友申请：缺少用户ID", Toast.LENGTH_SHORT).show();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            String error = DiscuzUserActionManager.acceptFriendRequest(this, uid);
            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                if (error == null) {
                    // ★ 不删除通知条目，而是更新文案让 isFriendRequestMessage 返回 false（隐藏按钮）。
                    String oldTitle = message.getTitle();
                    if (oldTitle == null) oldTitle = "";
                    if (!oldTitle.contains("已成为好友") && !oldTitle.contains("已添加为好友")) {
                        message.setTitle(oldTitle + "（已成为好友）");
                    }
                    int pos = adapter.findItemPosition(message);
                    if (pos >= 0) {
                        adapter.notifyItemChanged(pos);
                    }
                    NoticeBadgeManager.markItemRead(this, badgeViewType,
                            NoticeBadgeManager.stableKeyFor(message));
                    NoticeBadgeManager.markNoticeClicked(this, badgeViewType,
                            NoticeBadgeManager.stableKeyFor(message));
                    NoticeBadgeManager.markFriendAccepted(this, uid);
                    updateInteractiveAggregateBadge();
                    Toast.makeText(this, "已添加为好友", Toast.LENGTH_SHORT).show();
                } else {
                    android.util.Log.e("MT_FRIEND", "showToast: " + error);
                    Toast.makeText(this, "添加好友失败: " + error, Toast.LENGTH_LONG).show();
                }
            });
        }, "accept-friend-request").start();
    }

    // ========== 删除功能 ==========

    private void showDeleteConfirmDialog(Message message, int position) {
        new AlertDialog.Builder(this)
                .setTitle("删除提醒")
                .setMessage("确定要删除这条提醒吗？")
                .setPositiveButton("删除", (dialog, which) -> executeDelete(message, position))
                .setNegativeButton("取消", null)
                .show();
    }

    private void executeDelete(Message message, int position) {
        String uid = message.getAuthorUid();
        if ("pm".equals(viewType)) {
            if (TextUtils.isEmpty(uid)) {
                Toast.makeText(this, "无法删除：缺少会话用户ID", Toast.LENGTH_SHORT).show();
                return;
            }

            progressBar.setVisibility(View.VISIBLE);
            new Thread(() -> {
                boolean success = DiscuzUserActionManager.deletePrivateMessage(
                        this, uid, cachedFormhash, message.getDeleteUrl());
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    if (success) {
                        adapter.removeItem(position);
                        Toast.makeText(NoticeDetailActivity.this, "删除成功",
                                Toast.LENGTH_SHORT).show();
                        if (adapter.getItemCount() == 0) showEmpty("暂无消息内容");
                    } else {
                        Toast.makeText(NoticeDetailActivity.this,
                                "删除失败，请稍后重试", Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();
            return;
        }

        executeNoticeDelete(message, position);
    }

    /** 非私信通知仍使用 Discuz! 的 delnotice 接口。 */
    private void executeNoticeDelete(Message message, int position) {
        String noticeId = message.getPmid();
        if (TextUtils.isEmpty(noticeId)) {
            Toast.makeText(this, "无法删除：缺少通知ID", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                HttpClient httpClient = HttpClient.getInstance();
                httpClient.syncFromCookieManager();
                String deleteUrl = HttpClient.BASE_URL
                        + "home.php?mod=misc&ac=ajax&op=delnotice&inajax=1&id=" + noticeId;
                if (!TextUtils.isEmpty(cachedFormhash)) {
                    deleteUrl += "&formhash=" + cachedFormhash;
                }
                String result = httpClient.get(deleteUrl);
                boolean success = result != null
                        && (result.contains("succeed") || result.contains("成功"));
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    if (success) {
                        adapter.removeItem(position);
                        Toast.makeText(NoticeDetailActivity.this, "删除成功",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(NoticeDetailActivity.this, "删除失败",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(NoticeDetailActivity.this,
                            "删除失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    // ========== 屏蔽功能 ==========

    private void showBlockConfirmDialog(Message message, int position) {
        String authorName = message.getAuthor() != null ? message.getAuthor() : "该用户";
        new AlertDialog.Builder(this)
                .setTitle("屏蔽用户")
                .setMessage("确定要屏蔽 " + authorName + " 吗？屏蔽后将不再收到该用户的通知。")
                .setPositiveButton("屏蔽", (dialog, which) -> executeBlock(message, position))
                .setNegativeButton("取消", null)
                .show();
    }

    private void executeBlock(Message message, int position) {
        String uid = message.getAuthorUid();
        if (uid == null || uid.isEmpty()) {
            Toast.makeText(this, "无法屏蔽：缺少用户信息", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                HttpClient httpClient = HttpClient.getInstance();
                httpClient.syncFromCookieManager();

                // Discuz! 屏蔽用户通知接口
                String blockUrl = HttpClient.BASE_URL
                        + "home.php?mod=spacecp&ac=common&op=ignore&authorid=" + uid
                        + "&type=post&handlekey=noticeignore";
                if (cachedFormhash != null && !cachedFormhash.isEmpty()) {
                    blockUrl += "&formhash=" + cachedFormhash;
                }

                String result = httpClient.get(blockUrl);

                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    if (result != null && !result.contains("error")) {
                        adapter.removeItem(position);
                        Toast.makeText(NoticeDetailActivity.this, "已屏蔽该用户", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(NoticeDetailActivity.this, "屏蔽失败", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(NoticeDetailActivity.this, "屏蔽失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
    @Override
    protected void onDestroy() {
        loadGeneration++;
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

}