package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理回复弹窗（dialog_reply_comment）的自定义配色：
 * 文字色、背景色、边框色、按钮背景色。
 * 颜色为 0 表示使用默认值。
 */
public class ReplyDialogColorManager {

    private static final String PREFS_NAME = "mt_forum_prefs";

    private static final String KEY_TEXT      = "reply_dialog_text";
    private static final String KEY_BG        = "reply_dialog_bg";
    private static final String KEY_BORDER    = "reply_dialog_border";
    private static final String KEY_BTN       = "reply_dialog_btn";

    private ReplyDialogColorManager() {}

    // ==================== 文字颜色 ====================

    public static int getTextColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_TEXT, 0);
    }

    public static int resolveTextColor(Context context) {
        int color = getTextColor(context);
        return color != 0 ? color : 0xFF333333;
    }

    public static void setTextColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_TEXT, color).apply();
    }

    // ==================== 背景颜色 ====================

    public static int getBgColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_BG, 0);
    }

    public static int resolveBgColor(Context context) {
        int color = getBgColor(context);
        return color != 0 ? color : 0xFFFFFFFF;
    }

    public static void setBgColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_BG, color).apply();
    }

    // ==================== 边框颜色 ====================

    public static int getBorderColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_BORDER, 0);
    }

    public static int resolveBorderColor(Context context) {
        int color = getBorderColor(context);
        return color != 0 ? color : 0xFFE0E0E0;
    }

    public static void setBorderColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_BORDER, color).apply();
    }

    // ==================== 按钮背景色 ====================

    public static int getBtnColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_BTN, 0);
    }

    public static int resolveBtnColor(Context context) {
        int color = getBtnColor(context);
        return color != 0 ? color : 0xFF4CAF50;
    }

    public static void setBtnColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_BTN, color).apply();
    }
}
