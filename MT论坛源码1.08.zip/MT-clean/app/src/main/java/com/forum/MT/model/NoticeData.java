package com.forum.MT.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 通知数据 - 对应官方APK的NoticeData
 * 每个Tab对应一个NoticeData，包含列表、加载状态、错误信息、分页
 */
public class NoticeData {
    private List<NoticeItem> items = new ArrayList<>();
    private boolean isLoading;
    private String error;
    private int currentPage = 1;
    private int totalPages = 1;
    private boolean hasMore = true;

    public NoticeData() {}

    public NoticeData(List<NoticeItem> items, boolean isLoading, String error, int currentPage, int totalPages) {
        this.items = items != null ? items : new ArrayList<>();
        this.isLoading = isLoading;
        this.error = error;
        this.currentPage = currentPage;
        this.totalPages = totalPages;
        this.hasMore = currentPage < totalPages;
    }

    public List<NoticeItem> getItems() { return items; }
    public void setItems(List<NoticeItem> items) { this.items = items != null ? items : new ArrayList<>(); }

    public boolean isLoading() { return isLoading; }
    public void setLoading(boolean loading) { isLoading = loading; }

    public String getError() { return error; }
    public void setError(String error) { this.error = error; }

    public int getCurrentPage() { return currentPage; }
    public void setCurrentPage(int currentPage) { this.currentPage = currentPage; }

    public int getTotalPages() { return totalPages; }
    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
        this.hasMore = currentPage < totalPages;
    }

    public boolean hasMore() { return hasMore; }
    public void setHasMore(boolean hasMore) { this.hasMore = hasMore; }
}