package com.forum.MT.ui.post;
import com.forum.MT.ui.BaseActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.forum.MT.R;
import com.forum.MT.ui.post.ForumPickerAdapter;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import android.widget.ListView;
import android.widget.ProgressBar;
import com.forum.MT.model.ForumCategory;
import com.forum.MT.model.PostPageData;
import com.forum.MT.model.PostResult;
import com.forum.MT.model.PostType;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.network.PostPageParser;
import com.forum.MT.ui.detail.ForumSmileyData;
import com.forum.MT.ui.widget.SmileyPanelHelper;
import com.forum.MT.util.MarkdownBbcodeConverter;
import com.forum.MT.util.MarkdownImportHelper;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 发帖页面 Activity
 * 完全对接网页端功能：表情、@朋友、插入、附件、高级
 */
public class PostActivity extends BaseActivity {

    // views
    private TextView tvCancel;
    private TextView tvDrafts; // 草稿箱按钮
    private TextInputEditText etTitle;
    private TextView tvTitleCount;
    private LinearLayout llCircleSelector;
    private TextView tvSelectedForum;
    private TextInputEditText etContent;
    private MaterialButton btnPublish;
    private TextView tvError;
    private TextView tvCircleLabel;

    // 底部工具栏按钮（图标 + 文字的竖排容器）
    private LinearLayout btnSmiley, btnAt, btnInsert, btnImage, btnAttach, btnAdvanced, btnMarkdown;
    // 需要跟随面板开关切换选中态的图标/文字
    private ImageView ivToolSmiley, ivToolAt, ivToolAdvanced;
    private TextView tvToolSmiley, tvToolAt, tvToolAdvanced;

    // 投票区块
    private LinearLayout llPollSection, llPollOptions;
    private EditText etPollMaxChoices, etPollExpiration;
    private TextView tabPost, tabPoll;
    private CheckBox cbPollVisibility, cbPollOvert, cbPollSingleMode;
    private EditText etPollBatch;
    private boolean pollEnabled = false;
    private int pendingPollOptionIndex = -1;
    private LinearLayout llSmileyPanel, llAtPanel;
    private com.google.android.material.tabs.TabLayout tlSmileyTabs;
    private androidx.viewpager.widget.ViewPager vpSmiley;
    private TextInputEditText etAtUsername;
    private TextView btnAtInsert;
    private LinearLayout llAdvancedOptions, llAttachList;
    private LinearLayout llImagePreview;

    // data
    private String selectedFid;
    private String selectedForumName;
    private String currentFormhash;
    private String currentUid;
    private String currentHash;

    // 发帖页面数据（对齐官方 PostPageData）
    private PostPageData pageData;
    private String selectedTypeId;

    // 防重复提交标志（对齐官方 PostComposerState.isSubmitting）
    private boolean isSubmitting = false;

    // 附件列表
    private final List<AttachFile> attachFiles = new ArrayList<>();
    /** 上次渲染缩略图时的顺序指纹，用于避免正文每次按键都重建图片视图。 */
    private String lastImageOrderSignature = "";
    /** 标题长度上限，与布局中 et_title 的 maxLength 保持一致。 */
    private static final int TITLE_MAX = 80;

    private static final int REQUEST_FILE_PICK = 1001;
    private static final int REQUEST_IMAGE_PICK = 1002;
    private static final int REQUEST_POLL_IMAGE_PICK = 1003;

    private static class AttachFile {
        String name;
        String path;
        String url;
        String bbcode;
        String aid;

        AttachFile(String name, String path) {
            this.name = name;
            this.path = path;
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_activity);

        initViews();
        setupTitleCounter();
        setupCircleSelector();
        setupToolbarButtons();
        setupPublishButton();
        loadFormhashAndUserInfo();
    }

    private void initViews() {
        tvCancel = findViewById(R.id.tv_cancel);
        // 取消与返回键共用同一套"放弃草稿"确认逻辑。
        tvCancel.setOnClickListener(v -> onBackPressed());

        tvDrafts = findViewById(R.id.tv_drafts);
        tvDrafts.setOnClickListener(v -> showDraftList());

        etTitle = findViewById(R.id.et_title);
        tvTitleCount = findViewById(R.id.tv_title_count);
        llCircleSelector = findViewById(R.id.ll_circle_selector);
        tvSelectedForum = findViewById(R.id.tv_selected_forum);
        etContent = findViewById(R.id.et_content);
        btnPublish = findViewById(R.id.btn_publish);
        tvError = findViewById(R.id.tv_error);
        tvCircleLabel = findViewById(R.id.tv_circle_label);

        // 预览按钮
        TextView tvPreview = findViewById(R.id.tv_preview);
        if (tvPreview != null) {
            tvPreview.setOnClickListener(v -> showPreview());
        }

        // 五大功能按钮
        btnSmiley = findViewById(R.id.btn_smiley);
        btnAt = findViewById(R.id.btn_at);
        btnInsert = findViewById(R.id.btn_insert);
        btnMarkdown = findViewById(R.id.btn_markdown);
        btnImage = findViewById(R.id.btn_image);
        btnAttach = findViewById(R.id.btn_attach);
        btnAdvanced = findViewById(R.id.btn_advanced);

        ivToolSmiley = findViewById(R.id.iv_tool_smiley);
        ivToolAt = findViewById(R.id.iv_tool_at);
        ivToolAdvanced = findViewById(R.id.iv_tool_advanced);
        tvToolSmiley = findViewById(R.id.tv_tool_smiley);
        tvToolAt = findViewById(R.id.tv_tool_at);
        tvToolAdvanced = findViewById(R.id.tv_tool_advanced);

        // 功能面板
        llSmileyPanel = findViewById(R.id.ll_smiley_panel);
        tlSmileyTabs = findViewById(R.id.tl_smiley_tabs);
        vpSmiley = findViewById(R.id.vp_smiley);
        llAtPanel = findViewById(R.id.ll_at_panel);
        etAtUsername = findViewById(R.id.et_at_username);
        btnAtInsert = findViewById(R.id.btn_at_insert);
        llAdvancedOptions = findViewById(R.id.ll_advanced_options);
        llAttachList = findViewById(R.id.ll_attach_list);
        llImagePreview = findViewById(R.id.ll_image_preview);

        // 投票区块
        llPollSection = findViewById(R.id.ll_poll_section);
        llPollOptions = findViewById(R.id.ll_poll_options);
        etPollMaxChoices = findViewById(R.id.et_poll_max_choices);
        etPollExpiration = findViewById(R.id.et_poll_expiration);
        cbPollVisibility = findViewById(R.id.cb_poll_visibility);
        cbPollOvert = findViewById(R.id.cb_poll_overt);
        cbPollSingleMode = findViewById(R.id.cb_poll_single_mode);
        etPollBatch = findViewById(R.id.et_poll_batch);
        TextView btnPollAddOption = findViewById(R.id.btn_poll_add_option);
        cbPollSingleMode.setOnCheckedChangeListener((button, checked) -> {
            // 单框模式：隐藏独立选项+增加按钮，显示大文本框
            llPollOptions.setVisibility(checked ? View.GONE : View.VISIBLE);
            btnPollAddOption.setVisibility(checked ? View.GONE : View.VISIBLE);
            etPollBatch.setVisibility(checked ? View.VISIBLE : View.GONE);
            if (checked && llPollOptions.getChildCount() == 0) {
                // 首次切到单框模式不需要初始化独立选项
            } else if (!checked && llPollOptions.getChildCount() == 0) {
                // 切回独立模式时初始化选项
                addPollOption();
                addPollOption();
                addPollOption();
            }
        });
        tabPost = findViewById(R.id.tab_post);
        tabPoll = findViewById(R.id.tab_poll);
        tabPost.setOnClickListener(v -> switchTab(false));
        tabPoll.setOnClickListener(v -> switchTab(true));
        findViewById(R.id.btn_poll_add_option).setOnClickListener(v -> addPollOption());
    }

    private void switchTab(boolean poll) {
        pollEnabled = poll;
        llPollSection.setVisibility(poll ? View.VISIBLE : View.GONE);
        tabPost.setTextColor(androidx.core.content.ContextCompat.getColor(this,
                poll ? R.color.text_secondary : R.color.accent_primary));
        tabPoll.setTextColor(androidx.core.content.ContextCompat.getColor(this,
                poll ? R.color.accent_primary : R.color.text_secondary));
        // Tab 下划线指示器
        findViewById(R.id.indicator_post).setVisibility(poll ? View.GONE : View.VISIBLE);
        findViewById(R.id.indicator_poll).setVisibility(poll ? View.VISIBLE : View.GONE);
        if (poll) {
            if (llPollOptions.getChildCount() == 0) {
                addPollOption();
                addPollOption();
                addPollOption();
            }
            final android.widget.ScrollView sv = findViewById(R.id.sv_post_content);
            if (sv != null) sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void setupTitleCounter() {
        etTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int len = s != null ? s.length() : 0;
                tvTitleCount.setText(len + "/" + TITLE_MAX);
                // 接近上限时把计数染红，提示用户快没位置了。
                tvTitleCount.setTextColor(androidx.core.content.ContextCompat.getColor(
                        PostActivity.this,
                        len >= TITLE_MAX ? R.color.error : R.color.text_hint));
                clearError();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
        // 正文变化时也清掉上一次的报错，避免旧提示一直挂着。
        etContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                clearError();
            }
            @Override
            public void afterTextChanged(Editable s) {
                // 用户手动移动或删除正文里的 [attachimg] 时，缩略图顺序跟着调整。
                maybeRefreshImagePreviewOrder();
            }
        });
        // 点正文时收起所有面板，让编辑区尽量大。
        etContent.setOnClickListener(v -> {
            if (llSmileyPanel.getVisibility() == View.VISIBLE
                    || llAtPanel.getVisibility() == View.VISIBLE
                    || llAdvancedOptions.getVisibility() == View.VISIBLE) {
                hideAllPanels();
                updateToolStates();
            }
        });
    }

    private void setupCircleSelector() {
        llCircleSelector.setOnClickListener(v -> showForumPicker());
    }

    // ==================== 五大功能 ====================

    private void setupToolbarButtons() {
        // 1. 表情
        btnSmiley.setOnClickListener(v -> toggleSmileyPanel());

        // 2. @朋友（再次点击可收起）
        btnAt.setOnClickListener(v -> {
            boolean show = llAtPanel.getVisibility() != View.VISIBLE;
            hideAllPanels();
            if (show) {
                llAtPanel.setVisibility(View.VISIBLE);
                etAtUsername.requestFocus();
            }
            updateToolStates();
        });
        btnAtInsert.setOnClickListener(v -> {
            String name = etAtUsername.getText() != null ?
                    etAtUsername.getText().toString().trim() : "";
            if (name.isEmpty()) {
                Toast.makeText(this, "请输入用户名", Toast.LENGTH_SHORT).show();
                return;
            }
            insertIntoContent("@ " + name + " ");
            llAtPanel.setVisibility(View.GONE);
            etAtUsername.setText("");
            updateToolStates();
            Toast.makeText(this, "已插入 @" + name, Toast.LENGTH_SHORT).show();
        });

        // 3. 插入（引用/代码/Free/Hide）
        btnInsert.setOnClickListener(v -> showInsertDialog());
        btnMarkdown.setOnClickListener(v -> showMarkdownHelp());

        // 4. 图片上传（从相册选图，与网页端对齐）
        btnImage.setOnClickListener(v -> {
            hideAllPanels();
            updateToolStates();
            pickImage();
        });

        // 5. 文件附件
        btnAttach.setOnClickListener(v -> pickFile());

        // 6. 高级选项
        btnAdvanced.setOnClickListener(v -> {
            boolean show = llAdvancedOptions.getVisibility() != View.VISIBLE;
            hideAllPanels();
            if (show) {
                hideKeyboard();
                llAdvancedOptions.setVisibility(View.VISIBLE);
                final android.widget.ScrollView sv = findViewById(R.id.sv_post_content);
                if (sv != null) sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
            }
            updateToolStates();
        });
    }

    // ==================== 投票功能 ====================

    private void addPollOption() {
        // 最多 20 个选项（Discuz 限制）
        if (llPollOptions.getChildCount() >= 20) {
            Toast.makeText(this, "最多 20 个投票选项", Toast.LENGTH_SHORT).show();
            return;
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        int margin8dp = (int) (8 * getResources().getDisplayMetrics().density + 0.5f);
        rowLp.bottomMargin = margin8dp;
        row.setLayoutParams(rowLp);

        // 图片选择按钮（单框模式时隐藏）
        final android.widget.ImageView ivPollImg = new android.widget.ImageView(this);
        int imgSize = (int) (40 * getResources().getDisplayMetrics().density + 0.5f);
        LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(imgSize, imgSize);
        imgLp.setMarginEnd(margin8dp);
        ivPollImg.setLayoutParams(imgLp);
        ivPollImg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        ivPollImg.setBackgroundResource(R.drawable.post_at_input_bg);
        ivPollImg.setImageResource(R.drawable.ic_image);
        androidx.core.content.ContextCompat.getDrawable(this, R.drawable.ic_image);
        ivPollImg.setImageDrawable(androidx.core.content.ContextCompat.getDrawable(this, R.drawable.ic_image));
        ivPollImg.setClickable(true);
        ivPollImg.setFocusable(true);
        ivPollImg.setBackground(androidx.core.content.ContextCompat.getDrawable(this, R.drawable.post_tool_ripple));
        // tag 存放已上传的图片 aid（初始 null）
        ivPollImg.setTag(null);
        ivPollImg.setVisibility(cbPollSingleMode.isChecked() ? View.GONE : View.VISIBLE);
        ivPollImg.setOnClickListener(v -> {
            pendingPollOptionIndex = llPollOptions.indexOfChild(row);
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            startActivityForResult(intent, REQUEST_POLL_IMAGE_PICK);
        });
        row.addView(ivPollImg);

        EditText et = new EditText(this);
        et.setHint("投票选项 " + (llPollOptions.getChildCount() + 1));
        et.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        et.setBackground(androidx.core.content.ContextCompat.getDrawable(this, R.drawable.post_at_input_bg));
        et.setPadding(32, 16, 32, 16);
        et.setTextSize(14);
        et.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.text_primary));
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        et.setLayoutParams(etLp);
        et.setMaxLines(1);
        et.setSingleLine(true);
        et.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);
        row.addView(et);

        // 删除按钮
        TextView btnRemove = new TextView(this);
        btnRemove.setText("✕");
        btnRemove.setTextSize(16);
        btnRemove.setPadding(32, 24, 32, 24);
        btnRemove.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.text_hint));
        btnRemove.setClickable(true);
        btnRemove.setFocusable(true);
        btnRemove.setBackground(androidx.core.content.ContextCompat.getDrawable(this, R.drawable.post_tool_ripple));
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        btnLp.setMarginStart(margin8dp);
        btnRemove.setLayoutParams(btnLp);
        // 至少保留 2 个选项
        btnRemove.setOnClickListener(v2 -> {
            if (llPollOptions.getChildCount() > 2) {
                llPollOptions.removeView(row);
            } else {
                Toast.makeText(this, "至少保留 2 个投票选项", Toast.LENGTH_SHORT).show();
            }
        });
        row.addView(btnRemove);

        llPollOptions.addView(row);
    }

    /** 收集投票选项文本，过滤空行 */
    private java.util.List<String> collectPollOptions() {
        java.util.List<String> options = new java.util.ArrayList<>();
        if (cbPollSingleMode.isChecked()) {
            // 单框模式：从大文本框按行分割
            String text = etPollBatch.getText() != null ? etPollBatch.getText().toString() : "";
            for (String line : text.split("\n")) {
                String trimmed = line.trim();
                if (!trimmed.isEmpty()) {
                    options.add(trimmed);
                }
            }
        } else {
            for (int i = 0; i < llPollOptions.getChildCount(); i++) {
                LinearLayout row = (LinearLayout) llPollOptions.getChildAt(i);
                if (row != null) {
                    EditText et = findEditTextInRow(row);
                    if (et != null) {
                        String text = et.getText() != null ? et.getText().toString().trim() : "";
                        if (!text.isEmpty()) {
                            options.add(text);
                        }
                    }
                }
            }
        }
        return options;
    }

    /** 收集每个投票选项对应的图片aid（无图片则为null） */
    private java.util.List<String> collectPollImageAids() {
        java.util.List<String> aids = new java.util.ArrayList<>();
        for (int i = 0; i < llPollOptions.getChildCount(); i++) {
            LinearLayout row = (LinearLayout) llPollOptions.getChildAt(i);
            String aid = null;
            if (row != null && row.getChildCount() > 0 && row.getChildAt(0) instanceof android.widget.ImageView) {
                Object tag = row.getChildAt(0).getTag();
                if (tag instanceof String) {
                    aid = (String) tag;
                }
            }
            aids.add(aid);
        }
        return aids;
    }

    private EditText findEditTextInRow(LinearLayout row) {
        for (int i = 0; i < row.getChildCount(); i++) {
            if (row.getChildAt(i) instanceof EditText) {
                return (EditText) row.getChildAt(i);
            }
        }
        return null;
    }

    // ---- 表情功能 ----

    /**
     * 切换表情面板。面板内容与评论区共用 {@link ForumSmileyData} 的三分类本地表情
     * （贴吧 / QQ / 狗头），装配逻辑复用 {@link SmileyPanelHelper}。
     *
     * <p>此前这里用的是 15 个 Discuz 冒号表情（smile.gif / biggrin.gif 等），
     * 但项目里没有这些 drawable，getIdentifier 全部返回 0，面板里显示的其实是
     * 系统占位图 ic_menu_gallery，点进去也插不出论坛能识别的表情代码。
     */
    private void toggleSmileyPanel() {
        boolean show = llSmileyPanel.getVisibility() != View.VISIBLE;
        hideAllPanels();
        if (!show) {
            updateToolStates();
            return;
        }
        // 表情面板展开时收起键盘，避免面板被输入法顶出屏幕。
        hideKeyboard();
        SmileyPanelHelper.setUp(tlSmileyTabs, vpSmiley, 7, 44, this::insertSmiley);
        llSmileyPanel.setVisibility(View.VISIBLE);
        updateToolStates();
    }

    /**
     * 在正文光标处插入表情：文本仍是论坛能识别的表情代码（如 {@code [#呵呵]}），
     * 同时套一层 ImageSpan 让用户在编辑器里直接看到图，提交时 toString() 拿到的还是代码。
     */
    private void insertSmiley(String code, int iconRes) {
        Editable editable = etContent.getText();
        if (editable == null) {
            etContent.setText(code);
            return;
        }
        int start = etContent.getSelectionStart();
        int end = etContent.getSelectionEnd();
        if (start < 0) start = editable.length();
        if (end < start) end = start;
        if (end > start) editable.delete(start, end);
        editable.insert(start, code);

        if (iconRes != 0) {
            Drawable d = androidx.core.content.ContextCompat.getDrawable(this, iconRes);
            if (d != null) {
                // 表情尺寸跟随正文字号，行高不会被撑得忽大忽小。
                int size = (int) (etContent.getTextSize() * 1.3f);
                d.setBounds(0, 0, size, size);
                editable.setSpan(new ImageSpan(d, ImageSpan.ALIGN_BOTTOM),
                        start, start + code.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        etContent.setSelection(start + code.length());
    }

    // ---- 插入功能 ----
    /** 打开「导入 Markdown」底部面板，首行 # 标题自动提取到标题栏。 */
    private void showMarkdownHelp() {
        MarkdownImportHelper.show(this, etContent, etTitle);
    }

    private void showInsertDialog() {
        hideAllPanels();
        final String[] items = {"引用", "代码", "免费信息", "隐藏内容"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("插入内容");
        builder.setItems(items, (dialog, which) -> {
            String bbcode = "";
            switch (which) {
                case 0: bbcode = "\n[quote]请输入引用内容[/quote]\n"; break;
                case 1: bbcode = "\n[code]请输入代码[/code]\n"; break;
                case 2: bbcode = "\n[free]请输入免费内容[/free]\n"; break;
                case 3: bbcode = "\n[hide]请输入隐藏内容[/hide]\n"; break;
            }
            insertIntoContent(bbcode);
            Toast.makeText(this, "已插入" + items[which], Toast.LENGTH_SHORT).show();
        });
        builder.show();
    }

    // ---- 🖼 图片上传功能（与网页端对齐：支持多选、预览、上传） ----

    private void pickImage() {
        hideAllPanels();
        // 使用 Intent.ACTION_PICK 打开系统相册，支持多图选择
        Intent intent;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
            intent = new Intent(Intent.ACTION_PICK);
            intent.setData(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.setType("image/*");
        } else {
            intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
        }
        startActivityForResult(intent, REQUEST_IMAGE_PICK);
    }

    /**
     * 上传结果：要么拿到 aid，要么带一条能解释原因的错误信息。
     *
     * <p>此前失败只返回 null，调用方只能提示笼统的"上传失败"，
     * 且服务端返回的状态码（大小超限、格式不支持等）被丢掉了。
     */
    private static final class UploadOutcome {
        final String aid;
        final String error;

        private UploadOutcome(String aid, String error) {
            this.aid = aid;
            this.error = error;
        }

        static UploadOutcome ok(String aid) { return new UploadOutcome(aid, null); }

        static UploadOutcome fail(String error) { return new UploadOutcome(null, error); }

        boolean isSuccess() { return aid != null; }
    }

private void uploadImages(List<Uri> uris) {
        Toast.makeText(this, "正在上传 " + uris.size() + " 张图片...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                if (!ensureUploadAuth()) {
                    runOnUiThread(() -> Toast.makeText(this, "获取上传授权失败，请先选择圈子或重新登录", Toast.LENGTH_SHORT).show());
                    return;
                }

                // 与网页端 buildfileupload 完全一致：simple=2 + inajax/infloat。
                String uploadUrl = HttpClient.BASE_URL
                        + "misc.php?mod=swfupload&operation=upload"
                        + "&type=image&inajax=yes&infloat=yes&simple=2";

                int success = 0;
                String firstError = null;
                for (int i = 0; i < uris.size(); i++) {
                    Uri uri = uris.get(i);
                    String rawName = getFileNameFromUri(uri);
                    // 统一转成标准 JPEG 再上传：论坛的 swfupload 会按文件头、扩展名、
                    // 尺寸和大小联合校验，直接送相册原图时 HEIC/AVIF/特殊 WebP、
                    // 透明 PNG、超高分辨率都会被拒，表现为"网页能传、App 传不上"。
                    File tempFile = transcodeImageToJpeg(uri);
                    String fileName;
                    if (tempFile != null) {
                        fileName = tempFile.getName();
                    } else {
                        // 转码失败（如损坏文件、不可解码格式）时退回原样上传，
                        // 让服务端给出具体原因，而不是本地静默跳过。
                        fileName = rawName.matches("(?i).*\\.(jpg|jpeg|png|gif|bmp|webp)$")
                                ? rawName : "image_" + System.currentTimeMillis() + ".jpg";
                        tempFile = copyUriToTempFile(uri, fileName);
                    }
                    if (tempFile == null) {
                        if (firstError == null) firstError = rawName + "：无法读取图片";
                        final String message = rawName + " 读取失败";
                        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
                        continue;
                    }

                    Map<String, String> extraFields = new HashMap<>();
                    extraFields.put("uid", currentUid);
                    extraFields.put("hash", currentHash);
                    String response = HttpClient.getInstance().uploadFile(
                            uploadUrl, tempFile, "Filedata", extraFields);
                    UploadOutcome outcome = parseDiscuzUploadResponse(response);
                    if (!outcome.isSuccess()) {
                        if (firstError == null) firstError = outcome.error;
                        final String message = rawName + " 上传失败：" + outcome.error;
                        runOnUiThread(() -> Toast.makeText(this,
                                message, Toast.LENGTH_LONG).show());
                        continue;
                    }

                    success++;
                    String bbcode = "\n[attachimg]" + outcome.aid + "[/attachimg]\n";
                    AttachFile af = new AttachFile(fileName, tempFile.getAbsolutePath());
                    af.aid = outcome.aid;
                    af.bbcode = bbcode;
                    synchronized (attachFiles) { attachFiles.add(af); }
                    runOnUiThread(() -> {
                        insertIntoContent(bbcode);
                        updateAttachList();
                        updateImagePreview();
                    });
                }

                // 汇总提示必须反映真实结果：全失败时不能再说"处理完成"。
                final int okCount = success;
                final int failCount = uris.size() - success;
                final String reason = firstError;
                runOnUiThread(() -> {
                    String text;
                    if (failCount == 0) {
                        text = "已上传 " + okCount + " 张图片";
                    } else if (okCount == 0) {
                        text = "图片上传失败" + (TextUtils.isEmpty(reason) ? "" : "：" + reason);
                    } else {
                        text = "已上传 " + okCount + " 张，" + failCount + " 张失败";
                    }
                    Toast.makeText(this, text,
                            failCount == 0 ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                        "图片上传异常: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    /**
     * 正文中该 aid 的附件 BBCode 首次出现的位置；未出现返回 {@link Integer#MAX_VALUE}。
     *
     * <p>用于让缩略图顺序与正文中的插入位置一致。
     */
    private int indexOfAttachBBCode(String body, String aid) {
        if (body == null || body.isEmpty() || aid == null || !aid.matches("\\d+")) {
            return Integer.MAX_VALUE;
        }
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("\\[attach(?:img)?\\]\\s*" + aid + "\\s*\\[/attach(?:img)?\\]")
                .matcher(body);
        return m.find() ? m.start() : Integer.MAX_VALUE;
    }

    /**
     * 正文顺序变化时重排缩略图。
     *
     * <p>用户可能手动剪切、粘贴或删除正文里的 BBCode，缩略图顺序要跟着变。
     * 先比较顺序签名，只有真正变了才重建视图，避免每次按键都重新加载图片。
     */
    private void maybeRefreshImagePreviewOrder() {
        if (llImagePreview == null) return;
        String signature = buildImageOrderSignature();
        if (signature.equals(lastImageOrderSignature)) return;
        updateImagePreview();
    }

    /** 按正文位置排序后的 aid 序列，作为缩略图顺序的指纹。 */
    private String buildImageOrderSignature() {
        StringBuilder sb = new StringBuilder();
        for (AttachFile af : collectPreviewImages()) {
            sb.append(af.aid).append(',');
        }
        return sb.toString();
    }

    /**
     * 取出图片类型附件，并按正文中 BBCode 的出现位置排序。
     *
     * <p>正文里找不到对应标记的（例如用户手工删掉了 BBCode）排在末尾，
     * 相同位置时保持上传先后顺序（{@code sort} 是稳定排序）。
     */
    private List<AttachFile> collectPreviewImages() {
        List<AttachFile> images = new ArrayList<>();
        synchronized (attachFiles) {
            for (AttachFile af : attachFiles) {
                if (af.name != null && af.name.matches("(?i).*\\.(jpg|jpeg|png|gif|bmp|webp)$")) {
                    images.add(af);
                }
            }
        }
        String body = (etContent != null && etContent.getText() != null)
                ? etContent.getText().toString() : "";
        final java.util.Map<AttachFile, Integer> positions = new java.util.HashMap<>();
        for (AttachFile af : images) {
            positions.put(af, indexOfAttachBBCode(body, af.aid));
        }
        java.util.Collections.sort(images, (a, b) ->
                Integer.compare(positions.get(a), positions.get(b)));
        return images;
    }

    private void updateImagePreview() {
        if (llImagePreview == null) return;
        llImagePreview.removeAllViews();
        // 缩略图顺序与正文中 [attachimg] 的位置对应，而不是上传先后顺序。
        List<AttachFile> images = collectPreviewImages();
        lastImageOrderSignature = buildImageOrderSignature();
        if (images.isEmpty()) {
            llImagePreview.setVisibility(View.GONE);
            return;
        }
        llImagePreview.setVisibility(View.VISIBLE);

        LinearLayout row = null;
        int colCount = 4;
        int density = (int) getResources().getDisplayMetrics().density;
        int imgSize = (int) (75 * density);

        for (int i = 0; i < images.size(); i++) {
            if (i % colCount == 0) {
                row = new LinearLayout(this);
                row.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(0, 0, 0, (int)(4 * density));
                llImagePreview.addView(row);
            }

            AttachFile af = images.get(i);
            ImageView iv = new ImageView(this);
            // 固定 75dp 方格，不设 weight：设了 weight 会让单张图被拉满整行宽度。
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(imgSize, imgSize);
            lp.setMargins(0, 0, (int)(4 * density), 0);
            if (row != null) {
                iv.setLayoutParams(lp);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setBackgroundColor(0xFFF0F0F0);

                Glide.with(this)
                        .load(af.path)
                        .placeholder(new android.graphics.drawable.ColorDrawable(0xFFF0F0F0))
                        .error(new android.graphics.drawable.ColorDrawable(0xFFE0E0E0))
                        .into(iv);

                // 点击提示删除方式（长按才真正移除，避免误删）
                iv.setOnClickListener(v -> Toast.makeText(PostActivity.this,
                        "长按可移除图片", Toast.LENGTH_SHORT).show());
                // 长按删除（同时清掉正文里的 BBCode）
                final AttachFile afFinal = af;
                iv.setOnLongClickListener(v -> {
                    removeAttachment(afFinal);
                    return true;
                });

                row.addView(iv);
            }
        }
    }

    // ---- 附件功能 ----
    private void pickFile() {
        hideAllPanels();
        // 先选文件，上传时在后台线程统一获取授权
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_FILE_PICK);
    }

    // 在后台线程安全地预加载上传授权（必须使用桌面版UA，移动端UA会被Discuz!强制返回移动版页面，不含hash令牌）
    private boolean ensureUploadAuth() {
        // 登录可能由 WebView 完成；仅在原生 CookieJar 未登录时才同步，避免覆盖有效会话。
        if (!HttpClient.getInstance().isLoggedIn()) {
            HttpClient.getInstance().syncFromCookieManager();
        }
        if (!HttpClient.getInstance().isLoggedIn()) return false;
        if (isValidUploadAuth()) return true;
        try {
            // 桌面版发帖页面（含hash上传令牌）— 必须用桌面版 UA，不能带 mobile=2
            String fid = selectedFid != null ? selectedFid : "39";
            String url = HttpClient.BASE_URL + "forum.php?mod=post&action=newthread&fid=" + fid;
            String html = HttpClient.getInstance().getDesktop(url);
            if (html != null) {
                if (currentFormhash == null) currentFormhash = ForumParser.parseFormhash(html);
                extractUidAndHash(html);
            }
            return isValidUploadAuth();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isValidUploadAuth() {
        return currentUid != null && currentUid.matches("[1-9]\\d*")
                && currentHash != null && !currentHash.trim().isEmpty();
    }

    private void preloadUploadAuth() {
        new Thread(() -> {
            ensureUploadAuth();
        }).start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE_PICK && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                uploadFile(uri);
            }
        } else if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK && data != null) {
            List<Uri> imageUris = new ArrayList<>();
            // 多图选择
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                for (int i = 0; i < count; i++) {
                    Uri uri = data.getClipData().getItemAt(i).getUri();
                    if (uri != null) imageUris.add(uri);
                }
            } else if (data.getData() != null) {
                imageUris.add(data.getData());
            }
            if (!imageUris.isEmpty()) {
                uploadImages(imageUris);
            }
        } else if (requestCode == REQUEST_POLL_IMAGE_PICK && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null && pendingPollOptionIndex >= 0 && pendingPollOptionIndex < llPollOptions.getChildCount()) {
                LinearLayout row = (LinearLayout) llPollOptions.getChildAt(pendingPollOptionIndex);
                if (row != null && row.getChildCount() > 0 && row.getChildAt(0) instanceof android.widget.ImageView) {
                    android.widget.ImageView ivPollImg = (android.widget.ImageView) row.getChildAt(0);
                    // 先显示缩略图
                    Glide.with(this).load(uri).into(ivPollImg);
                    // 异步上传图片
                    uploadPollOptionImage(uri, ivPollImg);
                }
            }
            pendingPollOptionIndex = -1;
        }
    }

    private void uploadPollOptionImage(Uri uri, android.widget.ImageView ivPollImg) {
        Toast.makeText(this, "正在上传投票图片...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                if (!ensureUploadAuth()) {
                    runOnUiThread(() -> Toast.makeText(this, "获取上传授权失败", Toast.LENGTH_SHORT).show());
                    return;
                }
                String uploadUrl = HttpClient.BASE_URL
                        + "misc.php?mod=swfupload&operation=upload"
                        + "&type=image&inajax=yes&infloat=yes&simple=2";
                File tempFile = transcodeImageToJpeg(uri);
                String fileName;
                if (tempFile != null) {
                    fileName = tempFile.getName();
                } else {
                    fileName = "pollimg_" + System.currentTimeMillis() + ".jpg";
                    tempFile = copyUriToTempFile(uri, fileName);
                }
                if (tempFile == null) {
                    runOnUiThread(() -> Toast.makeText(this, "无法读取图片", Toast.LENGTH_SHORT).show());
                    return;
                }
                Map<String, String> extraFields = new HashMap<>();
                extraFields.put("uid", currentUid);
                extraFields.put("hash", currentHash);
                String response = HttpClient.getInstance().uploadFile(
                        uploadUrl, tempFile, "Filedata", extraFields);
                UploadOutcome outcome = parseDiscuzUploadResponse(response);
                if (!outcome.isSuccess()) {
                    runOnUiThread(() -> Toast.makeText(this,
                            "投票图片上传失败：" + outcome.error, Toast.LENGTH_LONG).show());
                    return;
                }
                final String aid = outcome.aid;
                runOnUiThread(() -> {
                    ivPollImg.setTag(aid);
                    Toast.makeText(this, "投票图片上传成功", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                        "投票图片上传异常", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void uploadFile(Uri uri) {
        Toast.makeText(this, "正在上传附件...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String fileName = getFileNameFromUri(uri);
                File tempFile = copyUriToTempFile(uri, fileName);
                if (tempFile == null) {
                    runOnUiThread(() -> Toast.makeText(this, "无法读取文件", Toast.LENGTH_SHORT).show());
                    return;
                }
                if (!ensureUploadAuth()) {
                    runOnUiThread(() -> Toast.makeText(this, "获取上传授权失败，请先选择圈子或重新登录", Toast.LENGTH_SHORT).show());
                    return;
                }

                String uploadUrl = HttpClient.BASE_URL
                        + "misc.php?mod=swfupload&operation=upload"
                        + "&type=attach&inajax=yes&infloat=yes&simple=2";
                Map<String, String> extraFields = new HashMap<>();
                extraFields.put("uid", currentUid);
                extraFields.put("hash", currentHash);
                String response = HttpClient.getInstance().uploadFile(
                        uploadUrl, tempFile, "Filedata", extraFields);
                UploadOutcome outcome = parseDiscuzUploadResponse(response);
                if (!outcome.isSuccess()) {
                    runOnUiThread(() -> Toast.makeText(this,
                            "附件上传失败：" + outcome.error, Toast.LENGTH_LONG).show());
                    return;
                }

                String bbcode = fileName.matches("(?i).*\\.(jpg|jpeg|png|gif|bmp|webp)$")
                        ? "\n[attachimg]" + outcome.aid + "[/attachimg]\n"
                        : "\n[attach]" + outcome.aid + "[/attach]\n";
                AttachFile af = new AttachFile(fileName, tempFile.getAbsolutePath());
                af.aid = outcome.aid;
                af.bbcode = bbcode;
                synchronized (attachFiles) { attachFiles.add(af); }
                runOnUiThread(() -> {
                    insertIntoContent(bbcode);
                    updateAttachList();
                    updateImagePreview();
                    Toast.makeText(this, "附件已上传: " + fileName, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                        "附件上传异常: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    /**
     * 解析 Discuz! 附件上传响应。
     *
     * <p>真实格式（simple=2）：{@code DISCUZUPLOAD|<uploadId>|<状态码>|<aid>|<hash>|<相对路径>|<文件名>|<限制信息>}。
     * 成功的判据是状态码为 0 且 aid 为数字；非 0 的状态码各有含义，翻译成可读文案，
     * 否则用户只能看到"上传失败"却不知道该改什么。
     *
     * <p>响应可能被 {@code <![CDATA[...]]>} 包裹（inajax=yes），也可能混着 HTML，
     * 因此先剥壳再定位标记，不能只看是否以 DISCUZUPLOAD 开头。
     */
    private UploadOutcome parseDiscuzUploadResponse(String response) {
        if (response == null) return UploadOutcome.fail("服务器无响应");
        String text = response.trim();
        if (text.isEmpty()) return UploadOutcome.fail("服务器返回空响应");

        // inajax 响应会包一层 CDATA，先取出内部内容。
        java.util.regex.Matcher cdata = java.util.regex.Pattern
                .compile("(?s)<!\\[CDATA\\[(.*?)\\]\\]>").matcher(text);
        if (cdata.find()) text = cdata.group(1).trim();

        int marker = text.indexOf("DISCUZUPLOAD|");
        if (marker < 0) {
            if (ForumParser.isLoginPage(text) || text.contains("请先登录")) {
                return UploadOutcome.fail("登录状态已失效，请重新登录");
            }
            String plain = text.replaceAll("(?s)<[^>]+>", " ")
                    .replaceAll("\\s+", " ").trim();
            if (plain.length() > 120) plain = plain.substring(0, 120) + "…";
            return UploadOutcome.fail(plain.isEmpty() ? "服务器返回格式异常" : plain);
        }

        // 标记之后可能还跟着换行或 HTML，只取本行。
        String payload = text.substring(marker).split("[\\r\\n<]", 2)[0];
        String[] parts = payload.split("\\|", -1);
        if (parts.length < 4) return UploadOutcome.fail("上传响应格式异常");

        String status = parts[2].trim();
        String aid = parts[3].trim();
        String limitInfo = parts.length > 7 ? parts[7].trim() : "";

        if ("0".equals(status) && aid.matches("\\d+")) {
            return UploadOutcome.ok(aid);
        }

        String reason;
        switch (status) {
            case "1": reason = "服务器写入文件失败"; break;
            case "2": reason = "图片超过论坛大小限制"; break;
            case "3": reason = "论坛不支持该图片格式"; break;
            case "9": reason = "图片无效或尺寸过小"; break;
            default: reason = "服务器拒绝了附件（状态 " + status + "）"; break;
        }
        // 服务端有时把具体限制说明放在末位字段，比它的状态码更有用。
        if (!limitInfo.isEmpty() && !"0".equals(limitInfo) && !limitInfo.matches("\\d+")) {
            reason = limitInfo;
        }
        return UploadOutcome.fail(reason);
    }

    private String extractAttachUrlFromResponse(String response) {
        try {
            JSONObject json = new JSONObject(response);
            if (json.has("url")) return json.getString("url");
            if (json.has("attach")) return json.getJSONObject("attach").optString("url");
        } catch (Exception ignored) {}
        return null;
    }

    private String extractAidFromHtml(String html) {
        try {
            Document doc = Jsoup.parse(html);
            Element input = doc.select("input[name=aid]").first();
            if (input != null) return input.val();
            // 从attachnotice中提取
            Element notice = doc.getElementById("attachnotice_attach");
            if (notice != null) {
                String text = notice.text();
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)").matcher(text);
                if (m.find()) return m.group(1);
            }
        } catch (Exception ignored) {}
        return null;
    }

    private String getFileNameFromUri(Uri uri) {
        String name = "attachment";
        try {
            String path = uri.getPath();
            if (path != null) name = path.substring(path.lastIndexOf('/') + 1);
        } catch (Exception ignored) {}
        if (!name.contains(".")) name += ".dat";
        return name;
    }

    /**
     * 把相册图片规范化为论坛 swfupload 接口最兼容的 JPEG（与回复框上传同一套处理）。
     *
     * <p>压平透明通道、限制最长边 1920、逐步降质到 2 MiB 以内，规避 HEIC/AVIF/特殊 WebP、
     * 透明 PNG、超大分辨率导致的服务端拒收。无法解码时返回 null，由调用方回退原样上传。
     */
    private File transcodeImageToJpeg(Uri uri) {
        if (uri == null) return null;
        try {
            final int maxSide = 1920;
            android.graphics.ImageDecoder.Source source =
                    android.graphics.ImageDecoder.createSource(getContentResolver(), uri);
            android.graphics.Bitmap decoded = android.graphics.ImageDecoder.decodeBitmap(source,
                    (decoder, info, ignoredSource) -> {
                        int width = info.getSize().getWidth();
                        int height = info.getSize().getHeight();
                        int largest = Math.max(width, height);
                        if (largest > maxSide) {
                            float scale = maxSide / (float) largest;
                            decoder.setTargetSize(Math.max(1, Math.round(width * scale)),
                                    Math.max(1, Math.round(height * scale)));
                        }
                        // 软件位图便于 Canvas 压平透明通道，也避免硬件位图无法直接压缩。
                        decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                    });
            if (decoded == null || decoded.getWidth() <= 0 || decoded.getHeight() <= 0) return null;

            android.graphics.Bitmap flattened = android.graphics.Bitmap.createBitmap(
                    decoded.getWidth(), decoded.getHeight(),
                    android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas canvas = new android.graphics.Canvas(flattened);
            canvas.drawColor(android.graphics.Color.WHITE);
            canvas.drawBitmap(decoded, 0, 0, null);
            if (flattened != decoded) decoded.recycle();

            byte[] jpeg = null;
            for (int quality = 88; quality >= 58; quality -= 6) {
                java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
                flattened.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, output);
                jpeg = output.toByteArray();
                if (jpeg.length <= 2 * 1024 * 1024 || quality == 58) break;
            }
            flattened.recycle();
            if (jpeg == null || jpeg.length == 0) return null;

            File dir = new File(getCacheDir(), "attachments");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File target = new File(dir, "post_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream output = new FileOutputStream(target)) {
                output.write(jpeg);
                output.flush();
            }
            return target;
        } catch (Exception e) {
            return null;
        }
    }

    private File copyUriToTempFile(Uri uri, String fileName) throws Exception {
        File tmpDir = new File(getCacheDir(), "attachments");
        if (!tmpDir.exists()) tmpDir.mkdirs();
        File tmpFile = new File(tmpDir, fileName);
        try (InputStream is = getContentResolver().openInputStream(uri);
             FileOutputStream os = new FileOutputStream(tmpFile)) {
            if (is == null) return null;
            byte[] buf = new byte[8192];
            int len;
            while ((len = is.read(buf)) != -1) os.write(buf, 0, len);
        }
        return tmpFile;
    }

    private void updateAttachList() {
        llAttachList.removeAllViews();
        // 图片附件由 llImagePreview 统一以缩略图网格展示；这里只列非图片文件，
        // 否则同一张图会在两个卡片里各出现一次。
        List<AttachFile> files = new ArrayList<>();
        for (AttachFile af : attachFiles) {
            if (af.name == null || !af.name.matches("(?i).*\\.(jpg|jpeg|png|gif|bmp|webp)$")) {
                files.add(af);
            }
        }
        if (files.isEmpty()) {
            llAttachList.setVisibility(View.GONE);
            return;
        }
        llAttachList.setVisibility(View.VISIBLE);
        for (AttachFile af : files) {
            TextView tv = new TextView(this);
            tv.setText("📎 " + af.name);
            tv.setPadding(8, 8, 8, 8);
            tv.setTextSize(13);
            tv.setCompoundDrawablesWithIntrinsicBounds(0, 0, android.R.drawable.ic_menu_delete, 0);
            // 按对象移除，避免用过滤后的下标误删 attachFiles 中的其他项。
            final AttachFile target = af;
            tv.setOnClickListener(v -> removeAttachment(target));
            llAttachList.addView(tv);
        }
    }

    // ---- 高级功能 ----
    // llAdvancedOptions 中已包含：cb_hidden_replies, cb_reverse_order, cb_usesig, cb_smiley_off, cb_bbcode_off

    // ---- 面板管理 ----
    private void hideAllPanels() {
        llSmileyPanel.setVisibility(View.GONE);
        llAtPanel.setVisibility(View.GONE);
        llAdvancedOptions.setVisibility(View.GONE);
    }

    /** 面板开合后把对应工具按钮染成主题色，让用户知道当前打开的是哪个面板。 */
    private void updateToolStates() {
        applyToolState(ivToolSmiley, tvToolSmiley,
                llSmileyPanel.getVisibility() == View.VISIBLE);
        applyToolState(ivToolAt, tvToolAt,
                llAtPanel.getVisibility() == View.VISIBLE);
        applyToolState(ivToolAdvanced, tvToolAdvanced,
                llAdvancedOptions.getVisibility() == View.VISIBLE);
    }

    private void applyToolState(ImageView icon, TextView label, boolean active) {
        int color = androidx.core.content.ContextCompat.getColor(this,
                active ? R.color.accent_primary : R.color.text_secondary);
        if (icon != null) icon.setColorFilter(color);
        if (label != null) label.setTextColor(color);
    }

    private void hideKeyboard() {
        View focus = getCurrentFocus();
        if (focus == null) return;
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager)
                        getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
    }

    // 插入内容到正文
    /**
     * 移除附件：同时清掉正文里对应的 BBCode。
     *
     * <p>此前只从 {@code attachFiles} 移除对象，正文里的 {@code [attachimg]aid[/attachimg]}
     * 还留着。这会让缩略图消失但发布出来仍带图（或变成一个失效的附件占位），
     * 与用户"已删除"的预期不符。
     */
    private void removeAttachment(AttachFile af) {
        if (af == null) return;
        synchronized (attachFiles) { attachFiles.remove(af); }
        removeAttachBBCode(af.aid);
        updateAttachList();
        updateImagePreview();
    }

    /** 从正文中删除该 aid 的 attachimg/attach 标记，并收敛因此产生的多余空行。 */
    private void removeAttachBBCode(String aid) {
        if (aid == null || !aid.matches("\\d+") || etContent == null) return;
        Editable editable = etContent.getText();
        if (editable == null) return;
        String text = editable.toString();
        // 同一 aid 可能被重复插入，用全局替换；两种标签都清。
        String cleaned = text.replaceAll(
                "\\[attach(?:img)?\\]\\s*" + aid + "\\s*\\[/attach(?:img)?\\]", "");
        if (cleaned.equals(text)) return;
        // 删除标记后常留下连续空行，压缩成一个空行；首尾空白一并去掉。
        cleaned = cleaned.replaceAll("[ \\t]*\\n{3,}", "\n\n").trim();
        int selection = Math.min(etContent.getSelectionStart(), cleaned.length());
        etContent.setText(cleaned);
        if (selection >= 0) etContent.setSelection(Math.max(0, selection));
    }

    private void insertIntoContent(String text) {
        Editable editable = etContent.getText();
        if (editable == null) {
            etContent.setText(text);
            return;
        }
        int start = etContent.getSelectionStart();
        int end = etContent.getSelectionEnd();
        if (start < 0) start = editable.length();
        if (start >= 0 && end > start) {
            editable.replace(start, end, text);
        } else {
            editable.insert(start >= 0 ? start : editable.length(), text);
        }
    }

    // ==================== 圈子选择 ====================

    private BottomSheetDialog forumSheet;

    private void showForumPicker() {
        // 先用进度对话框阻塞 UI，数据加载完成后再弹出 BottomSheet
        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在加载版块列表…");
        pd.setCancelable(true);
        pd.setOnCancelListener(d -> {});
        pd.show();

        new Thread(() -> {
            try {
                String url = HttpClient.BASE_URL + "forum.php?forumlist=1&mobile=2";
                String html = HttpClient.getInstance().get(url);
                if (html == null || html.isEmpty()) {
                    pd.dismiss();
                    runOnUiThread(() -> Toast.makeText(this, R.string.network_error, Toast.LENGTH_SHORT).show());
                    return;
                }
                List<ForumCategory> categories = ForumParser.parseForumCategories(html);
                pd.dismiss();
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    showForumPickerSheet(categories);
                });
            } catch (Exception e) {
                e.printStackTrace();
                pd.dismiss();
                runOnUiThread(() -> Toast.makeText(this, R.string.network_error, Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void showForumPickerSheet(List<ForumCategory> categories) {
        forumSheet = new BottomSheetDialog(this);
        View content = getLayoutInflater().inflate(R.layout.dialog_forum_picker, null);
        content.findViewById(R.id.btn_close).setOnClickListener(v -> forumSheet.dismiss());
        TextView tvEmpty = content.findViewById(R.id.tv_empty);
        ListView lv = content.findViewById(R.id.lv_forum);

        ForumPickerAdapter adapter = new ForumPickerAdapter(this, categories);
        lv.setAdapter(adapter);
        tvEmpty.setVisibility(adapter.isEmpty() ? View.VISIBLE : View.GONE);

        lv.setOnItemClickListener((parent, view, position, id) -> {
            ForumCategory.Forum forum = adapter.getForumAt(position);
            if (forum != null) {
                selectForum(forum);
                forumSheet.dismiss();
            }
        });

        forumSheet.setContentView(content);
        forumSheet.show();
    }

    private void selectForum(ForumCategory.Forum forum) {
        selectedFid = forum.getFid();
        selectedForumName = forum.getName();
        tvSelectedForum.setText(selectedForumName);
        tvSelectedForum.setVisibility(View.VISIBLE);
        // 选中版块后把左侧引导文字改为"发布版块"
        tvCircleLabel.setText("发布版块");
        tvCircleLabel.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.text_primary));
        // 切换圈子后清除页面数据和类型选择
        pageData = null;
        selectedTypeId = null;
        // 切换圈子后重新加载formhash
        loadFormhashAndUserInfo();
    }

    // ==================== formhash & hash 加载 ====================

    private void loadFormhashAndUserInfo() {
        new Thread(() -> {
            try {
                if (selectedFid == null) return;
                // 获取移动端发帖页面（更轻量）
                String mobileUrl = ForumParser.getNewThreadUrl(selectedFid);
                String mobileHtml = HttpClient.getInstance().get(mobileUrl);

                if (mobileHtml != null) {
                    // 使用 PostPageParser 解析发帖页面（对齐官方）
                    pageData = PostPageParser.parsePostPage(mobileHtml, selectedFid);
                    currentFormhash = pageData.getFormhash();

                    // 如果页面有错误（如权限不足），显示错误
                    if (pageData.getError() != null) {
                        runOnUiThread(() -> showError(pageData.getError()));
                    }
                    // 如果有帖子类型，显示类型选择器
                    if (pageData.getPostTypes() != null && !pageData.getPostTypes().isEmpty()) {
                        runOnUiThread(() -> showPostTypeSelector(pageData.getPostTypes()));
                    }
                }

                // 获取 uid + hash 必须用桌面版页面（移动版不含 hash 令牌）
                String desktopUrl = HttpClient.BASE_URL + "forum.php?mod=post&action=newthread&fid=" + selectedFid;
                String desktopHtml = HttpClient.getInstance().getDesktop(desktopUrl);
                if (desktopHtml != null) {
                    if (currentFormhash == null) currentFormhash = ForumParser.parseFormhash(desktopHtml);
                    extractUidAndHash(desktopHtml);
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void loadFormhashSync() {
        try {
            if (selectedFid == null) return;
            // 使用 PostPageParser 解析发帖页面（对齐官方）
            String mobileUrl = ForumParser.getNewThreadUrl(selectedFid);
            String mobileHtml = HttpClient.getInstance().get(mobileUrl);
            if (mobileHtml != null) {
                pageData = PostPageParser.parsePostPage(mobileHtml, selectedFid);
                currentFormhash = pageData.getFormhash();
            }
            // uid + hash 必须桌面版
            String desktopUrl = HttpClient.BASE_URL + "forum.php?mod=post&action=newthread&fid=" + selectedFid;
            String desktopHtml = HttpClient.getInstance().getDesktop(desktopUrl);
            if (desktopHtml != null) {
                if (currentFormhash == null) currentFormhash = ForumParser.parseFormhash(desktopHtml);
                extractUidAndHash(desktopHtml);
            }
        } catch (Exception ignored) {}
    }

    private void extractUidAndHash(String html) {
        if (TextUtils.isEmpty(html)) return;
        try {
            // 兼容 JS 变量、JSON 对象以及隐藏 input 的属性顺序/单双引号差异。
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                    "(?:var\\s+|\\b)discuz_uid\\s*(?:=|:)\\s*['\\\"]([1-9]\\d*)['\\\"]",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
            if (m.find()) currentUid = m.group(1);

            m = java.util.regex.Pattern.compile(
                    "<input[^>]+name\\s*=\\s*['\\\"]hash['\\\"][^>]+value\\s*=\\s*['\\\"]([^'\\\"]+)['\\\"]",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
            boolean hashFound = m.find();
            if (!hashFound) {
                m = java.util.regex.Pattern.compile(
                        "<input[^>]+value\\s*=\\s*['\\\"]([^'\\\"]+)['\\\"][^>]+name\\s*=\\s*['\\\"]hash['\\\"]",
                        java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
                hashFound = m.find();
            }
            if (!hashFound) {
                m = java.util.regex.Pattern.compile(
                        "(?:var\\s+|\\b)hash\\s*(?:=|:)\\s*['\\\"]([^'\\\"]+)['\\\"]",
                        java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
                hashFound = m.find();
            }
            if (hashFound) currentHash = m.group(1);
        } catch (Exception ignored) {
        }
    }

    // ==================== 发布 ====================

    private void setupPublishButton() {
        btnPublish.setOnClickListener(v -> attemptPost());
    }

    /** 发帖预览：跳转到 PostPreviewActivity，以帖子页面样式渲染 BBCode 内容。 */
    private void showPreview() {
        String content = etContent.getText() != null ? etContent.getText().toString().trim() : "";
        if (content.isEmpty()) {
            showError("请先输入内容");
            return;
        }
        String title = etTitle.getText() != null ? etTitle.getText().toString().trim() : "";
        Intent intent = new Intent(this, PostPreviewActivity.class);
        intent.putExtra(PostPreviewActivity.EXTRA_TITLE, title);
        intent.putExtra(PostPreviewActivity.EXTRA_CONTENT, content);
        startActivity(intent);
    }

    private void attemptPost() {
        tvError.setVisibility(View.GONE);

        // 对齐官方验证顺序：isSubmitting → pageData==null → title空 → content空 → formhash空
        if (isSubmitting) {
            showError("正在提交中，请勿重复操作");
            return;
        }
        if (pageData == null) {
            showError("页面加载中，请稍后");
            return;
        }

        String rawTitle = etTitle.getText() != null ? etTitle.getText().toString() : "";
        String rawContent = etContent.getText() != null ? etContent.getText().toString() : "";
        String title = rawTitle.trim();
        // 正文已在 Markdown 导入面板中完成 BBCode 转换；此处直接使用原文提交。
        String content = rawContent.trim();

        if (title.isEmpty()) { showError("请输入标题"); return; }
        if (selectedFid == null) { showError("请选择圈子"); return; }
        if (content.isEmpty()) { showError("请输入内容"); return; }
        if (currentFormhash == null || currentFormhash.isEmpty()) {
            showError("请先登录后再发帖"); return;
        }

        // Discuz旧版内容处理会在遇到部分Unicode表情、组合符号或异常代理字符时吞掉整段正文。
        // 标题和正文统一清洗，避免只清洗正文但标题仍携带问题字符。
        String cleanTitle = sanitizeForumText(title);
        String cleanContent = sanitizeForumText(content);
        if (cleanTitle.isEmpty() || cleanContent.isEmpty()) {
            showError("标题或正文清洗后为空，请重新输入");
            return;
        }
        if (!cleanTitle.equals(title) || !cleanContent.equals(content)) {
            new AlertDialog.Builder(this)
                    .setTitle("检测到不兼容字符")
                    .setMessage("内容中包含论坛不支持的表情或不可见字符，可能导致正文不显示。\n\n是否自动移除后发布？")
                    .setPositiveButton("移除并发布", (d, w) -> {
                        etTitle.setText(cleanTitle);
                        etContent.setText(cleanContent);
                        etContent.setSelection(cleanContent.length());
                        proceedPost(cleanTitle, cleanContent);
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }

        proceedPost(cleanTitle, cleanContent);
    }

    /** 提交前统一移除论坛旧版解析器无法稳定处理的字符。 */
    private String sanitizeForumText(String text) {
        if (text == null || text.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); ) {
            int codePoint = text.codePointAt(i);
            int charCount = Character.charCount(codePoint);
            boolean invalid = codePoint == 0xFFFD
                    || (codePoint >= 0xD800 && codePoint <= 0xDFFF)
                    || isEmojiCodePoint(codePoint)
                    || (codePoint >= 0x200B && codePoint <= 0x200F)
                    || (codePoint >= 0x202A && codePoint <= 0x202E)
                    || (codePoint >= 0x2060 && codePoint <= 0x206F)
                    || codePoint == 0xFEFF;
            if (!invalid) sb.appendCodePoint(codePoint);
            i += charCount;
        }
        return sb.toString().trim();
    }

    /** 检测字符串是否包含 Emoji 表情 */
    private boolean containsEmoji(String text) {
        if (text == null || text.isEmpty()) return false;
        for (int i = 0; i < text.length(); ) {
            int codePoint = text.codePointAt(i);
            if (isEmojiCodePoint(codePoint)) return true;
            i += Character.charCount(codePoint);
        }
        return false;
    }

    /** 移除 Emoji 表情，保留普通文本 */
    private String stripEmoji(String text) {
        if (text == null || text.isEmpty()) return text;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); ) {
            int codePoint = text.codePointAt(i);
            if (!isEmojiCodePoint(codePoint)) {
                sb.appendCodePoint(codePoint);
            }
            i += Character.charCount(codePoint);
        }
        return sb.toString().trim();
    }

    /** 判断 Unicode 码点是否为 Emoji */
    private boolean isEmojiCodePoint(int codePoint) {
        // 论坛端使用旧版 GBK/BBCode 处理链，所有补充平面字符都可能使整段 message 被丢弃。
        // 这里覆盖完整的常见 Emoji 区域，而不是只覆盖 😀 这一小段。
        return (codePoint >= 0x1F000 && codePoint <= 0x1FAFF) // 旗帜、键帽、表情、交通及扩展表情
            || (codePoint >= 0x2300 && codePoint <= 0x23FF)   // ⌚、⏰ 等
            || (codePoint >= 0x2600 && codePoint <= 0x27BF)   // ☀、⚡、✈ 等
            || (codePoint >= 0x2B00 && codePoint <= 0x2BFF)   // ⬆、⭐ 等
            || codePoint == 0x00A9 || codePoint == 0x00AE
            || codePoint == 0x203C || codePoint == 0x2049
            || codePoint == 0x2122 || codePoint == 0x2139
            || (codePoint >= 0x2190 && codePoint <= 0x21FF)
            || (codePoint >= 0xFE00 && codePoint <= 0xFE0F)   // 变体选择符
            || (codePoint >= 0x1F3FB && codePoint <= 0x1F3FF) // 肤色修饰符
            || codePoint == 0x200D                               // ZWJ
            || codePoint == 0x20E3;                              // 组合键帽
    }

    /** 实际执行发帖提交 */
    private void proceedPost(String title, String content) {
        // 设置提交状态（对齐官方 PostComposerState.isSubmitting = true）
        isSubmitting = true;
        btnPublish.setEnabled(false);
        btnPublish.setText("发布中...");

        new Thread(() -> {
            try {
                // 如果 formhash 为空，尝试同步加载
                if (currentFormhash == null || currentFormhash.isEmpty()) {
                    loadFormhashSync();
                }
                if (currentFormhash == null || currentFormhash.isEmpty()) {
                    runOnUiThread(() -> { showError("请先登录后再发帖"); resetPublishButton(); });
                    return;
                }

                // 组装 POST 参数（对齐官方 submitPost）
                Map<String, String> params = new HashMap<>();
                params.put("formhash", currentFormhash);
                params.put("subject", title);
                params.put("message", content);
                // 移动版提交的是 BBCode；wysiwyg=1 会让 Discuz 把纯文本/BBCode 当 HTML 转换，
                // 在 comiis 移动端可能只保存标题而丢掉正文。
                params.put("wysiwyg", "0");
                params.put("allownoticeauthor", "1");
                // 对齐官方：posttime（当前时间戳秒）
                params.put("posttime", String.valueOf(System.currentTimeMillis() / 1000));

                // 帖子类型（对齐官方：如果有选typeid则提交）
                if (selectedTypeId != null && !selectedTypeId.isEmpty()) {
                    params.put("typeid", selectedTypeId);
                }

                // 上传接口返回的 aid 只是暂存附件，发帖时还必须提交 attachnew[aid][description]，
                // Discuz! 才会把附件正式关联到新主题。
                synchronized (attachFiles) {
                    for (AttachFile af : attachFiles) {
                        if (af != null && af.aid != null && af.aid.matches("\\d+")) {
                            params.put("attachnew[" + af.aid + "][description]", "");
                        }
                    }
                }

                // 高级选项参数
                CheckBox cbHiddenReplies = findViewById(R.id.cb_hidden_replies);
                if (cbHiddenReplies != null && cbHiddenReplies.isChecked()) {
                    params.put("hiddenreplies", "1");
                }
                CheckBox cbReverseOrder = findViewById(R.id.cb_reverse_order);
                if (cbReverseOrder != null && cbReverseOrder.isChecked()) {
                    params.put("ordertype", "1");
                }
                CheckBox cbUsesig = findViewById(R.id.cb_usesig);
                if (cbUsesig != null && cbUsesig.isChecked()) {
                    params.put("usesig", "1");
                }
                CheckBox cbSmileyOff = findViewById(R.id.cb_smiley_off);
                if (cbSmileyOff != null && cbSmileyOff.isChecked()) {
                    params.put("smileyoff", "1");
                }
                CheckBox cbBbcodeOff = findViewById(R.id.cb_bbcode_off);
                if (cbBbcodeOff != null && cbBbcodeOff.isChecked()) {
                    params.put("bbcodeoff", "1");
                }

                // 投票参数（pollEnabled 时追加）
                if (pollEnabled) {
                    java.util.List<String> pollOptions = collectPollOptions();
                    if (pollOptions.size() < 2) {
                        runOnUiThread(() -> { showError("投票至少需要 2 个选项"); resetPublishButton(); });
                        return;
                    }
                    // Discuz poll 参数
                    StringBuilder pollOptStr = new StringBuilder();
                    for (int i = 0; i < pollOptions.size(); i++) {
                        if (i > 0) pollOptStr.append("\n");
                        pollOptStr.append(pollOptions.get(i));
                    }
                    params.put("polloptions", pollOptStr.toString());
                    String maxChoices = etPollMaxChoices.getText() != null
                            ? etPollMaxChoices.getText().toString().trim() : "1";
                    if (maxChoices.isEmpty() || Integer.parseInt(maxChoices) < 1) {
                        maxChoices = "1";
                    }
                    if (Integer.parseInt(maxChoices) > pollOptions.size()) {
                        maxChoices = String.valueOf(pollOptions.size());
                    }
                    params.put("maxchoices", maxChoices);
                    String expiration = etPollExpiration.getText() != null
                            ? etPollExpiration.getText().toString().trim() : "0";
                    if (expiration.isEmpty()) expiration = "0";
                    params.put("expiration", expiration);
                    params.put("visibilitypoll", cbPollVisibility.isChecked() ? "1" : "0");
                    params.put("overt", cbPollOvert.isChecked() ? "1" : "0");
                    // 单框模式：tpolloption=2(大文本框) / 1(独立输入)
                    params.put("tpolloption", cbPollSingleMode.isChecked() ? "2" : "1");
                    // 投票选项图片 aid（仅非单框模式时可能有图片）
                    if (!cbPollSingleMode.isChecked()) {
                        java.util.List<String> pollImageAids = collectPollImageAids();
                        boolean hasPollImages = false;
                        for (String aid : pollImageAids) {
                            if (aid != null) { hasPollImages = true; break; }
                        }
                        if (hasPollImages) {
                            StringBuilder pollImgStr = new StringBuilder();
                            for (int i = 0; i < pollImageAids.size(); i++) {
                                if (i > 0) pollImgStr.append("\n");
                                pollImgStr.append(pollImageAids.get(i) != null ? pollImageAids.get(i) : "");
                            }
                            params.put("pollimage", pollImgStr.toString());
                        }
                    }
                }

                // 确定提交URL（对齐官方：优先使用从页面解析的postUrl，兜底硬编码）
                String submitUrl;
                if (pageData != null && pageData.getPostUrl() != null && !pageData.getPostUrl().isEmpty()) {
                    submitUrl = pageData.getPostUrl();
                    // 确保URL包含 topicsubmit=yes
                    if (!submitUrl.contains("topicsubmit=yes")) {
                        submitUrl += (submitUrl.contains("&") ? "&" : "?") + "topicsubmit=yes";
                    }
                } else {
                    submitUrl = HttpClient.BASE_URL + "forum.php?mod=post&action=newthread&fid=" + selectedFid + "&topicsubmit=yes";
                }
                // 投票帖需要 special=1 参数
                if (pollEnabled && !submitUrl.contains("special=1")) {
                    submitUrl += "&special=1";
                }

                String response = HttpClient.getInstance().post(submitUrl, params);

                // 使用 PostPageParser.parsePostResult 解析结果（对齐官方）
                PostResult result = PostPageParser.parsePostResult(response);

                // 重置提交状态（对齐官方 PostComposerState.isSubmitting = false）
                isSubmitting = false;

                if (result.isSuccess()) {
                    runOnUiThread(() -> {
                        Toast.makeText(PostActivity.this, result.getMessage(), Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK, new Intent().putExtra("tid", result.getTid() != null ? result.getTid() : ""));
                        finish();
                    });
                } else {
                    runOnUiThread(() -> { showError(result.getMessage()); resetPublishButton(); });
                }
            } catch (Exception e) {
                e.printStackTrace();
                isSubmitting = false;
                runOnUiThread(() -> { showError(getString(R.string.network_error)); resetPublishButton(); });
            }
        }).start();
    }

    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
    }

    private void clearError() {
        if (tvError != null && tvError.getVisibility() != View.GONE) {
            tvError.setVisibility(View.GONE);
        }
    }

    /**
     * 返回键分级处理：先收面板，再确认放弃草稿，避免误触丢失已写内容。
     */
    @Override
    public void onBackPressed() {
        if (llSmileyPanel.getVisibility() == View.VISIBLE
                || llAtPanel.getVisibility() == View.VISIBLE
                || llAdvancedOptions.getVisibility() == View.VISIBLE) {
            hideAllPanels();
            updateToolStates();
            return;
        }
        if (isSubmitting) {
            Toast.makeText(this, "正在提交中，请稍候", Toast.LENGTH_SHORT).show();
            return;
        }
        if (hasDraftContent()) {
            new AlertDialog.Builder(this)
                    .setTitle("放弃编辑？")
                    .setMessage("当前内容尚未发布，是否保存为草稿？")
                    .setNegativeButton("继续编辑", null)
                    .setNeutralButton("保存草稿", (d, w) -> {
                        saveDraft();
                        Toast.makeText(this, "草稿已保存", Toast.LENGTH_SHORT).show();
                        super.onBackPressed();
                    })
                    .setPositiveButton("放弃", (d, w) -> super.onBackPressed())
                    .show();
            return;
        }
        super.onBackPressed();
    }

    // ==================== 草稿箱功能 ====================

    private static final String DRAFT_PREFS = "post_drafts";
    private static final String DRAFT_KEY = "drafts_json";
    private static final int MAX_DRAFTS = 20;
    private AlertDialog dialog; // 草稿箱列表弹窗引用

    /** 保存当前内容为草稿 */
    private void saveDraft() {
        try {
            String title = etTitle.getText() != null ? etTitle.getText().toString() : "";
            String content = etContent.getText() != null ? etContent.getText().toString() : "";
            long timestamp = System.currentTimeMillis();

            org.json.JSONArray drafts = loadDraftsArray();
            // 去重：如果有标题相同的草稿，替换它
            for (int i = drafts.length() - 1; i >= 0; i--) {
                org.json.JSONObject d = drafts.getJSONObject(i);
                if (title.equals(d.optString("title", "")) && title.length() > 0) {
                    drafts.remove(i);
                }
            }
            org.json.JSONObject draft = new org.json.JSONObject();
            draft.put("title", title);
            draft.put("content", content);
            draft.put("timestamp", timestamp);

            // 保存投票数据
            if (pollEnabled) {
                draft.put("pollEnabled", true);
                java.util.List<String> opts = collectPollOptions();
                org.json.JSONArray optArr = new org.json.JSONArray();
                for (String opt : opts) optArr.put(opt);
                draft.put("pollOptions", optArr);
                draft.put("pollMaxChoices", etPollMaxChoices.getText() != null
                        ? etPollMaxChoices.getText().toString() : "");
                draft.put("pollExpiration", etPollExpiration.getText() != null
                        ? etPollExpiration.getText().toString() : "");
                draft.put("pollVisibility", cbPollVisibility.isChecked());
                draft.put("pollOvert", cbPollOvert.isChecked());
                draft.put("pollSingleMode", cbPollSingleMode.isChecked());
            }

            // 保存附件信息（名称+本地路径，aid可能已失效）
            synchronized (attachFiles) {
                if (!attachFiles.isEmpty()) {
                    org.json.JSONArray attachArr = new org.json.JSONArray();
                    for (AttachFile af : attachFiles) {
                        org.json.JSONObject a = new org.json.JSONObject();
                        a.put("name", af.name != null ? af.name : "");
                        a.put("path", af.path != null ? af.path : "");
                        a.put("url", af.url != null ? af.url : "");
                        a.put("bbcode", af.bbcode != null ? af.bbcode : "");
                        attachArr.put(a);
                    }
                    draft.put("attachments", attachArr);
                }
            }

            drafts.put(draft);

            // 限制数量
            while (drafts.length() > MAX_DRAFTS) {
                drafts.remove(0);
            }

            getSharedPreferences(DRAFT_PREFS, MODE_PRIVATE)
                    .edit().putString(DRAFT_KEY, drafts.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** 加载草稿列表（JSON数组） */
    private org.json.JSONArray loadDraftsArray() {
        try {
            String json = getSharedPreferences(DRAFT_PREFS, MODE_PRIVATE)
                    .getString(DRAFT_KEY, "[]");
            return new org.json.JSONArray(json);
        } catch (Exception e) {
            return new org.json.JSONArray();
        }
    }

    /** 显示草稿箱列表 */
    private void showDraftList() {
        org.json.JSONArray drafts = loadDraftsArray();
        if (drafts.length() == 0) {
            Toast.makeText(this, "草稿箱为空", Toast.LENGTH_SHORT).show();
            return;
        }

        // 自定义适配器：每行 = 草稿信息 + 删除按钮
        android.widget.BaseAdapter adapter = new android.widget.BaseAdapter() {
            @Override
            public int getCount() { return drafts.length(); }

            @Override
            public Object getItem(int position) { return position; }

            @Override
            public long getItemId(int position) { return position; }

            @Override
            public View getView(int position, View convertView, android.view.ViewGroup parent) {
                final int displayIdx = position;
                final int realIdx = drafts.length() - 1 - position;
                if (convertView == null) {
                    convertView = android.view.LayoutInflater.from(PostActivity.this)
                            .inflate(R.layout.draft_list_item, parent, false);
                }
                TextView tvInfo = convertView.findViewById(R.id.tv_draft_info);
                TextView btnDelete = convertView.findViewById(R.id.btn_draft_delete);

                try {
                    org.json.JSONObject d = drafts.getJSONObject(realIdx);
                    String title = d.optString("title", "");
                    if (title.isEmpty()) title = "(无标题)";
                    long ts = d.optLong("timestamp", 0);
                    String timeStr = ts > 0
                            ? new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault())
                            .format(new java.util.Date(ts))
                            : "";
                    String preview = d.optString("content", "");
                    if (preview.length() > 30) preview = preview.substring(0, 30) + "...";
                    tvInfo.setText(title + "\n" + timeStr + (preview.isEmpty() ? "" : "  " + preview));
                } catch (Exception e) {
                    tvInfo.setText("(草稿)");
                }

                // 点击行 → 加载草稿
                convertView.setOnClickListener(v -> {
                    dialog.dismiss();
                    loadDraft(drafts, realIdx);
                });
                // 删除按钮
                btnDelete.setOnClickListener(v -> {
                    new AlertDialog.Builder(PostActivity.this)
                            .setTitle("删除草稿")
                            .setMessage("确定删除此草稿？")
                            .setPositiveButton("删除", (d2, w2) -> {
                                deleteDraft(realIdx);
                                dialog.dismiss();
                                // 刷新列表
                                showDraftList();
                            })
                            .setNegativeButton("取消", null)
                            .show();
                });
                return convertView;
            }
        };

        dialog = new AlertDialog.Builder(this)
                .setTitle("草稿箱（" + drafts.length() + "）")
                .setAdapter(adapter, null)
                .setNegativeButton("关闭", null)
                .create();
        dialog.show();
    }

    /** 加载指定草稿到编辑器 */
    private void loadDraft(org.json.JSONArray drafts, int index) {
        try {
            org.json.JSONObject d = drafts.getJSONObject(index);
            String title = d.optString("title", "");
            String content = d.optString("content", "");
            etTitle.setText(title);
            etContent.setText(content);

            // 恢复投票数据
            if (d.optBoolean("pollEnabled", false)) {
                // 切换到投票Tab
                if (!pollEnabled) {
                    TextView tabPoll = findViewById(R.id.tab_poll);
                    if (tabPoll != null) tabPoll.performClick();
                }
                // 投票配置
                String maxChoices = d.optString("pollMaxChoices", "");
                String expiration = d.optString("pollExpiration", "");
                if (etPollMaxChoices != null) etPollMaxChoices.setText(maxChoices);
                if (etPollExpiration != null) etPollExpiration.setText(expiration);
                if (cbPollVisibility != null) cbPollVisibility.setChecked(d.optBoolean("pollVisibility", false));
                if (cbPollOvert != null) cbPollOvert.setChecked(d.optBoolean("pollOvert", false));
                boolean singleMode = d.optBoolean("pollSingleMode", false);
                if (cbPollSingleMode != null) cbPollSingleMode.setChecked(singleMode);

                // 投票选项
                org.json.JSONArray optArr = d.optJSONArray("pollOptions");
                if (optArr != null && optArr.length() > 0) {
                    if (singleMode) {
                        // 单框模式：把所有选项拼成多行文本
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < optArr.length(); i++) {
                            if (i > 0) sb.append("\n");
                            sb.append(optArr.getString(i));
                        }
                        if (etPollBatch != null) etPollBatch.setText(sb.toString());
                    } else {
                        // 独立框模式：逐个添加选项
                        // 先清除已有选项（保留第一个作为模板）
                        while (llPollOptions.getChildCount() > 1) {
                            llPollOptions.removeViewAt(llPollOptions.getChildCount() - 1);
                        }
                        // 填充第一个
                        if (llPollOptions.getChildCount() > 0) {
                            EditText et = findEditTextInRow((LinearLayout) llPollOptions.getChildAt(0));
                            if (et != null) et.setText(optArr.length() > 0 ? optArr.getString(0) : "");
                        }
                        // 添加剩余选项
                        for (int i = 1; i < optArr.length(); i++) {
                            TextView btnAdd = findViewById(R.id.btn_poll_add_option);
                            if (btnAdd != null) btnAdd.performClick();
                            if (llPollOptions.getChildCount() > 0) {
                                EditText et = findEditTextInRow(
                                        (LinearLayout) llPollOptions.getChildAt(llPollOptions.getChildCount() - 1));
                                if (et != null) et.setText(optArr.getString(i));
                            }
                        }
                    }
                }
            }

            // 恢复附件信息
            org.json.JSONArray attachArr = d.optJSONArray("attachments");
            if (attachArr != null && attachArr.length() > 0) {
                synchronized (attachFiles) {
                    attachFiles.clear();
                    for (int i = 0; i < attachArr.length(); i++) {
                        org.json.JSONObject a = attachArr.getJSONObject(i);
                        String afName = a.optString("name", "");
                        String afPath = a.optString("path", "");
                        String afUrl = a.optString("url", "");
                        String afBbcode = a.optString("bbcode", "");
                        // 检查本地文件是否仍存在
                        boolean fileExists = afPath.length() > 0
                                && new java.io.File(afPath).exists();
                        if (fileExists || afUrl.length() > 0) {
                            AttachFile af = new AttachFile(afName, afPath);
                            af.url = afUrl;
                            af.bbcode = afBbcode;
                            attachFiles.add(af);
                        }
                    }
                }
                // 刷新附件列表UI
                updateAttachList();
                updateImagePreview();
            }

            etTitle.requestFocus();
            etTitle.setSelection(title.length());
            Toast.makeText(this, "草稿已加载", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "加载草稿失败", Toast.LENGTH_SHORT).show();
        }
    }

    /** 删除指定草稿 */
    private void deleteDraft(int index) {
        try {
            org.json.JSONArray drafts = loadDraftsArray();
            drafts.remove(index);
            getSharedPreferences(DRAFT_PREFS, MODE_PRIVATE)
                    .edit().putString(DRAFT_KEY, drafts.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** 打开页面时自动加载最新草稿（仅当输入为空时） */
    private void autoLoadLatestDraft() {
        if (etTitle.getText() != null && etTitle.getText().length() > 0) return;
        if (etContent.getText() != null && etContent.getText().length() > 0) return;

        org.json.JSONArray drafts = loadDraftsArray();
        if (drafts.length() == 0) return;
        try {
            org.json.JSONObject d = drafts.getJSONObject(drafts.length() - 1);
            long ts = d.optLong("timestamp", 0);
            // 只加载1小时内的草稿
            if (ts > 0 && System.currentTimeMillis() - ts > 3600000) return;
            String title = d.optString("title", "");
            String content = d.optString("content", "");
            if (title.isEmpty() && content.isEmpty()
                    && !d.optBoolean("pollEnabled", false)
                    && d.optJSONArray("attachments") == null) return;

            new AlertDialog.Builder(this)
                    .setTitle("发现未完成草稿")
                    .setMessage("是否加载上次未完成的编辑？")
                    .setPositiveButton("加载", (dialog, w) -> {
                        loadDraft(drafts, drafts.length() - 1);
                    })
                    .setNegativeButton("取消", (dialog, w) -> {
                        // 删除旧草稿，不再提示
                        deleteDraft(drafts.length() - 1);
                    })
                    .show();
        } catch (Exception ignored) {
        }
    }

    private boolean hasDraftContent() {
        boolean hasTitle = etTitle.getText() != null
                && etTitle.getText().toString().trim().length() > 0;
        boolean hasContent = etContent.getText() != null
                && etContent.getText().toString().trim().length() > 0;
        boolean hasAttach;
        synchronized (attachFiles) {
            hasAttach = !attachFiles.isEmpty();
        }
        boolean hasPoll = pollEnabled && !collectPollOptions().isEmpty();
        return hasTitle || hasContent || hasAttach || hasPoll;
    }

    private void resetPublishButton() {
        btnPublish.setEnabled(true);
        btnPublish.setText(R.string.post_publish);
    }

    // ==================== 帖子类型选择（对齐官方） ====================

    private void showPostTypeSelector(List<PostType> postTypes) {
        if (postTypes == null || postTypes.isEmpty()) return;

        String[] names = new String[postTypes.size()];
        for (int i = 0; i < postTypes.size(); i++) {
            names[i] = postTypes.get(i).getName();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("选择帖子类型");
        builder.setItems(names, (dialog, which) -> {
            selectedTypeId = postTypes.get(which).getId();
            Toast.makeText(this, "已选择类型: " + postTypes.get(which).getName(), Toast.LENGTH_SHORT).show();
        });
        builder.show();
    }
}