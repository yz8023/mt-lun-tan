package com.forum.MT.ui.detail;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.Color;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.DiffUtil;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.forum.MT.R;
import com.forum.MT.model.ReplyItem;
import com.forum.MT.network.HttpClient;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 回复列表适配器
 * 支持 Glide 加载头像、楼层标签、楼主标识、等级、时间、地点等完整信息

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.forum.MT.R;
import com.forum.MT.model.ReplyItem;
import com.forum.MT.network.HttpClient;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 回复列表适配器
 * 支持 Glide 加载头像、楼层标签、楼主标识、等级、时间、地点等完整信息
 */
public class ReplyAdapter extends RecyclerView.Adapter<ReplyAdapter.ViewHolder> {

    private List<ReplyItem> replyList;
    private OnReplyClickListener replyClickListener;
    private OnUserClickListener userClickListener;
    private OnRewardClickListener rewardClickListener;
    private OnReportClickListener reportClickListener;
    private OnEditClickListener editClickListener;
    private OnPinClickListener pinClickListener;
    /** 当前登录用户 uid，用于判断"编辑"按钮是否显示；为空表示未登录。 */
    private String currentUid;
    private String highlightedPid; // 需要高亮的 pid

    public interface OnReplyClickListener {
        void onReplyClick(ReplyItem item, int position);
    }

    public interface OnUserClickListener {
        void onUserClick(ReplyItem item, int position);
    }

    public interface OnRewardClickListener {
        void onRewardClick(ReplyItem item, int position);
    }

    public interface OnReportClickListener {
        void onReportClick(ReplyItem item, int position);
    }

    /** 编辑该楼层。仅在 Activity 判定为自己的回复时才注册。 */
    public interface OnEditClickListener {
        void onEditClick(ReplyItem item, int position);
    }

    /** 置顶/取消置顶该楼层。仅对自己的回复显示，实际权限由服务端判定。 */
    public interface OnPinClickListener {
        void onPinClick(ReplyItem item, int position);
    }

    public void setOnReplyClickListener(OnReplyClickListener listener) {
        this.replyClickListener = listener;
    }

    public void setOnUserClickListener(OnUserClickListener listener) {
        this.userClickListener = listener;
    }

    public void setOnRewardClickListener(OnRewardClickListener listener) {
        this.rewardClickListener = listener;
    }

    public void setOnReportClickListener(OnReportClickListener listener) {
        this.reportClickListener = listener;
    }

    public void setOnEditClickListener(OnEditClickListener listener) {
        this.editClickListener = listener;
    }

    public void setOnPinClickListener(OnPinClickListener listener) {
        this.pinClickListener = listener;
    }

    /**
     * 设置当前登录用户 uid。
     *
     * <p>只有 uid 与楼层作者一致时才显示"编辑"，避免给别人的回复展示无权限的入口。
     */
    public void setCurrentUid(String uid) {
        boolean changed = !TextUtils.equals(this.currentUid, uid);
        this.currentUid = uid;
        if (changed) notifyDataSetChanged();
    }

    public ReplyAdapter(List<ReplyItem> replyList) {
        this.replyList = replyList;
    }

    public void updateData(List<ReplyItem> newList) {
        final List<ReplyItem> oldList = this.replyList;
        final List<ReplyItem> nextList = newList != null ? newList : new ArrayList<>();
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override
            public int getOldListSize() { return oldList != null ? oldList.size() : 0; }
            @Override
            public int getNewListSize() { return nextList.size(); }
            @Override
            public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                ReplyItem o = oldList.get(oldItemPosition);
                ReplyItem n = nextList.get(newItemPosition);
                if (o == null || n == null) return false;
                String op = o.getPid();
                String np = n.getPid();
                if (op != null && np != null) return op.equals(np);
                return o == n;
            }
            @Override
            public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                // ★ 不能无条件返回 true。pid 相同不代表内容相同：
                // 编辑评论、置顶、楼层标签变化都会保留原 pid 而改变渲染结果，
                // 一律视为"内容相同"会让 DiffUtil 跳过重绑，界面只能靠退出重进才更新。
                ReplyItem o = oldList.get(oldItemPosition);
                ReplyItem n = nextList.get(newItemPosition);
                return isSameRenderState(o, n);
            }
        });
        this.replyList = nextList;
        diffResult.dispatchUpdatesTo(this);
    }

    /**
     * 判断两个楼层的可见渲染状态是否一致。
     *
     * <p>只比较真正影响绑定结果的字段，不做整对象 equals：
     * ReplyItem 没有重写 equals，而刷新后拿到的都是新实例，整对象比较等于永远"不同"，
     * 会退化成全量重绑，长列表下就是 ANR。
     */
    private static boolean isSameRenderState(ReplyItem o, ReplyItem n) {
        if (o == null || n == null) return o == n;
        return TextUtils.equals(o.getContentHtml(), n.getContentHtml())
                && TextUtils.equals(o.getContentText(), n.getContentText())
                && TextUtils.equals(o.getQuotedContentHtml(), n.getQuotedContentHtml())
                && TextUtils.equals(o.getFloorLabel(), n.getFloorLabel())
                && TextUtils.equals(o.getTime(), n.getTime())
                && TextUtils.equals(o.getAuthor(), n.getAuthor())
                && TextUtils.equals(o.getAuthorLevel(), n.getAuthorLevel())
                && TextUtils.equals(o.getAvatarUrl(), n.getAvatarUrl())
                && o.isPinned() == n.isPinned()
                && o.isOP() == n.isOP();
    }

    /**
     * ★ 增量追加回复，只 notifyItemRangeInserted，不重新绑定已有项。
     * 避免 loadAllReplies 每批加载后 notifyDataSetChanged 导致主线程 ANR。
     */
    public void appendItems(List<ReplyItem> newItems) {
        if (newItems == null || newItems.isEmpty()) return;
        int startPos = replyList == null ? 0 : replyList.size();
        if (replyList == null) replyList = new ArrayList<>();
        replyList.addAll(newItems);
        notifyItemRangeInserted(startPos, newItems.size());
    }

    /**
     * ★ 增量前插回复：用于通知定位时先显示目标页，再后台把前面的页补进来。
     * 只通知头部插入，避免整列表重绑。
     */
    public void prependItems(List<ReplyItem> newItems) {
        if (newItems == null || newItems.isEmpty()) return;
        if (replyList == null) replyList = new ArrayList<>();
        replyList.addAll(0, newItems);
        notifyItemRangeInserted(0, newItems.size());
    }

    public int findPositionByPid(String pid) {
        if (pid == null || replyList == null || replyList.isEmpty()) return -1;
        for (int i = 0; i < replyList.size(); i++) {
            ReplyItem item = replyList.get(i);
            if (item != null && pid.equals(item.getPid())) {
                return i;
            }
        }
        return -1;
    }

    public void setHighlightedPid(String pid) {
        if (TextUtils.equals(this.highlightedPid, pid)) {
            return;
        }
        int oldPos = findPositionByPid(this.highlightedPid);
        this.highlightedPid = pid;
        int newPos = findPositionByPid(this.highlightedPid);
        if (oldPos >= 0) notifyItemChanged(oldPos);
        if (newPos >= 0 && newPos != oldPos) notifyItemChanged(newPos);
        if (oldPos < 0 && newPos < 0) {
            notifyDataSetChanged();
        }
    }

    public String getHighlightedPid() {
        return highlightedPid;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_reply, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReplyItem item = replyList.get(position);
        holder.bind(item, highlightedPid);
    }

    @Override
    public int getItemCount() {
        return replyList == null ? 0 : replyList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView ivAvatar;
        private final TextView tvFloorLabel;
        private final TextView tvAuthor;
        private final TextView tvOpBadge;
        private final TextView tvLevel;
        private final TextView tvTime;
        private final TextView tvContent;
        private final LinearLayout layoutReplyQuote;
        private final TextView tvReplyQuote;
        private final LinearLayout layoutReplyAttach;
        private final TextView tvReplyAttachName;
        private final TextView tvReplyAttachInfo;
        private final LinearLayout llReplyImages;
        private final TextView btnReplyTo;
        private final TextView btnRewardReply;
        private final TextView btnReportReply;
        private final TextView btnEditReply;
        private final TextView btnPinReply;
        private final TextView tvPinned;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.iv_reply_avatar);
            tvFloorLabel = itemView.findViewById(R.id.tv_floor_label);
            tvAuthor = itemView.findViewById(R.id.tv_reply_author);
            tvOpBadge = itemView.findViewById(R.id.tv_op_badge);
            tvLevel = itemView.findViewById(R.id.tv_reply_level);
            tvTime = itemView.findViewById(R.id.tv_reply_time);
            tvContent = itemView.findViewById(R.id.tv_reply_content);
            layoutReplyQuote = itemView.findViewById(R.id.layout_reply_quote);
            tvReplyQuote = itemView.findViewById(R.id.tv_reply_quote);
            layoutReplyAttach = itemView.findViewById(R.id.layout_reply_attach);
            tvReplyAttachName = itemView.findViewById(R.id.tv_reply_attach_name);
            tvReplyAttachInfo = itemView.findViewById(R.id.tv_reply_attach_info);
            llReplyImages = itemView.findViewById(R.id.ll_reply_images);
            btnReplyTo = itemView.findViewById(R.id.btn_reply_to);
            btnRewardReply = itemView.findViewById(R.id.btn_reward_reply);
            btnReportReply = itemView.findViewById(R.id.btn_report_reply);
            btnEditReply = itemView.findViewById(R.id.btn_edit_reply);
            btnPinReply = itemView.findViewById(R.id.btn_pin_reply);
            tvPinned = itemView.findViewById(R.id.tv_pinned);
        }

        void bind(ReplyItem item, String highlightedPid) {
            // ★ 应用"帖子大小"设置：评论正文/引用字号
            float ts = com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(itemView.getContext(),
                    com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_REPLY);
            tvContent.setTextSize(ts);
            tvReplyQuote.setTextSize(ts);

            // 头像 - Glide 加载圆图
            String avatarUrl = item.getAvatarUrl();
            if (!TextUtils.isEmpty(avatarUrl)) {
                Glide.with(ivAvatar.getContext())
                        .load(avatarUrl)
                        .transform(new CircleCrop())
                        .placeholder(R.drawable.ic_account)
                        .error(R.drawable.ic_account)
                        .into(ivAvatar);
            } else {
                ivAvatar.setImageResource(R.drawable.ic_account);
            }

            // ★ 高亮目标回复：清除旧高亮，命中时设置淡黄色背景
            if (highlightedPid != null && highlightedPid.equals(item.getPid())) {
                itemView.setBackgroundColor(0x33FFEB3B); // 淡黄色高亮
            } else {
                // 评论描边边框：由主题设置控制开关与颜色
                android.graphics.drawable.Drawable borderBg =
                        com.forum.MT.ui.widget.CommentBorderDrawable.create(itemView.getContext());
                if (borderBg != null) {
                    itemView.setBackground(borderBg);
                } else {
                    itemView.setBackgroundColor(Color.TRANSPARENT);
                }
            }

            // ★ 新增：头像和用户名点击 → 打开原生用户资料页
            final int pos = getAdapterPosition();
            final ReplyItem currentItem = item;
            ivAvatar.setOnClickListener(v -> {
                if (userClickListener != null && !TextUtils.isEmpty(currentItem.getAuthorUid())) {
                    userClickListener.onUserClick(currentItem, pos);
                }
            });
            tvAuthor.setOnClickListener(v -> {
                if (userClickListener != null && !TextUtils.isEmpty(currentItem.getAuthorUid())) {
                    userClickListener.onUserClick(currentItem, pos);
                }
            });

            // 楼层标签（沙发/椅子/地毯/报纸/N#）
            String floorLabel = item.getFloorLabel();
            if (!TextUtils.isEmpty(floorLabel)) {
                tvFloorLabel.setVisibility(View.VISIBLE);
                tvFloorLabel.setText(floorLabel);
            } else {
                tvFloorLabel.setVisibility(View.GONE);
            }

            // 作者名
            tvAuthor.setText(!TextUtils.isEmpty(item.getAuthor()) ? item.getAuthor() : "匿名");

            // 楼主标识
            if (item.isOP()) {
                tvOpBadge.setVisibility(View.VISIBLE);
            } else {
                tvOpBadge.setVisibility(View.GONE);
            }

            // 等级
            String level = item.getAuthorLevel();
            if (!TextUtils.isEmpty(level)) {
                tvLevel.setVisibility(View.VISIBLE);
                tvLevel.setText(level);
            } else {
                tvLevel.setVisibility(View.GONE);
            }

            // 时间
            String time = item.getTime();
            if (!TextUtils.isEmpty(time)) {
                tvTime.setVisibility(View.VISIBLE);
                tvTime.setText(time);
            } else {
                tvTime.setVisibility(View.GONE);
            }

            // 评论区按参考样式仅显示时间，不显示回复项地点，避免与回复按钮并列出现重复灰色定位文字。

            // 回复按钮
            String author = item.getAuthor();
            if (!TextUtils.isEmpty(author)) {
                btnReplyTo.setVisibility(View.VISIBLE);
                btnReplyTo.setOnClickListener(v -> {
                    if (replyClickListener != null) {
                        replyClickListener.onReplyClick(item, getAdapterPosition());
                    }
                });
            } else {
                btnReplyTo.setVisibility(View.GONE);
                btnReplyTo.setOnClickListener(null);
            }

            // 判断是否为自己发的楼层。自己的评论不显示"打赏"和"举报"
            // （给自己打赏、举报自己都没有意义），改为显示"置顶"。
            boolean isSelfReply = !TextUtils.isEmpty(currentUid)
                    && !TextUtils.isEmpty(item.getAuthorUid())
                    && currentUid.equals(item.getAuthorUid());

            // 服务端置顶角标：状态只来自页面解析结果，不做本地伪造。
            tvPinned.setVisibility(item.isPinned() ? View.VISIBLE : View.GONE);

            // 评论打赏按钮：只负责回调，登录检查、formhash、pid 与 Discuz
            // 响应判断统一由 Activity 处理，避免适配器复制网络逻辑。
            if (!isSelfReply && !TextUtils.isEmpty(item.getPid()) && rewardClickListener != null) {
                btnRewardReply.setVisibility(View.VISIBLE);
                btnRewardReply.setOnClickListener(v ->
                        rewardClickListener.onRewardClick(item, getAdapterPosition()));
            } else {
                btnRewardReply.setVisibility(View.GONE);
                btnRewardReply.setOnClickListener(null);
            }

            // 编辑按钮：只对自己发的楼层显示。是否真的有编辑权限（时限、版规）
            // 由服务端决定，进入编辑页后再反馈，避免在列表里做不可靠的权限推断。
            if (isSelfReply && !TextUtils.isEmpty(item.getPid()) && editClickListener != null) {
                btnEditReply.setVisibility(View.VISIBLE);
                btnEditReply.setOnClickListener(v ->
                        editClickListener.onEditClick(item, getAdapterPosition()));
            } else {
                btnEditReply.setVisibility(View.GONE);
                btnEditReply.setOnClickListener(null);
            }

            // 置顶按钮：替代自己楼层上的"打赏/举报"。走 Discuz stickreply 接口，
            // 真实权限（版主）由服务端判定，这里只负责入口与文案。
            if (isSelfReply && !TextUtils.isEmpty(item.getPid()) && pinClickListener != null) {
                btnPinReply.setVisibility(View.VISIBLE);
                btnPinReply.setText(item.isPinned()
                        ? R.string.reply_unpin_action : R.string.reply_pin_action);
                btnPinReply.setOnClickListener(v ->
                        pinClickListener.onPinClick(item, getAdapterPosition()));
            } else {
                btnPinReply.setVisibility(View.GONE);
                btnPinReply.setText(R.string.reply_pin_action);
                btnPinReply.setOnClickListener(null);
            }

            // 举报按钮：只负责回调，具体弹窗与 Discuz 提交由 Activity 处理。
            if (!isSelfReply && !TextUtils.isEmpty(item.getPid()) && reportClickListener != null) {
                btnReportReply.setVisibility(View.VISIBLE);
                btnReportReply.setOnClickListener(v ->
                        reportClickListener.onReportClick(item, getAdapterPosition()));
            } else {
                btnReportReply.setVisibility(View.GONE);
                btnReportReply.setOnClickListener(null);
            }

            // 内容 - 优先显示纯文本

            // 引用内容单独显示，模拟网页端的浅黄色引用框；当前回复保持深色正文。
            String quotedText = item.getQuotedContentText();
            if (!TextUtils.isEmpty(quotedText)) {
                layoutReplyQuote.setVisibility(View.VISIBLE);
                // ★ 修复：Html.fromHtml() 会把文本中的 \n 折叠成空格（HTML空白规则），
                // 导致引用原文的"元信息行"与"正文"粘连。先把换行转成 <br> 再渲染，确保换行保留。
                String quoteWithBr = quotedText.replace("\n", "<br>");
                tvReplyQuote.setText(fromForumHtml(quoteWithBr, tvReplyQuote));
                // ★ 修复：引用文本中"xx 发表于 xxx"也是带下划线的链接，
                // 必须设置可点击（与 tvContent 保持一致）
                setupClickableLinks(tvReplyQuote);
            } else {
                layoutReplyQuote.setVisibility(View.GONE);
                tvReplyQuote.setText("");
            }

            String contentText = item.getContentText();
            String htmlContent = item.getContentHtml();

            // ★ 提取附件块(div.comiis_attach)信息，显示灰色附件卡片；
            // 同时从 htmlContent 移除该块，避免正文重复显示"上传/下载次数"文本
            String attachUrl = null, attachName = null, attachInfo = null;
            String htmlForProcess = htmlContent;
            if (htmlContent != null && htmlContent.contains("comiis_attach")) {
                try {
                    org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parseBodyFragment(htmlContent);
                    doc.outputSettings().prettyPrint(false);
                    org.jsoup.nodes.Element attachDiv = doc.selectFirst("div.comiis_attach");
                    if (attachDiv != null) {
                        org.jsoup.nodes.Element a = attachDiv.selectFirst(
                                "a[href*=mod=attachment], a[href*=aid=]");
                        if (a != null) {
                            attachUrl = normalizeLinkUrl(a.attr("href"));
                        }
                        org.jsoup.nodes.Element titEl = attachDiv.selectFirst(".attach_tit");
                        attachName = titEl != null ? titEl.text().trim()
                                : (a != null ? a.text().trim() : "附件");
                        if (TextUtils.isEmpty(attachName)) attachName = "附件";
                        org.jsoup.nodes.Element sizeEl = attachDiv.selectFirst(".attach_size");
                        attachInfo = sizeEl != null ? sizeEl.text().trim() : "";
                        attachDiv.remove();
                        htmlForProcess = doc.body().html();
                    }
                } catch (Exception ignored) {}
            }

            // ★ 显示附件卡片（灰色，可点击下载）
            if (!TextUtils.isEmpty(attachUrl)) {
                layoutReplyAttach.setVisibility(View.VISIBLE);
                tvReplyAttachName.setText(attachName);
                tvReplyAttachInfo.setText(attachInfo);
                final String finalAttachUrl = attachUrl;
                layoutReplyAttach.setOnClickListener(v ->
                        openContentLink(finalAttachUrl, v.getContext()));
            } else {
                layoutReplyAttach.setVisibility(View.GONE);
                tvReplyAttachName.setText("");
                tvReplyAttachInfo.setText("");
            }

            // ★ 渲染前先清除上一次可能残留的动态视图（防止刷新后内容叠加/复制）
            clearDynamicViews(itemView, llReplyImages);

            // ★ 优先使用后台预处理缓存（解决加载500条回复时主线程 ANR）
            // 命中前必须校验指纹：pid 不变但正文可能已被编辑，旧缓存会让界面停在编辑前内容。
            ReplyPreProcessResult cached = null;
            String pid = item.getPid();
            if (pid != null) {
                ReplyPreProcessResult candidate = sPreProcessCache.get(pid);
                if (candidate != null && !TextUtils.isEmpty(htmlContent)
                        && contentFingerprint(htmlContent).equals(candidate.sourceFingerprint)) {
                    cached = candidate;
                }
            }

            // ★ 修复：优先使用 htmlContent（保留<a>链接标签），而不是 contentText（纯文本丢失链接）
            if (!TextUtils.isEmpty(htmlContent)) {
                tvContent.setVisibility(View.VISIBLE);
                if (cached != null) {
                    // ★ 快速路径：直接使用预处理结果，跳过所有 Jsoup/正则处理
                    preloadSmileysAndRender(cached.cleanHtml, cached.tables, itemView,
                            tvContent, llReplyImages, cached.imageUrls, cached.codeCards);
                } else {
                    // 慢速路径：主线程执行完整处理（首次加载或缓存未命中时）
                    List<CodeCardRef> replyCodeCards = new ArrayList<>();
                    String processedHtml = extractCodeBlocks(htmlForProcess, replyCodeCards);
                    processedHtml = convertTextLinkBBCode(processedHtml);
                    processedHtml = convertAttachBBCodeToImg(processedHtml);
                    processedHtml = fixTruncatedLinkTexts(processedHtml);
                    List<String> replyImageUrls = new ArrayList<>();
                    processedHtml = extractWebUploadedImages(processedHtml, replyImageUrls);
                    String cleanHtml = extractImagesFromHtml(processedHtml, replyImageUrls);
                    List<TableData> replyTables = new ArrayList<>();
                    cleanHtml = convertHtmlTables(cleanHtml, replyTables);
                    String finalCleanHtml = cleanHtml;
                    preloadSmileysAndRender(finalCleanHtml, replyTables, itemView,
                            tvContent, llReplyImages, replyImageUrls, replyCodeCards);
                }
            } else if (!TextUtils.isEmpty(contentText)) {
                // 兜底：只有纯文本，直接显示（丢失链接但至少能看到文字）
                tvContent.setVisibility(View.VISIBLE);
                tvContent.setText(fromForumHtml(contentText, tvContent));
                setupClickableLinks(tvContent);
                applyEditTimeColor(tvContent);
                llReplyImages.setVisibility(View.GONE);
            } else {
                tvContent.setVisibility(View.GONE);
                llReplyImages.setVisibility(View.GONE);
            }
        }
    }

    /**
     * ★ 修复：服务端返回的<a>显示文本可能被截断（包含...），
     * 用 href 完整URL替换显示文本，并保持<a>标签样式
     */
    private static String fixTruncatedLinkTexts(String html) {
        if (TextUtils.isEmpty(html)) return html;
        // ★ 纯正则替换，不使用 Jsoup 解析整个 HTML（避免重新序列化打乱元素顺序）
        // 匹配 <a href="...">显示文本含...</a>，将显示文本替换为 href
        java.util.regex.Pattern linkPattern = java.util.regex.Pattern.compile(
                "(<a\\b[^>]*href\\s*=\\s*\")([^\"]+)(\"[^>]*>)([^<]*(?:\\.{2,}|…)[^<]*)(</a>)",
                java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Matcher m = linkPattern.matcher(html);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String href = m.group(2);
            String prefix = m.group(1) + m.group(2) + m.group(3);
            String suffix = m.group(5);
            m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(prefix + href + suffix));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /**
     * 将 Discuz! 的 [attachimg]/[attach]/[img] BBCode 转换为 HTML 标签。
     * <p>
     * 注意：
     * - [attachimg] 是图片附件 → 转为 <img>，由图片管线加载
     * - [attach] 是通用文件附件（zip/pdf/doc等）→ 转为附件链接，
     *   由后续的附件卡片渲染为 📎 卡片（参考开源 sqapp 项目）
     * - [img]url[/img] → 直接转为 <img>，由图片管线加载
     */
    private static String convertAttachBBCodeToImg(String html) {
        if (TextUtils.isEmpty(html)) return "";
        String result = html;
        // ★ 加 data-mt-inline="true" 标记，让 extractImagesFromHtml 知道这是内联图片，不要移到底部
        // ★ 属性值中的 & 必须转义为 &amp;，否则 Html.fromHtml 解析时可能吞掉参数
        // ★ 换行由 extractImagesFromHtml 的 appendBlockImage 统一补齐（大图独占一行）
        result = result.replaceAll("(?i)\\[attachimg\\]([0-9]+)\\[/attachimg\\]",
                "<img data-mt-inline=\"true\" src=\"https://bbs.binmt.cc/forum.php?mod=image&amp;aid=$1&amp;size=300x300&amp;key=&amp;nocache=1\">");
        // [attach] 是文件附件：转为附件链接（保留 aid），由附件卡片渲染
        result = result.replaceAll("(?i)\\[attach\\]([0-9]+)\\[/attach\\]",
                "<a data-sqapp-attachment=\"true\" href=\"https://bbs.binmt.cc/forum.php?mod=attachment&amp;aid=$1\">附件 $1</a>");
        result = result.replaceAll("\\[img(?:=[^\\]]*)?\\]\\s*([^\\[\\]]+?)\\s*\\[/img\\]",
                "<img src=\"$1\">");
        return result;
    }

    /** 判断已生成内容的尾部是否已构成视觉换行。 */
    private static boolean endsWithHtmlLineBreak(CharSequence cs) {
        String s = cs.toString();
        int end = s.length();
        while (true) {
            while (end > 0 && Character.isWhitespace(s.charAt(end - 1))) end--;
            if (end == 0) return true; // 内容开头，无需补
            if (s.charAt(end - 1) != '>') return false; // 尾部是文字 → 需要换行
            int start = s.lastIndexOf('<', end - 1);
            if (start < 0) return false;
            String tag = s.substring(start, end).toLowerCase(java.util.Locale.ROOT);
            if (isHtmlLineBreakTag(tag)) return true;
            if (tag.startsWith("<img")) return false; // 紧邻上一张图片 → 需要换行分隔
            // 透明的行内标签（span/a/font/b/i 等）：跳过继续往前看
            end = start;
        }
    }

    /** 判断指定位置之后是否紧跟视觉换行（&lt;br&gt;、块级标签边界或字符串结束）。 */
    private static boolean startsWithHtmlLineBreak(String html, int from) {
        int i = from;
        while (true) {
            while (i < html.length() && Character.isWhitespace(html.charAt(i))) i++;
            if (i >= html.length()) return true; // 内容结尾，无需补
            if (html.charAt(i) != '<') return false; // 后面是文字 → 需要换行
            int gt = html.indexOf('>', i);
            if (gt < 0) return false;
            String tag = html.substring(i, gt + 1).toLowerCase(java.util.Locale.ROOT);
            if (isHtmlLineBreakTag(tag)) return true;
            if (tag.startsWith("<img")) return false;
            i = gt + 1;
        }
    }

    /** &lt;br&gt; 或块级标签（其边界本身就构成换行）。 */
    private static boolean isHtmlLineBreakTag(String lowerTag) {
        return lowerTag.matches("(?s)<br\\s*/?>")
                || lowerTag.matches("(?s)</?(?:div|p|li|td|tr|ul|ol|blockquote|table|tbody|center|pre|h[1-6])[\\s>/].*");
    }

    /**
     * ★ 把"保留在正文中的大图"按块级元素方式写入结果：必要时补前后 &lt;br&gt;，使图片独占一行。
     *
     * <p>原因：{@code Html.fromHtml} 把 &lt;img&gt; 渲染成行内 ImageSpan，后续文字会紧贴图片右侧；
     * 而网页端 Discuz 把附件图包在块级容器（comiis_postimg）中，图片独占一行、文字另起一行。
     * 表情/小图不走此方法，仍保持行内。
     */
    private static void appendBlockImage(StringBuffer sb, java.util.regex.Matcher matcher,
                                        String html, String keptTag) {
        int tagEnd = matcher.end();
        // 先把匹配之前的原文追加进 sb（替换为空），便于检查其尾部是否已有换行
        matcher.appendReplacement(sb, "");
        if (!endsWithHtmlLineBreak(sb)) {
            sb.append("<br>");
        }
        sb.append(keptTag);
        if (!startsWithHtmlLineBreak(html, tagEnd)) {
            sb.append("<br>");
        }
    }

    /**
     * 将 Discuz! BBCode 文字链接转为 HTML <a> 标签
     * 支持格式：
     *   [url=https://example.com]点我下载[/url]
     *   [url]https://example.com[/url]
     */
    private static String convertTextLinkBBCode(String html) {
        if (TextUtils.isEmpty(html)) return "";
        String result = html;
        // [url=https://...]text[/url]
        result = result.replaceAll("(?is)\\[url\\s*=\\s*([^\\]\\s]+)\\]([^\\[]*?)\\[/url\\]",
                "<a href=\"$1\">$2</a>");
        // [url]url[/url]
        result = result.replaceAll("(?is)\\[url\\]([^\\[]+?)\\[/url\\]",
                "<a href=\"$1\">$1</a>");
        return result;
    }

    /**
     * 为 TextView 设置可点击链接（蓝色高亮 + 可点击跳转）
     * ★ 统一方案：与 ThreadDetailActivity.setupClickableLinks 保持一致
     * 
     * 注意：此方法不会覆盖已有文本，只会在现有 Spannable 上添加链接处理
     */
    private static void setupClickableLinks(TextView textView) {
        if (textView == null) return;
        
        // ★ 修复：启用文本选择，允许长按复制
        textView.setTextIsSelectable(true);
        textView.setFocusable(true);
        textView.setClickable(true);
        textView.setLongClickable(true);
        textView.setHighlightColor(0x332196F3);
        
        // 获取当前文本（可能已经是 Spannable）
        CharSequence value = textView.getText();
        if (!(value instanceof Spannable)) {
            // 如果不是 Spannable，创建一个并设置回 TextView
            // ★ 修复：使用 SpannableStringBuilder 而非 SpannableString
            // SpannableString 是不可变的，会导致 Glide 异步加载表情图片后
            // targetView.setText(targetView.getText()) 无法正确更新 ImageSpan
            value = new SpannableStringBuilder(value == null ? "" : value);
            textView.setText(value, TextView.BufferType.SPANNABLE);
        }
        
        // 强制重新获取 Spannable（确保是最新的）
        Spannable spannable = (Spannable) textView.getText();
        
        // ★ 修复：更精确的URL正则，避免匹配到URL后面的中文/标点
        // 正确结构：域名部分一次匹配（含点号），路径允许中划线/斜杠/query等常见URL字符
        // 修复点1：Android 的 \w 默认匹配 Unicode 字母（含中文），导致 (?<![\w]) 在中文字符后阻止 URL 匹配。
        //          改用 [a-zA-Z0-9_] 显式 ASCII 字符集。
        // 修复点2：原正则域名部分使用 [\w\-.]++ 后又重复要求 (?:\.[\w\-]++)+，
        // 导致含有多个点的域名（如 bbs.binmt.cc）整体匹配失败，链接无法渲染。
        Pattern urlPattern = Pattern.compile(
            "(?<![a-zA-Z0-9_])" +                          // 前面不是ASCII单词字符（Android \w含中文，改用显式ASCII）
            "(?:" +
                "https?://" +                               // http:// 或 https://
                "[a-zA-Z0-9.\\-]+" +                       // 域名（ASCII字母数字、中划线、点）
                "(?::\\d+)?" +                              // 可选端口 :8080
                "(?:/[a-zA-Z0-9\\-._/?=&%#@+~:]*)" +        // 可选路径
                "|" +
                "https?://" +                               // http:// 或 https://（无路径时）
                "[a-zA-Z0-9.\\-]+" +
                "(?::\\d+)?" +
                "|" +
                "www\\." +                                  // www. 开头（无协议时）
                "[a-zA-Z0-9.\\-]+" +
                "(?::\\d+)?" +
                "(?:/[a-zA-Z0-9\\-._/?=&%#@+~:]*)" +
                "|" +
                "www\\." +                                  // www. 开头（无路径时）
                "[a-zA-Z0-9.\\-]+" +
                "(?::\\d+)?" +
            ")" +
            "(?![a-zA-Z0-9_/])" +                           // 后面不是ASCII单词字符或斜杠
            "(?<![,.;:!?)\\]>'" + "\u201d" + "\u201c])",      // 后面不是标点符号、引号、括号
            Pattern.CASE_INSENSITIVE
        );
        FixNestedScrollLinkMovementMethod.matcherLinkify(
            spannable,
            urlPattern,
            url -> normalizeLinkUrl(url),  // URL处理器：规范化URL
            url -> {
                if (isImageUrl(url)) {
                    Context c = textView.getContext();
                    try {
                        Intent intent = new Intent(c, ImagePreviewActivity.class);
                        intent.putExtra("image_url", url);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        c.startActivity(intent);
                    } catch (Exception ignored) {}
                } else {
                    openContentLink(url, textView.getContext());
                }
            }  // 点击处理器：打开链接或图片预览
        );
        
        // Html.fromHtml() 产生 URLSpan；统一替换为应用自己的 ClickableSpan
        // ★ 修复：当 <a> 标签文本包含非 URL 前缀（如"成品链接：https://..."）时，
        //   URLSpan 覆盖整个文本，直接替换会导致前缀也变成链接。
        //   解决：在 URLSpan 范围内用正则定位真实 URL，只对 URL 部分添加 ClickableSpan。
        URLSpan[] urlSpans = spannable.getSpans(0, spannable.length(), URLSpan.class);
        for (URLSpan oldSpan : urlSpans) {
            final String targetUrl = normalizeLinkUrl(oldSpan.getURL());
            int start = spannable.getSpanStart(oldSpan);
            int end = spannable.getSpanEnd(oldSpan);
            int flags = spannable.getSpanFlags(oldSpan);
            spannable.removeSpan(oldSpan);
            if (start >= 0 && end > start && !TextUtils.isEmpty(targetUrl)) {
                // 在 URLSpan 文本范围内查找真实 URL 的位置
                String spanText = spannable.subSequence(start, end).toString();
                java.util.regex.Matcher urlMatcher = urlPattern.matcher(spanText);
                if (urlMatcher.find()) {
                    int urlStartInSpan = urlMatcher.start();
                    int urlEndInSpan = urlMatcher.end();
                    spannable.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(View widget) {
                            if (isImageUrl(targetUrl)) {
                                Context c = widget.getContext();
                                try {
                                    Intent intent = new Intent(c, ImagePreviewActivity.class);
                                    intent.putExtra("image_url", targetUrl);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    c.startActivity(intent);
                                } catch (Exception ignored) {}
                            } else {
                                openContentLink(targetUrl, widget.getContext());
                            }
                        }
                    }, start + urlStartInSpan, start + urlEndInSpan, flags);
                } else {
                    spannable.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(View widget) {
                            if (isImageUrl(targetUrl)) {
                                Context c = widget.getContext();
                                try {
                                    Intent intent = new Intent(c, ImagePreviewActivity.class);
                                    intent.putExtra("image_url", targetUrl);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    c.startActivity(intent);
                                } catch (Exception ignored) {}
                            } else {
                                openContentLink(targetUrl, widget.getContext());
                            }
                        }
                    }, start, end, flags);
                }
            }
        }
        
        // ★ 使用自定义 LinkMovementMethod 解决嵌套滚动兼容性问题
        textView.setMovementMethod(new FixNestedScrollLinkMovementMethod());
        textView.setAutoLinkMask(0);
        // ★ 启动内联 GIF 动画（setText 已完成，callback 已设置）
        startGifAnimationsInTextView(textView);
    }
    
    /**
     * 规范化链接URL：补全相对路径
     */
    private static String normalizeLinkUrl(String url) {
        if (TextUtils.isEmpty(url)) return url;
        if (url.startsWith("//")) return "https:" + url;
        if (url.startsWith("/")) return HttpClient.BASE_URL + url.substring(1);
        if (url.startsWith("./")) return HttpClient.BASE_URL + url.substring(2);
        if (url.startsWith("http://") || url.startsWith("https://")) return url;
        if (url.startsWith("www.")) return "http://" + url;
        return HttpClient.BASE_URL + url;
    }
    
    /**
     * 打开链接：论坛内部链接应用内跳转，外部链接用浏览器打开。
     */
    /**
     * 判断 URL 是否为图片/附件链接，用于判断是否打开 App 内图片预览而非浏览器
     */
    private static boolean isImageUrl(String url) {
        if (TextUtils.isEmpty(url)) return false;
        String lower = url.toLowerCase();
        // 图片文件扩展名
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png")
                || lower.endsWith(".gif") || lower.endsWith(".webp") || lower.endsWith(".bmp")) {
            return true;
        }
        // 论坛附件/图片 URL
        if (lower.contains("mod=image") || lower.contains("mod=attachment")) {
            return true;
        }
        return false;
    }

    private static void openContentLink(String url, Context context) {
        if (TextUtils.isEmpty(url) || context == null) return;
        try {
            // 1. 用户主页: home.php?mod=space&uid=xxx 或 space-uid-xxx.html
            java.util.regex.Matcher uidMatcher = java.util.regex.Pattern.compile(
                "(?:mod=space&uid=|space-uid-)(\\d+)").matcher(url);
            if (uidMatcher.find()) {
                String uid = uidMatcher.group(1);
                Intent intent = new Intent(context, com.forum.MT.ui.space.UserProfileActivity.class);
                intent.putExtra("uid", uid);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return;
            }
            // 2. 帖子链接: thread-xxx-1-1.html 或 forum.php?mod=viewthread&tid=xxx
            java.util.regex.Matcher tidMatcher = java.util.regex.Pattern.compile(
                "(?:thread-(\\d+)|tid=(\\d+))").matcher(url);
            if (tidMatcher.find()) {
                String tid = tidMatcher.group(1) != null ? tidMatcher.group(1) : tidMatcher.group(2);
                Intent intent = new Intent(context, com.forum.MT.ui.detail.ThreadDetailActivity.class);
                intent.putExtra("tid", tid);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return;
            }
            // 3. 其他链接：用浏览器打开
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(browserIntent);
        } catch (Exception ignored) {
            // 当前设备没有可用浏览器时不阻断帖子内容展示
        }
    }

    /**
     * 为评论内容中的"本帖最后由…编辑"文字应用自定义颜色。
     * 在 setupClickableLinks 之后调用。
     */
    private static void applyEditTimeColor(TextView textView) {
        if (textView == null) return;
        int editTimeColor = com.forum.MT.ui.widget.HomeBarColorManager.getEditTimeColor();
        try {
            CharSequence text = textView.getText();
            if (!(text instanceof Spannable)) return;
            Spannable spannable = (Spannable) text;
            String fullText = spannable.toString();
            int startIdx = fullText.indexOf("本帖最后由");
            if (startIdx < 0) return;
            int endIdx = fullText.indexOf("编辑", startIdx);
            if (endIdx < 0) return;
            endIdx += "编辑".length();
            // ★ 应用"显示大小-编辑时间"字号（默认 0 = 跟随容器不覆盖）
            float editTimeSize = com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(
                    textView.getContext(),
                    com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_EDIT_TIME);
            if (editTimeSize > 0) {
                android.text.style.AbsoluteSizeSpan[] sizeSpans = spannable.getSpans(
                        startIdx, endIdx, android.text.style.AbsoluteSizeSpan.class);
                for (android.text.style.AbsoluteSizeSpan old : sizeSpans) {
                    spannable.removeSpan(old);
                }
                spannable.setSpan(new android.text.style.AbsoluteSizeSpan(
                                (int) (editTimeSize * textView.getResources().getDisplayMetrics().scaledDensity)),
                        startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (editTimeColor != 0) {
                android.text.style.ForegroundColorSpan[] oldSpans = spannable.getSpans(
                        startIdx, endIdx, android.text.style.ForegroundColorSpan.class);
                for (android.text.style.ForegroundColorSpan old : oldSpans) {
                    spannable.removeSpan(old);
                }
                spannable.setSpan(new android.text.style.ForegroundColorSpan(editTimeColor),
                        startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        } catch (Exception ignored) {}
    }

    /**
     * 为评论中的图片 ImageView 添加点击预览监听
     */
    private static void setImageClick(Context context, ImageView imageView, String imgUrl) {
        imageView.setOnClickListener(v -> {
            if (context != null && !android.text.TextUtils.isEmpty(imgUrl)) {
                Intent intent = new Intent(context, ImagePreviewActivity.class);
                intent.putExtra("image_url", imgUrl);
                context.startActivity(intent);
            }
        });
    }

    /**
     * 将 HTML <table> 转换为内联表格占位符。
     * <p>
     * 提取每个 <table> 的行列数据到 outTables（TableData），
     * 并替换为 &lt;img src="table://N"&gt; 占位符，
     * 由 ImageGetter 渲染为带边框的表格位图，内联显示在正文原位置。
     */
    private static String convertHtmlTables(String html, List<TableData> outTables) {
        if (TextUtils.isEmpty(html)) return html;
        // ★ 纯正则匹配 <table> 块，不依赖 Jsoup 重新序列化，保证不改变元素顺序
        String result = html;
        // 匹配非嵌套的 <table>...</table> 块
        java.util.regex.Pattern tablePattern = java.util.regex.Pattern.compile(
                "<table\\b[^>]*>.*?</table>",
                java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.DOTALL);
        java.util.regex.Matcher matcher = tablePattern.matcher(result);
        StringBuffer sb = new StringBuffer();
        int index = 0;
        while (matcher.find()) {
            String tableOuter = matcher.group();
            // 用 Jsoup 解析该表格块提取行数据
            try {
                org.jsoup.nodes.Document tdDoc = org.jsoup.Jsoup.parseBodyFragment(tableOuter);
                org.jsoup.select.Elements trs = tdDoc.select("tr");
                List<List<String>> rows = new ArrayList<>();
                for (org.jsoup.nodes.Element tr : trs) {
                    List<String> cells = new ArrayList<>();
                    org.jsoup.select.Elements tds = tr.select("th, td");
                    for (org.jsoup.nodes.Element td : tds) {
                        cells.add(td.text().trim());
                    }
                    if (!cells.isEmpty()) {
                        rows.add(cells);
                    }
                }
                if (!rows.isEmpty() && outTables != null) {
                    outTables.add(new TableData(rows));
                }
                String placeholder = rows.isEmpty() ? "" : "<img src=\"table://" + index + "\" />";
                matcher.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(placeholder));
                if (!rows.isEmpty()) index++;
            } catch (Exception e) {
                // 表格解析失败，保留原样
                matcher.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(tableOuter));
            }
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    /** 表格数据：行列表 */
    private static class TableData {
        final List<List<String>> rows;

        TableData(List<List<String>> rows) {
            this.rows = rows;
        }

        List<List<String>> getRows() {
            return rows;
        }
    }


    /**
     * 从 HTML 内容中提取所有 img 标签的 src URL，并返回去掉 img 标签后的纯 HTML
     * ★ 重写：使用 Jsoup 替代正则，避免因标签不标准/未闭合导致 Html.fromHtml() 截断
     */
    /** 从 <img> 标签中按优先级提取真实图片地址（仿 sqapp：comiis_loadimages 优先，file 靠后） */
    private static String extractImageSource(String tag) {
        String[] attrs = {"comiis_loadimages", "zoomfile", "data-zoomfile", "data-original",
                "data-src", "data-file", "data-lazy-src", "file", "src"};
        for (String attr : attrs) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                    "\\b" + java.util.regex.Pattern.quote(attr)
                            + "\\s*=\\s*['\"]([^'\"]+)['\"]",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(tag);
            if (m.find() && !TextUtils.isEmpty(m.group(1))
                    && !m.group(1).contains("none.png")) {
                return m.group(1);
            }
        }
        return "";
    }

    /** 替换 <img> 标签中某个属性的值（不存在则插入），确保 ImageGetter 能拿到真实地址 */
    private static String replaceImageAttribute(String tag, String attr, String value) {
        String replacement = attr + "=\"" + value + "\"";
        String pattern = "(?i)\\b" + java.util.regex.Pattern.quote(attr)
                + "\\s*=\\s*['\"][^'\"]*['\"]";
        String replaced = tag.replaceFirst(pattern, java.util.regex.Matcher.quoteReplacement(replacement));
        return replaced.equals(tag) ? tag.replaceFirst("<img", "<img " + replacement) : replaced;
    }

    /**
     * 从 HTML 中提取图片；表情和小图保留在原文位置，大图移到独立图片容器。
     * ★ 完全对照开源 sqapp 的正则方案，属性优先级 comiis_loadimages 优先、file 靠后。
     */
    private static String extractImagesFromHtml(String html, List<String> outImageUrls) {
        if (TextUtils.isEmpty(html)) return "";
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile(
                "<img\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String originalTag = matcher.group();
            String rawUrl = extractImageSource(originalTag);
            String fullUrl = normalizeImageUrl(rawUrl);
            if (fullUrl != null) {
                // ★ 统一为 & 形式（Html.fromHtml 会把 &amp; 解码成 &）
                fullUrl = fullUrl.replace("&amp;", "&");
            }
            String lowerUrl = fullUrl == null ? "" : fullUrl.toLowerCase(java.util.Locale.ROOT);
            // 判断是否为内联小图/表情 → 保留在文本中（只补全 src）
            boolean inlineImage = originalTag.toLowerCase(java.util.Locale.ROOT).contains("smilieid")
                    || lowerUrl.contains("/static/image/")
                    || lowerUrl.contains("smiley")
                    || lowerUrl.contains("emoticon")
                    || lowerUrl.contains("face")
                    || lowerUrl.contains("stamp")
                    || lowerUrl.contains("magic")
                    || lowerUrl.contains("mini")
                    || lowerUrl.contains("icon");

            // ★ 优先检查 data-mt-inline 标记（[attachimg] 转换的图片），不依赖 URL 内容
            boolean mtInline = originalTag.toLowerCase(java.util.Locale.ROOT).contains("data-mt-inline");

            // ★ 判断是否为真实图片文件 URL（.jpg/.png/.gif/.webp 等结尾），
            // 这类图片应保留在原文内联位置，不移到最底部的图片列表
            boolean realImageFile = !inlineImage
                    && (lowerUrl.matches(".*\\.(jpe?g|png|gif|webp|bmp)(\\?.*)?$")
                    || lowerUrl.contains("data/attachment/")
                    || lowerUrl.contains("/forum/"));
            // ★ 网页端插入的图片（非 mod=image、非真实图片文件）→ 从正文移除到底部列表
            boolean webUploaded = !mtInline && !realImageFile;

            if (inlineImage && !TextUtils.isEmpty(fullUrl)) {
                // 无论原地址在 src、file 还是懒加载属性，都统一写入 src，
                // 让 Html.ImageGetter 一定拿到真实地址，而不是 none/loading 占位图。
                String keptTag = replaceImageAttribute(originalTag, "src", fullUrl);
                matcher.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(keptTag));
            } else if (mtInline && !TextUtils.isEmpty(fullUrl)
                    && (fullUrl.startsWith("http://") || fullUrl.startsWith("https://"))) {
                // ★ [attachimg] 转换的图片（带 data-mt-inline 标记）→ 保留在原文内联位置
                // ★ fullUrl 已归一化为 & 形式；写入 HTML 属性时必须用 &amp;，否则 Html 解析出错
                String keptTag = replaceImageAttribute(originalTag, "src", fullUrl.replace("&", "&amp;"));
                keptTag = keptTag.replaceAll("(?i)\\s+(?:file|zoomfile|comiis_loadimages)=(\"[^\"]*\"|'[^']*')", "");
                String hrefEscaped = fullUrl.replace("&", "&amp;");
                keptTag = "<a href=\"" + hrefEscaped + "\">" + keptTag + "</a>";
                appendBlockImage(sb, matcher, html, keptTag);
            } else if (!TextUtils.isEmpty(fullUrl)
                    && (fullUrl.startsWith("http://") || fullUrl.startsWith("https://"))) {
                if (lowerUrl.contains("mod=image") || realImageFile) {
                    // ★ 附件图 / 真实图片文件 → 保留在原文内联位置，包 <a> 便于点击放大
                    String keptTag = replaceImageAttribute(originalTag, "src", fullUrl.replace("&", "&amp;"));
                    keptTag = keptTag.replaceAll("(?i)\\s+(?:file|zoomfile|comiis_loadimages)=(\"[^\"]*\"|'[^']*')", "");
                    String hrefEscaped = fullUrl.replace("&", "&amp;");
                    keptTag = "<a href=\"" + hrefEscaped + "\">" + keptTag + "</a>";
                    appendBlockImage(sb, matcher, html, keptTag);
                } else if (webUploaded) {
                    // ★ 网页端插入的图片（飞书网盘、外部图床等无扩展名URL）→ 保留在原文内联位置
                    //   不再移到底部图片列表，避免图片脱离上下文
                    String keptTag = replaceImageAttribute(originalTag, "src", fullUrl.replace("&", "&amp;"));
                    keptTag = keptTag.replaceAll("(?i)\\s+(?:file|zoomfile|comiis_loadimages)=(\"[^\"]*\"|'[^']*')", "");
                    String hrefEscaped = fullUrl.replace("&", "&amp;");
                    keptTag = "<a href=\"" + hrefEscaped + "\">" + keptTag + "</a>";
                    appendBlockImage(sb, matcher, html, keptTag);
                } else {
                    // 兜底：保留在原文（避免丢失）
                    String keptTag = replaceImageAttribute(originalTag, "src", fullUrl.replace("&", "&amp;"));
                    matcher.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(keptTag));
                }
            } else {
                // 没有可用地址的图片不能继续留在 HTML 中，否则可能显示为乱码。
                matcher.appendReplacement(sb, "");
            }
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    /**
     * ★ 提取网页端插入的图片（<ul class="comiis_img_one"> 或 <ul class="comiis_img">，
     * 位于回复内容末尾），将其中所有图片 URL 收集到 outImageUrls，并从正文 HTML 中移除整个 ul。
     * <p>
     * 这样网页端图片会显示在内容最底部的图片列表（llReplyImages，可点击预览），
     * 而 [attachimg] 插入的图片（正文中的 <img>）保留在原文位置内联。区分依据是 HTML 结构而非 URL。
     */
    private static String extractWebUploadedImages(String html, List<String> outImageUrls) {
        if (TextUtils.isEmpty(html)) return html;
        // ★ 只用正则做块级提取，不重新序列化 HTML，绝不改变其余内容的顺序
        // 网页端插入的图片结构：<ul class="comiis_img_one"> <li><img src="...">...</li> </ul>
        // ★ 注意：ul.comiis_img_list 是附件图片列表（如截图证据），应保留在正文中内联显示，
        //   不能移除到底部。只提取 comiis_img_one（网页端插入的图片）。
        try {
            java.util.regex.Pattern ulPattern = java.util.regex.Pattern.compile(
                    "<ul\\b[^>]*class\\s*=\\s*\"[^\"]*comiis_img_one[^\"]*\"[^>]*>.*?</ul>",
                    java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.DOTALL);
            java.util.regex.Matcher ulMatcher = ulPattern.matcher(html);
            StringBuffer sb = new StringBuffer();
            boolean found = false;
            while (ulMatcher.find()) {
                found = true;
                String ulBlock = ulMatcher.group();
                // 收集 ul 内所有可用的图片 URL
                java.util.regex.Matcher imgMatcher = java.util.regex.Pattern.compile(
                        "<img\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(ulBlock);
                while (imgMatcher.find()) {
                    String rawUrl = extractImageSource(imgMatcher.group());
                    String fullUrl = normalizeImageUrl(rawUrl);
                    // ★ 修复：HTML 中 &amp; 需解码为 &，否则 Glide 用字面 &amp; 请求，
                    //   服务器参数解析失败，返回 1x1 透明 GIF（43字节），图片显示为空白
                    if (fullUrl != null) {
                        fullUrl = fullUrl.replace("&amp;", "&");
                    }
                    if (!TextUtils.isEmpty(fullUrl)
                            && (fullUrl.startsWith("http://") || fullUrl.startsWith("https://"))
                            && outImageUrls != null && !outImageUrls.contains(fullUrl)) {
                        outImageUrls.add(fullUrl);
                    }
                }
                // 整块移除 ul（网页端图片 → 底部列表）
                ulMatcher.appendReplacement(sb, "");
            }
            if (!found) return html;
            ulMatcher.appendTail(sb);
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_REPLY_IMG", "extractWebUploadedImages removed " + (found ? "ul" : "none"));
            return sb.toString();
        } catch (Exception e) {
            return html;
        }
    }

    /**
     * 提取代码块（[code]、<pre>、<code>、div.blockcode、div.comiis_blockcode）为 <!--CODE_CARD_N--> 占位符。
     */
    private static String extractCodeBlocks(String html, java.util.List<CodeCardRef> outCodes) {
        if (TextUtils.isEmpty(html)) return html;
        // 1) 将 [code] BBCode 转为 <div data-mt-code="true">
        String result = html;
        result = result.replaceAll("(?is)\\[code(?:=[^\\]]*)?\\](.*?)\\[/code\\]",
                "<div data-mt-code=\"true\">$1</div>");
        // 2) 扫描代码块起始标签，用深度匹配找到正确的外层闭合标签
        // 支持：div.blockcode, div.comiis_blockcode, div[data-mt-code=true],
        //       pre.blockcode, pre.comiis_blockcode
        // ★ 不使用 .*?</div> 非贪婪匹配——内层还有 div 时会提前截断，
        //   导致外层闭合标签残留在正文，渲染出多余空白段。
        try {
            java.util.regex.Pattern startPattern = java.util.regex.Pattern.compile(
                    "<(div|pre)\\b[^>]*(?:blockcode|comiis_blockcode|data-mt-code\\s*=\\s*\"?true\"?)[^>]*>",
                    java.util.regex.Pattern.CASE_INSENSITIVE);
            java.util.regex.Matcher startMatcher = startPattern.matcher(result);
            StringBuffer sb = new StringBuffer();
            int index = 0;
            int lastEnd = 0;
            while (startMatcher.find()) {
                String startTag = startMatcher.group();
                String tagName = startMatcher.group(1).toLowerCase(java.util.Locale.ROOT);
                int blockStart = startMatcher.start();
                int blockEnd = findMatchingClose(result, startMatcher.end(), tagName);
                if (blockEnd < 0) {
                    // 找不到闭合标签，跳过（不替换，保持原样）
                    continue;
                }
                String codeBlockOuter = result.substring(blockStart, blockEnd);
                // 提取代码文本内容
                String rawHtml = "";
                // 尝试提取 <code> 标签内的内容
                java.util.regex.Matcher codeTagMatcher = java.util.regex.Pattern.compile(
                        "<code\\b[^>]*>(.*?)</code>",
                        java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.DOTALL)
                        .matcher(codeBlockOuter);
                if (codeTagMatcher.find()) {
                    rawHtml = codeTagMatcher.group(1);
                } else {
                    // 没有 <code> 标签，取整个块内容（去掉外层标签）
                    rawHtml = codeBlockOuter.replaceAll("(?si)^<[^>]+>(.*)</[^>]+>$", "$1");
                }
                if (outCodes != null) {
                    outCodes.add(new CodeCardRef(rawHtml));
                }
                // 追加占位符
                sb.append(result, lastEnd, blockStart);
                sb.append("<!--CODE_CARD_").append(index).append("-->");
                index++;
                lastEnd = blockEnd;
            }
            sb.append(result, lastEnd, result.length());
            result = sb.toString();
        } catch (Exception e) {
            return html;
        }
        return result;
    }

    /**
     * 从 start 位置开始，找到与开标签同名的匹配闭合标签的结束位置（end exclusive）。
     * 支持 div 嵌套深度计数；遇到 <pre> 直接找最近的 </pre>（pre 内不会有嵌套 pre）。
     * 找不到返回 -1。
     * ★ 每次循环都从当前 pos 重新找"最近的"开/闭标签，比较先后顺序推进，
     *   不能各自维护独立 Matcher 连续 find()（会提前消耗闭合标签，导致匹配失败）。
     */
    private static int findMatchingClose(String html, int start, String tagName) {
        if (tagName.equals("pre")) {
            int idx = html.indexOf("</pre>", start);
            return idx < 0 ? -1 : idx + "</pre>".length();
        }
        // div：深度计数
        int depth = 1;
        int pos = start;
        java.util.regex.Pattern openP = java.util.regex.Pattern.compile(
                "<div\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Pattern closeP = java.util.regex.Pattern.compile(
                "</div\\s*>", java.util.regex.Pattern.CASE_INSENSITIVE);
        while (true) {
            java.util.regex.Matcher om = openP.matcher(html);
            java.util.regex.Matcher cm = closeP.matcher(html);
            om.region(pos, html.length());
            cm.region(pos, html.length());
            boolean hasOpen = om.find();
            boolean hasClose = cm.find();
            if (!hasClose) return -1; // 缺闭合
            if (!hasOpen || cm.start() < om.start()) {
                // 先遇到闭合 → 深度减一
                depth--;
                if (depth == 0) {
                    return cm.end();
                }
                pos = cm.end();
            } else {
                // 先遇到开标签 → 深度加一
                depth++;
                pos = om.end();
            }
        }
    }


    /**
     * 补全图片URL：处理 //、/ 和 ./ 开头的相对路径
     */
    private static String normalizeImageUrl(String url) {
        if (TextUtils.isEmpty(url)) return null;
        if (url.startsWith("//")) {
            return "https:" + url;
        } else if (url.startsWith("/")) {
            return HttpClient.BASE_URL + url.substring(1);
        } else if (url.startsWith("./")) {
            return HttpClient.BASE_URL + url.substring(2);
        } else if (url.startsWith("http://") || url.startsWith("https://")) {
            return url;
        }
        // 其他情况（不含协议的相对路径如 "data/attachment/..."）
        return HttpClient.BASE_URL + url;
    }

    /**
     * 附件 CDN 有时会校验 Referer / User-Agent；普通 Glide 请求缺少这些请求头时会被
     * 返回占位或拒绝。使用与论坛页面一致的请求头和登录 Cookie 加载回复图片。
     */
    public static GlideUrl buildForumImageRequest(String imageUrl) {
        LazyHeaders.Builder headers = new LazyHeaders.Builder()
                .addHeader("User-Agent", HttpClient.USER_AGENT)
                .addHeader("Referer", HttpClient.BASE_URL)
                .addHeader("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8");
        String cookie = HttpClient.getInstance().getCookieHeader();
        if (!TextUtils.isEmpty(cookie)) {
            headers.addHeader("Cookie", cookie);
        }
        return new GlideUrl(imageUrl, headers.build());
    }

    /**
     * 从 HTML 内容中提取图片 URL 列表，并用 Glide 加载到 llReplyImages 布局中
     */
    private static void loadReplyImages(Context context, String html, LinearLayout container) {
        List<String> urls = new ArrayList<>();
        extractImagesFromHtml(html, urls);
        loadReplyImages(context, urls, container);
    }

    /**
     * ★ 图片原始尺寸缓存：URL → {width, height}。
     *
     * <p>用于消除评论图片的行高跳变：RecyclerView 向上滚动时锚点在下方，
     * item 在 bind 之后才长高会把已可见内容整体顶走，视觉上就是"突然跳一下"。
     * 记录原始尺寸后，再次 bind 时可直接算出最终显示尺寸并预设到 LayoutParams，
     * 使行高一次到位，不再经历"占位尺寸 → 真实尺寸"的二次布局。
     */
    static final java.util.concurrent.ConcurrentHashMap<String, int[]> sImageSizeCache =
            new java.util.concurrent.ConcurrentHashMap<>();

    /**
     * 按原始尺寸计算图片在评论区的最终显示尺寸。
     *
     * <p>需与 ImageView 的约束保持一致：宽度不超过 maxImgWidth，高度不超过
     * maxImgWidth * 1.2，等比缩放（等价于 adjustViewBounds + FIT_CENTER 的测量结果）。
     *
     * @return {displayWidth, displayHeight}
     */
    private static int[] computeImageDisplaySize(int srcW, int srcH, int maxImgWidth) {
        int maxH = (int) (maxImgWidth * 1.2f);
        if (srcW <= 0 || srcH <= 0) {
            return new int[]{maxImgWidth, (int) (maxImgWidth * 0.6f)};
        }
        float scale = Math.min((float) maxImgWidth / srcW, (float) maxH / srcH);
        // 小图不放大，保持原始像素尺寸
        if (scale > 1f) scale = 1f;
        int w = Math.max(1, Math.round(srcW * scale));
        int h = Math.max(1, Math.round(srcH * scale));
        return new int[]{w, h};
    }

    /**
     * ★ 将给定的图片 URL 列表加载到 llReplyImages 布局（网页端插入的图片显示在最底部）
     */
    private static void loadReplyImages(Context context, List<String> urls, LinearLayout container) {
        if (urls == null || urls.isEmpty()) {
            container.removeAllViews();
            container.setVisibility(View.GONE);
            return;
        }
        container.removeAllViews();
        container.setVisibility(View.VISIBLE);
        int maxImgWidth = getMaxImageWidth(context);
        for (String imgUrl : urls) {
            ImageView imageView = new ImageView(context);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setBackgroundColor(0xFFF0F0F0);
            // ★ 添加点击预览
            imageView.setClickable(true);
            imageView.setFocusable(true);
            setImageClick(context, imageView, imgUrl);

            // ★ 关键：尺寸已知时预设精确宽高，使行高一次到位（消除上滑跳变）
            int[] known = sImageSizeCache.get(imgUrl);
            LinearLayout.LayoutParams lp;
            if (known != null) {
                int[] disp = computeImageDisplaySize(known[0], known[1], maxImgWidth);
                lp = new LinearLayout.LayoutParams(disp[0], disp[1]);
                lp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
                // 尺寸已固定，无需 ImageView 自行按 intrinsic 比例测量
                imageView.setAdjustViewBounds(false);
            } else {
                // 首次加载：尺寸未知，用默认比例占位，避免 ColorDrawable(-1/-1) 被当成 1:1 正方形
                int[] disp = computeImageDisplaySize(0, 0, maxImgWidth);
                lp = new LinearLayout.LayoutParams(disp[0], disp[1]);
                lp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
                imageView.setAdjustViewBounds(false);
            }
            imageView.setLayoutParams(lp);

            final ImageView targetIv = imageView;
            final String targetUrl = imgUrl;
            final boolean sizeWasKnown = known != null;
            Glide.with(context)
                    .load(buildForumImageRequest(imgUrl))
                    .placeholder(new ColorDrawable(0xFFF0F0F0))
                    .error(createFailedImageDrawable(context))
                    .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                        @Override
                        public boolean onLoadFailed(@androidx.annotation.Nullable com.bumptech.glide.load.engine.GlideException e,
                                                    Object model,
                                                    com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                                                    boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(android.graphics.drawable.Drawable resource,
                                                       Object model,
                                                       com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                                                       com.bumptech.glide.load.DataSource dataSource,
                                                       boolean isFirstResource) {
                            if (resource == null) return false;
                            int rw = resource.getIntrinsicWidth();
                            int rh = resource.getIntrinsicHeight();
                            if (rw <= 0 || rh <= 0) return false;
                            sImageSizeCache.putIfAbsent(targetUrl, new int[]{rw, rh});
                            // 首次加载时尺寸未知，按真实比例校正一次（后续 bind 会直接命中缓存）
                            if (!sizeWasKnown) {
                                int[] disp = computeImageDisplaySize(rw, rh, getMaxImageWidth(targetIv.getContext()));
                                android.view.ViewGroup.LayoutParams cur = targetIv.getLayoutParams();
                                if (cur != null && (cur.width != disp[0] || cur.height != disp[1])) {
                                    cur.width = disp[0];
                                    cur.height = disp[1];
                                    targetIv.setLayoutParams(cur);
                                }
                            }
                            return false;
                        }
                    })
                    .into(imageView);
            container.addView(imageView);
        }
    }

    /**
     * 获取评论图片的最大显示宽度（屏幕宽度的80%，最多不超过360dp）
     */
    private static int getMaxImageWidth(Context context) {
        int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
        int maxDp = 360;
        int maxPx = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, maxDp, context.getResources().getDisplayMetrics());
        int width80 = (int)(screenWidth * 0.8f);
        return Math.min(width80, maxPx);
    }

    // ==================== 内联图片渲染（表情等） ====================

    /** 表情图缓存：URL → Bitmap，避免重复下载 */
    static final java.util.concurrent.ConcurrentHashMap<String, android.graphics.drawable.Drawable> sSmileyCache =
            new java.util.concurrent.ConcurrentHashMap<>();

    // ★ 内联大图缓存：URL → 缩放到内容宽度的 Drawable，由 ImageGetter 从原文读取
    static final java.util.concurrent.ConcurrentHashMap<String, android.graphics.drawable.Drawable> sReplyImageCache =
            new java.util.concurrent.ConcurrentHashMap<>();

    // ★ GIF 字节缓存：URL → 原始 GIF 字节数据。
    // 不缓存 GifDrawable（其 ConstantState.newDrawable() 副本共享 GifFrameLoader 导致串帧），
    // 而是缓存原始字节，每次渲染时用 Glide 从字节解码出完全独立的 GifDrawable（拥有独立的 GifFrameLoader）。
    static final java.util.concurrent.ConcurrentHashMap<String, byte[]> sGifBytesCache =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** ★ 标记评论中动态创建的视图（extra 文本/表格滚动视图/代码卡片）。刷新清理时按此 tag 全量删除。 */
    private static final Object DYNAMIC_VIEW_TAG = new Object();

    // ==================== 回复预处理缓存（解决加载全部 ANR） ====================

    /**
     * 预处理结果：在后台线程中完成所有 Jsoup / 正则转换，主线程直接渲染。
     */
    private static class ReplyPreProcessResult {
        final String cleanHtml;               // 预处理后的 HTML（含图片占位符）
        final List<String> imageUrls;         // 提取的图片 URL
        final List<CodeCardRef> codeCards;    // 代码卡片
        final List<TableData> tables;         // 表格数据
        /**
         * 生成这份结果时所用源 HTML 的指纹。
         *
         * <p>缓存键是 pid，而编辑评论不会改变 pid，只会改变正文。若不校验来源内容，
         * 编辑后即使重新拉取了服务端数据也会命中旧缓存，界面永远停在编辑前的正文。
         */
        final String sourceFingerprint;

        ReplyPreProcessResult(String cleanHtml, List<String> imageUrls,
                              List<CodeCardRef> codeCards, List<TableData> tables,
                              String sourceFingerprint) {
            this.cleanHtml = cleanHtml;
            this.imageUrls = imageUrls;
            this.codeCards = codeCards;
            this.tables = tables;
            this.sourceFingerprint = sourceFingerprint;
        }
    }

    /**
     * 计算源 HTML 指纹。用长度 + hashCode 组合，碰撞概率足够低，
     * 且 String.hashCode 有内部缓存，反复调用几乎零成本——这点很重要，
     * 因为 bind() 每次绑定都会算一次。
     */
    private static String contentFingerprint(String html) {
        if (html == null) return "0#0";
        return html.length() + "#" + html.hashCode();
    }

    /** 预处理缓存：pid → 预处理结果 */
    static final java.util.concurrent.ConcurrentHashMap<String, ReplyPreProcessResult> sPreProcessCache =
            new java.util.concurrent.ConcurrentHashMap<>();

    /**
     * ★ 在后台线程中对回复 HTML 执行步骤1-7预处理，结果缓存到 sPreProcessCache。
     * 这是纯字符串处理，不涉及任何 View 操作，可安全在后台线程执行。
     */
    static void preProcessReply(ReplyItem item) {
        if (item == null) return;
        String pid = item.getPid();
        if (pid == null) return;
        String htmlContent = item.getContentHtml();
        if (TextUtils.isEmpty(htmlContent)) return;
        // ★ 移除附件块(div.comiis_attach)，避免正文残留"上传/下载次数"文本
        // 附件信息由 bindData 单独提取并渲染为灰色附件卡片
        if (htmlContent.contains("comiis_attach")) {
            try {
                org.jsoup.nodes.Document doc = org.jsoup.Jsoup.parseBodyFragment(htmlContent);
                doc.outputSettings().prettyPrint(false);
                doc.select("div.comiis_attach").remove();
                htmlContent = doc.body().html();
            } catch (Exception ignored) {}
        }
        // 只有指纹一致才算命中；正文变了（例如用户编辑过该评论）必须重新预处理。
        String fingerprint = contentFingerprint(htmlContent);
        ReplyPreProcessResult existing = sPreProcessCache.get(pid);
        if (existing != null && fingerprint.equals(existing.sourceFingerprint)) return;

        List<CodeCardRef> replyCodeCards = new ArrayList<>();
        String processedHtml = extractCodeBlocks(htmlContent, replyCodeCards);
        processedHtml = convertTextLinkBBCode(processedHtml);
        processedHtml = convertAttachBBCodeToImg(processedHtml);
        processedHtml = fixTruncatedLinkTexts(processedHtml);
        List<String> replyImageUrls = new ArrayList<>();
        processedHtml = extractWebUploadedImages(processedHtml, replyImageUrls);
        String cleanHtml = extractImagesFromHtml(processedHtml, replyImageUrls);
        List<TableData> replyTables = new ArrayList<>();
        cleanHtml = convertHtmlTables(cleanHtml, replyTables);

        sPreProcessCache.put(pid, new ReplyPreProcessResult(cleanHtml, replyImageUrls,
                replyCodeCards, replyTables, fingerprint));
    }

    public static java.util.concurrent.ConcurrentHashMap<String, android.graphics.drawable.Drawable> getSmileyCache() {
        return sSmileyCache;
    }

    /**
     * ★ 修复：先在后台线程预加载 HTML 中所有表情图到缓存，然后在主线程渲染。
     * 这样 ImageGetter 只需从缓存读取，不会触发 NetworkOnMainThreadException。
     */
    private static void preloadSmileysAndRender(String html, List<TableData> tables,
                                                 View rootView, TextView tvContent,
                                                 LinearLayout llReplyImages,
                                                 List<String> bigImageUrls,
                                                 List<CodeCardRef> codeCards) {
        // 1) 扫描 HTML 中所有 <img src> 中含 smiley 的 URL
        java.util.Set<String> smileyUrls = new java.util.LinkedHashSet<>();
        if (!TextUtils.isEmpty(html)) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                    "<img\\s+[^>]*src=\"([^\"]+)\"", java.util.regex.Pattern.CASE_INSENSITIVE)
                    .matcher(html);
            while (m.find()) {
                String src = m.group(1);
                if (src != null && (src.contains("smiley") || src.contains("emoticon")
                        || src.contains("/static/image/"))) {
                    String fullUrl = normalizeImageUrl(src);
                    if (fullUrl != null) {
                        // ★ 统一缓存键为 & 形式，与 ImageGetter normSource 一致
                        fullUrl = fullUrl.replace("&amp;", "&");
                        smileyUrls.add(fullUrl);
                    }
                }
            }
        }

        // 2) 找出需要下载的（缓存中还没有的）
        java.util.List<String> toDownload = new java.util.ArrayList<>();
        for (String url : smileyUrls) {
            if (!sSmileyCache.containsKey(url)) {
                toDownload.add(url);
            }
        }

        Runnable renderTask = () -> {
            // 3) 渲染：文本段 + 可横滑表格段交替显示
            renderReplyWithInlineTables(html, tables, rootView, tvContent, llReplyImages, codeCards);
            // 4) 设置链接可点击
            setupClickableLinks(tvContent);
            // ★ 应用"编辑时间"自定义文字颜色
            applyEditTimeColor(tvContent);
            // 5) 网页端插入的图片（非 mod=image）显示在内容最底部
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_REPLY_IMG", "renderTask run, bigImageUrls=" + bigImageUrls);
            if (bigImageUrls != null && !bigImageUrls.isEmpty()) {
                loadReplyImages(rootView.getContext(), bigImageUrls, llReplyImages);
            } else {
                llReplyImages.removeAllViews();
                llReplyImages.setVisibility(View.GONE);
            }
        };

        // 收集需要下载的大图（仅 [attachimg] 内联图需要预缓存到 sReplyImageCache）
        // ★ 注意：extractImagesFromHtml 将 [attachimg] 图片保留在 HTML 正文中，
        // 不加入 bigImageUrls，所以不能只扫描 bigImageUrls。必须从 HTML 中提取。
        java.util.List<String> bigToDownload = new java.util.ArrayList<>();
        // a) 从 bigImageUrls 中查找（兜底，可能某些场景有 mod=image 图在列表中）
        if (bigImageUrls != null) {
            for (String imgUrl : bigImageUrls) {
                if (imgUrl.toLowerCase(java.util.Locale.ROOT).contains("mod=image")
                        && !sReplyImageCache.containsKey(imgUrl)) {
                    bigToDownload.add(imgUrl);
                }
            }
        }
        // b) 从 HTML 正文中扫描所有 <img> 标签，提取需要预缓存的内联大图
        //    （data-mt-inline 标记的 [attachimg] 图片 或 URL 含 mod=image 的图片）
        if (!TextUtils.isEmpty(html)) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                    "<img\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
            while (m.find()) {
                String imgTag = m.group();
                String tagLower = imgTag.toLowerCase(java.util.Locale.ROOT);
                String rawUrl = extractImageSource(imgTag);
                String fullUrl = normalizeImageUrl(rawUrl);
                if (fullUrl == null) continue;
                // ★ 统一缓存键：把 &amp; 解码为 &，与 ImageGetter 的 normSource 一致
                fullUrl = fullUrl.replace("&amp;", "&");
                String urlLower = fullUrl.toLowerCase(java.util.Locale.ROOT);
                boolean isSmiley = urlLower.contains("smiley") || urlLower.contains("emoticon")
                        || urlLower.contains("/static/image/");
                boolean realImageFile = !isSmiley && (urlLower.matches(".*\\.(jpe?g|png|gif|webp|bmp)(\\?.*)?$")
                        || urlLower.contains("data/attachment/")
                        || urlLower.contains("/forum/"));
                boolean needCache = (tagLower.contains("data-mt-inline") || urlLower.contains("mod=image") || realImageFile)
                        || (!isSmiley && (fullUrl.startsWith("http://") || fullUrl.startsWith("https://")));
                if (needCache && !sReplyImageCache.containsKey(fullUrl)
                        && !bigToDownload.contains(fullUrl)) {
                    bigToDownload.add(fullUrl);
                }
            }
        }

        if (toDownload.isEmpty() && bigToDownload.isEmpty()) {
            // 表情与大图都已缓存，直接渲染
            renderTask.run();
        } else {
            // 后台线程下载表情 + 大图，完成后主线程渲染
            tvContent.setVisibility(View.INVISIBLE); // 先隐藏，等加载完再显示
            new Thread(() -> {
                int maxImgWidth = getMaxImageWidth(rootView.getContext());
                for (String url : toDownload) {
                    try {
                        // ★ 用 Glide 在后台线程加载（支持 GIF 动画）
                        android.graphics.drawable.Drawable drawable = Glide.with(rootView.getContext())
                                .load(url)
                                .submit()
                                .get();
                        if (drawable != null) {
                            int maxSize = dpToPx(24, rootView);
                            int w = drawable.getIntrinsicWidth();
                            int h = drawable.getIntrinsicHeight();
                            if (w > maxSize || h > maxSize) {
                                float ratio = (float) maxSize / Math.max(w, h);
                                w = (int) (w * ratio);
                                h = (int) (h * ratio);
                            } else {
                                w = Math.max(w, 16);
                                h = Math.max(h, 16);
                            }
                            drawable.setBounds(0, 0, w, h);
                            sSmileyCache.put(url, drawable);
                            // ★ 如果是 GIF，额外缓存原始字节（用于 ImageGetter 创建独立实例）
                            if (isGifDrawable(drawable)) {
                                preloadGifBytes(rootView.getContext(), url);
                            }
                        }
                    } catch (Exception e) {
                        // 忽略单个表情加载失败
                    }
                }
                // ★ 下载内联大图到 sReplyImageCache（带请求头，防防盗链）
                for (String imgUrl : bigToDownload) {
                    try {
                        android.graphics.drawable.Drawable drawable = Glide.with(rootView.getContext())
                                .load(buildForumImageRequest(imgUrl))
                                .apply(new com.bumptech.glide.request.RequestOptions()
                                        .override(maxImgWidth, com.bumptech.glide.request.target.Target.SIZE_ORIGINAL))
                                .submit()
                                .get();
                        if (drawable != null) {
                            int w = drawable.getIntrinsicWidth();
                            int h = drawable.getIntrinsicHeight();
                            if (w <= 0 || h <= 0) {
                                w = maxImgWidth;
                                h = (int) (maxImgWidth * 0.6f);
                            }
                            if (w > maxImgWidth) {
                                float ratio = (float) maxImgWidth / w;
                                w = maxImgWidth;
                                h = (int) (h * ratio);
                            }
                            drawable.setBounds(0, 0, w, h);
                            sReplyImageCache.put(imgUrl, drawable);
                            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_REPLY_IMG", "big image cached: " + imgUrl + " " + w + "x" + h);
                        }
                    } catch (Exception e) {
                        android.util.Log.e("MT_REPLY_IMG", "big image download failed: " + imgUrl, e);
                        // ★ 加载失败：放入"图片已失效"占位图，避免 ImageGetter 返回 null（空白）
                        sReplyImageCache.put(imgUrl, createFailedImageDrawable(rootView.getContext()));
                    }
                }
                // 主线程渲染
                rootView.post(renderTask);
            }).start();
        }
    }

    private static int dpToPx(int dp, View view) {
        return (int) (dp * view.getContext().getResources().getDisplayMetrics().density + 0.5f);
    }

    /**
     * 创建"图片已失效"占位 Drawable（浅灰背景 + 提示文字）。
     * 用于飞书网盘等临时链接过期或图片加载失败时显示。
     */
    private static android.graphics.drawable.Drawable createFailedImageDrawable(Context context) {
        float density = context.getResources().getDisplayMetrics().density;
        int w = (int) (160 * density + 0.5f);
        int h = (int) (48 * density + 0.5f);
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(w, h,
                android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(bmp);
        android.graphics.Paint bgPaint = new android.graphics.Paint();
        bgPaint.setColor(0xFFF0F0F0);
        canvas.drawRect(0, 0, w, h, bgPaint);
        android.graphics.Paint borderPaint = new android.graphics.Paint();
        borderPaint.setColor(0xFFCCCCCC);
        borderPaint.setStyle(android.graphics.Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1);
        canvas.drawRect(0, 0, w - 1, h - 1, borderPaint);
        android.graphics.Paint textPaint = new android.graphics.Paint();
        textPaint.setColor(0xFF999999);
        textPaint.setTextSize(13 * density);
        textPaint.setAntiAlias(true);
        textPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        float baseline = h / 2f - (textPaint.descent() + textPaint.ascent()) / 2;
        canvas.drawText("图片已失效", w / 2f, baseline, textPaint);
        android.graphics.drawable.BitmapDrawable drawable =
                new android.graphics.drawable.BitmapDrawable(context.getResources(), bmp);
        drawable.setBounds(0, 0, w, h);
        return drawable;
    }

    private static android.graphics.Bitmap renderTableToBitmap(
            TableData table, int maxWidthPx, Context ctx) {
        try {
            float density = ctx.getResources().getDisplayMetrics().density;
            return com.forum.MT.ui.detail.TableBitmapRenderer.renderTable(
                    density, maxWidthPx, table.getRows(),
                    com.forum.MT.ui.widget.TableColorManager.resolveColors(ctx));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * ★ 清理该项可能残留的动态渲染视图（带 DYNAMIC_VIEW_TAG 的 extra/表格/代码卡片）。
     * 在 bind 渲染前调用，确保任何分支（html/纯文本）都从干净状态开始，防止刷新后内容叠加。
     */
    private static void clearDynamicViews(View rootView, android.widget.LinearLayout llReplyImages) {
        if (!(rootView instanceof android.widget.LinearLayout)) return;
        android.widget.LinearLayout linearRoot = (android.widget.LinearLayout) rootView;
        for (int i = linearRoot.getChildCount() - 1; i >= 0; i--) {
            android.view.View child = linearRoot.getChildAt(i);
            if (child == llReplyImages) continue;
            if (child.getTag() == DYNAMIC_VIEW_TAG) {
                linearRoot.removeViewAt(i);
            }
        }
    }

    private static CharSequence fromForumHtml(String html, android.widget.TextView targetView) {
        return fromForumHtml(html, targetView, null);
    }

    private static CharSequence fromForumHtml(String html, android.widget.TextView targetView,
                                              java.util.List<TableData> tables) {
        if (TextUtils.isEmpty(html)) return "";
        android.content.Context ctx = targetView.getContext();
        Html.ImageGetter ig = createInlineImageGetter(targetView, tables);
        String preprocessed = com.forum.MT.ui.widget.InlineHighlightPreprocessor.convert(html);
        // 帖子正文强制默认颜色：去除 <font> 的 color 属性和 style 中的 color
        if (com.forum.MT.ui.widget.ForceDefaultTextColorManager.isEnabled()) {
            preprocessed = stripFontColors(preprocessed);
        }
        com.forum.MT.ui.widget.InlineHighlightTagHandler tagHandler =
                new com.forum.MT.ui.widget.InlineHighlightTagHandler(
                        com.forum.MT.ui.widget.InlineHighlightManager.resolveBgColor(ctx),
                        com.forum.MT.ui.widget.InlineHighlightManager.resolveTextColor(ctx),
                        com.forum.MT.ui.widget.InlineHighlightManager.isEnabled(ctx),
                        com.forum.MT.ui.widget.InlineCodeManager.resolveBgColor(ctx),
                        com.forum.MT.ui.widget.InlineCodeManager.resolveTextColor(ctx),
                        com.forum.MT.ui.widget.InlineCodeManager.isEnabled(ctx));
        CharSequence rendered = Html.fromHtml(preprocessed, Html.FROM_HTML_MODE_COMPACT, ig, tagHandler);
        // ★ 应用"评论加粗文字粗度"设置：将 BOLD 样式的 Span 替换为自定义粗度
        int boldWeight = com.forum.MT.ui.widget.ReplyBoldWeightManager.getWeight(ctx);
        if (boldWeight != 700 && rendered instanceof android.text.Spannable) {
            android.text.Spannable sp = (android.text.Spannable) rendered;
            android.text.style.StyleSpan[] spans = sp.getSpans(0, sp.length(), android.text.style.StyleSpan.class);
            for (android.text.style.StyleSpan span : spans) {
                if (span.getStyle() == android.graphics.Typeface.BOLD) {
                    int start = sp.getSpanStart(span);
                    int end = sp.getSpanEnd(span);
                    int flags = sp.getSpanFlags(span);
                    sp.removeSpan(span);
                    android.graphics.Typeface customTf = android.graphics.Typeface.create(
                            android.graphics.Typeface.DEFAULT, boldWeight, false);
                    sp.setSpan(new android.text.style.TypefaceSpan(customTf), start, end, flags);
                }
            }
        }
        return rendered;
    }

    /**
     * 去除 HTML 中 <font> 标签的颜色属性（color="..." 或 style="color:..."），
     * 使回复正文强制使用默认文字颜色。
     */
    private static String stripFontColors(String html) {
        if (html == null || html.isEmpty()) return html;
        String out = html.replaceAll("(?i)(<font\\b[^>]*?)\\scolor\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)", "$1");
        out = out.replaceAll("(?i)(<font\\b[^>]*?\\bstyle\\s*=\\s*\")([^\"]*?)(?:;?\\s*color\\s*:\\s*[^;\"']+;?)([^\"]*)\"", "$1$2$3\"");
        out = out.replaceAll("(?i)(<font\\b[^>]*?)\\sstyle\\s*=\\s*\"\\s*\"", "$1");
        return out;
    }

    /**
     * 将回复内容按 table:// 占位符和卡片占位符分段渲染，保证文本段、表格、卡片按原始顺序交错排列。
     * ★ 修复：代码卡片不再全部跑到底部，而是出现在原文中的原始位置。
     */
    private static void renderReplyWithInlineTables(String html, java.util.List<TableData> tables,
                                                     View rootView, android.widget.TextView tvContent,
                                                     android.widget.LinearLayout llReplyImages,
                                                     java.util.List<CodeCardRef> codeCards) {
        if (TextUtils.isEmpty(html)) {
            tvContent.setVisibility(View.GONE);
            return;
        }
        android.content.Context ctx = rootView.getContext();
        int maxWidth = ctx.getResources().getDisplayMetrics().widthPixels - dpToPx(48, rootView);
        // 第一步：按 table:// 占位符拆分
        java.util.regex.Pattern tablePattern = java.util.regex.Pattern.compile(
                "<img\\s+[^>]*src=\"table://(\\d+)\"[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.List<Object> segments = new java.util.ArrayList<>();
        java.util.regex.Matcher m = tablePattern.matcher(html);
        int lastEnd = 0;
        while (m.find()) {
            if (m.start() > lastEnd) {
                segments.add(html.substring(lastEnd, m.start()));
            }
            segments.add(Integer.parseInt(m.group(1)));
            lastEnd = m.end();
        }
        if (lastEnd < html.length()) {
            segments.add(html.substring(lastEnd));
        }
        // 第二步：按卡片占位符二次拆分
        java.util.List<Object> finalSegments = new java.util.ArrayList<>();
        java.util.regex.Pattern cardPattern = java.util.regex.Pattern.compile(
                "<!--(QUOTE_CARD_(\\d+)|CODE_CARD_(\\d+))-->");
        for (Object seg : segments) {
            if (seg instanceof String) {
                String text = (String) seg;
                java.util.regex.Matcher cm = cardPattern.matcher(text);
                int p = 0;
                while (cm.find()) {
                    if (cm.start() > p) {
                        finalSegments.add(text.substring(p, cm.start()));
                    }
                    if (cm.group(1).startsWith("QUOTE_CARD_")) {
                        int idx = Integer.parseInt(cm.group(2));
                        finalSegments.add(-idx - 1); // 引用卡片编码
                    } else {
                        int idx = Integer.parseInt(cm.group(3));
                        finalSegments.add(-idx - 1001); // 代码卡片编码
                    }
                    p = cm.end();
                }
                if (p < text.length()) {
                    finalSegments.add(text.substring(p));
                }
            } else {
                finalSegments.add(seg);
            }
        }
        // ★ 修复评论重复：用 tag 标记动态视图，清理时删除所有带 tag 的动态视图
        // （无论它们被插在 tvContent 之前还是之后），避免每次刷新残留上轮视图导致内容叠加。
        int mainIdx = -1;
        for (int i = 0; i < ((android.widget.LinearLayout) rootView).getChildCount(); i++) {
            if (((android.widget.LinearLayout) rootView).getChildAt(i) == tvContent) {
                mainIdx = i;
                break;
            }
        }
        tvContent.setVisibility(View.GONE);
        android.widget.LinearLayout linearRoot = (android.widget.LinearLayout) rootView;
        for (int i = linearRoot.getChildCount() - 1; i >= 0; i--) {
            android.view.View child = linearRoot.getChildAt(i);
            if (child == llReplyImages) continue;
            if (child.getTag() == DYNAMIC_VIEW_TAG) {
                linearRoot.removeViewAt(i);
            }
        }
        // ★ 找到 llReplyImages 在 LinearLayout 中的位置，所有动态视图都插入到它之前
        int imagesIdx = -1;
        for (int i = 0; i < linearRoot.getChildCount(); i++) {
            if (linearRoot.getChildAt(i) == llReplyImages) {
                imagesIdx = i;
                break;
            }
        }
        // insertPos：从 tvContent 位置开始插入（这样文本段、表格、卡片严格按 finalSegments 顺序交错）
        int insertPos = mainIdx >= 0 ? mainIdx : -1;

        // 第四步：按顺序交错渲染文本段、表格、卡片（所有段统一插入，不再把首段塞进 tvContent，
        // 否则卡片插在 tvContent 之后、而首段文本固定在 tvContent 内，导致"代码块在前文本在后"时顺序颠倒）
        for (Object seg : finalSegments) {
            if (seg instanceof Integer) {
                int idx = (Integer) seg;
                if (idx >= 0) {
                    // 表格段
                    if (tables != null && idx < tables.size()) {
                        android.graphics.Bitmap bmp = renderTableToBitmap(tables.get(idx), maxWidth, ctx);
                        if (bmp != null) {
                            android.widget.HorizontalScrollView scrollView = new android.widget.HorizontalScrollView(ctx);
                            android.widget.ImageView imgView = new android.widget.ImageView(ctx);
                            imgView.setImageBitmap(bmp);
                            imgView.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
                            scrollView.setTag(DYNAMIC_VIEW_TAG);
                            scrollView.addView(imgView);
                            if (insertPos >= 0) {
                                linearRoot.addView(scrollView, insertPos);
                                insertPos++;
                            } else {
                                linearRoot.addView(scrollView);
                            }
                        }
                    }
                } else if (idx > -1000) {
                    // 引用卡片（暂不处理）
                } else {
                    // 代码卡片
                    int codeIdx = -idx - 1001;
                    if (codeCards != null && codeIdx >= 0 && codeIdx < codeCards.size()) {
                        View codeCard = buildCodeCard(codeCards.get(codeIdx).html, rootView);
                        codeCard.setTag(DYNAMIC_VIEW_TAG);
                        if (insertPos >= 0) {
                            linearRoot.addView(codeCard, insertPos);
                            insertPos++;
                        } else {
                            linearRoot.addView(codeCard);
                        }
                    }
                }
            } else {
                String textPart = (String) seg;
                if (textPart.trim().isEmpty()) continue;
                CharSequence rendered = fromForumHtml(textPart, tvContent, tables);
                android.widget.TextView extra = new android.widget.TextView(ctx);
                extra.setTextSize(tvContent.getTextSize() / ctx.getResources().getDisplayMetrics().scaledDensity);
                extra.setTextColor(tvContent.getTextColors());
                extra.setLineSpacing(tvContent.getLineSpacingExtra(), tvContent.getLineSpacingMultiplier());
                extra.setTag(DYNAMIC_VIEW_TAG);
                extra.setText(rendered, android.widget.TextView.BufferType.SPANNABLE);
                applyEditTimeColor(extra);
                // ★ 修复：extra 动态 TextView 也必须设置链接可点击。
                // 从 fromForumHtml 得到的链接是 URLSpan（带下划线），但未设置
                // MovementMethod/ClickableSpan 时点击无响应；与 tvContent 保持一致。
                setupClickableLinks(extra);
                if (insertPos >= 0) {
                    linearRoot.addView(extra, insertPos, new android.widget.LinearLayout.LayoutParams(
                            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
                    insertPos++;
                } else {
                    linearRoot.addView(extra, new android.widget.LinearLayout.LayoutParams(
                            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
                }
            }
        }
    }

    /**
     * 复制 Drawable（通过 ConstantState），复制失败时返回原 drawable。
     * ★ 对于 GifDrawable，不使用 ConstantState.newDrawable()（会共享 GifFrameLoader
     *   导致多个 GIF 串帧），而是通过 Glide 从缓存的字节重新解码独立实例。
     */
    private static android.graphics.drawable.Drawable copyDrawable(android.graphics.drawable.Drawable src) {
        if (src == null) return null;
        android.graphics.drawable.Drawable.ConstantState cs = src.getConstantState();
        if (cs != null) {
            android.graphics.drawable.Drawable copy = cs.newDrawable();
            copy.setBounds(src.getBounds());
            return copy;
        }
        return src;
    }

    /**
     * ★ 判断 Drawable 是否为 Glide 的 GifDrawable（通过反射，避免硬依赖 Glide 类）。
     */
    private static boolean isGifDrawable(android.graphics.drawable.Drawable d) {
        if (d == null) return false;
        String name = d.getClass().getName();
        return name != null && name.contains("GifDrawable");
    }

    /**
     * 用原始 GIF 字节解码一个真正独立的动画 Drawable。
     * 优先使用 Android 原生 ImageDecoder（AnimatedImageDrawable），彻底绕开 Glide GifDrawable
     * 的共享状态问题；低版本或失败时再退回 Glide.asGif + 唯一 signature。
     */
    private static android.graphics.drawable.Drawable decodeIndependentGifDrawable(
            android.content.Context ctx, String cacheKey, byte[] gifBytes, TextView targetView) {
        if (gifBytes == null || gifBytes.length == 0) return null;
        int maxSize = dpToPx(24, targetView);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            try {
                byte[] localBytes = java.util.Arrays.copyOf(gifBytes, gifBytes.length);
                android.graphics.ImageDecoder.Source src = android.graphics.ImageDecoder.createSource(
                        java.nio.ByteBuffer.wrap(localBytes));
                android.graphics.drawable.Drawable decoded = android.graphics.ImageDecoder.decodeDrawable(src,
                        (decoder, info, source) -> {
                            android.util.Size size = info.getSize();
                            int w = Math.max(1, size.getWidth());
                            int h = Math.max(1, size.getHeight());
                            int tw;
                            int th;
                            if (w > maxSize || h > maxSize) {
                                float ratio = (float) maxSize / Math.max(w, h);
                                tw = Math.max(1, Math.round(w * ratio));
                                th = Math.max(1, Math.round(h * ratio));
                            } else {
                                tw = Math.max(w, 16);
                                th = Math.max(h, 16);
                            }
                            decoder.setTargetSize(tw, th);
                        });
                if (decoded != null) {
                    int w = Math.max(decoded.getIntrinsicWidth(), 16);
                    int h = Math.max(decoded.getIntrinsicHeight(), 16);
                    decoded.setBounds(0, 0, w, h);

                    return decoded;
                }
            } catch (Exception e) {
                android.util.Log.e("MT_REPLY_IMG", "ImageDecoder GIF failed: " + cacheKey, e);
            }
        }

        try {
            byte[] localBytes = java.util.Arrays.copyOf(gifBytes, gifBytes.length);
            android.graphics.drawable.Drawable fresh = com.bumptech.glide.Glide.with(ctx)
                    .asGif()
                    .load(localBytes)
                    .skipMemoryCache(true)
                    .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                    .signature(new com.bumptech.glide.signature.ObjectKey(cacheKey + "#" + System.nanoTime()))
                    .submit()
                    .get();
            if (fresh != null) {
                int w = fresh.getIntrinsicWidth();
                int h = fresh.getIntrinsicHeight();
                if (w > maxSize || h > maxSize) {
                    float ratio = (float) maxSize / Math.max(w, h);
                    w = Math.max(1, Math.round(w * ratio));
                    h = Math.max(1, Math.round(h * ratio));
                } else {
                    w = Math.max(w, 16);
                    h = Math.max(h, 16);
                }
                fresh.setBounds(0, 0, w, h);
                return fresh;
            }
        } catch (Exception e) {
            android.util.Log.e("MT_REPLY_IMG", "Glide GIF decode failed: " + cacheKey, e);
        }
        return null;
    }

    /**
     * ★ 为 GIF 表情获取一个完全独立的动画 Drawable。
     * 先从 sGifBytesCache 读取字节；未命中则同步拉取文件字节并缓存，然后再独立解码。
     */
    private static android.graphics.drawable.Drawable getIndependentGifDrawable(
            android.content.Context ctx, String url,
            TextView targetView, android.graphics.Rect srcBounds) {
        String normUrl = url == null ? null : url.replace("&amp;", "&");
        if (TextUtils.isEmpty(normUrl)) return null;

        byte[] gifBytes = sGifBytesCache.get(normUrl);
        if (gifBytes == null && !normUrl.equals(url)) {
            gifBytes = sGifBytesCache.get(url);
        }
        if (gifBytes == null) {
            try {
                java.io.File gifFile = com.bumptech.glide.Glide.with(ctx)
                        .asFile()
                        .load(buildForumImageRequest(normUrl))
                        .submit()
                        .get();
                if (gifFile != null && gifFile.exists()) {
                    gifBytes = java.nio.file.Files.readAllBytes(gifFile.toPath());
                    if (gifBytes != null && gifBytes.length > 0) {
                        sGifBytesCache.put(normUrl, gifBytes);
                        if (!normUrl.equals(url)) {
                            sGifBytesCache.put(url, gifBytes);
                        }

                    }
                }
            } catch (Exception e) {
                android.util.Log.e("MT_REPLY_IMG", "load GIF bytes on demand failed: " + normUrl, e);
            }
        }
        return decodeIndependentGifDrawable(ctx, normUrl, gifBytes, targetView);
    }

    /**
     * ★ 在后台线程下载 GIF 文件并缓存原始字节。
     * 在预加载阶段调用，确保 ImageGetter 能从字节缓存快速解码独立 GifDrawable。
     * @param ctx 上下文
     * @param url GIF 图片 URL
     */
    private static void preloadGifBytes(android.content.Context ctx, String url) {
        if (sGifBytesCache.containsKey(url)) return;
        try {
            java.io.File gifFile = com.bumptech.glide.Glide.with(ctx)
                    .asFile()
                    .load(buildForumImageRequest(url))
                    .submit()
                    .get();
            if (gifFile != null && gifFile.exists()) {
                byte[] bytes = java.nio.file.Files.readAllBytes(gifFile.toPath());
                if (bytes != null && bytes.length > 0) {
                    sGifBytesCache.put(url, bytes);

                }
            }
        } catch (Exception e) {
            android.util.Log.e("MT_REPLY_IMG", "preloadGifBytes failed: " + url, e);
        }
    }

    /**
     * ★ 如果 drawable 是 Glide 的 GifDrawable，调用 start() 启动动画。
     * GifDrawable 通过 newDrawable() 复制后默认不自动播放，必须显式 start()。
     * 同时需要 setVisible(true) 让 GifDrawable 的帧回调生效。
     */
    private static void startGifIfNeeded(android.graphics.drawable.Drawable drawable) {
        if (drawable == null) return;
        startGifDrawableInternal(drawable, null);
    }

    /**
     * ★ 遍历 TextView 文本中的所有 ImageSpan，找到 GifDrawable 并启动动画。
     * 必须在 setText() 之后调用——此时 TextView 已为 drawable 设置了 callback，
     * GifDrawable 的帧调度才能通过 invalidateSelf() → callback.invalidateDrawable() 触发重绘。
     */
    private static void startGifAnimationsInTextView(TextView textView) {
        if (textView == null) return;
        CharSequence text = textView.getText();
        if (!(text instanceof android.text.Spannable)) return;
        android.text.Spannable spannable = (android.text.Spannable) text;
        android.text.style.ImageSpan[] imageSpans = spannable.getSpans(0, spannable.length(),
                android.text.style.ImageSpan.class);
        for (android.text.style.ImageSpan span : imageSpans) {
            android.graphics.drawable.Drawable d = span.getDrawable();
            startGifDrawableInternal(d, textView);
        }
    }

    /**
     * 内部方法：检测 GifDrawable 并启动动画，设置 callback。
     * ★ 关键修复：TextView 的 verifyDrawable() 只检查 compound drawable，
     *   不检查 ImageSpan 的 drawable，所以 GifDrawable.invalidateSelf() 调用
     *   callback.invalidateDrawable() 时 TextView 不会重绘。
     *   解决方案：用自定义 Callback 包装，直接调用 textView.invalidate()。
     * @param drawable 要检测的 drawable
     * @param callback 宿主 TextView（为 null 时不设置 callback，仅 start）
     */
    private static void startGifDrawableInternal(android.graphics.drawable.Drawable drawable,
                                                  TextView callback) {
        if (drawable == null) return;
        String className = drawable.getClass().getName();
        boolean isGlideGif = className != null && className.contains("GifDrawable");
        boolean isAnimatedImage = drawable instanceof android.graphics.drawable.Animatable
                && className != null && className.contains("AnimatedImageDrawable");
        if (!isGlideGif && !isAnimatedImage) return;
        try {
            // ★ 关键：设置自定义 callback，绕过 TextView.verifyDrawable() 的限制
            if (callback != null) {
                drawable.setCallback(new android.graphics.drawable.Drawable.Callback() {
                    @Override
                    public void invalidateDrawable(android.graphics.drawable.Drawable who) {
                        callback.invalidate();
                    }
                    @Override
                    public void scheduleDrawable(android.graphics.drawable.Drawable who, Runnable what, long when) {
                        long delay = Math.max(0L, when - android.os.SystemClock.uptimeMillis());
                        callback.postDelayed(what, delay);
                    }
                    @Override
                    public void unscheduleDrawable(android.graphics.drawable.Drawable who, Runnable what) {
                        callback.removeCallbacks(what);
                    }
                });
            }
            try {
                java.lang.reflect.Method setVisible = drawable.getClass().getMethod("setVisible", boolean.class, boolean.class);
                setVisible.invoke(drawable, true, false);
            } catch (Exception ignore) {
            }
            if (drawable instanceof android.graphics.drawable.Animatable) {
                ((android.graphics.drawable.Animatable) drawable).start();
            } else {
                java.lang.reflect.Method start = drawable.getClass().getMethod("start");
                start.invoke(drawable);
            }
        } catch (Exception e) {
            android.util.Log.e("MT_REPLY_IMG", "Failed to start animated drawable", e);
        }
    }

    /**
     * 为 Html.fromHtml 提供 ImageGetter，用 Glide 异步加载内联图片（表情等小图）
     * 缩放到 24dp 以内
     */
    private static Html.ImageGetter createInlineImageGetter(TextView targetView) {
        return createInlineImageGetter(targetView, null);
    }

    private static Html.ImageGetter createInlineImageGetter(TextView targetView,
                                                             java.util.List<TableData> tables) {
        final android.content.Context ctx = targetView.getContext();
        final int maxWidth = ctx.getResources().getDisplayMetrics().widthPixels - dpToPx(48, targetView);
        return source -> {
            // table://N 表格占位符
            if (source != null && source.startsWith("table://")) {
                try {
                    int idx = Integer.parseInt(source.substring("table://".length()));
                    if (tables != null && idx >= 0 && idx < tables.size()) {
                        android.graphics.Bitmap bmp = renderTableToBitmap(tables.get(idx), maxWidth, ctx);
                        if (bmp != null) {
                            android.graphics.drawable.BitmapDrawable drawable =
                                    new android.graphics.drawable.BitmapDrawable(ctx.getResources(), bmp);
                            drawable.setBounds(0, 0, bmp.getWidth(), bmp.getHeight());
                            return drawable;
                        }
                    }
                    return new android.graphics.drawable.Drawable() {
                        @Override public void draw(android.graphics.Canvas canvas) {}
                        @Override public void setAlpha(int alpha) {}
                        @Override public void setColorFilter(android.graphics.ColorFilter cf) {}
                        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSPARENT; }
                        @Override public int getIntrinsicWidth() { return 1; }
                        @Override public int getIntrinsicHeight() { return 1; }
                    };
                } catch (Exception e) {
                    return null;
                }
            }
            // 普通图片（表情等）
            // ★ 内联大图优先：从预加载缓存读取，按原尺寸显示在原文位置
            // ★ URL 归一化：Html 解析会把 &amp; 解码为 &，缓存键可能来自两种形式，统一比较
            String normSource = source == null ? null
                    : source.replace("&amp;", "&");
            if (com.forum.MT.util.Dbg.ON) android.util.Log.d("MT_REPLY_IMG", "ImageGetter source=" + source + " cacheKeys=" + sReplyImageCache.keySet());
            // ★ 先走 GIF 字节缓存：直接解码独立动画实例，避免任何 GifDrawable 共享状态
            if (normSource != null) {
                byte[] gifBytes = sGifBytesCache.get(normSource);
                if (gifBytes == null && source != null) {
                    gifBytes = sGifBytesCache.get(source);
                }
                if (gifBytes != null) {
                    android.graphics.drawable.Drawable independent = decodeIndependentGifDrawable(
                            ctx, normSource, gifBytes, targetView);
                    if (independent != null) {

                        return independent;
                    }
                }
            }
            // ★ 判断是否为表情/小图标 URL
            boolean isSmileyUrl = normSource != null
                    && (normSource.contains("smiley") || normSource.contains("emoticon")
                        || normSource.contains("/static/image/"));
            // ★ 表情优先查 sSmileyCache（24dp 小图），跳过 sReplyImageCache（大图缓存）
            //   防止表情被误缓存到大图缓存后按大图尺寸渲染
            if (!isSmileyUrl && normSource != null && sReplyImageCache.containsKey(normSource)) {
                android.graphics.drawable.Drawable cached = sReplyImageCache.get(normSource);
                if (cached != null) {
                    // ★ 不在此处 start() GIF 动画——由 startGifAnimationsInTextView 统一启动
                    // 过早 start() 会导致 FrameLoader callback 错乱
                    // ★ GifDrawable：使用 Glide 加载独立实例（不共享 GifFrameLoader）
                    String clsName = cached.getClass().getName();
                    if (clsName != null && clsName.contains("GifDrawable")) {
                        android.graphics.drawable.Drawable independent = getIndependentGifDrawable(
                                ctx, source, targetView, cached.getBounds());
                        if (independent != null) {
    
                            return independent;
                        }
                    }
                    return copyDrawable(cached);
                }
            }
            android.graphics.drawable.Drawable smileyCached = null;
            if (normSource != null) {
                smileyCached = sSmileyCache.get(normSource);
            }
            if (smileyCached == null && source != null) {
                smileyCached = sSmileyCache.get(source);
            }
            if (smileyCached != null) {
                android.graphics.drawable.Drawable cached = smileyCached;
                if (cached != null) {
                    // ★ 不在此处 start() GIF 动画——由 startGifAnimationsInTextView 统一启动
                    // ★ GifDrawable：使用 Glide 加载独立实例（不共享 GifFrameLoader）
                    String clsName = cached.getClass().getName();
                    if (clsName != null && clsName.contains("GifDrawable")) {
                        android.graphics.drawable.Drawable independent = getIndependentGifDrawable(
                                ctx, source, targetView, cached.getBounds());
                        if (independent != null) {

                            return independent;
                        }
                    }
                    return copyDrawable(cached);
                }
            }
            // Glide 异步加载
            android.graphics.drawable.Drawable[] holder = new android.graphics.drawable.Drawable[1];
            try {
                android.graphics.drawable.Drawable drawable = com.bumptech.glide.Glide.with(ctx)
                        .load(buildForumImageRequest(source))
                        .submit()
                        .get();
                if (drawable != null) {
                    int maxSize = dpToPx(24, targetView);
                    int w = drawable.getIntrinsicWidth();
                    int h = drawable.getIntrinsicHeight();
                    if (w > maxSize || h > maxSize) {
                        float ratio = (float) maxSize / Math.max(w, h);
                        w = (int) (w * ratio);
                        h = (int) (h * ratio);
                    }
                    drawable.setBounds(0, 0, w, h);
                    String saveKey = source == null ? null : source.replace("&amp;", "&");
                    if (saveKey != null) {
                        sSmileyCache.put(saveKey, drawable);
                    }
                    if (source != null && !source.equals(saveKey)) {
                        sSmileyCache.put(source, drawable);
                    }
                    if (isGifDrawable(drawable) && saveKey != null) {
                        preloadGifBytes(ctx, saveKey);
                    }
                    // ★ 不在此处 start() GIF 动画——由 startGifAnimationsInTextView 统一启动
                    return drawable;
                }
            } catch (Exception e) {
                // ignore
            }
            return null;
        };
    }

    /**
     * 为 Html.fromHtml 提供 ImageGetter，用 Glide 异步加载内联图片（表情等小图）
     * 缩放到 24dp 以内；同时支持 table://N 表格占位符，渲染为内联表格位图。
     */

    /**
     * 将回复内容按 table:// 占位符分段渲染：文本段 + 可横滑表格段交替显示。
     * <p>
     * 表格段以 HorizontalScrollView + 自然宽度位图呈现，支持横向滑动查看全表；
     * 表格视图插入到 tvContent 之后、ll_reply_images 之前的正确位置。
     */
    
    /**
     * 构建代码块卡片视图（深色背景、等宽字体、可横向滚动、复制按钮）。
     */
        private static View buildCodeCard(String codeHtml, View rootView) {
        android.content.Context ctx = rootView.getContext();
        int bgColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveBgColor(ctx);
        int borderColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveBorderColor(ctx);
        int textColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveTextColor(ctx);
        int titleBgColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveTitleBgColor(ctx);
        int titleTextColor = com.forum.MT.ui.widget.CodeBlockColorManager.resolveTitleTextColor(ctx);

        com.google.android.material.card.MaterialCardView card =
                new com.google.android.material.card.MaterialCardView(ctx);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dpToPx(6, rootView), 0, dpToPx(6, rootView));
        card.setLayoutParams(params);
        card.setRadius(dpToPx(12, rootView));
        card.setCardBackgroundColor(bgColor);
        card.setStrokeWidth(dpToPx(1, rootView));
        card.setStrokeColor(borderColor);
        card.setCardElevation(0f);
        card.setContentPadding(dpToPx(12, rootView), dpToPx(10, rootView), dpToPx(12, rootView), dpToPx(10, rootView));

        LinearLayout body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);

        // 标题行（尺寸对齐"隐藏内容"卡片）
        LinearLayout titleRow = new LinearLayout(ctx);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(ctx);
        titleView.setText("代码内容");
        titleView.setTextColor(titleTextColor);
        titleView.setTextSize(14);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        titleRow.addView(titleView, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // —— 查看/收起 按钮 ——（用 TextView 对齐正文代码卡片，避免 Button 默认 minHeight=48dp 导致更高）
        TextView viewBtn = new TextView(ctx);
        viewBtn.setText("查看");
        viewBtn.setTextSize(13);
        viewBtn.setTextColor(textColor);
        viewBtn.setTypeface(null, android.graphics.Typeface.BOLD);
        viewBtn.setGravity(android.view.Gravity.CENTER);
        android.graphics.drawable.GradientDrawable viewGd = new android.graphics.drawable.GradientDrawable();
        viewGd.setColor(titleBgColor);
        viewGd.setCornerRadius(dpToPx(16, rootView));
        viewGd.setStroke(dpToPx(1, rootView), textColor);
        viewBtn.setBackground(viewGd);
        android.widget.LinearLayout.LayoutParams viewBtnParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        viewBtnParams.setMargins(0, 0, dpToPx(6, rootView), 0);
        viewBtn.setLayoutParams(viewBtnParams);
        viewBtn.setPadding(dpToPx(12, rootView), dpToPx(4, rootView), dpToPx(12, rootView), dpToPx(4, rootView));

        titleRow.addView(viewBtn);

        // —— 复制按钮 ——（用 TextView 对齐正文代码卡片）
        TextView copyBtn = new TextView(ctx);
        copyBtn.setText("复制");
        copyBtn.setTextSize(13);
        copyBtn.setTextColor(textColor);
        copyBtn.setTypeface(null, android.graphics.Typeface.BOLD);
        copyBtn.setGravity(android.view.Gravity.CENTER);
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(titleBgColor);
        gd.setCornerRadius(dpToPx(16, rootView));
        gd.setStroke(dpToPx(1, rootView), textColor);
        copyBtn.setBackground(gd);
        android.widget.LinearLayout.LayoutParams btnParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        copyBtn.setLayoutParams(btnParams);
        copyBtn.setPadding(dpToPx(12, rootView), dpToPx(4, rootView), dpToPx(12, rootView), dpToPx(4, rootView));
        copyBtn.setOnClickListener(v -> {
            String plainText = android.text.Html.fromHtml(codeHtml,
                    android.text.Html.FROM_HTML_MODE_COMPACT).toString();
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("code", plainText));
            android.widget.Toast.makeText(ctx, "代码已复制", android.widget.Toast.LENGTH_SHORT).show();
        });
        titleRow.addView(copyBtn);

        body.addView(titleRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // 代码区容器（默认折叠，点"查看"展开，点"收起"折叠）
        final LinearLayout codeArea = new LinearLayout(ctx);
        codeArea.setOrientation(LinearLayout.VERTICAL);
        codeArea.setVisibility(View.GONE);

        // 分隔线
        View divider = new View(ctx);
        divider.setBackgroundColor(borderColor);
        divider.setAlpha(0.3f);
        LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1, rootView));
        divParams.setMargins(0, dpToPx(6, rootView), 0, dpToPx(6, rootView));
        codeArea.addView(divider, divParams);

        // 代码正文（可横向滚动，宽度限制在屏幕内）
        android.widget.HorizontalScrollView scrollView = new android.widget.HorizontalScrollView(ctx);
        scrollView.setHorizontalScrollBarEnabled(true);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        // ★ 防误触刷新 + 防晃动：方向一旦判定为「横向」，整个手势内锁定 disallow，
        // 不再每次 MOVE 来回切换（来回切换会让父容器反复抢手势 → 上下晃动）。
        final float[] downXY = {0f, 0f};
        final boolean[] lockedHorizontal = {false};
        scrollView.setOnTouchListener((v, ev) -> {
            switch (ev.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    downXY[0] = ev.getX();
                    downXY[1] = ev.getY();
                    lockedHorizontal[0] = false;
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    break;
                case android.view.MotionEvent.ACTION_MOVE:
                    if (!lockedHorizontal[0]) {
                        float dx = Math.abs(ev.getX() - downXY[0]);
                        float dy = Math.abs(ev.getY() - downXY[1]);
                        // 水平优先且超过阈值 → 锁定为横向手势，禁止父容器拦截，直到手势结束
                        if (dx > dy && dx > dpToPx(8, rootView)) {
                            lockedHorizontal[0] = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                    }
                    break;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    lockedHorizontal[0] = false;
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    break;
            }
            return false;
        });

        String raw = codeHtml
                .replace("&lt;", "<").replace("&gt;", ">")
                .replace("&amp;", "&").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&apos;", "'")
                .replace("&nbsp;", " ").replace("&#160;", " ")
                .replace("&#10;", "\n").replace("&#x0A;", "\n")
                .replace("&#13;", "\n").replace("&#9;", "\t");
        raw = raw.replaceAll("(?i)<br\\s*/?>", "\n");
        raw = raw.replaceAll("(?i)<[^>]+>", "");
        StringBuilder codeSb = new StringBuilder();
        for (String line : raw.split("\n")) {
            line = line.trim().replaceAll("[ \\t]+", " ");
            if (line.isEmpty()) continue;
            codeSb.append(line).append('\n');
        }
        String codeText = codeSb.toString();

        TextView codeView = new TextView(ctx);
        codeView.setTextSize(12);
        codeView.setTextColor(textColor);
        codeView.setTypeface(android.graphics.Typeface.MONOSPACE);
        codeView.setLineSpacing(0f, 1.25f);
        codeView.setPadding(dpToPx(4, rootView), dpToPx(4, rootView), dpToPx(4, rootView), dpToPx(4, rootView));
        codeView.setBackgroundColor(bgColor);
        codeView.setHorizontallyScrolling(true);
        codeView.setText(codeText);
        // ★ 链接可点击：复用 setupClickableLinks
        setupClickableLinks(codeView);
        codeView.setLinkTextColor(0xFF4FC3F7);
        scrollView.addView(codeView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        codeArea.addView(scrollView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // 查看/收起 切换
        final boolean[] expandedCode = {false};
        viewBtn.setOnClickListener(v -> {
            if (expandedCode[0]) {
                codeArea.setVisibility(View.GONE);
                viewBtn.setText("查看");
            } else {
                codeArea.setVisibility(View.VISIBLE);
                viewBtn.setText("收起");
            }
            expandedCode[0] = !expandedCode[0];
        });

        body.addView(codeArea, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        card.addView(body);
        return card;
    }

    private static class CodeCardRef {
        final String html;
        CodeCardRef(String html) {
            this.html = html;
        }
    }

}
