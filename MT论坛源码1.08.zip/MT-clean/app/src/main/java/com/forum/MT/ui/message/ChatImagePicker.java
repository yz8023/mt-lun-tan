package com.forum.MT.ui.message;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * 把相册选中的 {@code content://} Uri 变成一个可以直接上传的临时文件。
 *
 * <p>为什么不能直接把原 Uri 交给 OkHttp：{@code MultipartBody} 需要
 * {@link File}，而 MediaStore 的 Uri 没有稳定的文件路径（Android 10 起
 * 分区存储下更是拿不到）。
 *
 * <p>为什么必须压缩：图床限制单张 5MB，而现在手机随手一拍就是 8~15MB。
 * 不压缩的话大部分图片会在服务端被直接拒掉，用户只能看到"上传失败"。
 * 这里按"先降采样到长边上限，再逐步降 JPEG 质量"的策略收敛到限额以内。
 */
final class ChatImagePicker {

    /** 长边上限。聊天气泡最宽 266dp，2K 长边已经远超展示需要。 */
    private static final int MAX_EDGE = 2048;
    /** 目标体积，留出 multipart 头部与图床自身余量。 */
    private static final long TARGET_BYTES = 4L * 1024 * 1024;
    private static final int MIN_QUALITY = 60;

    private ChatImagePicker() {}

    /**
     * 读取并（按需）压缩图片，返回缓存目录下的临时文件。
     *
     * <p>阻塞调用，必须在后台线程执行。调用方负责在上传结束后删除返回的文件。
     *
     * @return 临时文件；读取失败返回 null
     */
    @Nullable
    static File prepareUploadFile(@NonNull Context context, @NonNull Uri uri) throws Exception {
        File dir = new File(context.getCacheDir(), "chat_upload");
        if (!dir.exists() && !dir.mkdirs()) return null;

        // GIF 必须原样上传：解码成 Bitmap 再压缩会丢掉全部动画帧。
        String mime = context.getContentResolver().getType(uri);
        boolean gif = mime != null && mime.toLowerCase(java.util.Locale.ROOT).contains("gif");

        File raw = new File(dir, "pm_" + System.currentTimeMillis() + (gif ? ".gif" : ".jpg"));
        if (!copyTo(context, uri, raw)) return null;

        if (gif || raw.length() <= TARGET_BYTES) return raw;

        File compressed = compress(raw, dir);
        if (compressed == null) return raw;
        // 压缩产物已经独立成文件，原始副本不再需要。
        try { raw.delete(); } catch (Exception ignored) {}
        return compressed;
    }

    private static boolean copyTo(Context context, Uri uri, File target) throws Exception {
        try (InputStream is = context.getContentResolver().openInputStream(uri);
             FileOutputStream os = new FileOutputStream(target)) {
            if (is == null) return false;
            byte[] buffer = new byte[8192];
            int len;
            while ((len = is.read(buffer)) != -1) os.write(buffer, 0, len);
        }
        return target.length() > 0;
    }

    /**
     * 降采样 + 递减质量压缩到 {@link #TARGET_BYTES} 以内。
     *
     * @return 压缩后的文件；解码失败返回 null（调用方回落原图）
     */
    @Nullable
    private static File compress(File source, File dir) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(source.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        // inSampleSize 只接受 2 的幂，先算出不小于所需比例的那一档。
        int sample = 1;
        int longEdge = Math.max(bounds.outWidth, bounds.outHeight);
        while (longEdge / sample > MAX_EDGE) sample *= 2;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        Bitmap bitmap = BitmapFactory.decodeFile(source.getAbsolutePath(), options);
        if (bitmap == null) return null;

        File target = new File(dir, "pm_c_" + System.currentTimeMillis() + ".jpg");
        try {
            int quality = 88;
            while (true) {
                try (FileOutputStream os = new FileOutputStream(target)) {
                    bitmap.compress(Bitmap.CompressFormat.JPEG, quality, os);
                }
                if (target.length() <= TARGET_BYTES || quality <= MIN_QUALITY) break;
                quality -= 12;
            }
            return target.length() > 0 ? target : null;
        } catch (Exception e) {
            try { target.delete(); } catch (Exception ignored) {}
            return null;
        } finally {
            bitmap.recycle();
        }
    }
}
