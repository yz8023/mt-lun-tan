package com.forum.MT.model;

/**
 * 编辑提交结果。
 */
public class PostEditResult {

    private final boolean success;
    private final String message;

    public PostEditResult(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public static PostEditResult ok(String message) {
        return new PostEditResult(true, message);
    }

    public static PostEditResult fail(String message) {
        return new PostEditResult(false, message);
    }

    public boolean isSuccess() { return success; }

    public String getMessage() { return message; }
}
