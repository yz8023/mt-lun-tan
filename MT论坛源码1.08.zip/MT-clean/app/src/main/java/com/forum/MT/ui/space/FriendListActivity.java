package com.forum.MT.ui.space;
import com.forum.MT.ui.BaseActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.forum.MT.R;
import com.forum.MT.adapter.FriendAdapter;
import com.forum.MT.databinding.ActivityFriendListBinding;
import com.forum.MT.model.Friend;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.session.FollowerLevelSettingsManager;
import com.forum.MT.session.UserSessionManager;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 好友/关注/粉丝列表页（原生）
 * 支持 3 种模式：friends（好友）、following（关注）、followers（粉丝）
 */
public class FriendListActivity extends BaseActivity {

    // ★ 等级缓存：uid -> 等级。进程存活期间有效，刷新页面时避免重复请求资料页
    private static final java.util.Map<String, String> LEVEL_CACHE = new HashMap<>();
    // ★ 等级缓存时间戳：uid -> 缓存时间(ms)。超过 FRESH_MS 视为过期，重新请求
    private static final java.util.Map<String, Long> LEVEL_CACHE_TIME = new HashMap<>();
    private static final long FRESH_MS = 10 * 60 * 1000L; // 10 分钟新鲜期

    private ActivityFriendListBinding binding;
    private HttpClient httpClient;
    private FriendAdapter adapter;
    private String mode;
    private boolean viewingOtherUser;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFriendListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        httpClient = HttpClient.getInstance();
        mode = getIntent().getStringExtra("mode");

        String title;
        String listUrl;

        // 未指定目标 UID 时保持个人中心原行为，使用当前登录账号。
        String currentUid = UserSessionManager.getInstance().getUid(this);
        if (currentUid == null) currentUid = "";
        String targetUid = getIntent().getStringExtra("uid");
        String listUid = TextUtils.isEmpty(targetUid) ? currentUid : targetUid;
        String username = getIntent().getStringExtra("username");
        viewingOtherUser = !TextUtils.isEmpty(targetUid)
                && !targetUid.equals(currentUid);

        if ("following".equals(mode)) {
            title = viewingOtherUser && !TextUtils.isEmpty(username)
                    ? username + "的关注" : "我的关注";
            // 正确 URL: home.php?mod=follow&do=following&uid={uid}&mobile=2
            listUrl = HttpClient.BASE_URL + "home.php?mod=follow&do=following&uid="
                    + listUid + "&mobile=2";
        } else if ("followers".equals(mode)) {
            title = viewingOtherUser && !TextUtils.isEmpty(username)
                    ? username + "的粉丝" : "我的粉丝";
            listUrl = HttpClient.BASE_URL + "home.php?mod=follow&do=follower&uid="
                    + listUid + "&mobile=2";
        } else {
            title = "我的好友";
            listUrl = HttpClient.BASE_URL + "home.php?mod=space&do=friend&mobile=2";
        }

        binding.toolbar.setTitle(title);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        // ★ 移除返回箭头图标
        binding.toolbar.setNavigationIcon(null);

        adapter = new FriendAdapter(this);
        // 功能开关控制“我的关注”和“我的粉丝”；他人的关注、粉丝列表保持显示等级。
        boolean isOwnFollowList = !viewingOtherUser
                && ("following".equals(mode) || "followers".equals(mode));
        boolean showFollowLevel = !isOwnFollowList
                || FollowerLevelSettingsManager.isEnabled(this);
        adapter.setShowLevel(showFollowLevel);
        adapter.setOnItemClickListener((friend, position) -> {
            // ★ 修复：从 WebView 跳转改为原生用户资料页
            if (friend != null && friend.getUid() != null) {
                Intent intent = new Intent(this, UserProfileActivity.class);
                intent.putExtra("uid", friend.getUid());
                intent.putExtra("username", friend.getUsername());
                startActivity(intent);
            }
        });
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);

        binding.swipeRefresh.setOnRefreshListener(() -> loadData(listUrl, true));
        binding.swipeRefresh.setColorSchemeResources(R.color.primary);

        loadData(listUrl, false);
    }

    private void loadData(String listUrl) {
        loadData(listUrl, false);
    }

    private void loadData(String listUrl, boolean forceRefresh) {
        binding.progressBar.setVisibility(android.view.View.VISIBLE);
        binding.swipeRefresh.setEnabled(false);

        new Thread(() -> {
            try {
                String html = httpClient.get(listUrl);

                if (ForumParser.isLoginPage(html)) {
                    runOnUiThread(() -> {
                        binding.progressBar.setVisibility(android.view.View.GONE);
                        binding.swipeRefresh.setRefreshing(false);
                        binding.swipeRefresh.setEnabled(true);
                        Toast.makeText(this, "登录已过期，请重新登录", Toast.LENGTH_SHORT).show();
                        finish();
                    });
                    return;
                }

                List<Friend> friends = ForumParser.parseFriendList(html);

                // 开关控制“我的关注”和“我的粉丝”；他人的关注、粉丝列表始终补充等级。
                boolean isFollowList = "following".equals(mode) || "followers".equals(mode);
                boolean shouldLoadLevels = isFollowList
                        && (viewingOtherUser
                        || FollowerLevelSettingsManager.isEnabled(this));
                if (shouldLoadLevels) {
                    // 先显示基础数据（无等级）
                    runOnUiThread(() -> {
                        binding.progressBar.setVisibility(android.view.View.GONE);
                        binding.swipeRefresh.setRefreshing(false);
                        binding.swipeRefresh.setEnabled(true);

                        if (friends.isEmpty()) {
                            binding.recyclerView.setVisibility(android.view.View.GONE);
                            binding.tvEmpty.setVisibility(android.view.View.VISIBLE);
                        } else {
                            binding.recyclerView.setVisibility(android.view.View.VISIBLE);
                            binding.tvEmpty.setVisibility(android.view.View.GONE);
                            adapter.setFriendList(friends);
                        }
                    });

                    // 先应用缓存中的等级（仅当缓存新鲜时）
                    final long now = System.currentTimeMillis();
                    for (Friend f : friends) {
                        String cached = LEVEL_CACHE.get(f.getUid());
                        Long cachedTime = LEVEL_CACHE_TIME.get(f.getUid());
                        boolean fresh = cached != null && cachedTime != null
                                && (now - cachedTime) <= FRESH_MS;
                        if (fresh) {
                            f.setLevel(cached);
                        }
                    }
                    runOnUiThread(() -> adapter.notifyDataSetChanged());

                    // 后台批量获取未命中/已过期的用户等级
                    ExecutorService executor = Executors.newFixedThreadPool(4);
                    for (Friend f : friends) {
                        final String uid = f.getUid();
                        // 非强制刷新时：新鲜缓存直接跳过
                        if (!forceRefresh) {
                            String cached = LEVEL_CACHE.get(uid);
                            Long cachedTime = LEVEL_CACHE_TIME.get(uid);
                            boolean fresh = cached != null && cachedTime != null
                                    && (now - cachedTime) <= FRESH_MS;
                            if (fresh) continue; // 缓存新鲜，跳过
                        }
                        executor.execute(() -> {
                            try {
                                String profileUrl = HttpClient.BASE_URL + "home.php?mod=space&uid=" + uid + "&do=profile&mobile=2";
                                String profileHtml = httpClient.get(profileUrl);
                                String level = ForumParser.parseProfileLevel(profileHtml);
                                if (level != null && !level.isEmpty()) {
                                    LEVEL_CACHE.put(uid, level);
                                    LEVEL_CACHE_TIME.put(uid, System.currentTimeMillis());
                                    f.setLevel(level);
                                    // 仅更新该 item
                                    runOnUiThread(() -> {
                                        int pos = adapter.indexOf(f);
                                        if (pos >= 0) adapter.notifyItemChanged(pos);
                                    });
                                }
                            } catch (Exception ignored) {}
                        });
                    }
                    executor.shutdown();
                } else {
                    runOnUiThread(() -> {
                        binding.progressBar.setVisibility(android.view.View.GONE);
                        binding.swipeRefresh.setRefreshing(false);
                        binding.swipeRefresh.setEnabled(true);

                        if (friends.isEmpty()) {
                            binding.recyclerView.setVisibility(android.view.View.GONE);
                            binding.tvEmpty.setVisibility(android.view.View.VISIBLE);
                        } else {
                            binding.recyclerView.setVisibility(android.view.View.VISIBLE);
                            binding.tvEmpty.setVisibility(android.view.View.GONE);
                            adapter.setFriendList(friends);
                        }
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    binding.progressBar.setVisibility(android.view.View.GONE);
                    binding.swipeRefresh.setRefreshing(false);
                    binding.swipeRefresh.setEnabled(true);
                    Toast.makeText(this, "加载失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
}