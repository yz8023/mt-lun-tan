package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 管理「私信内容持久化」的设置。
 *
 * <p>开启后，每次打开会话拉取到的私信都会写入本地数据库，
 * 服务端记录过期后仍可在本地查看完整历史。默认关闭，避免未经用户同意占用存储。
 */
public class ChatPersistenceManager {
    private static final String PREF_NAME = "chat_persistence_pref";
    private static final String KEY_ENABLED = "enabled";

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
    }
}
