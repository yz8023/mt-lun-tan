package com.forum.MT.ui.message;
import com.forum.MT.ui.BaseFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.forum.MT.R;
import com.forum.MT.model.MessageTab;
import com.forum.MT.model.NoticeData;
import com.forum.MT.model.NoticeItem;
import com.forum.MT.model.PrivateMessageData;
import com.forum.MT.model.Message;

import java.util.List;

/**
 * 消息Tab Fragment - 通用列表页
 * 对应官方APK的4个Tab（私信/@我/帖子/系统通知）
 */
public class FragmentNoticeList extends BaseFragment {

    private static final String ARG_TAB_INDEX = "tab_index";

    private int tabIndex;
    private MessageViewModel viewModel;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvEmpty;
    private TextView tvError;
    private ProgressBar progressBar;

    private NoticeItemAdapter noticeAdapter;
    private PrivateMessageAdapter pmAdapter;
    private boolean isPrivateMessageTab;

    public static FragmentNoticeList newInstance(int tabIndex) {
        FragmentNoticeList fragment = new FragmentNoticeList();
        Bundle args = new Bundle();
        args.putInt(ARG_TAB_INDEX, tabIndex);
        fragment.setArguments(args);
        return fragment;
    }

    /** Tab 下标 → NoticeBadgeManager 分类 key。 */
    private static String getViewTypeForTab(int tabIndex) {
        switch (MessageTab.fromIndex(tabIndex)) {
            case AT_ME: return "mypost_at";
            case MY_POST: return "mypost_post";
            case OTHER_MESSAGES: return "system";
            case PRIVATE_MESSAGE:
            default: return "pm";
        }
    }

    private NoticeBadgeHost getBadgeHost() {
        Fragment parentFragment = getParentFragment();
        if (parentFragment instanceof NoticeBadgeHost) {
            return (NoticeBadgeHost) parentFragment;
        }
        if (getActivity() instanceof NoticeBadgeHost) {
            return (NoticeBadgeHost) getActivity();
        }
        return null;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            tabIndex = getArguments().getInt(ARG_TAB_INDEX, 0);
        }
        MessageTab tab = MessageTab.fromIndex(tabIndex);
        isPrivateMessageTab = (tab == MessageTab.PRIVATE_MESSAGE);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_notice_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recycler_view);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        tvEmpty = view.findViewById(R.id.tv_empty);
        tvError = view.findViewById(R.id.tv_error);
        progressBar = view.findViewById(R.id.progress_bar);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // 如果嵌套在 MessageFragment 中（即 MainActivity 的悬浮导航栏上方），
        // 需要给 RecyclerView 底部增加 padding，避免最后一条被底部导航栏遮挡
        boolean insideMessageFragment = getParentFragment() instanceof MessageFragment;
        if (insideMessageFragment) {
            float density = getResources().getDisplayMetrics().density;
            // 导航栏高度 68dp + 底部边距 12dp + 额外留白 8dp = 88dp
            int extraBottom = (int) (88f * density);
            recyclerView.setPadding(
                    recyclerView.getPaddingLeft(),
                    recyclerView.getPaddingTop(),
                    recyclerView.getPaddingRight(),
                    recyclerView.getPaddingBottom() + extraBottom);
        }

        if (isPrivateMessageTab) {
            pmAdapter = new PrivateMessageAdapter();
            pmAdapter.setContext(getContext());
            pmAdapter.setViewType("pm");
            pmAdapter.setBadgeHost(getBadgeHost());
            recyclerView.setAdapter(pmAdapter);
        } else {
            noticeAdapter = new NoticeItemAdapter();
            noticeAdapter.setContext(getContext());
            noticeAdapter.setViewType(getViewTypeForTab(tabIndex));
            noticeAdapter.setBadgeHost(getBadgeHost());
            recyclerView.setAdapter(noticeAdapter);
        }

        swipeRefresh.setOnRefreshListener(() -> {
            if (viewModel != null) {
                MessageTab tab = MessageTab.fromIndex(tabIndex);
                switch (tab) {
                    case PRIVATE_MESSAGE: viewModel.loadPrivateMessages(); break;
                    case AT_ME: viewModel.loadAtMeNotices(); break;
                    case MY_POST: viewModel.loadMyPostNotices(); break;
                    case OTHER_MESSAGES: viewModel.loadSystemNotices(); break;
                }
            }
        });

        // 获取ViewModel（从父Fragment或Activity）
        Fragment parentFragment = getParentFragment();
        if (parentFragment instanceof MessageFragment) {
            viewModel = ((MessageFragment) parentFragment).getViewModel();
        } else if (getActivity() != null) {
            viewModel = new ViewModelProvider(requireActivity()).get(MessageViewModel.class);
        }
        if (viewModel != null) {
            observeData();
        }
    }

    private void observeData() {
        if (viewModel == null) return;

        MessageTab tab = MessageTab.fromIndex(tabIndex);
        LiveData<?> liveData;
        boolean needsLoad = false;
        switch (tab) {
            case PRIVATE_MESSAGE:
                liveData = viewModel.getPrivateMessageData();
                {
                    PrivateMessageData d = viewModel.getPrivateMessageData().getValue();
                    needsLoad = d == null || (!d.isLoading() && d.getError() == null && d.getMessages().isEmpty());
                }
                break;
            case AT_ME:
                liveData = viewModel.getAtMeData();
                {
                    NoticeData d = viewModel.getAtMeData().getValue();
                    needsLoad = d == null || (!d.isLoading() && d.getError() == null && d.getItems().isEmpty());
                }
                break;
            case MY_POST:
                liveData = viewModel.getMyPostData();
                {
                    NoticeData d = viewModel.getMyPostData().getValue();
                    needsLoad = d == null || (!d.isLoading() && d.getError() == null && d.getItems().isEmpty());
                }
                break;
            case OTHER_MESSAGES:
                liveData = viewModel.getSystemNoticeData();
                {
                    NoticeData d = viewModel.getSystemNoticeData().getValue();
                    needsLoad = d == null || (!d.isLoading() && d.getError() == null && d.getItems().isEmpty());
                }
                break;
            default:
                return;
        }

        // 惰性加载：数据为空且未加载过时触发
        if (needsLoad) {
            switch (tab) {
                case PRIVATE_MESSAGE: viewModel.loadPrivateMessages(); break;
                case AT_ME: viewModel.loadAtMeNotices(); break;
                case MY_POST: viewModel.loadMyPostNotices(); break;
                case OTHER_MESSAGES: viewModel.loadSystemNotices(); break;
            }
        }

        liveData.observe(getViewLifecycleOwner(), new Observer<Object>() {
            @Override
            public void onChanged(Object data) {
                if (data instanceof PrivateMessageData) {
                    bindPrivateMessageData((PrivateMessageData) data);
                } else if (data instanceof NoticeData) {
                    bindNoticeData((NoticeData) data);
                }
            }
        });
    }

    private void bindPrivateMessageData(PrivateMessageData data) {
        swipeRefresh.setRefreshing(false);
        progressBar.setVisibility(View.GONE);

        if (data.isLoading()) {
            progressBar.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            tvError.setVisibility(View.GONE);
            return;
        }

        if (data.getError() != null) {
            tvError.setVisibility(View.VISIBLE);
            tvError.setText(data.getError());
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.GONE);
            return;
        }

        List<Message> messages = data.getMessages();
        if (messages == null || messages.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            if (pmAdapter != null) {
                pmAdapter.setMessages(messages);
            }
        }
    }

    private void bindNoticeData(NoticeData data) {
        swipeRefresh.setRefreshing(false);
        progressBar.setVisibility(View.GONE);

        if (data.isLoading()) {
            progressBar.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            tvError.setVisibility(View.GONE);
            return;
        }

        if (data.getError() != null) {
            tvError.setVisibility(View.VISIBLE);
            tvError.setText(data.getError());
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.GONE);
            return;
        }

        List<NoticeItem> items = data.getItems();
        if (items == null || items.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            if (noticeAdapter != null) {
                noticeAdapter.setItems(items);
            }
        }
    }
}