package com.forum.MT.model;

/**
 * 帖子类型（对应官方APK PostType）
 * 从发帖页面的 #typeid option 解析
 */
public class PostType {
    private final String id;
    private final String name;

    public PostType(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}
