package com.forum.MT.ui.widget;

import android.graphics.Typeface;
import android.text.Editable;
import android.text.Html;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.TypefaceSpan;

import org.xml.sax.XMLReader;

/**
 * 自定义 TagHandler：将 <code> 行内代码渲染为 浅色背景 + 等宽字体 + 指定文字色。
 * 背景色/文字色通过构造传入（由调用方从 InlineCodeManager 读取当前配置），
 * 颜色可自定义、随用户设置生效。
 *
 * <p>文字色使用高优先级 ForegroundColorSpan，确保压过外层 &lt;font color=...&gt;
 * 生成的默认优先级颜色 span，让用户自定义文字色始终生效。
 */
public class InlineCodeTagHandler implements Html.TagHandler {

    private final int mBgColor;
    private final int mTextColor;

    private int mCodeStart = -1;
    private boolean mInCode;

    public InlineCodeTagHandler(int bgColor, int textColor) {
        mBgColor = bgColor;
        mTextColor = textColor;
    }

    @Override
    public void handleTag(boolean opening, String tag, Editable output, XMLReader xmlReader) {
        if (!"code".equalsIgnoreCase(tag)) return;

        if (opening) {
            mCodeStart = output.length();
            mInCode = true;
            return;
        }

        // 闭合 </code>
        if (!mInCode || mCodeStart < 0) return;
        int start = mCodeStart;
        int end = output.length();
        // 修剪首尾空白（html 解析会把 code 首尾空白并入）
        CharSequence text = output.subSequence(start, end);
        int trimStart = 0;
        int trimEnd = text.length();
        while (trimStart < trimEnd && Character.isWhitespace(text.charAt(trimStart))) trimStart++;
        while (trimEnd > trimStart && Character.isWhitespace(text.charAt(trimEnd - 1))) trimEnd--;
        start += trimStart;
        end = start + (trimEnd - trimStart);

        if (start < end) {
            output.setSpan(new BackgroundColorSpan(mBgColor), start, end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            output.setSpan(new ForegroundColorSpan(mTextColor), start, end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            output.setSpan(new TypefaceSpan("monospace"), start, end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        mCodeStart = -1;
        mInCode = false;
    }
}