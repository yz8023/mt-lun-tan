package com.forum.MT.ui;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.forum.MT.ui.widget.BackgroundColorManager;
import com.forum.MT.ui.widget.StatusBarColorManager;

/**
 * 全局 Activity 基类。
 * 在 setContentView 后统一应用自定义背景颜色与状态栏颜色。
 */
public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setContentView(android.view.View view) {
        super.setContentView(view);
        BackgroundColorManager.apply(view);
        applyStatusBarColor();
    }

    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);
        BackgroundColorManager.apply(findViewById(android.R.id.content));
        applyStatusBarColor();
    }

    /** 根据用户设置应用状态栏颜色。 */
    private void applyStatusBarColor() {
        if (android.os.Build.VERSION.SDK_INT < 21) return;
        int color = StatusBarColorManager.resolveStatusBarColor();
        getWindow().setStatusBarColor(color);
        // 根据亮度自动调整状态栏图标颜色
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            int brightness = (int) (0.299 * android.graphics.Color.red(color)
                    + 0.587 * android.graphics.Color.green(color)
                    + 0.114 * android.graphics.Color.blue(color));
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (brightness > 128) {
                getWindow().getDecorView().setSystemUiVisibility(
                        flags | android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        flags & ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }
    }
}