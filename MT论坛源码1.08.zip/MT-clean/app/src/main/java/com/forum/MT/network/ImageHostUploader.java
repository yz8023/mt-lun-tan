package com.forum.MT.network;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * MT 论坛专用图床（img.binmt.cc，Lsky Pro）匿名上传客户端。
 *
 * <p>为什么不用论坛自带的 {@code misc.php?mod=swfupload} 附件上传：
 * 那条链路返回的是附件 aid，只能以 {@code [attachimg]aid[/attachimg]} 的形式
 * 挂在**帖子**上（依赖 uid/hash 上传授权，且授权是按版块签发的）。私信正文
 * 不走附件系统，服务端只认 {@code [img]url[/img]} 这种绝对 URL 形式。所以
 * 发私信图片必须先把图片传到图床拿到直链。
 *
 * <p>会话要求（与网页端一致）：
 * <ol>
 *   <li>图床是 Laravel 应用，{@code POST /upload} 会校验 CSRF。必须先 GET 首页，
 *       从 {@code <meta name="csrf-token">} 取 token，并携带同一次会话的
 *       {@code XSRF-TOKEN} / {@code lsky_pro_session} Cookie。</li>
 *   <li>{@code strategy_id} 是存储策略，网页端默认存储为 2。</li>
 * </ol>
 *
 * <p>刻意使用**独立** OkHttpClient 与独立 CookieJar，绝不复用
 * {@link HttpClient} 的会话：图床与论坛是不同域，把论坛登录 Cookie 带过去
 * 没有意义，还会把论坛会话暴露给第三方服务。
 */
public final class ImageHostUploader {

    private static final String BASE_URL = "https://img.binmt.cc";
    /** 网页端「默认存储」策略 id。 */
    private static final String STRATEGY_ID = "2";
    /** 图床限制单张 5MB。 */
    public static final long MAX_UPLOAD_BYTES = 5L * 1024 * 1024;

    private static final Pattern CSRF_PATTERN = Pattern.compile(
            "<meta\\s+name=[\"']csrf-token[\"']\\s+content=[\"']([^\"']+)[\"']",
            Pattern.CASE_INSENSITIVE);

    private ImageHostUploader() {}

    /** 一次上传的结果。 */
    public static final class Result {
        /** 图片直链。 */
        public final String url;
        /** 可直接插入正文的 BBCode，形如 {@code [img]url[/img]}。 */
        public final String bbcode;

        Result(String url, String bbcode) {
            this.url = url;
            this.bbcode = bbcode;
        }
    }

    /**
     * 上传一张图片。
     *
     * <p>阻塞调用，必须在后台线程执行。
     *
     * @throws IOException 网络失败、图床拒绝、或返回体无法解析
     */
    @NonNull
    public static Result upload(@NonNull File file) throws IOException {
        if (!file.isFile() || file.length() <= 0) {
            throw new IOException("图片文件不存在或为空");
        }
        if (file.length() > MAX_UPLOAD_BYTES) {
            throw new IOException("图片超过 5MB 上限");
        }

        OkHttpClient client = newClient();
        String csrf = fetchCsrfToken(client);
        if (TextUtils.isEmpty(csrf)) {
            throw new IOException("图床会话初始化失败：未获取到 CSRF Token");
        }

        RequestBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("strategy_id", STRATEGY_ID)
                .addFormDataPart("file", file.getName(),
                        RequestBody.create(MediaType.parse(guessMime(file.getName())), file))
                .build();

        Request request = new Request.Builder()
                .url(BASE_URL + "/upload")
                .header("User-Agent", "okhttp/4.12.0")
                .header("Accept", "application/json, text/javascript, */*; q=0.01")
                .header("X-Requested-With", "XMLHttpRequest")
                .header("X-CSRF-TOKEN", csrf)
                .header("Origin", BASE_URL)
                .header("Referer", BASE_URL + "/")
                .post(body)
                .build();

        try (Response response = client.newCall(request).execute()) {
            String text = response.body() == null ? "" : response.body().string();
            if (TextUtils.isEmpty(text)) {
                throw new IOException("图床无响应（HTTP " + response.code() + "）");
            }
            return parseResponse(text);
        }
    }

    /**
     * 解析图床返回的 JSON。
     *
     * <p>成功形态：{@code {"status":true,"data":{"links":{"url":"...","bbcode":"[img]...[/img]"}}}}
     * 失败时 {@code status=false}，{@code message} 是可直接展示的原因
     * （例如「上传队列已满」「不支持的图片格式」）。
     */
    @NonNull
    static Result parseResponse(@NonNull String text) throws IOException {
        try {
            JSONObject root = new JSONObject(text);
            boolean status = root.optBoolean("status", false);
            String message = root.optString("message", "").trim();
            JSONObject data = root.optJSONObject("data");
            JSONObject links = data == null ? null : data.optJSONObject("links");
            String url = links == null ? "" : links.optString("url", "").trim();
            String bbcode = links == null ? "" : links.optString("bbcode", "").trim();

            if (!status || TextUtils.isEmpty(url)) {
                throw new IOException(TextUtils.isEmpty(message) ? "图片上传失败" : message);
            }
            return new Result(url, TextUtils.isEmpty(bbcode) ? "[img]" + url + "[/img]" : bbcode);
        } catch (org.json.JSONException e) {
            // HTML 错误页（限流、维护、CSRF 失效）会走到这里。
            throw new IOException("图床返回格式异常");
        }
    }

    @Nullable
    private static String fetchCsrfToken(OkHttpClient client) throws IOException {
        Request request = new Request.Builder()
                .url(BASE_URL + "/")
                .header("User-Agent", "okhttp/4.12.0")
                .header("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
                .get()
                .build();
        try (Response response = client.newCall(request).execute()) {
            String html = response.body() == null ? "" : response.body().string();
            if (TextUtils.isEmpty(html)) return null;
            Matcher matcher = CSRF_PATTERN.matcher(html);
            return matcher.find() ? matcher.group(1) : null;
        }
    }

    /**
     * 独立客户端 + 会话内存 CookieJar。
     *
     * <p>每次上传新建：Cookie 只需在「取 token」与「提交」两次请求之间保持，
     * 长期持有反而会让 Laravel session 过期后拿着旧 XSRF 反复失败。
     */
    private static OkHttpClient newClient() {
        final java.util.Map<String, java.util.List<Cookie>> jar = new java.util.HashMap<>();
        return new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .cookieJar(new CookieJar() {
                    @Override
                    public void saveFromResponse(@NonNull HttpUrl url,
                                                 @NonNull java.util.List<Cookie> cookies) {
                        java.util.List<Cookie> existing = jar.get(url.host());
                        if (existing == null) {
                            existing = new java.util.ArrayList<>();
                            jar.put(url.host(), existing);
                        }
                        for (Cookie cookie : cookies) {
                            for (int i = existing.size() - 1; i >= 0; i--) {
                                if (existing.get(i).name().equals(cookie.name())) {
                                    existing.remove(i);
                                }
                            }
                            existing.add(cookie);
                        }
                    }

                    @NonNull
                    @Override
                    public java.util.List<Cookie> loadForRequest(@NonNull HttpUrl url) {
                        java.util.List<Cookie> cookies = jar.get(url.host());
                        return cookies == null ? java.util.Collections.emptyList() : cookies;
                    }
                })
                .build();
    }

    private static String guessMime(String name) {
        String lower = name == null ? "" : name.toLowerCase(java.util.Locale.ROOT);
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".gif")) return "image/gif";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".bmp")) return "image/bmp";
        return "image/jpeg";
    }
}
