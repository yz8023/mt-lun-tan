package com.forum.MT.ui.community;
import com.forum.MT.ui.BaseFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.forum.MT.R;
import com.forum.MT.adapter.ForumGridAdapter;
import com.forum.MT.databinding.FragmentCommunityBinding;
import com.forum.MT.ui.widget.RainbowBorderHelper;
import com.forum.MT.model.ForumCategory;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.session.UserSessionManager;
import com.forum.MT.session.SignInSoundPlayer;
import com.forum.MT.ui.forum.ForumDetailActivity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommunityFragment extends BaseFragment {

    private FragmentCommunityBinding binding;
    private HttpClient httpClient;
    private ForumGridAdapter forumGridAdapter;
    private String currentFormhash;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentCommunityBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RainbowBorderHelper.applyToCardViews(view, requireContext());

        httpClient = HttpClient.getInstance();
        // 圈子页面不启用下拉刷新，避免普通滑动被误触发。

        // Setup forum grid (2 columns, nested scrolling disabled)
        forumGridAdapter = new ForumGridAdapter(requireContext());
        binding.rvForumGrid.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        binding.rvForumGrid.setAdapter(forumGridAdapter);
        forumGridAdapter.setOnForumClickListener((forum, position) -> {
            Intent intent = new Intent(requireContext(), ForumDetailActivity.class);
            intent.putExtra("fid", forum.getFid());
            intent.putExtra("forumName", forum.getName());
            intent.putExtra("description", forum.getDescription());
            intent.putExtra("iconUrl", forum.getIconUrl());
            intent.putExtra("totalPosts", forum.getTotalPosts());
            intent.putExtra("totalThreads", forum.getTotalThreads());
            startActivity(intent);
        });

        // Ensure button text is centered (override any theme default)
        binding.btnSignIn.setGravity(android.view.Gravity.CENTER);

        // Setup sign-in button click
        binding.btnSignIn.setOnClickListener(v -> {
            // 检查登录状态
            if (!httpClient.isLoggedIn()) {
                Toast.makeText(requireContext(), R.string.login_required, Toast.LENGTH_SHORT).show();
                return;
            }
            // 自动签到成功后可能仍停留在社区页，先读取本地签到状态，避免重复请求和误播放音效。
            if (UserSessionManager.getInstance().isSignedInToday(requireContext())) {
                showAlreadySignedIn();
                return;
            }
            if (currentFormhash == null || currentFormhash.isEmpty()) {
                Toast.makeText(requireContext(), "formhash 获取失败，请刷新页面", Toast.LENGTH_SHORT).show();
                return;
            }
            // 禁用按钮防止重复点击
            binding.btnSignIn.setEnabled(false);
            binding.btnSignIn.setText("签到中...");
            performSignIn();
        });

        // Initial data load
        loadCommunityData();
    }

    /**
     * Load community page data: sign-in info, stats, and forum grid.
     * Also fetches descriptions for each forum from their individual pages.
     * Uses ForumParser.getForumlistMobileUrl() as data source.
     */
    /** 双击底部导航栏时触发：重新加载圈子页数据 */
    public void refreshData() {
        loadCommunityData();
    }

    private void loadCommunityData() {        // NestedScrollView 不显示刷新指示器，直接加载数据。

        new java.lang.Thread(() -> {
            try {
                // 加载论坛列表页
                String html = httpClient.get(ForumParser.getForumlistMobileUrl());
                ForumParser.CommunityPageData data = ForumParser.parseCommunityPage(html);

                // 判断列表页文字是否已显示"已签到"
                String signText = data.getSignInText();
                boolean listPageSignedIn = data.isAlreadySignedIn()
                        || (signText != null && signText.contains("已"));

                // 如果列表页未显示已签到，额外请求签到页面确认真实状态
                if (!listPageSignedIn) {
                    boolean signPageResult = fetchSignInStatusFromSignPage(data.getFormhash());
                    if (signPageResult) {
                        listPageSignedIn = true;
                    }
                }

                final boolean finalSignedIn = listPageSignedIn;

                requireActivity().runOnUiThread(() -> {
                    if (binding == null) return;

                    // 0. 提取 formhash
                    currentFormhash = data.getFormhash();
                    if (currentFormhash != null && !currentFormhash.isEmpty()) {
                        binding.btnSignIn.setEnabled(true);
                    }

                    // 1. Sign-in card — 一次更新，无二次刷新
                    if (finalSignedIn) {
                        showAlreadySignedIn();
                        UserSessionManager.getInstance().saveSignInDate(requireContext());
                    } else if (signText != null && !signText.isEmpty()) {
                        // 左边状态文字用服务器文本，按钮文字始终用资源字符串（避免服务器不可见字符污染）
                        String cleanText = signText
                                .replace((char)0x00A0, ' ').replace((char)0x200B, ' ')
                                .replace((char)0x200C, ' ').replace((char)0x200D, ' ')
                                .replace((char)0xFEFF, ' ').replace((char)0x3000, ' ')
                                .trim();
                        binding.tvSignInStatus.setText(cleanText);
                        binding.btnSignIn.setText(R.string.action_sign_in);
                    }

                    // 2. Stats cards
                    binding.tvStatsValue1.setText(String.valueOf(data.getTodayPosts()));
                    binding.tvStatsValue2.setText(String.valueOf(data.getYesterdayPosts()));
                    binding.tvStatsValue3.setText(String.valueOf(data.getTotalPosts()));
                    binding.tvStatsValue4.setText(String.valueOf(data.getTotalMembers()));

                    // 3. Forum grid
                    final List<ForumCategory.Forum> forums = data.getForums();
                    final List<ForumCategory.Forum> adapterForums;
                    if (forums != null && !forums.isEmpty()) {
                        forumGridAdapter.setForumList(forums);
                        adapterForums = forums;
                    } else {
                        // Fallback: use categories to flatten forums
                        List<ForumCategory> categories = data.getCategories();
                        if (categories != null) {
                            List<ForumCategory.Forum> allForums = new java.util.ArrayList<>();
                            for (ForumCategory cat : categories) {
                                if (cat.getForums() != null) {
                                    allForums.addAll(cat.getForums());
                                }
                            }
                            forumGridAdapter.setForumList(allForums);
                            adapterForums = allForums;
                        } else {
                            adapterForums = null;
                        }
                    }

                    // 4. 异步加载各个版块的描述（并发请求，逐个更新）
                    if (adapterForums != null && !adapterForums.isEmpty()) {
                        loadForumDescriptionsConcurrently(adapterForums);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() -> {
                    if (binding != null) {
                        binding.tvSignInStatus.setText(R.string.network_error);
                    }
                });
            }
        }).start();
    }

    /**
     * 并发加载各个版块的描述，逐个更新到适配器
     * 使用固定线程池，最多同时 4 个请求
     */
    private void loadForumDescriptionsConcurrently(List<ForumCategory.Forum> forums) {
        final java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newFixedThreadPool(4);
        for (final ForumCategory.Forum forum : forums) {
            executor.execute(() -> {
                try {
                    String forumUrl = ForumParser.getForumPageUrl(forum.getFid());
                    String forumHtml = httpClient.get(forumUrl);
                    String desc = ForumParser.parseForumDescription(forumHtml);
                    if (desc != null && !desc.isEmpty()) {
                        // 更新到主线程
                        if (getActivity() != null) {
                            requireActivity().runOnUiThread(() -> {
                                if (binding == null) return;
                                forumGridAdapter.updateDescription(forum, desc);
                            });
                        }
                    }
                } catch (Exception ignored) {
                    // 单个版块描述加载失败不影响其他版块
                }
            });
        }
        executor.shutdown();
    }

    /**
     * 从服务器响应中提取纯文本消息（去除 XML/CDATA 包裹）
     * 例如: <root><![CDATA[今日已签]]></root> → "今日已签"
     */
    private String extractSignMessage(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        // 尝试提取 <![CDATA[...]]> 中的内容
        java.util.regex.Pattern cdataPattern = java.util.regex.Pattern.compile("<!\\[CDATA\\[(.*?)\\]\\]>", java.util.regex.Pattern.DOTALL);
        java.util.regex.Matcher matcher = cdataPattern.matcher(raw);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }
        // 尝试提取 <root>...</root> 中的内容（非CDATA情况）
        java.util.regex.Pattern rootPattern = java.util.regex.Pattern.compile("<root>(.*?)</root>", java.util.regex.Pattern.DOTALL);
        matcher = rootPattern.matcher(raw);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }
        // 去掉可能的XML标签
        String cleaned = raw.replaceAll("<[^>]+>", "").trim();
        if (!cleaned.isEmpty()) return cleaned;
        return raw.trim();
    }

    /**
     * 请求签到页面获取真实签到状态
     * 论坛列表页的签到按钮文字始终显示"签到"，不反映真实状态，需要额外请求签到页面确认。
     */
    private boolean fetchSignInStatusFromSignPage(String formhash) {
        try {
            String signPageUrl = HttpClient.BASE_URL
                    + "plugin.php?id=k_misign:sign&mobile=2&formhash=" + formhash;
            String signHtml = httpClient.get(signPageUrl);
            return parseSignInStatusFromHtml(signHtml);
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * 解析签到页面 HTML 判断是否已签到
     */
    private boolean parseSignInStatusFromHtml(String html) {
        if (html == null) return false;
        return html.contains("今日已签")
                || html.contains("已签到")
                || html.contains("已经签到")
                || html.contains("签到成功");
    }

    private void showAlreadySignedIn() {
        if (binding == null) return;
        binding.tvSignInStatus.setText("今日已签到");
        binding.btnSignIn.setBackgroundResource(R.drawable.rounded_btn_success);
        binding.btnSignIn.setText("今日已签到");
        binding.btnSignIn.setEnabled(false);
    }

    /**
     * 执行签到请求
     */
    private void performSignIn() {
        new java.lang.Thread(() -> {
            try {
                String signUrl = HttpClient.BASE_URL + "plugin.php?id=k_misign:sign&operation=qiandao&format=text";
                Map<String, String> params = new HashMap<>();
                params.put("formhash", currentFormhash);
                String result = httpClient.post(signUrl, params);

                requireActivity().runOnUiThread(() -> {
                    if (binding == null) return;

                    // 提取纯文本消息
                    String msg = result != null ? extractSignMessage(result) : "";
                    // 服务器明确返回“已签到”时只更新状态；其余只要不是明确失败，就视为本次手动签到成功。
                    boolean alreadySigned = isAlreadySignedMessage(msg);
                    boolean isSuccess = !alreadySigned && isSuccessfulSignResponse(msg, result);

                    if (isSuccess || alreadySigned) {
                        String displayMsg = msg.isEmpty() ? (alreadySigned ? "今日已签到" : "签到成功") : msg;
                        Toast.makeText(requireContext(), displayMsg, Toast.LENGTH_SHORT).show();
                        showAlreadySignedIn();
                        if (isSuccess) {
                            playRandomSignInSound();
                        }
                        // 持久化签到状态
                        UserSessionManager.getInstance().saveSignInDate(requireContext());
                    } else {
                        String displayMsg = !msg.isEmpty() ? msg : (result != null ? result.trim() : "签到失败");
                        Toast.makeText(requireContext(), displayMsg, Toast.LENGTH_SHORT).show();
                        binding.btnSignIn.setEnabled(true);
                        binding.btnSignIn.setText(R.string.action_sign_in);
                    }
                });
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> {
                    if (binding == null) return;
                    Toast.makeText(requireContext(), "签到失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    binding.btnSignIn.setEnabled(true);
                    binding.btnSignIn.setText(R.string.action_sign_in);
                });
            }
        }).start();
    }
    private boolean isAlreadySignedMessage(String text) {
        if (text == null) return false;
        return text.contains("今日已签") || text.contains("已签到")
                || text.contains("已经签到") || text.contains("已签");
    }

    private boolean isSuccessfulSignResponse(String message, String rawResult) {
        String text = message == null ? "" : message.trim();
        String raw = rawResult == null ? "" : rawResult.trim();
        String lower = text.toLowerCase();
        if (text.isEmpty() && raw.isEmpty()) return false;
        return !(text.contains("失败") || text.contains("错误") || text.contains("异常")
                || text.contains("请先登录") || text.contains("没有权限") || text.contains("非法操作")
                || lower.contains("fail") || lower.contains("error"));
    }

    private void playRandomSignInSound() {
        if (isAdded() && getContext() != null) {
            SignInSoundPlayer.play(getContext());
        }
    }

    /**
     * 页面已取消下拉刷新，仅保留首次进入时的自动加载。
     */

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}