package com.forum.MT.ui.widget;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.forum.MT.ui.detail.ForumSmileyData;
import com.google.android.material.tabs.TabLayout;

import java.util.List;

/**
 * 论坛表情面板（贴吧 / QQ / 狗头三分类）的通用装配器。
 *
 * <p>原先这套 TabLayout + ViewPager + 网格的逻辑只存在于 ThreadDetailActivity 的回复弹窗里，
 * 发帖页则用了另一份写死的 15 个 Discuz 冒号表情，且那些 drawable 在本项目中并不存在，
 * 面板里显示的全是系统占位图。这里把面板装配抽成公共实现，
 * 让发帖页与评论区共用同一套 {@link ForumSmileyData} 本地资源，避免两处再次走偏。
 */
public final class SmileyPanelHelper {

    /** 表情被点击时的回调，参数为表情代码（如 {@code [doge]}）与其本地图标资源。 */
    public interface OnSmileySelectedListener {
        void onSmileySelected(@NonNull String code, int iconRes);
    }

    private SmileyPanelHelper() {}

    /**
     * 装配表情面板。重复调用是安全的：已初始化过的 TabLayout 会直接返回，
     * 便于放在"每次展开面板时调用"的位置。
     *
     * @param columns  网格列数，面板较窄时可传 6，较宽可传 7
     * @param iconDp   单个表情格子的边长（dp）
     */
    public static void setUp(@Nullable TabLayout tabs, @Nullable ViewPager pager,
                             int columns, final int iconDp,
                             @NonNull final OnSmileySelectedListener listener) {
        if (tabs == null || pager == null) return;
        if (tabs.getTabCount() > 0) return;

        final List<ForumSmileyData.SmileyGroup> groups = ForumSmileyData.ALL_GROUPS;
        for (ForumSmileyData.SmileyGroup g : groups) {
            tabs.addTab(tabs.newTab().setText(g.title));
        }

        final int gridColumns = columns > 0 ? columns : 6;
        pager.setAdapter(new PagerAdapter() {
            @Override
            public int getCount() { return groups.size(); }

            @Override
            public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
                return view == object;
            }

            @NonNull
            @Override
            public Object instantiateItem(@NonNull ViewGroup container, int position) {
                Context ctx = container.getContext();
                final float density = ctx.getResources().getDisplayMetrics().density;
                final List<ForumSmileyData.SmileyItem> items = groups.get(position).items;

                RecyclerView rv = new RecyclerView(ctx);
                rv.setLayoutParams(new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                int pad6 = (int) (6 * density + 0.5f);
                rv.setPadding(pad6, pad6, pad6, pad6);
                rv.setOverScrollMode(View.OVER_SCROLL_NEVER);
                rv.setLayoutManager(new GridLayoutManager(ctx, gridColumns));
                // 表情格子尺寸固定，开启该优化可省掉每次插入时的重新测量。
                rv.setHasFixedSize(true);
                rv.setItemAnimator(null);
                rv.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                    @NonNull
                    @Override
                    public RecyclerView.ViewHolder onCreateViewHolder(
                            @NonNull ViewGroup parent, int viewType) {
                        ImageView iv = new ImageView(parent.getContext());
                        int s = (int) (iconDp * density + 0.5f);
                        iv.setLayoutParams(new RecyclerView.LayoutParams(s, s));
                        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        int pad4 = (int) (4 * density + 0.5f);
                        iv.setPadding(pad4, pad4, pad4, pad4);
                        return new RecyclerView.ViewHolder(iv) {};
                    }

                    @Override
                    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder,
                                                 int position) {
                        ImageView iv = (ImageView) holder.itemView;
                        if (position >= items.size()) return;
                        final ForumSmileyData.SmileyItem item = items.get(position);
                        iv.setImageResource(item.iconRes);
                        // 无障碍：读屏时念出表情名称而不是"图片"。
                        iv.setContentDescription(item.code);
                        iv.setOnClickListener(v ->
                                listener.onSmileySelected(item.code, item.iconRes));
                    }

                    @Override
                    public int getItemCount() { return items.size(); }
                });
                container.addView(rv);
                return rv;
            }

            @Override
            public void destroyItem(@NonNull ViewGroup container, int position,
                                    @NonNull Object object) {
                container.removeView((View) object);
            }
        });

        final TabLayout tabLayout = tabs;
        final ViewPager viewPager = pager;
        pager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                TabLayout.Tab tab = tabLayout.getTabAt(position);
                if (tab != null) tab.select();
            }
        });
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition(), true);
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });
    }
}
