package com.forum.MT.network;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.FormBody;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.MultipartBody;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;

/**
 * 网络请求管理器
 * 基于 OkHttp 封装，支持会话保持（Cookie 持久化）
 */
public class HttpClient {
    public static final String BASE_URL = "https://bbs.binmt.cc/";
    public static final String MOBILE_SUFFIX = "&mobile=2";
    public static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
    public static final String DESKTOP_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    private static volatile HttpClient instance;
    private OkHttpClient client;
    private Map<String, List<Cookie>> cookieStore;
    private static final String PREF_NAME = "sqapp_cookies";
    private static final String KEY_COOKIES = "cookies_json";
    private static boolean initialized = false;
    /** 保存 Application 上下文，用于在每次请求后自动持久化 Cookie */
    private Context appContext;

    // 进程级请求节流：多个页面和后台任务共用同一客户端，必须统一控制请求节奏。
    private static final Object REQUEST_PACING_LOCK = new Object();
    private static final long MIN_REQUEST_GAP_MS = 300L;
    private static final long RATE_LIMIT_COOLDOWN_MS = 60_000L;
    private static long lastRequestStartedAt = 0L;
    private static long cooldownUntil = 0L;

    private HttpClient() {
        cookieStore = new HashMap<>();
        client = new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                // 图片在后台先被规范化，移动网络上传时仍可能超过普通页面请求时长。
                .readTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                // 所有同步请求统一节流，并在服务端限流后暂停后续请求。
                .addInterceptor(chain -> {
                    try {
                        awaitRequestSlot();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new IOException("request pacing interrupted", e);
                    }
                    Response response = chain.proceed(chain.request());
                    recordRateLimit(response.code());
                    return response;
                })
                // 阿里云 WAF acw_sc__v2 挑战自动求解（必须是应用层拦截器，
                // 网络拦截器拿到的是未解压 gzip 流，无法识别挑战页）
                .addInterceptor(new AcwChallengeInterceptor())
                .cookieJar(new CookieJar() {
                    @Override
                    public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                        String host = url.host();
                        List<Cookie> existing = cookieStore.get(host);
                        if (existing == null) {
                            existing = new ArrayList<>();
                            cookieStore.put(host, existing);
                        }
                        for (Cookie cookie : cookies) {
                            boolean found = false;
                            for (int i = 0; i < existing.size(); i++) {
                                if (existing.get(i).name().equals(cookie.name())) {
                                    existing.set(i, cookie);
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) {
                                existing.add(cookie);
                            }
                        }
                    }

                    @Override
                    public List<Cookie> loadForRequest(HttpUrl url) {
                        String host = url.host();
                        List<Cookie> cookies = cookieStore.get(host);
                        if (cookies == null) return Collections.emptyList();
                        // 过滤已过期 cookie，避免发送 stale acw_tc 触发 WAF 403 限流
                        long now = System.currentTimeMillis();
                        List<Cookie> valid = new ArrayList<>();
                        for (Cookie c : cookies) {
                            if (c.persistent() && c.expiresAt() <= now) continue;
                            valid.add(c);
                        }
                        return valid;
                    }
                })
                .build();
    }

    public static HttpClient getInstance() {
        if (instance == null) {
            synchronized (HttpClient.class) {
                if (instance == null) {
                    instance = new HttpClient();
                }
            }
        }
        return instance;
    }

    private static void awaitRequestSlot() throws InterruptedException {
        synchronized (REQUEST_PACING_LOCK) {
            long now = System.currentTimeMillis();
            long waitMs = Math.max(cooldownUntil - now, lastRequestStartedAt + MIN_REQUEST_GAP_MS - now);
            if (waitMs > 0L) {
                REQUEST_PACING_LOCK.wait(waitMs);
            }
            lastRequestStartedAt = System.currentTimeMillis();
        }
    }

    private static void recordRateLimit(int code) {
        if (code == 403 || code == 429) {
            synchronized (REQUEST_PACING_LOCK) {
                cooldownUntil = Math.max(cooldownUntil,
                        System.currentTimeMillis() + RATE_LIMIT_COOLDOWN_MS);
            }
            android.util.Log.w("HttpClient", "server returned " + code + "; pausing requests");
        }
    }

    /**
     * GET 请求
     */
    public String get(String url) throws Exception {
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                .get()
                .build();
        try (Response response = client.newCall(request).execute()) {
            String body = response.body() != null ? response.body().string() : "";
            // 请求完成后自动持久化 Cookie，确保服务端更新的 Cookie 及时落盘
            if (appContext != null) {
                commitCookieStore(appContext);
            }
            return body;
        }
    }

    /**
     * 官方方案：调用论坛的 findpost 重定向接口，让服务端直接返回目标页码。
     * 对应官方 APK 中 BinmtApiService.resolveFindPostRedirect。
     * 注意：这里必须用桌面版 UA，否则服务端可能返回移动版页面，导致拿不到 page=。
     *
     * @return 目标页码字符串，找不到时返回 null
     */
    public String resolveFindPostPage(String tid, String pid) throws Exception {
        String url = BASE_URL
                + "forum.php?mod=viewthread&goto=findpost&ptid=" + tid + "&pid=" + pid;
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                .get()
                .build();
        // 用一个不自动跟随重定向的 client，直接从 302 Location 提取 page
        OkHttpClient noRedirectClient = client.newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
        try (Response response = noRedirectClient.newCall(request).execute()) {
            // 302/301 重定向：从 Location 头提取 page
            String location = response.headers().get("Location");
            android.util.Log.d("MT_FindPost", "code=" + response.code() + " location=" + location);
            if (location != null) {
                String page = extractPageFromUrl(location, tid);
                if (page != null) return page;
                // Location 指向该帖但不含页码信息 → 说明就是第 1 页
                if (location.contains("tid=" + tid) || location.contains("thread-" + tid + "-")) {
                    return "1";
                }
            }

            // 如果没有重定向（可能 findpost 直接返回了页面内容）
            // 从最终 URL 中提取
            String finalUrl = response.request().url().toString();
            String page = extractPageFromUrl(finalUrl, tid);
            if (page != null) return page;

            // 再兜底：从响应体中提取。★ 不能用宽松的 [?&]page=(\d+)，
            // 因为整页 HTML 里第一个匹配几乎总是分页条的 page=1，会导致定位到错误页。
            // 只接受明确的跳转语义或“当前页”标记。
            if (response.body() != null) {
                String body = response.body().string();
                // JS / meta 跳转
                Matcher jsM = Pattern.compile(
                        "(?:window\\.location|location\\.href|URL=)[^;\"'>]*?"
                                + "(?:[?&]page=(\\d+)|thread-" + Pattern.quote(tid) + "-(\\d+)-)")
                        .matcher(body);
                if (jsM.find()) {
                    String p = jsM.group(1) != null ? jsM.group(1) : jsM.group(2);
                    if (p != null) return p;
                }
                // Discuz 分页条中的当前页：<strong>3</strong> 位于 div.pg 内
                Matcher curM = Pattern.compile(
                        "<div[^>]*class=\"[^\"]*\\bpg\\b[^\"]*\"[^>]*>.*?<strong>(\\d+)</strong>",
                        Pattern.DOTALL).matcher(body);
                if (curM.find()) {
                    return curM.group(1);
                }
            }
            return null;
        }
    }

    /**
     * 从 URL 中提取帖子页码。支持两种形式：
     *  - 查询串：forum.php?mod=viewthread&tid=123&page=3
     *  - 伪静态：thread-123-3-1.html
     */
    private static String extractPageFromUrl(String url, String tid) {
        if (url == null) return null;
        try {
            int idx = url.indexOf("page=");
            if (idx >= 0) {
                int start = idx + 5;
                int end = start;
                while (end < url.length() && Character.isDigit(url.charAt(end))) {
                    end++;
                }
                String page = url.substring(start, end);
                if (!page.isEmpty()) {
                    return page;
                }
            }
            // 伪静态形式 thread-<tid>-<page>-<x>.html
            if (tid != null && !tid.isEmpty()) {
                Matcher m = Pattern.compile("thread-" + Pattern.quote(tid) + "-(\\d+)-").matcher(url);
                if (m.find()) return m.group(1);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** GET 请求返回 byte[]（用于下载图片等二进制内容） */
    public byte[] getBytes(String url) throws Exception {
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .get()
                .build();
        try (Response response = client.newCall(request).execute()) {
            return response.body() != null ? response.body().bytes() : new byte[0];
        }
    }

    /**
     * GET 请求（强制使用桌面端 UA，用于获取桌面版页面中的 hash 等仅桌面版存在的字段）
     */
    public String getDesktop(String url) throws Exception {
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                .get()
                .build();
        try (Response response = client.newCall(request).execute()) {
            String body = response.body() != null ? response.body().string() : "";
            if (appContext != null) {
                commitCookieStore(appContext);
            }
            return body;
        }
    }

    /**
     * GET 请求并携带 Referer。
     *
     * <p>Discuz 的编辑页会校验来源，缺少 Referer 时部分模板只返回表单壳而不带原文。
     */
    public String getWithReferer(String url, String referer) throws Exception {
        Request.Builder builder = new Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                .header("Cache-Control", "no-cache")
                .get();
        if (referer != null && !referer.trim().isEmpty()) {
            builder.header("Referer", referer);
        }
        try (Response response = client.newCall(builder.build()).execute()) {
            String body = response.body() != null ? response.body().string() : "";
            if (appContext != null) {
                commitCookieStore(appContext);
            }
            return body;
        }
    }

    /**
     * POST 请求（表单提交）
     */
    public String post(String url, Map<String, String> params) throws Exception {
        FormBody.Builder formBuilder = new FormBody.Builder();
        if (params != null) {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                formBuilder.add(entry.getKey(), entry.getValue());
            }
        }
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post(formBuilder.build())
                .build();
        try (Response response = client.newCall(request).execute()) {
            String body = response.body() != null ? response.body().string() : "";
            // 请求完成后自动持久化 Cookie，确保登录等操作更新的 Cookie 及时落盘
            if (appContext != null) {
                commitCookieStore(appContext);
            }
            return body;
        }
    }

    /**
     * POST 请求，可额外携带 Referer（Discuz 的 inajax 评论回复校验来源页）
     */
    public String postWithReferer(String url, Map<String, String> params, String referer) throws Exception {
        FormBody.Builder formBuilder = new FormBody.Builder();
        if (params != null) {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                formBuilder.add(entry.getKey(), entry.getValue());
            }
        }
        Request.Builder builder = new Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post(formBuilder.build());
        if (referer != null && !referer.trim().isEmpty()) {
            builder.header("Referer", referer);
        }
        try (Response response = client.newCall(builder.build()).execute()) {
            String body = response.body() != null ? response.body().string() : "";
            if (appContext != null) {
                commitCookieStore(appContext);
            }
            return body;
        }
    }

    /**
     * POST 请求（表单提交）+ Referer + X-Requested-With，用于 Discuz inajax 接口。
     */
    public String postAjax(String url, Map<String, String> params, String referer) throws Exception {
        FormBody.Builder formBuilder = new FormBody.Builder();
        if (params != null) {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                formBuilder.add(entry.getKey(), entry.getValue());
            }
        }
        Request.Builder builder = new Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                .header("X-Requested-With", "XMLHttpRequest")
                .post(formBuilder.build());
        if (referer != null && !referer.trim().isEmpty()) {
            builder.header("Referer", referer);
        }
        try (Response response = client.newCall(builder.build()).execute()) {
            String body = response.body() != null ? response.body().string() : "";
            if (appContext != null) {
                commitCookieStore(appContext);
            }
            return body;
        }
    }

    /**
     * 上传文件（multipart/form-data）
     * 用于 Discuz! 附件上传接口 forum.php?mod=ajax&action=upload&mobile=2
     */
    public String uploadFile(String url, File file, String fieldName, Map<String, String> extraFields) throws IOException {
        return uploadFileWithUserAgent(url, file, fieldName, extraFields, DESKTOP_USER_AGENT);
    }

    /**
     * multipart 上传并显式指定 UA/Cookie 头。Discuz Comiis 的 swfupload
     * 令牌由桌面版页面生成，上传请求也使用桌面 UA 更稳定。
     */
    public String uploadFileWithUserAgent(String url, File file, String fieldName,
                                          Map<String, String> extraFields, String userAgent) throws IOException {
        return uploadFileWithUserAgent(url, file, fieldName, extraFields, userAgent,
                guessContentType(file));
    }

    /**
     * multipart 上传，允许调用方保留系统相册提供的真实 MIME 类型。
     * 部分 Discuz/Comiis 站点会同时校验文件名扩展名和 Content-Type；把 PNG、WebP、HEIC
     * 一律伪装为 jpg/octet-stream 会导致网页端能传、原生端被拒绝。
     */
    public String uploadFileWithUserAgent(String url, File file, String fieldName,
                                          Map<String, String> extraFields, String userAgent,
                                          String contentType) throws IOException {
        if (file == null || !file.isFile() || file.length() <= 0) {
            throw new IOException("上传文件不存在或为空");
        }

        // 登录可能发生在 WebView。仅当原生会话缺失时才拉取，避免空/旧 WebView Cookie
        // 覆盖仍然有效的 OkHttp 登录态；随后仍显式把当前 Cookie 写入上传请求。
        if (!isLoggedIn()) syncFromCookieManager();
        String cookieHeader = getCookieHeader();

        MultipartBody.Builder builder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(fieldName, file.getName(),
                        okhttp3.RequestBody.create(MediaType.parse(
                                contentType == null || contentType.trim().isEmpty()
                                        ? "application/octet-stream" : contentType), file));

        if (extraFields != null) {
            for (Map.Entry<String, String> entry : extraFields.entrySet()) {
                if (entry.getKey() != null && entry.getValue() != null) {
                    builder.addFormDataPart(entry.getKey(), entry.getValue());
                }
            }
        }

        okhttp3.RequestBody requestBody = builder.build();
        okhttp3.Request.Builder requestBuilder = new okhttp3.Request.Builder()
                .url(url)
                .header("User-Agent", userAgent == null || userAgent.isEmpty()
                        ? DESKTOP_USER_AGENT : userAgent)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                .header("Referer", BASE_URL)
                .post(requestBody);
        // 手动设置 Cookie 时 OkHttp 不会重复由 CookieJar 注入同名 Header。
        if (cookieHeader != null && !cookieHeader.isEmpty()) {
            requestBuilder.header("Cookie", cookieHeader);
        }

        try (okhttp3.Response response = client.newCall(requestBuilder.build()).execute()) {
            String body = response.body() != null ? response.body().string() : "";
            if (appContext != null) {
                commitCookieStore(appContext);
            }
            if (!response.isSuccessful()) {
                throw new IOException("上传请求失败（HTTP " + response.code() + "）");
            }
            return body;
        }
    }

    private static String guessContentType(File file) {
        String name = file == null ? "" : file.getName().toLowerCase(java.util.Locale.ROOT);
        if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
        if (name.endsWith(".png")) return "image/png";
        if (name.endsWith(".gif")) return "image/gif";
        if (name.endsWith(".webp")) return "image/webp";
        if (name.endsWith(".bmp")) return "image/bmp";
        if (name.endsWith(".heic") || name.endsWith(".heif")) return "image/heic";
        return "application/octet-stream";
    }

    /**
     * ★ 使用 HttpClient 的 OkHttpClient（含 Cookie）执行自定义 Request
     * 用于头像上传等需要保持会话的外部请求
     * 返回 okhttp3.Response（调用方记得关闭 response.body()）
     */
    public okhttp3.Response executeDirect(okhttp3.Request request) throws Exception {
        okhttp3.Response response = client.newCall(request).execute();
        // 请求完成后自动持久化 Cookie
        if (appContext != null) {
            commitCookieStore(appContext);
        }
        return response;
    }

    /**
     * 获取当前 cookie 值
     */
    /**
     * 运行时注入 Cookie（如 WAF 挑战求解出的 acw_sc__v2），写入 CookieJar。
     */
    public synchronized void addRuntimeCookie(String host, String name, String value) {
        addRuntimeCookie(host, name, value, Long.MAX_VALUE);
    }

    /**
     * 运行时注入带过期时间的 Cookie。
     * acw_sc__v2 必须设较短有效期（早于 acw_tc 的 1h），过期后自动重新挑战，
     * 避免「acw_sc__v2 仍在、acw_tc 已过期」导致 WAF 403 限流。
     */
    public synchronized void addRuntimeCookie(String host, String name, String value, long expiresAt) {
        Cookie.Builder b = new Cookie.Builder()
                .name(name)
                .value(value)
                .domain(host)
                .path("/")
                .expiresAt(expiresAt);
        Cookie cookie = b.build();
        List<Cookie> existing = cookieStore.get(host);
        if (existing == null) {
            existing = new ArrayList<>();
            cookieStore.put(host, existing);
        }
        for (int i = 0; i < existing.size(); i++) {
            if (existing.get(i).name().equals(name)) {
                existing.set(i, cookie);
                return;
            }
        }
        existing.add(cookie);
    }

    /**
     * 移除指定 host 下指定名称的 Cookie（用于 WAF 403 自愈：清掉 stale 的 acw cookie）。
     */
    public synchronized void removeRuntimeCookie(String host, String name) {
        List<Cookie> existing = cookieStore.get(host);
        if (existing == null) return;
        for (int i = existing.size() - 1; i >= 0; i--) {
            if (existing.get(i).name().equals(name)) existing.remove(i);
        }
    }

    public String getCookieValue(String host, String name) {
        List<Cookie> cookies = cookieStore.get(host);
        if (cookies != null) {
            for (Cookie c : cookies) {
                if (c.name().equals(name)) {
                    return c.value();
                }
            }
        }
        return null;
    }

/**
     * 获取指定 URL 域名的所有 Cookie 字符串（用于同步到 WebView）
     * 格式: "name1=value1; name2=value2"
     */
    public String getCookieString() {
        String host = HttpUrl.parse(BASE_URL).host();
        List<Cookie> cookies = cookieStore.get(host);
        if (cookies == null || cookies.isEmpty()) return "";

        StringBuilder sb = new StringBuilder();
        for (Cookie c : cookies) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(c.name()).append("=").append(c.value());
        }
        return sb.toString();
    }

    /**
     * 判断是否已登录（检查是否有 Discuz 的 auth cookie）
     * 遍历所有 cookie，查找名称以 _auth 结尾的 cookie
     * 兼容不同论坛实例的不同 cookiepre 前缀
     */
    public synchronized boolean isLoggedIn() {
        if (hasValidAuthCookie()) return true;

        // 登录可能刚在 WebView 中完成，或进程恢复时 CookieStore 尚未同步。
        // 只在本地没有有效 auth cookie 时同步，避免覆盖原生客户端已有会话。
        syncFromCookieManager();
        return hasValidAuthCookie();
    }

    private boolean hasValidAuthCookie() {
        String host = HttpUrl.parse(BASE_URL).host();
        List<Cookie> cookies = cookieStore.get(host);
        if (cookies == null) return false;
        long now = System.currentTimeMillis();
        for (Cookie c : cookies) {
            if (c.name().endsWith("_auth")
                    && !c.value().isEmpty()
                    && c.expiresAt() > now) {
                return true;
            }
        }
        return false;
    }
    /** 返回当前论坛域名的 Cookie Header，供需要显式携带会话的 multipart 请求使用。 */
    public synchronized String getCookieHeader() {
        return getCookieString();
    }

    /**
     * 从 WebView CookieManager 同步 Cookie。不同 Android/Chromium 版本对
     * BASE_URL、host URL 和末尾斜杠的处理不同，因此依次读取多个等价地址。
     */
    public synchronized void syncFromCookieManager() {
        try {
            CookieManager manager = CookieManager.getInstance();
            String[] urls = new String[] {
                    BASE_URL,
                    "https://bbs.binmt.cc",
                    "https://bbs.binmt.cc/",
                    "http://bbs.binmt.cc/"
            };
            StringBuilder merged = new StringBuilder();
            for (String url : urls) {
                String value = manager.getCookie(url);
                if (value == null || value.trim().isEmpty()) continue;
                if (merged.length() > 0) merged.append("; ");
                merged.append(value);
            }
            if (merged.length() == 0) return;

            String host = HttpUrl.parse(BASE_URL).host();
            List<Cookie> existing = cookieStore.get(host);
            if (existing == null) {
                existing = new ArrayList<>();
                cookieStore.put(host, existing);
            }
            String[] pairs = merged.toString().split(";\\s*");
            for (String pair : pairs) {
                int eq = pair.indexOf('=');
                if (eq <= 0) continue;
                String name = pair.substring(0, eq).trim();
                String value = pair.substring(eq + 1).trim();
                if (name.isEmpty() || value.isEmpty()) continue;
                Cookie old = null;
                for (Cookie c : existing) {
                    if (c.name().equals(name)) { old = c; break; }
                }
                Cookie.Builder b = new Cookie.Builder().name(name).value(value)
                        .domain(host).path("/").expiresAt(Long.MAX_VALUE);
                if (old != null && old.secure()) b.secure();
                boolean replaced = false;
                for (int i = 0; i < existing.size(); i++) {
                    if (existing.get(i).name().equals(name)) {
                        existing.set(i, b.build()); replaced = true; break;
                    }
                }
                if (!replaced) existing.add(b.build());
            }
            if (appContext != null) commitCookieStore(appContext);
        } catch (Exception ignored) {
        }
    }


    /**
     * 将 HttpClient CookieJar 中的 Cookie 同步到 Android WebView CookieManager。
     * 用于登录由原生 OkHttp 完成、随后需要在 WebView 或混合页面中继续使用登录态的场景。
     */
    public synchronized void syncToCookieManager() {
        try {
            CookieManager webViewCookieMgr = CookieManager.getInstance();
            String cookies = getCookieString();
            if (cookies == null || cookies.isEmpty()) return;
            String[] pairs = cookies.split(";\\s*");
            for (String pair : pairs) {
                if (pair == null || pair.trim().isEmpty()) continue;
                webViewCookieMgr.setCookie(BASE_URL, pair.trim());
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                webViewCookieMgr.flush();
            } else {
                CookieSyncManager.getInstance().sync();
            }
        } catch (Exception ignored) {
            // Cookie 同步失败不应阻断原生请求流程
        }
    }
/**
     * 初始化 — 从磁盘恢复持久化的 Cookie
     * 在 Application.onCreate() 或首次使用前调用一次
     * 初始化后自动从 WebView CookieManager 拉取一次 Cookie，确保双向同步
     */
    public synchronized void init(Context context) {
        if (initialized) return;
        initialized = true;
        this.appContext = context;
        restoreCookieStore(context);
        // ★ 初始化后立即从 WebView CookieManager 拉取 Cookie，确保双向同步
        syncFromCookieManager();
    }

    /**
     * 判断是否为 WAF 短期/会话型 cookie（不应持久化，按需重新获取）。
     */
    private static boolean isWafTransientCookie(String name) {
        if (name == null) return false;
        return "acw_sc__v2".equals(name) || "acw_tc".equals(name)
                || "cdn_sec_tc".equals(name);
    }

    /**
     * 将当前内存中的 Cookie 持久化到 SharedPreferences（AES-GCM 加密）
     * 在登录成功后调用
     */
    public synchronized void commitCookieStore(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            JSONArray cookiesArray = new JSONArray();

            for (Map.Entry<String, List<Cookie>> entry : cookieStore.entrySet()) {
                String host = entry.getKey();
                for (Cookie cookie : entry.getValue()) {
                    // WAF 短期 cookie（acw_sc__v2/acw_tc/cdn_sec_tc）不持久化：
                    // 它们与 IP/会话绑定且有效期短，持久化后重启会带 stale 值触发 403 限流。
                    // 这些 cookie 在每次请求时由拦截器按需重新求解/获取。
                    if (isWafTransientCookie(cookie.name())) continue;
                    JSONObject obj = new JSONObject();
                    obj.put("host", host);
                    obj.put("name", cookie.name());
                    obj.put("value", cookie.value());
                    obj.put("domain", cookie.domain());
                    obj.put("path", cookie.path());
                    obj.put("expiresAt", cookie.expiresAt());
                    obj.put("secure", cookie.secure());
                    obj.put("httpOnly", cookie.httpOnly());
                    obj.put("persistent", cookie.persistent());
                    cookiesArray.put(obj);
                }
            }

            // AES-GCM 加密后存储，防止文件被提取后直接读到登录态 cookie
            String encrypted = CookieCrypto.encrypt(cookiesArray.toString());
            if (encrypted != null) {
                prefs.edit().putString(KEY_COOKIES, encrypted).apply();
            }
        } catch (Exception ignored) {
            // 序列化失败不抛出
        }
    }

    /**
     * 从 SharedPreferences 恢复 Cookie 到内存（解密）
     * 在应用启动时调用
     */
    public synchronized void restoreCookieStore(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            String stored = prefs.getString(KEY_COOKIES, null);
            if (stored == null || stored.isEmpty()) return;

            // 优先按密文解密；解密失败则可能是旧版本明文，直接解析并随后迁移加密
            String json = CookieCrypto.decrypt(stored);
            boolean legacy = false;
            if (json == null) {
                json = stored;
                legacy = stored.trim().startsWith("[");
            }
            if (json == null || json.isEmpty()) return;

            JSONArray cookiesArray = new JSONArray(json);
            cookieStore.clear();

            for (int i = 0; i < cookiesArray.length(); i++) {
                JSONObject obj = cookiesArray.getJSONObject(i);
                String name = obj.getString("name");
                // 迁移：丢弃旧版误持久化的 WAF 短期 cookie，避免重启带 stale 值触发 403
                if (isWafTransientCookie(name)) continue;
                String host = obj.optString("host", HttpUrl.parse(BASE_URL).host());

                Cookie.Builder builder = new Cookie.Builder()
                        .name(obj.getString("name"))
                        .value(obj.getString("value"))
                        .domain(obj.optString("domain", HttpUrl.parse(BASE_URL).host()))
                        .path(obj.optString("path", "/"))
                        .expiresAt(obj.optLong("expiresAt", Long.MAX_VALUE));

                if (obj.optBoolean("secure")) {
                    builder.secure();
                }
                if (obj.optBoolean("httpOnly")) {
                    // Cookie.Builder 没有 httpOnly() 方法，跳过
                }

                Cookie cookie = builder.build();

                List<Cookie> cookies = cookieStore.get(host);
                if (cookies == null) {
                    cookies = new ArrayList<>();
                    cookieStore.put(host, cookies);
                }
                cookies.add(cookie);
            }

            // 旧明文迁移为加密存储
            if (legacy) {
                commitCookieStore(context);
            }
        } catch (Exception ignored) {
            // 反序列化失败时使用空 cookieStore（ignored）
        }
    }

    /**
     * 从字符串格式设置 Cookie（用于 Cookie 登录）。
     * 格式: "name1=value1; name2=value2; ..."
     */
    public synchronized void setCookiesFromString(String cookieStr) {
        if (cookieStr == null || cookieStr.trim().isEmpty()) return;
        String host = HttpUrl.parse(BASE_URL).host();
        List<Cookie> existing = cookieStore.get(host);
        if (existing == null) {
            existing = new ArrayList<>();
            cookieStore.put(host, existing);
        }
        String[] pairs = cookieStr.split(";\\s*");
        for (String pair : pairs) {
            if (pair == null || pair.trim().isEmpty()) continue;
            int eq = pair.indexOf('=');
            if (eq <= 0) continue;
            String name = pair.substring(0, eq).trim();
            String value = pair.substring(eq + 1).trim();
            if (name.isEmpty() || value.isEmpty()) continue;
            boolean replaced = false;
            for (int i = 0; i < existing.size(); i++) {
                if (existing.get(i).name().equals(name)) {
                    Cookie.Builder b = new Cookie.Builder()
                            .name(name).value(value)
                            .domain(host).path("/")
                            .expiresAt(Long.MAX_VALUE);
                    existing.set(i, b.build());
                    replaced = true;
                    break;
                }
            }
            if (!replaced) {
                Cookie.Builder b = new Cookie.Builder()
                        .name(name).value(value)
                        .domain(host).path("/")
                        .expiresAt(Long.MAX_VALUE);
                existing.add(b.build());
            }
        }
        if (appContext != null) commitCookieStore(appContext);
    }

    /**
     * 清除所有 Cookie（内存 + 磁盘）
     */
    public void clearCookies() {
        cookieStore.clear();
    }

    /**
     * 清除所有 Cookie（内存 + 磁盘 + WebView）
     * 在登出时调用
     * ★ 必须同时清除 WebView CookieManager 的明文 SQLite，
     *   否则 root 设备可从 app_webview/Default/Cookies 读取登录态。
     */
    public void clearCookies(Context context) {
        cookieStore.clear();
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            prefs.edit().remove(KEY_COOKIES).apply();
        } catch (Exception ignored) {
        }
        // ★ 清除 WebView CookieManager 中的明文 cookie（防 root 抓取）
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
            } else {
                //noinspection deprecation
                CookieManager.getInstance().removeAllCookie();
                CookieSyncManager.getInstance().sync();
            }
        } catch (Exception ignored) {
        }
    }
}