package com.forum.MT.util;

import android.content.Context;
import android.text.TextUtils;

import com.forum.MT.model.ChatMessage;
import com.forum.MT.ui.detail.ForumSmileyData;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 判定"本地发出的私信原文"与"服务端返回的私信消息"是否是同一条。
 *
 * <p>两侧文本天生不可直接比较：
 * <ul>
 *   <li>本地原文里的表情是 {@code [#呵呵]} 这样的表情代码（发送时原样提交）；</li>
 *   <li>服务端把表情渲染成 {@code <img src=".../smiley/qq/qq006.gif">}，
 *       纯文本里一个字都不留；</li>
 *   <li>换行与连续空白在服务端 HTML 里形态不定。</li>
 * </ul>
 *
 * <p>因此这里把两侧都折算成同一套"规范键"：普通文字去掉全部空白后原样保留，
 * 表情统一折算成本地 drawable 资源 id（{@code #2130903123}）。表情代码经
 * {@link ForumSmileyData#iconForCode} 取 id，服务端图片 URL 经
 * {@link ForumSmileyData#iconForUrl} 取同一个 id，于是"只发了一个表情"的消息
 * 也能精确匹配，而不会像"剥掉全部表情码"那样退化成空串、导致两条不同表情
 * 的消息互相误判。
 */
public final class PmContentMatcher {

    private PmContentMatcher() {}

    /** 表情代码：{@code [#呵呵]} / {@code [doge]} / {@code [qq006]}。 */
    private static final Pattern CODE_PATTERN =
            Pattern.compile("\\[[^\\[\\]]{1,16}\\]");
    private static final Pattern WHITESPACE_PATTERN = Pattern.compile("\\s+");
    /** 精简 HTML 里的 {@code <img src="...">}，src 允许单双引号。 */
    private static final Pattern IMG_SRC_PATTERN = Pattern.compile(
            "<img[^>]*src\\s*=\\s*([\"'])(.*?)\\1", Pattern.CASE_INSENSITIVE);
    /** 无法映射到本地资源的表情，用同一个记号占位。 */
    private static final String UNKNOWN_SMILEY = "#?";

    /**
     * 本地原文 → 规范键。
     *
     * @param content 用户在输入框里输入、原样提交给服务端的文本
     */
    public static String fromLocalText(Context context, String content) {
        if (TextUtils.isEmpty(content)) return "";
        StringBuilder sb = new StringBuilder();
        Matcher matcher = CODE_PATTERN.matcher(content);
        int last = 0;
        while (matcher.find()) {
            appendText(sb, content.substring(last, matcher.start()));
            String code = matcher.group();
            int resId = ForumSmileyData.iconForCode(code);
            // 查不到的方括号内容不是表情，而是用户真的输入了方括号，原样保留。
            if (resId != 0) sb.append('#').append(resId);
            else appendText(sb, code);
            last = matcher.end();
        }
        appendText(sb, content.substring(last));
        return sb.toString();
    }

    /**
     * 服务端消息 → 规范键。
     *
     * <p>优先用 {@link ChatMessage#getContentHtml()}：那里保留了表情的真实图片
     * URL，能换算出与本地表情代码相同的资源 id。没有富文本（旧版本持久化下来的
     * 历史消息）时退化到纯文本，此时表情记号形如 {@code [qq006]}，
     * {@link ForumSmileyData#iconForCode} 查不到，只能按普通文本比较。
     */
    public static String fromServerMessage(Context context, ChatMessage message) {
        if (message == null) return "";
        String html = message.getContentHtml();
        if (TextUtils.isEmpty(html) || html.indexOf('<') < 0) {
            return fromLocalText(context, message.getContent());
        }
        StringBuilder sb = new StringBuilder();
        Matcher matcher = IMG_SRC_PATTERN.matcher(html);
        int last = 0;
        while (matcher.find()) {
            appendText(sb, stripTags(html.substring(last, matcher.start())));
            String src = unescape(matcher.group(2));
            int resId = ForumSmileyData.iconForUrl(context, src);
            sb.append(resId != 0 ? "#" + resId : UNKNOWN_SMILEY);
            last = matcher.end();
        }
        appendText(sb, stripTags(html.substring(last)));
        return sb.toString();
    }

    /** 本地原文与某条服务端消息是否为同一条。 */
    public static boolean matches(Context context, String localText, ChatMessage server) {
        if (server == null) return false;
        // 完全相同的原文直接判定（服务端偶尔原样回显）。
        if (!TextUtils.isEmpty(localText)
                && TextUtils.equals(localText, server.getContent())) {
            return true;
        }
        String local = fromLocalText(context, localText);
        if (local.isEmpty()) return false;
        return local.equals(fromServerMessage(context, server));
    }

    /**
     * 服务端消息列表里是否已经包含这条本地原文。
     *
     * <p>只比对自己发出的、非待确认的消息：对方发来的内容即使文字相同也不是
     * 同一条，本地回显自己更不能当作服务端确认。
     */
    public static boolean containsLocalText(Context context,
                                            List<ChatMessage> serverMessages,
                                            String localText) {
        if (serverMessages == null || serverMessages.isEmpty()) return false;
        for (ChatMessage m : serverMessages) {
            if (m == null || !m.isOutgoing() || m.isPending()) continue;
            if (matches(context, localText, m)) return true;
        }
        return false;
    }

    /** 统计列表中"自己发出且已被服务端确认"的消息条数，用于按条数增长兜底判定。 */
    public static int countConfirmedOutgoing(List<ChatMessage> messages) {
        if (messages == null) return 0;
        int count = 0;
        for (ChatMessage m : messages) {
            if (m != null && m.isOutgoing() && !m.isPending()) count++;
        }
        return count;
    }

    /** 追加普通文字：去掉全部空白，规避两侧换行/缩进形态不一致。 */
    private static void appendText(StringBuilder sb, String text) {
        if (TextUtils.isEmpty(text)) return;
        sb.append(WHITESPACE_PATTERN.matcher(text).replaceAll(""));
    }

    /** 精简 HTML 里除 img 之外只可能有 {@code <br>}，直接去标签即可。 */
    private static String stripTags(String html) {
        if (TextUtils.isEmpty(html)) return "";
        return unescape(html.replaceAll("<[^>]*>", ""));
    }

    private static String unescape(String text) {
        if (TextUtils.isEmpty(text)) return "";
        return text.replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&");
    }
}
