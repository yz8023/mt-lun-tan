package com.forum.MT.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.SpannableStringBuilder;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.ChatMessage;
import com.forum.MT.ui.detail.FixNestedScrollLinkMovementMethod;
import com.forum.MT.ui.detail.ForumSmileyData;
import com.forum.MT.ui.widget.AnimatedSmileyLoader;
import com.forum.MT.ui.widget.ChatColorManager;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 私信聊天消息适配器。
 *
 * <p>设计要点：
 * <ul>
 *   <li>左右消息拆成两套 itemViewType/布局，避免单布局里同时保留两条消息树、
 *       每次 bind 都要切换两个分支的可见性（旧实现每个 item 都持有 8 个 View，
 *       其中一半永远是 GONE，仍然参与 inflate 与 findViewById）。</li>
 *   <li>日期分隔胶囊内联在 item 顶部，只在"与上一条消息日期不同"时显示，
 *       不再每条消息都重复渲染日期。</li>
 *   <li>URL 正则改为静态单例（旧实现每次 bind 都 Pattern.compile 一个
 *       长正则并立即丢弃，纯浪费）。</li>
 *   <li>取消 setTextIsSelectable(true)：它会为每个气泡创建
 *       Editable/光标控制器，在列表里开销明显；长按复制改为整条消息级别的回调。</li>
 * </ul>
 */
public class ChatMessageAdapter extends RecyclerView.Adapter<ChatMessageAdapter.Holder> {

    private static final int TYPE_IN = 0;
    private static final int TYPE_OUT = 1;

    private final Context context;
    private final List<ChatMessage> items = new ArrayList<>();
    private static Pattern sUrlPattern = null;
    /** 表情代码，如 {@code [doge]} / {@code [呵呵]}。 */
    private static final Pattern SMILEY_CODE_PATTERN =
            Pattern.compile("\\[[^\\[\\]\\s]{1,16}\\]");
    /** BBCode 图片，如 {@code [img]https://.../a.jpg[/img]}。 */
    private static final Pattern BBCODE_IMG_PATTERN = Pattern.compile(
            "\\[img(?:=[^\\]]*)?\\]\\s*([^\\[\\]\\r\\n]+?)\\s*\\[/img\\]",
            Pattern.CASE_INSENSITIVE);
    private OnMessageLongClickListener longClickListener;

    // 自定义配色一次性解析并缓存：SharedPreferences 不能在 bind 热路径里反复读。
    // ChatActivity 在 onResume 时调用 reloadColors() 同步主题设置页的改动。
    private int bubbleInColor;
    private int bubbleOutColor;
    private int textInColor;
    private int textOutColor;
    private int linkInColor;
    private int linkOutColor;

    /** 长按消息回调（用于复制等操作）。 */
    public interface OnMessageLongClickListener {
        void onMessageLongClick(ChatMessage message);
    }

    private static Pattern getUrlPattern() {
        if (sUrlPattern == null) {
            sUrlPattern = Pattern.compile(
                "(?<![a-zA-Z0-9_])" +
                "(?:" +
                    "https?://" +
                    "[a-zA-Z0-9.\\-]+" +
                    "(?::\\d+)?" +
                    "(?:/[a-zA-Z0-9\\-._/?=&%#@+~:]*)" +
                    "|" +
                    "https?://" +
                    "[a-zA-Z0-9.\\-]+" +
                    "(?::\\d+)?" +
                    "|" +
                    "www\\." +
                    "[a-zA-Z0-9.\\-]+" +
                    "(?::\\d+)?" +
                    "(?:/[a-zA-Z0-9\\-._/?=&%#@+~:]*)" +
                    "|" +
                    "www\\." +
                    "[a-zA-Z0-9.\\-]+" +
                    "(?::\\d+)?" +
                ")" +
                "(?![a-zA-Z0-9_/])" +
                "(?<![,.;:!?)\\]>'\u201d\u201c])",
                Pattern.CASE_INSENSITIVE
            );
        }
        return sUrlPattern;
    }

    public ChatMessageAdapter(Context context) {
        this.context = context;
        setHasStableIds(false);
        reloadColors();
    }

    /**
     * 重新读取自定义配色。主题设置页改色后需要调用（ChatActivity.onResume），
     * 否则已创建的 adapter 仍用旧值。
     *
     * @return 颜色是否发生变化，调用方可据此决定是否刷新列表
     */
    public boolean reloadColors() {
        int in = ChatColorManager.resolveBubbleInColor(context);
        int out = ChatColorManager.resolveBubbleOutColor(context);
        int tIn = ChatColorManager.resolveTextInColor(context);
        int tOut = ChatColorManager.resolveTextOutColor(context);
        int lIn = ChatColorManager.resolveLinkInColor(context);
        int lOut = ChatColorManager.resolveLinkOutColor(context);

        boolean changed = in != bubbleInColor || out != bubbleOutColor
                || tIn != textInColor || tOut != textOutColor
                || lIn != linkInColor || lOut != linkOutColor;

        bubbleInColor = in;
        bubbleOutColor = out;
        textInColor = tIn;
        textOutColor = tOut;
        linkInColor = lIn;
        linkOutColor = lOut;
        return changed;
    }

    public void setOnMessageLongClickListener(OnMessageLongClickListener listener) {
        this.longClickListener = listener;
    }

    /**
     * 整表刷新。会话轮询返回的列表通常与当前列表高度重合，
     * 若内容完全相同则直接跳过刷新，避免无意义的重新绑定与滚动位置抖动。
     */
    public void setItems(List<ChatMessage> list) {
        setItems(list, false);
    }

    /**
     * @param force 强制刷新，跳过内容相同的短路判断。
     *              本地回显对象是被原地修改的（例如 pending → 非 pending），
     *              此时新旧列表里是同一个对象引用，{@link #isSameContent} 会
     *              判定"内容没变"并跳过刷新，导致状态改变无法体现到界面上。
     */
    public void setItems(List<ChatMessage> list, boolean force) {
        if (!force && isSameContent(list)) return;

        final List<ChatMessage> next = new ArrayList<>();
        if (list != null) next.addAll(list);

        // 用 DiffUtil 而不是 notifyDataSetChanged()：进入会话时列表会被渲染两次
        // （先本地缓存，再服务端返回），整表刷新会让每条消息重新 bind，
        // 已经显示出来的图片 span 被丢弃重建，于是又从占位框走一遍异步加载 ——
        // 这就是"上一张图片在进入私信时闪一下"的直接原因。
        // 逐项比对后，未变化的消息不会重新 bind，图片保持原样。
        final List<ChatMessage> previous = new ArrayList<>(items);
        androidx.recyclerview.widget.DiffUtil.DiffResult result =
                androidx.recyclerview.widget.DiffUtil.calculateDiff(
                        new androidx.recyclerview.widget.DiffUtil.Callback() {
                            @Override
                            public int getOldListSize() { return previous.size(); }

                            @Override
                            public int getNewListSize() { return next.size(); }

                            @Override
                            public boolean areItemsTheSame(int oldPos, int newPos) {
                                return isSameMessage(previous.get(oldPos), next.get(newPos));
                            }

                            @Override
                            public boolean areContentsTheSame(int oldPos, int newPos) {
                                return isSameRendering(previous.get(oldPos), next.get(newPos));
                            }
                        });

        items.clear();
        items.addAll(next);
        // 临时诊断：定位"重进会话时旧图闪一下"。排查完成后移除。
        android.util.Log.w("MT_FLASH", "setItems force=" + force
                + " old=" + previous.size() + " new=" + next.size());
        result.dispatchUpdatesTo(new androidx.recyclerview.widget.ListUpdateCallback() {
            @Override
            public void onInserted(int position, int count) {
                android.util.Log.w("MT_FLASH", "  diff insert pos=" + position + " n=" + count);
                notifyItemRangeInserted(position, count);
            }

            @Override
            public void onRemoved(int position, int count) {
                android.util.Log.w("MT_FLASH", "  diff remove pos=" + position + " n=" + count);
                notifyItemRangeRemoved(position, count);
            }

            @Override
            public void onMoved(int fromPosition, int toPosition) {
                android.util.Log.w("MT_FLASH", "  diff move " + fromPosition + "->" + toPosition);
                notifyItemMoved(fromPosition, toPosition);
            }

            @Override
            public void onChanged(int position, int count, @Nullable Object payload) {
                android.util.Log.w("MT_FLASH", "  diff change pos=" + position + " n=" + count);
                notifyItemRangeChanged(position, count, payload);
            }
        });
    }

    /**
     * 是否为同一条消息。
     *
     * <p>没有服务端消息 id 可用，只能靠"方向 + 时间 + 正文"识别。
     * 这里刻意不比 pending / contentHtml：本地回显被服务端确认后，
     * pending 会翻转、contentHtml 会从 null 变成解析结果，
     * 但它仍是同一条消息，不应该被当成"删一条又插一条"。
     */
    private boolean isSameMessage(ChatMessage a, ChatMessage b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        return a.isOutgoing() == b.isOutgoing()
                && TextUtils.equals(a.getDate(), b.getDate())
                && TextUtils.equals(a.getTime(), b.getTime())
                && TextUtils.equals(a.getContent(), b.getContent());
    }

    /** 同一条消息的显示内容是否完全一致；不一致才需要重新 bind。 */
    private boolean isSameRendering(ChatMessage a, ChatMessage b) {
        if (a == null || b == null) return false;
        return a.isPending() == b.isPending()
                && TextUtils.equals(a.getContentHtml(), b.getContentHtml())
                && TextUtils.equals(a.getAvatarUrl(), b.getAvatarUrl());
    }

    /** 追加一条消息（发送后的本地回显）。 */
    public void addItem(ChatMessage item) {
        if (item == null) return;
        items.add(item);
        notifyItemInserted(items.size() - 1);
    }

    /**
     * 按对象身份刷新单条消息（本地回显的 pending 标记被原地改写后调用）。
     *
     * <p>不能依赖 {@link #setItems} 刷新：新旧列表里是同一个对象引用，
     * {@link #isSameContent} 会判定"内容没变"直接跳过。
     *
     * @return 是否找到并刷新了该消息
     */
    public boolean notifyItemChangedByIdentity(ChatMessage item) {
        if (item == null) return false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i) == item) {
                notifyItemChanged(i);
                return true;
            }
        }
        return false;
    }

    @Nullable
    public ChatMessage getItem(int position) {
        if (position < 0 || position >= items.size()) return null;
        return items.get(position);
    }

    /** 判断服务端返回的列表与当前显示内容是否完全一致。 */
    private boolean isSameContent(List<ChatMessage> list) {
        int size = list == null ? 0 : list.size();
        if (size != items.size()) return false;
        for (int i = 0; i < size; i++) {
            ChatMessage a = items.get(i);
            ChatMessage b = list.get(i);
            if (a == b) continue;
            if (a == null || b == null) return false;
            if (a.isOutgoing() != b.isOutgoing()) return false;
            if (a.isPending() != b.isPending()) return false;
            if (!TextUtils.equals(a.getContent(), b.getContent())) return false;
            if (!TextUtils.equals(a.getContentHtml(), b.getContentHtml())) return false;
            if (!TextUtils.equals(a.getTime(), b.getTime())) return false;
            if (!TextUtils.equals(a.getDate(), b.getDate())) return false;
            if (!TextUtils.equals(a.getAvatarUrl(), b.getAvatarUrl())) return false;
        }
        return true;
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).isOutgoing() ? TYPE_OUT : TYPE_IN;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = viewType == TYPE_OUT ? R.layout.item_chat_out : R.layout.item_chat_in;
        Holder holder = new Holder(LayoutInflater.from(context).inflate(layout, parent, false));
        // 配色只随 viewType 变化，在创建时套一次即可，不必进 bind 热路径。
        applyColors(holder, viewType == TYPE_OUT);
        return holder;
    }

    /** 把自定义配色套到气泡上：底色、正文色、链接色。 */
    private void applyColors(Holder holder, boolean outgoing) {
        int bubble = outgoing ? bubbleOutColor : bubbleInColor;
        int textColor = outgoing ? textOutColor : textInColor;
        int linkColor = outgoing ? linkOutColor : linkInColor;

        // 气泡背景是 shape drawable，mutate() 后单独改色，
        // 否则会污染同一份 ConstantState 下的其他 View。
        android.graphics.drawable.Drawable bg = holder.text.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            android.graphics.drawable.GradientDrawable shape =
                    (android.graphics.drawable.GradientDrawable) bg.mutate();
            shape.setColor(bubble);
        }
        holder.text.setTextColor(textColor);
        holder.text.setLinkTextColor(linkColor);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        ChatMessage m = items.get(position);

        android.util.Log.w("MT_FLASH", "onBind pos=" + position
                + " pending=" + m.isPending()
                + " hasHtml=" + !TextUtils.isEmpty(m.getContentHtml()));
        renderContent(h.text, m);

        // 日期胶囊：仅在与上一条消息日期不同时显示（首条总显示）。
        String date = m.getDate();
        boolean showDate = !TextUtils.isEmpty(date);
        if (showDate && position > 0) {
            String previousDate = items.get(position - 1).getDate();
            showDate = !TextUtils.equals(date, previousDate);
        }
        if (showDate) {
            h.date.setText(date);
            h.date.setVisibility(View.VISIBLE);
        } else {
            h.date.setVisibility(View.GONE);
        }

        h.time.setText(m.getTime() == null ? "" : m.getTime());
        h.time.setVisibility(TextUtils.isEmpty(m.getTime()) ? View.GONE : View.VISIBLE);

        if (h.sending != null) {
            h.sending.setVisibility(m.isPending() ? View.VISIBLE : View.GONE);
        }

        String avatarUrl = m.getAvatarUrl();
        if (isContextDestroyed()) {
            // 页面已在销毁流程中，不再发起任何图片请求。
            h.avatar.setImageResource(R.drawable.ic_account);
        } else if (!TextUtils.isEmpty(avatarUrl)) {
            Glide.with(context)
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(h.avatar);
        } else {
            Glide.with(context).clear(h.avatar);
            h.avatar.setImageResource(R.drawable.ic_account);
        }

        h.text.setOnLongClickListener(v -> {
            if (longClickListener == null) return false;
            int pos = h.getBindingAdapterPosition();
            if (pos == RecyclerView.NO_POSITION) return false;
            longClickListener.onMessageLongClick(items.get(pos));
            return true;
        });
    }

    @Override
    public void onViewRecycled(@NonNull Holder holder) {
        // 头像请求必须随 holder 回收取消，否则快速滚动时会出现错位头像。
        // 但 Activity 销毁时 RecyclerView.setAdapter(null) 也会走到这里，
        // 此时 Glide.with(Activity) 会因 assertNotDestroyed 抛异常并直接崩溃进程，
        // 所以必须先判活。
        if (!isContextDestroyed()) {
            Glide.with(context).clear(holder.avatar);
        }
        super.onViewRecycled(holder);
    }

    /** context 是否为已销毁/正在结束的 Activity。Glide 不允许对其发起或取消请求。 */
    private boolean isContextDestroyed() {
        if (context instanceof android.app.Activity) {
            android.app.Activity activity = (android.app.Activity) context;
            return activity.isDestroyed() || activity.isFinishing();
        }
        return false;
    }

    @Override
    public int getItemCount() { return items.size(); }

    /**
     * 渲染气泡正文。
     *
     * <p>有内联表情时（{@link ChatMessage#getContentHtml()} 非空）走富文本路径：
     * 把解析器产出的精简 HTML 展开成 {@link SpannableStringBuilder}，表情用本地
     * drawable 的 {@link ImageSpan} 替换；否则直接走纯文本快路径。
     *
     * <p>不用 {@code Html.fromHtml + ImageGetter}：ImageGetter 必须同步返回
     * Drawable，评论区那套实现是靠 Glide 阻塞等待加上内存缓存撑住的，放在聊天
     * 列表的 bind 里会卡主线程。表情已经全部有本地资源，直接查资源 id 即可。
     */
    private void renderContent(TextView textView, ChatMessage message) {
        if (textView == null || message == null) return;
        String html = message.getContentHtml();
        if (TextUtils.isEmpty(html) || html.indexOf('<') < 0) {
            // 纯文本路径：本地回显的正文里表情仍是 [code] 形式（发送时原样提交给
            // 服务端），这里同样替换成 ImageSpan，否则用户刚发出的表情会显示成
            // 一串方括号文字，等服务端返回后才变成图片。
            setupClickableLinks(textView, buildCodeContent(textView, message.getContent()));
            return;
        }
        CharSequence rich = buildRichContent(textView, html);
        if (rich == null) {
            setupClickableLinks(textView, buildCodeContent(textView, message.getContent()));
            return;
        }
        setupClickableLinks(textView, rich);
    }

    /**
     * 把纯文本里的 {@code [表情代码]} 与 {@code [img]url[/img]} 展开成 Span。
     *
     * <p>用于本地回显与旧版本持久化下来的（没有富文本的）历史消息。
     * 发图时本地回显的正文就是原始 BBCode（要原样提交给服务端），
     * 若不在这里处理，用户刚发出的图片会显示成一长串 {@code [img]http...} 文本，
     * 等服务端返回并重新解析后才变成图片。
     *
     * <p>没有任何可替换内容时原样返回，不产生多余对象。
     */
    private CharSequence buildCodeContent(TextView textView, String content) {
        if (TextUtils.isEmpty(content) || content.indexOf('[') < 0) return content;

        // 第一遍：BBCode 图片。必须先做，因为它会改变文本长度。
        CharSequence base = content;
        if (BBCODE_IMG_PATTERN.matcher(content).find()) {
            base = expandBbcodeImages(textView, content);
        }

        // 第二遍：表情代码。在第一遍产出的文本上就地打 span。
        java.util.regex.Matcher matcher = SMILEY_CODE_PATTERN.matcher(base);
        SpannableStringBuilder builder = base instanceof SpannableStringBuilder
                ? (SpannableStringBuilder) base : null;
        int size = (int) (textView.getTextSize() * 1.35f);
        while (matcher.find()) {
            int iconRes = ForumSmileyData.iconForCode(matcher.group());
            if (iconRes == 0) continue;
            android.graphics.drawable.Drawable icon =
                    androidx.core.content.ContextCompat.getDrawable(context, iconRes);
            if (icon == null) continue;
            if (builder == null) builder = new SpannableStringBuilder(base);
            android.graphics.drawable.Drawable display = AnimatedSmileyLoader.obtain(
                    context, ForumSmileyData.gifUrlForCode(context, matcher.group()),
                    icon, size, textView);
            if (display == null) continue;
            builder.setSpan(new android.text.style.ImageSpan(
                            display, android.text.style.ImageSpan.ALIGN_BOTTOM),
                    matcher.start(), matcher.end(),
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return builder == null ? base : builder;
    }

    /**
     * 把 {@code [img]url[/img]} 替换成 {@code [图片]} 占位并挂上图片 span。
     *
     * <p>URL 指向表情时走表情路径（尺寸跟随字号），否则走真实图片路径。
     */
    private SpannableStringBuilder expandBbcodeImages(TextView textView, String content) {
        SpannableStringBuilder builder = new SpannableStringBuilder();
        java.util.regex.Matcher matcher = BBCODE_IMG_PATTERN.matcher(content);
        int cursor = 0;
        while (matcher.find()) {
            if (matcher.start() > cursor) {
                builder.append(content, cursor, matcher.start());
            }
            cursor = matcher.end();
            String url = matcher.group(1) == null ? "" : matcher.group(1).trim();
            if (TextUtils.isEmpty(url)) continue;
            if (ForumSmileyData.isSmileyUrl(url)) {
                // 表情以 URL 形式出现（部分历史消息如此），转成表情 span。
                int start = builder.length();
                builder.append(smileyPlaceholder(url));
                int iconRes = ForumSmileyData.iconForUrl(context, url);
                android.graphics.drawable.Drawable icon = iconRes == 0 ? null
                        : androidx.core.content.ContextCompat.getDrawable(context, iconRes);
                if (icon == null) continue;
                int size = (int) (textView.getTextSize() * 1.35f);
                android.graphics.drawable.Drawable display = AnimatedSmileyLoader.obtain(
                        context, ForumSmileyData.gifUrlForUrl(url), icon, size, textView);
                if (display == null) continue;
                builder.setSpan(new android.text.style.ImageSpan(
                                display, android.text.style.ImageSpan.ALIGN_BOTTOM),
                        start, builder.length(),
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                continue;
            }
            int start = builder.length();
            builder.append("[图片]");
            appendRealImage(textView, builder, start, url);
        }
        if (cursor < content.length()) builder.append(content, cursor, content.length());
        return builder;
    }

    /**
     * 把精简 HTML（仅 text / {@code <br>} / {@code <img src="...">}）展开为带
     * ImageSpan 的富文本。没有任何表情成功替换时返回 null，让调用方回落纯文本。
     */
    @Nullable
    private CharSequence buildRichContent(TextView textView, String html) {
        SpannableStringBuilder builder = new SpannableStringBuilder();
        boolean anyImage = false;
        int index = 0;
        int length = html.length();
        while (index < length) {
            int tagStart = html.indexOf('<', index);
            if (tagStart < 0) {
                builder.append(unescapeHtml(html.substring(index)));
                break;
            }
            if (tagStart > index) {
                builder.append(unescapeHtml(html.substring(index, tagStart)));
            }
            int tagEnd = html.indexOf('>', tagStart);
            if (tagEnd < 0) {
                builder.append(unescapeHtml(html.substring(tagStart)));
                break;
            }
            String tag = html.substring(tagStart + 1, tagEnd).trim();
            index = tagEnd + 1;
            if (tag.startsWith("br")) {
                builder.append('\n');
                continue;
            }
            if (!tag.startsWith("img")) continue;
            String src = extractSrc(tag);
            if (TextUtils.isEmpty(src)) continue;
            boolean smiley = ForumSmileyData.isSmileyUrl(src);
            // 占位字符必须真实存在，ImageSpan 才有可以附着的区间。
            // 表情用文件名（不同表情彼此不同），真实图片统一用 [图片]。
            String placeholder = smiley ? smileyPlaceholder(src) : "[图片]";
            int start = builder.length();
            builder.append(placeholder);
            // 表情与真实图片是两条完全不同的渲染路径：表情有本地静态资源、
            // 尺寸固定跟随字号；真实图片（对方发来的附件图/OSS 图）没有本地兜底，
            // 必须联网取回并按原始宽高比缩放，因此先判断是不是表情。
            if (!smiley) {
                if (appendRealImage(textView, builder, start, src)) anyImage = true;
                continue;
            }
            int iconRes = ForumSmileyData.iconForUrl(context, src);
            if (iconRes == 0) continue;
            android.graphics.drawable.Drawable icon =
                    androidx.core.content.ContextCompat.getDrawable(context, iconRes);
            if (icon == null) continue;
            // 表情尺寸跟随气泡字号，避免行高被撑得忽大忽小。
            int size = (int) (textView.getTextSize() * 1.35f);
            // 本地资源全是静态 PNG，QQ 表情在服务端是多帧 GIF；
            // 这里先用本地图占位，动图就绪后由 loader 原地替换并播放。
            android.graphics.drawable.Drawable display = AnimatedSmileyLoader.obtain(
                    context, ForumSmileyData.gifUrlForUrl(src), icon, size, textView);
            if (display == null) continue;
            builder.setSpan(new android.text.style.ImageSpan(
                            display, android.text.style.ImageSpan.ALIGN_BOTTOM),
                    start, builder.length(),
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            anyImage = true;
        }
        if (!anyImage) return null;
        // 结尾的换行来自解析器对 <p>/<div> 的收尾补位，气泡里会多出一段空白。
        while (builder.length() > 0 && builder.charAt(builder.length() - 1) == '\n') {
            builder.delete(builder.length() - 1, builder.length());
        }
        return builder;
    }

    /**
     * 在气泡里插入一张真实图片（非表情），并把它做成可点击查看大图。
     *
     * <p>图片异步加载，返回时占位框已经就位。宽度上限取气泡的最大内容宽度，
     * 避免大图把气泡撑到超出屏幕。
     *
     * @param start 占位文本的起始位置，ImageSpan 覆盖 [start, builder.length())
     * @return 是否成功挂上了图片 span
     */
    private boolean appendRealImage(TextView textView, SpannableStringBuilder builder,
                                    int start, String src) {
        if (start >= builder.length()) return false;
        int maxWidth = resolveBubbleImageWidth(textView);
        android.util.Log.w("MT_FLASH", "appendRealImage maxWidth=" + maxWidth
                + " url=" + src);
        android.graphics.drawable.Drawable image =
                com.forum.MT.ui.widget.ChatImageLoader.obtain(context, src, maxWidth, textView);
        builder.setSpan(new android.text.style.ImageSpan(
                        image, android.text.style.ImageSpan.ALIGN_BOTTOM),
                start, builder.length(),
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        // 点击查看大图，与帖子正文里的图片行为一致。
        final String url = src;
        builder.setSpan(new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                openImagePreview(url);
            }

            @Override
            public void updateDrawState(@NonNull android.text.TextPaint ds) {
                // 图片上不要画下划线，也不要改颜色。
                ds.setUnderlineText(false);
            }
        }, start, builder.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return true;
    }

    /**
     * 气泡内图片的最大宽度。
     *
     * <p>布局里气泡 {@code maxWidth=266dp}，减去左右各 12dp 内边距即为内容宽度。
     * TextView 尚未测量时（首次 bind）也能算出来，不依赖 getWidth()。
     */
    /**
     * 气泡内图片的最大宽度，统一由 {@link ChatImageLoader#bubbleImageWidth} 提供，
     * 确保预热与实际渲染算出的尺寸完全一致（否则尺寸缓存无法命中）。
     */
    private int resolveBubbleImageWidth(TextView textView) {
        return com.forum.MT.ui.widget.ChatImageLoader.bubbleImageWidth(context);
    }

    private void openImagePreview(String url) {
        try {
            Intent intent = new Intent(context, com.forum.MT.ui.detail.ImagePreviewActivity.class);
            intent.putExtra("image_url", url);
            if (!(context instanceof android.app.Activity)) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(intent);
        } catch (Exception ignored) {}
    }

    /**
     * 收集消息列表里所有真实图片（非表情）的 URL，供进入界面前预热解码。
     *
     * <p>同时扫 HTML（服务端返回）与 BBCode（本地回显）两种表示，
     * 判定规则必须与 {@link #buildHtmlContent} / {@link #buildCodeContent} 一致，
     * 否则预热的 URL 与实际渲染用的对不上，预热就白做了。
     *
     * @param limit 最多收集多少张，从列表末尾（最新消息）往前扫，
     *              首屏只可能看到最后若干条，全量预热会拖慢进入速度
     */
    public static java.util.List<String> collectImageUrls(
            @Nullable java.util.List<ChatMessage> messages, int limit) {
        java.util.List<String> urls = new java.util.ArrayList<>();
        if (messages == null || messages.isEmpty() || limit <= 0) return urls;
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (int i = messages.size() - 1; i >= 0 && urls.size() < limit; i--) {
            ChatMessage message = messages.get(i);
            if (message == null) continue;
            String html = message.getContentHtml();
            if (!TextUtils.isEmpty(html) && html.indexOf('<') >= 0) {
                collectFromHtml(html, urls, seen, limit);
                continue;
            }
            String content = message.getContent();
            if (TextUtils.isEmpty(content)) continue;
            java.util.regex.Matcher matcher = BBCODE_IMG_PATTERN.matcher(content);
            while (matcher.find() && urls.size() < limit) {
                String url = matcher.group(1);
                if (TextUtils.isEmpty(url)) continue;
                if (ForumSmileyData.isSmileyUrl(url)) continue;
                if (seen.add(url)) urls.add(url);
            }
        }
        return urls;
    }

    /** 从 HTML 片段里挑出非表情的 img src。 */
    private static void collectFromHtml(String html, java.util.List<String> urls,
                                        java.util.Set<String> seen, int limit) {
        int index = 0;
        while (index < html.length() && urls.size() < limit) {
            int tagStart = html.indexOf('<', index);
            if (tagStart < 0) break;
            int tagEnd = html.indexOf('>', tagStart);
            if (tagEnd < 0) break;
            String tag = html.substring(tagStart + 1, tagEnd).trim();
            index = tagEnd + 1;
            if (!tag.startsWith("img")) continue;
            String src = extractSrc(tag);
            if (TextUtils.isEmpty(src)) continue;
            if (ForumSmileyData.isSmileyUrl(src)) continue;
            if (seen.add(src)) urls.add(src);
        }
    }

    @Nullable
    private static String extractSrc(String imgTag) {
        int i = imgTag.indexOf("src=");
        if (i < 0) return null;
        int start = i + 4;
        if (start >= imgTag.length()) return null;
        char quote = imgTag.charAt(start);
        if (quote == '"' || quote == '\'') {
            int end = imgTag.indexOf(quote, start + 1);
            if (end < 0) return null;
            return unescapeHtml(imgTag.substring(start + 1, end));
        }
        int end = start;
        while (end < imgTag.length() && !Character.isWhitespace(imgTag.charAt(end))) end++;
        return unescapeHtml(imgTag.substring(start, end));
    }

    /** ImageSpan 需要挂在真实字符上，这里用表情文件名做占位。 */
    private static String smileyPlaceholder(String src) {
        int slash = src.lastIndexOf('/');
        String file = slash >= 0 ? src.substring(slash + 1) : src;
        int dot = file.lastIndexOf('.');
        if (dot > 0) file = file.substring(0, dot);
        return file.isEmpty() ? "[图片]" : "[" + file + "]";
    }

    private static String unescapeHtml(String text) {
        if (text.indexOf('&') < 0) return text;
        return text.replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&");
    }

    /**
     * URL 链接渲染。与 ThreadDetailActivity.setupClickableLinks 行为一致：
     * Android 的 \w 默认匹配 Unicode 字母（含中文），因此正则使用显式 ASCII 字符集。
     *
     * <p>注意顺序：必须先在本地 Spannable 上打完所有 span，再一次性 setText。
     * TextView.setText(text, BufferType.SPANNABLE) 内部会通过 SpannableFactory
     * 复制一份新的 SpannableString，如果先 setText 再往原对象加 span，
     * 加到的是已经与 TextView 脱钩的那份对象，链接不会显示。
     */
    private void setupClickableLinks(TextView textView, CharSequence content) {
        if (textView == null) return;

        if (TextUtils.isEmpty(content)) {
            textView.setText("");
            textView.setMovementMethod(null);
            return;
        }

        SpannableStringBuilder spannable = content instanceof SpannableStringBuilder
                ? (SpannableStringBuilder) content
                : new SpannableStringBuilder(content);

        FixNestedScrollLinkMovementMethod.matcherLinkify(
            spannable,
            getUrlPattern(),
            ChatMessageAdapter::normalizeLinkUrl,
            this::openContentLink
        );

        URLSpan[] urlSpans = spannable.getSpans(0, spannable.length(), URLSpan.class);
        for (URLSpan oldSpan : urlSpans) {
            final String targetUrl = normalizeLinkUrl(oldSpan.getURL());
            int start = spannable.getSpanStart(oldSpan);
            int end = spannable.getSpanEnd(oldSpan);
            int flags = spannable.getSpanFlags(oldSpan);
            spannable.removeSpan(oldSpan);
            if (start >= 0 && end > start && !TextUtils.isEmpty(targetUrl)) {
                spannable.setSpan(new ClickableSpan() {
                    @Override
                    public void onClick(View widget) {
                        openContentLink(targetUrl);
                    }
                }, start, end, flags);
            }
        }

        boolean hasLink = spannable.getSpans(0, spannable.length(), ClickableSpan.class).length > 0;
        textView.setText(spannable, TextView.BufferType.SPANNABLE);

        // 只有真正含链接时才安装 MovementMethod：它会让 TextView 变为可聚焦、
        // 可点击并接管触摸事件，对纯文本气泡是不必要的开销。
        if (hasLink) {
            textView.setHighlightColor(0x332196F3);
            textView.setMovementMethod(new FixNestedScrollLinkMovementMethod());
        } else {
            textView.setMovementMethod(null);
            textView.setHighlightColor(0);
        }
        textView.setAutoLinkMask(0);
    }

    private static String normalizeLinkUrl(String url) {
        if (TextUtils.isEmpty(url)) return url;
        if (url.startsWith("//")) return "https:" + url;
        if (url.startsWith("/")) return "https://bbs.binmt.cc" + url;
        if (url.startsWith("./")) return "https://bbs.binmt.cc" + url.substring(1);
        if (url.startsWith("http://") || url.startsWith("https://")) return url;
        return "https://" + url;
    }

    private void openContentLink(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception ignored) {}
    }

    /** 左右两套布局共用同一组 ID，因此可以共用一个 ViewHolder。 */
    static class Holder extends RecyclerView.ViewHolder {
        final TextView text;
        final TextView date;
        final TextView time;
        final ImageView avatar;
        final ProgressBar sending;

        Holder(View v) {
            super(v);
            text = v.findViewById(R.id.tv_chat_text);
            date = v.findViewById(R.id.tv_chat_date);
            time = v.findViewById(R.id.tv_chat_time);
            avatar = v.findViewById(R.id.iv_chat_avatar);
            sending = v.findViewById(R.id.pb_chat_sending);
        }
    }
}
