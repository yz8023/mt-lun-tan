package com.forum.MT.adapter;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.model.RankThread;

import java.util.ArrayList;
import java.util.List;

/**
 * 热帖排行榜列表适配器。
 *
 * <p>榜单一次只有 20 条且整榜替换（切换榜单类型/时间范围就是全新数据），
 * 所以不用 DiffUtil，直接 {@code notifyDataSetChanged}：数据量小，
 * 而且相邻两榜的条目几乎不重叠，做差分收益低于复杂度成本。
 */
public class RankAdapter extends RecyclerView.Adapter<RankAdapter.RankViewHolder> {

    /** 4种颜色：金(黄)、绿、红、灰 */
    private static final int COLOR_GOLD = 0xFFFFB300;
    private static final int COLOR_SILVER = 0xFF66BB6A;
    private static final int COLOR_BRONZE = 0xFFEF5350;
    private static final int COLOR_DEFAULT = 0xFF9E9E9E;

    public interface OnRankItemClickListener {
        void onItemClick(RankThread item);
    }

    public interface OnRankAuthorClickListener {
        void onAuthorClick(RankThread item);
    }

    private final Context context;
    private final List<RankThread> items = new ArrayList<>();
    private OnRankItemClickListener itemClickListener;
    private OnRankAuthorClickListener authorClickListener;

    public RankAdapter(Context context) {
        this.context = context;
    }

    public void setOnItemClickListener(OnRankItemClickListener listener) {
        this.itemClickListener = listener;
    }

    public void setOnAuthorClickListener(OnRankAuthorClickListener listener) {
        this.authorClickListener = listener;
    }

    public void setItems(List<RankThread> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RankViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_rank_thread, parent, false);
        return new RankViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RankViewHolder holder, int position) {
        RankThread item = items.get(position);

        holder.tvRank.setText(String.valueOf(item.getRank()));
        // 直接用 GradientDrawable 设置颜色，避免 setBackgroundTintList 在部分设备上失效
        android.graphics.drawable.GradientDrawable badge = new android.graphics.drawable.GradientDrawable();
        badge.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        badge.setColor(rankColor(item.getRank()));
        holder.tvRank.setBackground(badge);

        holder.tvTitle.setText(item.getTitle() == null ? "" : item.getTitle());
        holder.tvMetric.setText(item.getMetricText() == null ? "" : item.getMetricText());

        holder.tvAuthor.setText(item.getAuthor() == null ? "" : item.getAuthor());
        holder.tvTime.setText(item.getPublishTime() == null ? "" : item.getPublishTime());

        String avatarUrl = item.getAvatarUrl();
        if (!TextUtils.isEmpty(avatarUrl)) {
            Glide.with(context)
                    .load(avatarUrl)
                    .placeholder(R.drawable.ic_account)
                    .error(R.drawable.ic_account)
                    .circleCrop()
                    .into(holder.ivAvatar);
        } else {
            Glide.with(context).clear(holder.ivAvatar);
            holder.ivAvatar.setImageResource(R.drawable.ic_account);
        }

        holder.itemView.setOnClickListener(v -> {
            if (itemClickListener != null) itemClickListener.onItemClick(item);
        });
        View.OnClickListener authorClick = v -> {
            if (authorClickListener != null) authorClickListener.onAuthorClick(item);
        };
        holder.ivAvatar.setOnClickListener(authorClick);
        holder.tvAuthor.setOnClickListener(authorClick);
    }

    private int rankColor(int rank) {
        switch (rank) {
            case 1: return COLOR_GOLD;
            case 2: return COLOR_SILVER;
            case 3: return COLOR_BRONZE;
            default: return COLOR_DEFAULT;
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class RankViewHolder extends RecyclerView.ViewHolder {
        final TextView tvRank;
        final TextView tvTitle;
        final TextView tvAuthor;
        final TextView tvTime;
        final TextView tvMetric;
        final ImageView ivAvatar;

        RankViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRank = itemView.findViewById(R.id.tv_rank);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvAuthor = itemView.findViewById(R.id.tv_author);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvMetric = itemView.findViewById(R.id.tv_metric);
            ivAvatar = itemView.findViewById(R.id.iv_avatar);
        }
    }
}
