package com.forum.MT.util;

import android.content.Context;
import android.net.Uri;

import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 论坛附件图片上传的共享逻辑：本地规范化转码 + swfupload 响应解析。
 *
 * <p>发帖页与编辑页共用同一套处理。相册原图直传会被 Discuz 的 swfupload
 * 按文件头、扩展名、尺寸、大小联合校验拒收（HEIC/AVIF/特殊 WebP、透明 PNG、
 * 超高分辨率），表现为"网页能传、App 传不上"，所以上传前统一转成标准 JPEG。
 */
public final class ImageUploadHelper {

    private ImageUploadHelper() {}

    /** 上传结果：要么拿到 aid，要么带一条能解释原因的错误信息。 */
    public static final class Outcome {
        public final String aid;
        public final String error;

        private Outcome(String aid, String error) {
            this.aid = aid;
            this.error = error;
        }

        public static Outcome ok(String aid) { return new Outcome(aid, null); }

        public static Outcome fail(String error) { return new Outcome(null, error); }

        public boolean isSuccess() { return aid != null; }
    }

    /**
     * 上传一张图片并返回 aid。
     *
     * <p>阻塞式，必须在后台线程调用。
     *
     * @param uid  swfupload 凭证 uid
     * @param hash swfupload 凭证 hash
     */
    public static Outcome uploadImage(Context context, Uri uri, String uid, String hash) {
        if (context == null || uri == null) return Outcome.fail("图片无效");
        if (uid == null || uid.isEmpty() || hash == null || hash.isEmpty()) {
            return Outcome.fail("缺少上传授权，请重新登录");
        }
        String rawName = getFileNameFromUri(uri);
        File file = transcodeImageToJpeg(context, uri);
        if (file == null) {
            // 转码失败（损坏文件、不可解码格式）时退回原样上传，
            // 让服务端给出具体原因，而不是本地静默跳过。
            String fileName = rawName.matches("(?i).*\\.(jpg|jpeg|png|gif|bmp|webp)$")
                    ? rawName : "image_" + System.currentTimeMillis() + ".jpg";
            try {
                file = copyUriToTempFile(context, uri, fileName);
            } catch (Exception e) {
                return Outcome.fail(rawName + "：无法读取图片");
            }
        }
        if (file == null) return Outcome.fail(rawName + "：无法读取图片");

        String uploadUrl = HttpClient.BASE_URL
                + "misc.php?mod=swfupload&operation=upload"
                + "&type=image&inajax=yes&infloat=yes&simple=2";
        Map<String, String> extraFields = new HashMap<>();
        extraFields.put("uid", uid);
        extraFields.put("hash", hash);
        try {
            String response = HttpClient.getInstance()
                    .uploadFile(uploadUrl, file, "Filedata", extraFields);
            return parseUploadResponse(response);
        } catch (Exception e) {
            String message = e.getMessage();
            return Outcome.fail(message == null || message.isEmpty() ? "网络异常" : message);
        }
    }

    /**
     * 上传任意类型附件（非图片走 {@code type=attach}）。
     *
     * <p>阻塞式，必须在后台线程调用。与图片不同，这里不做转码：文档、压缩包等
     * 一旦改动字节就损坏了，只能原样上传，由服务端裁定是否允许该扩展名。
     */
    public static Outcome uploadAttachment(Context context, Uri uri, String fileName,
                                           String uid, String hash) {
        if (context == null || uri == null) return Outcome.fail("文件无效");
        if (uid == null || uid.isEmpty() || hash == null || hash.isEmpty()) {
            return Outcome.fail("缺少上传授权，请重新登录");
        }
        File file;
        try {
            file = copyUriToTempFile(context, uri,
                    fileName == null || fileName.isEmpty() ? getFileNameFromUri(uri) : fileName);
        } catch (Exception e) {
            return Outcome.fail("无法读取文件");
        }
        if (file == null) return Outcome.fail("无法读取文件");

        String uploadUrl = HttpClient.BASE_URL
                + "misc.php?mod=swfupload&operation=upload"
                + "&type=attach&inajax=yes&infloat=yes&simple=2";
        Map<String, String> extraFields = new HashMap<>();
        extraFields.put("uid", uid);
        extraFields.put("hash", hash);
        try {
            String response = HttpClient.getInstance()
                    .uploadFile(uploadUrl, file, "Filedata", extraFields);
            return parseUploadResponse(response);
        } catch (Exception e) {
            String message = e.getMessage();
            return Outcome.fail(message == null || message.isEmpty() ? "网络异常" : message);
        }
    }

    /** 判断文件名是否为论坛按图片处理的扩展名（决定用 attachimg 还是 attach）。 */
    public static boolean isImageFileName(String name) {
        return name != null && name.matches("(?i).*\\.(jpg|jpeg|png|gif|bmp|webp)$");
    }

    /**
     * 解析 swfupload 的 {@code DISCUZUPLOAD|...} 响应。
     *
     * <p>状态码：0=成功，1=写入失败，2=超过大小限制，3=格式不支持，9=非法图片。
     */
    public static Outcome parseUploadResponse(String response) {
        if (response == null) return Outcome.fail("服务器无响应");
        String text = response.trim();
        if (text.isEmpty()) return Outcome.fail("服务器返回空响应");

        // inajax 响应会包一层 CDATA，先取出内部内容。
        Matcher cdata = Pattern.compile("(?s)<!\\[CDATA\\[(.*?)\\]\\]>").matcher(text);
        if (cdata.find()) text = cdata.group(1).trim();

        int marker = text.indexOf("DISCUZUPLOAD|");
        if (marker < 0) {
            if (ForumParser.isLoginPage(text) || text.contains("请先登录")) {
                return Outcome.fail("登录状态已失效，请重新登录");
            }
            String plain = text.replaceAll("(?s)<[^>]+>", " ")
                    .replaceAll("\\s+", " ").trim();
            if (plain.length() > 120) plain = plain.substring(0, 120) + "…";
            return Outcome.fail(plain.isEmpty() ? "服务器返回格式异常" : plain);
        }

        // 标记之后可能还跟着换行或 HTML，只取本行。
        String payload = text.substring(marker).split("[\\r\\n<]", 2)[0];
        String[] parts = payload.split("\\|", -1);
        if (parts.length < 4) return Outcome.fail("上传响应格式异常");

        String status = parts[2].trim();
        String aid = parts[3].trim();
        String limitInfo = parts.length > 7 ? parts[7].trim() : "";

        if ("0".equals(status) && aid.matches("\\d+")) {
            return Outcome.ok(aid);
        }

        String reason;
        switch (status) {
            case "1": reason = "服务器写入文件失败"; break;
            case "2": reason = "图片超过论坛大小限制"; break;
            case "3": reason = "论坛不支持该图片格式"; break;
            case "9": reason = "图片无效或尺寸过小"; break;
            default: reason = "服务器拒绝了附件（状态 " + status + "）"; break;
        }
        // 服务端有时把具体限制说明放在末位字段，比状态码更有用。
        if (!limitInfo.isEmpty() && !"0".equals(limitInfo) && !limitInfo.matches("\\d+")) {
            reason = limitInfo;
        }
        return Outcome.fail(reason);
    }

    /**
     * 把图片规范化为最兼容的 JPEG：压平透明通道、限制最长边 1920、
     * 逐步降质到 2 MiB 以内。无法解码时返回 null。
     */
    public static File transcodeImageToJpeg(Context context, Uri uri) {
        if (context == null || uri == null) return null;
        try {
            final int maxSide = 1920;
            android.graphics.ImageDecoder.Source source =
                    android.graphics.ImageDecoder.createSource(context.getContentResolver(), uri);
            android.graphics.Bitmap decoded = android.graphics.ImageDecoder.decodeBitmap(source,
                    (decoder, info, ignoredSource) -> {
                        int width = info.getSize().getWidth();
                        int height = info.getSize().getHeight();
                        int largest = Math.max(width, height);
                        if (largest > maxSide) {
                            float scale = maxSide / (float) largest;
                            decoder.setTargetSize(Math.max(1, Math.round(width * scale)),
                                    Math.max(1, Math.round(height * scale)));
                        }
                        // 软件位图便于 Canvas 压平透明通道，也避免硬件位图无法直接压缩。
                        decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                    });
            if (decoded == null || decoded.getWidth() <= 0 || decoded.getHeight() <= 0) return null;

            android.graphics.Bitmap flattened = android.graphics.Bitmap.createBitmap(
                    decoded.getWidth(), decoded.getHeight(),
                    android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas canvas = new android.graphics.Canvas(flattened);
            canvas.drawColor(android.graphics.Color.WHITE);
            canvas.drawBitmap(decoded, 0, 0, null);
            if (flattened != decoded) decoded.recycle();

            byte[] jpeg = null;
            for (int quality = 88; quality >= 58; quality -= 6) {
                java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
                flattened.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, output);
                jpeg = output.toByteArray();
                if (jpeg.length <= 2 * 1024 * 1024 || quality == 58) break;
            }
            flattened.recycle();
            if (jpeg == null || jpeg.length == 0) return null;

            File dir = new File(context.getCacheDir(), "attachments");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File target = new File(dir, "edit_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream output = new FileOutputStream(target)) {
                output.write(jpeg);
                output.flush();
            }
            return target;
        } catch (Exception e) {
            return null;
        }
    }

    public static File copyUriToTempFile(Context context, Uri uri, String fileName)
            throws Exception {
        File tmpDir = new File(context.getCacheDir(), "attachments");
        if (!tmpDir.exists() && !tmpDir.mkdirs()) return null;
        File tmpFile = new File(tmpDir, fileName);
        try (InputStream is = context.getContentResolver().openInputStream(uri);
             FileOutputStream os = new FileOutputStream(tmpFile)) {
            if (is == null) return null;
            byte[] buf = new byte[8192];
            int len;
            while ((len = is.read(buf)) != -1) os.write(buf, 0, len);
        }
        return tmpFile;
    }

    public static String getFileNameFromUri(Uri uri) {
        String name = "attachment";
        try {
            String path = uri.getPath();
            if (path != null) name = path.substring(path.lastIndexOf('/') + 1);
        } catch (Exception ignored) {}
        if (!name.contains(".")) name += ".dat";
        return name;
    }
}
