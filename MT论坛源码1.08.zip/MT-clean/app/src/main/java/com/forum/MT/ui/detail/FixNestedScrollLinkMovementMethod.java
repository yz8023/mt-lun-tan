package com.forum.MT.ui.detail;

import android.text.Layout;
import android.text.method.LinkMovementMethod;
import android.text.Selection;
import android.text.Spannable;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 自定义MovementMethod，解决NestedScrollView中链接点击与滚动冲突问题。
 * 继承 LinkMovementMethod（而非 ArrowKeyMovementMethod），避免 textIsSelectable 冲突。
 *
 * 核心改进：
 * 1. 继承 LinkMovementMethod 以保留链接点击能力
 * 2. 在 ACTION_DOWN/MOVE/UP 中管理父容器拦截，支持正常滚动
 * 3. 只在点击位置有链接时才阻止父容器拦截，否则允许正常滚动
 */
public class FixNestedScrollLinkMovementMethod extends LinkMovementMethod {
    
    private float mDownX;
    private float mDownY;
    private long mDownTime;
    private boolean mHasLinkAtDown;
    // ★ 滑动阈值（px），超过此距离视为滚动而非点击
    private static final int TOUCH_SLOP = 24;
    
    @Override
    public boolean onTouchEvent(TextView widget, Spannable buffer, MotionEvent event) {
        int action = event.getAction();
        
        if (action == MotionEvent.ACTION_DOWN) {
            mDownX = event.getX();
            mDownY = event.getY();
            mDownTime = System.currentTimeMillis();
            mHasLinkAtDown = hasLinkAtPosition(widget, buffer, mDownX, mDownY);
        }
        
        if (action == MotionEvent.ACTION_MOVE) {
            // ★ 计算手指移动距离，如果超过阈值则视为滚动操作
            float dx = Math.abs(event.getX() - mDownX);
            float dy = Math.abs(event.getY() - mDownY);
            boolean isScrolling = (dx > TOUCH_SLOP || dy > TOUCH_SLOP);
            
            NestedScrollView parent = findNestedScrollView(widget);
            if (parent != null) {
                if (isScrolling) {
                    // 滚动 → 放开父容器拦截，允许正常滚动
                    parent.requestDisallowInterceptTouchEvent(false);
                } else if (mHasLinkAtDown) {
                    // 短按且起点有链接且未移动 → 阻止父容器拦截（防误触刷新）
                    parent.requestDisallowInterceptTouchEvent(true);
                } else {
                    parent.requestDisallowInterceptTouchEvent(false);
                }
            }
        }
        
        if (action == MotionEvent.ACTION_UP) {
            // ★ 计算手指移动距离，判断是否为点击操作
            float dx = Math.abs(event.getX() - mDownX);
            float dy = Math.abs(event.getY() - mDownY);
            boolean isTap = (dx <= TOUCH_SLOP && dy <= TOUCH_SLOP);
            
            NestedScrollView parent = findNestedScrollView(widget);
            if (parent != null) {
                if (!isTap) {
                    parent.requestDisallowInterceptTouchEvent(false);
                } else {
                    parent.requestDisallowInterceptTouchEvent(!mHasLinkAtDown);
                }
            }
            
            // ★ 点击且位置有链接 → 触发链接点击
            if (isTap && mHasLinkAtDown) {
                ClickableSpan[] spans = buffer.getSpans(
                    widget.getOffsetForPosition(event.getX(), event.getY()),
                    widget.getOffsetForPosition(event.getX(), event.getY()),
                    ClickableSpan.class);
                if (spans.length > 0) {
                    try {
                        spans[0].onClick(widget);
                    } catch (Exception ignored) {}
                    return true;
                }
            }
        }
        
        if (action == MotionEvent.ACTION_CANCEL) {
            NestedScrollView parent = findNestedScrollView(widget);
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(false);
            }
        }
        
        // 链接点击/高亮等交给 LinkMovementMethod 处理
        return super.onTouchEvent(widget, buffer, event);
    }
    
    /**
     * 检查指定位置是否有ClickableSpan
     */
    private boolean hasLinkAtPosition(TextView widget, Spannable buffer, float x, float y) {
        try {
            android.text.Layout layout = widget.getLayout();
            if (layout == null) return false;
            
            int line = layout.getLineForVertical((int) y);
            int offset = layout.getOffsetForHorizontal(line, x);
            
            if (offset < 0) return false;
            
            ClickableSpan[] spans = buffer.getSpans(offset, offset, ClickableSpan.class);
            return spans.length > 0;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * 向上查找NestedScrollView父容器
     */
    private NestedScrollView findNestedScrollView(TextView view) {
        ViewParent parent = view.getParent();
        while (parent != null) {
            if (parent instanceof NestedScrollView) {
                return (NestedScrollView) parent;
            }
            parent = parent.getParent();
        }
        return null;
    }
    
    /**
     * 使用自定义Pattern在Spannable中查找URL并添加ClickableSpan
     */
    public static void matcherLinkify(Spannable spannable, Pattern pattern, 
            java.util.function.Function<String, String> urlProcessor,
            java.util.function.Consumer<String> onClickListener) {
        if (spannable == null || pattern == null) return;
        
        String text = spannable.toString();
        Matcher matcher;
        try {
            matcher = pattern.matcher(text);
        } catch (Exception e) {
            if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_HIDDEN_DBG", "[matcherLinkify] Pattern.matcher exception: " + e);
            return;
        }
        
        int matchCount = 0;
        while (matcher.find()) {
            int start = matcher.start();
            int end = matcher.end();
            if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_HIDDEN_DBG", "[matcherLinkify] match at " + start + "-" + end + " url=[" + text.substring(start, end) + "]");
            matchCount++;
            
            boolean alreadySpanned = false;
            for (ClickableSpan span : spannable.getSpans(start, end, ClickableSpan.class)) {
                if (spannable.getSpanStart(span) >= start && spannable.getSpanEnd(span) <= end) {
                    alreadySpanned = true;
                    if (com.forum.MT.util.Dbg.ON) android.util.Log.e("MT_HIDDEN_DBG", "[matcherLinkify] alreadySpanned, skipping");
                    break;
                }
            }
            if (alreadySpanned) continue;
            
            final String rawUrl = text.substring(start, end);
            final String processedUrl = urlProcessor != null ? urlProcessor.apply(rawUrl) : rawUrl;
            
            spannable.setSpan(new ClickableSpan() {
                @Override
                public void onClick(View widget) {
                    if (onClickListener != null) {
                        onClickListener.accept(processedUrl);
                    }
                }
            }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }
}