package com.forum.MT.model;

/**
 * 浏览历史记录模型
 * 记录用户浏览过的帖子信息
 */
public class BrowseHistory {
    private String tid;           // 帖子ID
    private String title;          // 帖子标题
    private String author;         // 作者名
    private String authorUid;      // 作者UID
    private String avatarUrl;      // 作者头像URL
    private String forumName;      // 版块名
    private long viewTime;         // 浏览时间（时间戳毫秒）

    public BrowseHistory() {}

    public BrowseHistory(String tid, String title, String author, String authorUid,
                         String avatarUrl, String forumName, long viewTime) {
        this.tid = tid;
        this.title = title;
        this.author = author;
        this.authorUid = authorUid;
        this.avatarUrl = avatarUrl;
        this.forumName = forumName;
        this.viewTime = viewTime;
    }

    // Getters & Setters
    public String getTid() { return tid; }
    public void setTid(String tid) { this.tid = tid; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getAuthorUid() { return authorUid; }
    public void setAuthorUid(String authorUid) { this.authorUid = authorUid; }

    public String getAvatarUrl() { return avatarUrl; }
    public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }

    public String getForumName() { return forumName; }
    public void setForumName(String forumName) { this.forumName = forumName; }

    public long getViewTime() { return viewTime; }
    public void setViewTime(long viewTime) { this.viewTime = viewTime; }
}
