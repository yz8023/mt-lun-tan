package com.forum.MT.ui.message;

import android.text.TextUtils;
import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.LiveData;

import com.forum.MT.model.MessageTab;
import com.forum.MT.model.NoticeData;
import com.forum.MT.model.NoticeItem;
import com.forum.MT.model.PrivateMessageData;
import com.forum.MT.model.Message;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.network.NoticeBadgeManager;
import com.forum.MT.session.UserSessionManager;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 消息ViewModel - 对应官方APK的MessageViewModel
 * 管理4个Tab的数据状态，提供数据加载接口
 */
public class MessageViewModel extends AndroidViewModel {

    // 私信数据
    private final MutableLiveData<PrivateMessageData> privateMessageData = new MutableLiveData<>(new PrivateMessageData());
    public LiveData<PrivateMessageData> getPrivateMessageData() { return privateMessageData; }

    // @我的数据
    private final MutableLiveData<NoticeData> atMeData = new MutableLiveData<>(new NoticeData());
    public LiveData<NoticeData> getAtMeData() { return atMeData; }

    // 我的帖子数据
    private final MutableLiveData<NoticeData> myPostData = new MutableLiveData<>(new NoticeData());
    public LiveData<NoticeData> getMyPostData() { return myPostData; }

    // 系统通知数据
    private final MutableLiveData<NoticeData> systemNoticeData = new MutableLiveData<>(new NoticeData());
    public LiveData<NoticeData> getSystemNoticeData() { return systemNoticeData; }

    // 当前选中的Tab
    private final MutableLiveData<MessageTab> currentTab = new MutableLiveData<>(MessageTab.PRIVATE_MESSAGE);
    public LiveData<MessageTab> getCurrentTab() { return currentTab; }

    // 事件消息通道（用于Toast提示等）
    private final MutableLiveData<String> toastMessage = new MutableLiveData<>();
    public LiveData<String> getToastMessage() { return toastMessage; }

    // 其它消息四个子分类异步加载完成信号。
    // 子页面用它刷新具体角标，父页面用它刷新“其它消息”汇总角标。
    private final MutableLiveData<Long> otherMessagesBadgesUpdated = new MutableLiveData<>();
    public LiveData<Long> getOtherMessagesBadgesUpdated() { return otherMessagesBadgesUpdated; }

    private final HttpClient httpClient;
    private final ExecutorService executor;
    private boolean isInitialized = false;

    public MessageViewModel(@NonNull Application application) {
        super(application);
        httpClient = HttpClient.getInstance();
        executor = Executors.newFixedThreadPool(3);
    }

    public void setCurrentTab(MessageTab tab) {
        currentTab.setValue(tab);
    }

    /** 初始化加载所有Tab数据 */
    public void loadAll() {
        if (isInitialized) return;
        isInitialized = true;
        loadPrivateMessages();
        loadAtMeNotices();
        loadMyPostNotices();
        loadSystemNotices();
        loadOtherMessagesBadges();
    }

    /** 刷新所有Tab */
    public void refreshAll() {
        loadPrivateMessages();
        loadAtMeNotices();
        loadMyPostNotices();
        loadSystemNotices();
        loadOtherMessagesBadges();
    }

    /** 加载私信列表 */
    public void loadPrivateMessages() {
        PrivateMessageData current = privateMessageData.getValue();
        if (current == null) current = new PrivateMessageData();
        current.setLoading(true);
        privateMessageData.setValue(current);

        executor.execute(() -> {
            try {
                httpClient.syncFromCookieManager();
                String url = HttpClient.BASE_URL + "home.php?mod=space&do=pm&filter=privatepm&page=1";
                String html = httpClient.getDesktop(url);
                List<Message> messages = ForumParser.parsePrivateMessageList(html);
                PrivateMessageData data = new PrivateMessageData(messages, false, null);
                data.setHasMore(messages != null && !messages.isEmpty());
                privateMessageData.postValue(data);
            } catch (Exception e) {
                PrivateMessageData data = new PrivateMessageData();
                data.setLoading(false);
                data.setError("加载失败: " + e.getMessage());
                privateMessageData.postValue(data);
            }
        });
    }

    /** 加载@我的通知：view=mypost&type=at（官方APK参数） */
    public void loadAtMeNotices() {
        loadNoticesWithType("mypost", "at", atMeData);
    }

    /** 加载我的帖子通知：view=mypost&type=post（官方APK参数） */
    public void loadMyPostNotices() {
        loadNoticesWithType("mypost", "post", myPostData);
    }

    /** 加载系统通知：view=system（官方APK参数） */
    public void loadSystemNotices() {
        loadNotices("system", systemNoticeData);
    }

    /**
     * 后台加载"其它消息"各子分类（粉丝/互动/系统/应用）的角标数据。
     * 各分类独立请求服务器，计算相对新增数，结果存入 NoticeBadgeManager。
     */
    public void loadOtherMessagesBadges() {
        executor.execute(() -> {
            try {
                httpClient.syncFromCookieManager();
                String uid = UserSessionManager.getInstance().getUid(getApplication());
                if (TextUtils.isEmpty(uid)) uid = "0";

                // 粉丝
                try {
                    String html = httpClient.get(HttpClient.BASE_URL
                            + "home.php?mod=follow&do=follower&uid=" + uid + "&mobile=2");
                    if (!TextUtils.isEmpty(html) && !ForumParser.isLoginPage(html)) {
                        String snapshot = NoticeBadgeManager.buildSnapshot("follower", html, null);
                        NoticeBadgeManager.saveCurrentAndGetNewCount(getApplication(), "follower", snapshot);
                    }
                } catch (Exception ignored) {}

                // 坛友互动：五个真实子分类分别建立快照，详情页才能显示并清除对应角标。
                String[] interactiveTypes = {"poke", "friend", "click", "wall", "comment", "share"};
                for (String type : interactiveTypes) {
                    try {
                        String html = httpClient.getDesktop(HttpClient.BASE_URL
                                + "home.php?mod=space&do=notice&view=interactive&type=" + type);
                        String badgeType = "interactive_" + type;
                        if (!TextUtils.isEmpty(html) && !ForumParser.isLoginPage(html)) {
                            String snapshot = NoticeBadgeManager.buildSnapshot(badgeType, html, null);
                            NoticeBadgeManager.saveCurrentAndGetNewCount(getApplication(), badgeType, snapshot);
                        }
                    } catch (Exception ignored) {}
                }
                int interactiveTotal = NoticeBadgeManager.getInteractiveAggregate(
                        getApplication(), interactiveTypes);
                NoticeBadgeManager.setNewCount(getApplication(), "interactive", interactiveTotal);

                // 系统通知
                try {
                    String html = httpClient.getDesktop(HttpClient.BASE_URL
                            + "home.php?mod=space&do=notice&view=system");
                    if (!TextUtils.isEmpty(html) && !ForumParser.isLoginPage(html)) {
                        String snapshot = NoticeBadgeManager.buildSnapshot("system", html, null);
                        NoticeBadgeManager.saveCurrentAndGetNewCount(getApplication(), "system", snapshot);
                    }
                } catch (Exception ignored) {}

                // 应用通知
                try {
                    String html = httpClient.getDesktop(HttpClient.BASE_URL
                            + "home.php?mod=space&do=notice&view=app");
                    if (!TextUtils.isEmpty(html) && !ForumParser.isLoginPage(html)) {
                        String snapshot = NoticeBadgeManager.buildSnapshot("app", html, null);
                        NoticeBadgeManager.saveCurrentAndGetNewCount(getApplication(), "app", snapshot);
                    }
                } catch (Exception ignored) {}

                // 四类请求完成后通知所有消息页面立即刷新角标。
                android.os.Handler main = new android.os.Handler(android.os.Looper.getMainLooper());
                main.post(() -> otherMessagesBadgesUpdated.setValue(System.currentTimeMillis()));
            } catch (Exception ignored) {
            }
        });
    }

    private void loadNoticesWithType(String view, String type, MutableLiveData<NoticeData> liveData) {
        NoticeData current = liveData.getValue();
        if (current == null) current = new NoticeData();
        current.setLoading(true);
        liveData.setValue(current);

        executor.execute(() -> {
            try {
                httpClient.syncFromCookieManager();
                // 官方APK使用桌面版请求，参数：mod=space&do=notice&view=mypost&type=at/post
                String url = HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=" + view + "&type=" + type;
                String html = httpClient.getDesktop(url);
                List<NoticeItem> items = ForumParser.parseNoticeItems(html);
                // ★ 同步更新当前快照，使 isNoticeRelativeNew 能基于最新数据判定
                String badgeViewType = view + "_" + type;
                String snapshot = NoticeBadgeManager.buildSnapshot(badgeViewType, html, null);
                NoticeBadgeManager.saveCurrentAndGetNewCount(getApplication(), badgeViewType, snapshot);
                String pagination = ForumParser.parseNoticePagination(html);
                int totalPages = 1;
                if (pagination != null) {
                    try { totalPages = Integer.parseInt(pagination); } catch (NumberFormatException ignored) {}
                }
                NoticeData data = new NoticeData(items, false, null, 1, totalPages);
                liveData.postValue(data);
            } catch (Exception e) {
                NoticeData data = new NoticeData();
                data.setLoading(false);
                data.setError("加载失败: " + e.getMessage());
                liveData.postValue(data);
            }
        });
    }

    private void loadNotices(String view, MutableLiveData<NoticeData> liveData) {
        NoticeData current = liveData.getValue();
        if (current == null) current = new NoticeData();
        current.setLoading(true);
        liveData.setValue(current);

        executor.execute(() -> {
            try {
                httpClient.syncFromCookieManager();
                // 官方APK使用桌面版请求，系统通知参数：view=system
                String url = HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=" + view;
                String html = httpClient.getDesktop(url);
                List<NoticeItem> items = ForumParser.parseNoticeItems(html);
                // ★ 同步更新当前快照，使 isNoticeRelativeNew 能基于最新数据判定
                String snapshot = NoticeBadgeManager.buildSnapshot(view, html, null);
                NoticeBadgeManager.saveCurrentAndGetNewCount(getApplication(), view, snapshot);
                String pagination = ForumParser.parseNoticePagination(html);
                int totalPages = 1;
                if (pagination != null) {
                    try { totalPages = Integer.parseInt(pagination); } catch (NumberFormatException ignored) {}
                }
                NoticeData data = new NoticeData(items, false, null, 1, totalPages);
                liveData.postValue(data);
            } catch (Exception e) {
                NoticeData data = new NoticeData();
                data.setLoading(false);
                data.setError("加载失败: " + e.getMessage());
                liveData.postValue(data);
            }
        });
    }

    public void refreshCurrentTab() {
        MessageTab tab = currentTab.getValue();
        if (tab == null) tab = MessageTab.PRIVATE_MESSAGE;
        switch (tab) {
            case PRIVATE_MESSAGE: loadPrivateMessages(); break;
            case AT_ME: loadAtMeNotices(); break;
            case MY_POST: loadMyPostNotices(); break;
            case OTHER_MESSAGES: loadSystemNotices(); break;
        }
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        executor.shutdownNow();
    }
}