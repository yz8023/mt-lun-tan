package com.forum.MT.ui.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.Spanned;
import android.text.style.ImageSpan;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 私信气泡里的真实图片加载器。
 *
 * <p>与 {@link AnimatedSmileyLoader} 的分工：那个类只负责表情（固定小尺寸、
 * 有本地 drawable 兜底、可能是多帧 GIF）；这个类负责对方发来的普通图片
 * （附件图、OSS 上的 jpg/png，尺寸不定、必须联网、没有本地兜底）。
 *
 * <p>难点在尺寸：{@link ImageSpan} 的行高由 Drawable 的 bounds 决定，而
 * 图片真实尺寸只有下载完成后才知道。若先给零尺寸再变大，气泡会在图片到达时
 * 突然长高（RecyclerView 里表现为列表跳动）。这里的处理是：
 * <ul>
 *   <li>把 URL→缩放后尺寸缓存下来，同一张图第二次绑定时占位框直接就是最终大小，
 *       不再跳变；</li>
 *   <li>首次加载给一个 4:3 的默认占位框，图片就绪后若尺寸变化则
 *       {@code requestLayout()} 让 TextView 重新测量。</li>
 * </ul>
 */
public final class ChatImageLoader {

    /** URL → 已确定的显示尺寸（px），消除重复绑定时的行高跳变。 */
    private static final ConcurrentHashMap<String, int[]> sSizeCache =
            new ConcurrentHashMap<>();

    /**
     * URL → 已解码好的图片。命中时 {@link #obtain} 在返回前就把内容填好，
     * 不经过占位框，也不触发重新测量，因此重进会话不会再闪。
     *
     * <p>容量取堆上限的 1/8：气泡内图片按 680px 宽解码，单张约 1.8MB，
     * 固定 8MB 只够放 4 张，一屏多图就会互相挤掉，等于没有缓存。
     *
     * <p>持有 Glide 产出的 Bitmap 是安全的：这里用的是 application 级
     * {@code RequestManager} 且从不 {@code clear(target)}，资源始终处于 active 状态，
     * 不会被回收进 BitmapPool 复用。
     */
    private static final android.util.LruCache<String, Bitmap> sBitmapCache =
            new android.util.LruCache<String, Bitmap>(
                    (int) Math.max(16L * 1024 * 1024,
                            Runtime.getRuntime().maxMemory() / 8)) {
                @Override
                protected int sizeOf(String key, Bitmap value) {
                    return value.getByteCount();
                }
            };

    /**
     * 尺寸缓存的落盘文件，跨进程保留，使冷启动后首次绑定就是最终高度。
     *
     * <p>名字带 v2：v1 的记录是按当时"随 TextView 实测宽度变化"的 maxWidth 算的，
     * 同一张图可能存过多个互相矛盾的尺寸，必须整体作废。
     */
    private static final String SIZE_PREFS = "chat_image_size_v2";
    /** 超过这个条数就整体清空，避免无上限增长。 */
    private static final int SIZE_PREFS_MAX = 400;
    private static volatile boolean sSizeCacheLoaded;

    private ChatImageLoader() {}

    /**
     * 气泡内图片的显示宽度上限（px）。
     *
     * <p>取布局常量而非实测宽度：{@code TextView.getWidth()} 在 bind 时刻的值
     * 取决于 holder 是新建（0）还是复用（上一条消息的宽度），会让同一张图
     * 算出不同尺寸，与按 URL 建立的尺寸缓存永远对不上。
     * 气泡 {@code maxWidth=266dp}，减去左右各 12dp 内边距。
     */
    public static int bubbleImageWidth(@NonNull Context context) {
        float density = context.getResources().getDisplayMetrics().density;
        return (int) ((266 - 24) * density);
    }

    /**
     * 阻塞式预热：把图片解码进内存缓存后再返回。
     *
     * <p>为什么需要它：{@link #obtain} 是"先给占位框、图片就绪后替换"的异步模型。
     * 进程刚启动时内存缓存为空，即使 Glide 磁盘缓存命中，解码也要几十毫秒，
     * 这段时间气泡里显示的是灰色占位框 —— 就是"重启软件第一次打开会闪"。
     * 首屏渲染前先在后台线程把可见范围内的图片解好，
     * 第一次 {@code onBind} 就能同步拿到 Bitmap，不再经过占位框。
     *
     * <p>必须在后台线程调用。整体耗时由 {@code timeoutMs} 兜住，
     * 超时或失败都直接返回，绝不能因为预热失败而挡住消息显示。
     */
    public static void preload(@NonNull Context context,
                               @NonNull java.util.List<String> urls,
                               long timeoutMs) {
        if (urls.isEmpty()) return;
        final Context appContext = context.getApplicationContext();
        loadSizeCache(appContext);
        int maxWidth = bubbleImageWidth(appContext);
        long deadline = System.currentTimeMillis() + timeoutMs;

        for (String url : urls) {
            if (System.currentTimeMillis() >= deadline) return;
            if (url == null || url.isEmpty()) continue;
            Bitmap exist = sBitmapCache.get(url);
            if (exist != null && !exist.isRecycled()) continue;
            long remain = deadline - System.currentTimeMillis();
            if (remain <= 0) return;
            try {
                Bitmap bitmap = com.bumptech.glide.Glide.with(appContext)
                        .asBitmap()
                        .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(url))
                        .submit()
                        .get(remain, java.util.concurrent.TimeUnit.MILLISECONDS);
                if (bitmap == null || bitmap.isRecycled()) continue;
                int w = bitmap.getWidth();
                int h = bitmap.getHeight();
                if (w <= 0 || h <= 0) continue;
                int showWidth = Math.min(w, maxWidth);
                int showHeight = Math.max(1, (int) ((long) h * showWidth / w));
                putSize(appContext, url, showWidth, showHeight);
                sBitmapCache.put(url, bitmap);
            } catch (Exception ignored) {
                // 预热是纯优化，失败就退回原来的异步加载路径。
            }
        }
    }

    /** 内存缓存里是否已有这张图（供调用方判断是否值得预热）。 */
    public static boolean isCached(@NonNull String url) {
        Bitmap bitmap = sBitmapCache.get(url);
        return bitmap != null && !bitmap.isRecycled();
    }

    /** 日志用短 URL，只保留文件名部分。 */
    private static String shortUrl(String url) {
        if (url == null) return "null";
        int slash = url.lastIndexOf('/');
        return slash >= 0 && slash < url.length() - 1 ? url.substring(slash + 1) : url;
    }

    /**
     * 取一个会自动填充内容的图片 Drawable，立即可用。
     *
     * @param maxWidth 气泡内可用的最大宽度（px）
     * @param host     宿主 TextView，用于图片就绪后的重新测量与重绘
     */
    @NonNull
    public static Drawable obtain(@NonNull Context context, @NonNull String url,
                                  int maxWidth, @NonNull TextView host) {
        final Context appContext = context.getApplicationContext();
        loadSizeCache(appContext);

        // 已解码过的图片直接同步填好：不出现占位框，也没有后续的 setText 重排。
        Bitmap cachedBitmap = sBitmapCache.get(url);
        android.util.Log.w("MT_FLASH", "obtain url=" + shortUrl(url)
                + " bitmapCached=" + (cachedBitmap != null)
                + " sizeCached=" + (sSizeCache.get(url) != null)
                + " maxWidth=" + maxWidth);
        if (cachedBitmap != null && !cachedBitmap.isRecycled()) {
            int w = cachedBitmap.getWidth();
            int h = cachedBitmap.getHeight();
            if (w > 0 && h > 0) {
                int showWidth = Math.min(w, maxWidth);
                int showHeight = Math.max(1, (int) ((long) h * showWidth / w));
                ResizableDrawable ready = new ResizableDrawable(showWidth, showHeight);
                ready.setContent(new BitmapDrawable(appContext.getResources(), cachedBitmap),
                        showWidth, showHeight);
                return ready;
            }
        }

        int[] cached = sSizeCache.get(url);
        int width = cached != null ? cached[0] : maxWidth;
        int height = cached != null ? cached[1] : maxWidth * 3 / 4;
        // 缓存尺寸是按当时的 maxWidth 算的；气泡宽度变了要等比换算，
        // 否则占位框尺寸不对，图片就绪后又会触发一次重排。
        if (cached != null && cached[0] != maxWidth && cached[0] > 0) {
            width = Math.min(cached[0], maxWidth);
            height = Math.max(1, (int) ((long) cached[1] * width / cached[0]));
        }
        final ResizableDrawable wrapper = new ResizableDrawable(width, height);

        com.bumptech.glide.Glide.with(appContext)
                .asBitmap()
                // 与正文图片共用带防盗链 header 的请求，避免同一张图两套缓存键。
                .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(url))
                .into(new com.bumptech.glide.request.target.CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap bitmap,
                                                @Nullable com.bumptech.glide.request.transition.Transition<? super Bitmap> t) {
                        int w = bitmap.getWidth();
                        int h = bitmap.getHeight();
                        if (w <= 0 || h <= 0) return;
                        int showWidth = Math.min(w, maxWidth);
                        int showHeight = Math.max(1, (int) ((long) h * showWidth / w));
                        putSize(appContext, url, showWidth, showHeight);
                        sBitmapCache.put(url, bitmap);
                        // Bitmap 可以共享，但 BitmapDrawable 带有可变的 bounds，
                        // 每个 span 必须持有自己的一份包装。
                        BitmapDrawable drawable =
                                new BitmapDrawable(appContext.getResources(), bitmap);
                        boolean sizeChanged = showWidth != wrapper.getIntrinsicWidth()
                                || showHeight != wrapper.getIntrinsicHeight();
                        android.util.Log.w("MT_FLASH", "onResourceReady url=" + shortUrl(url)
                                + " show=" + showWidth + "x" + showHeight
                                + " placeholder=" + wrapper.getIntrinsicWidth()
                                + "x" + wrapper.getIntrinsicHeight()
                                + " sizeChanged=" + sizeChanged);
                        // 内容必须无条件写进 wrapper：Glide 命中内存缓存时这个回调是
                        // 同步的，此刻 span 还没被 setText 挂到 TextView 上，任何
                        // "是否仍挂在宿主上"的检查都必然为假，一旦据此提前返回，
                        // 这张图就永远停在灰色占位框上，且再也不会有第二次回调。
                        // wrapper 由单个 span 独占，即使 item 已被复用也只是写了个废对象。
                        wrapper.setContent(drawable, showWidth, showHeight);
                        // 刷新宿主必须延后一帧：同步回调时 setText 还没执行，
                        // 立即 invalidate 刷的是上一条消息的内容。
                        refreshHost(host, wrapper, sizeChanged);
                    }

                    @Override
                    public void onLoadFailed(@Nullable Drawable errorDrawable) {
                        wrapper.markFailed();
                        refreshHost(host, wrapper, false);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {}
                });
        return wrapper;
    }

    /** 记录显示尺寸，同时写内存与落盘缓存。 */
    private static void putSize(Context appContext, String url, int width, int height) {
        int[] previous = sSizeCache.put(url, new int[]{width, height});
        if (previous != null && previous[0] == width && previous[1] == height) return;
        try {
            android.content.SharedPreferences prefs =
                    appContext.getSharedPreferences(SIZE_PREFS, Context.MODE_PRIVATE);
            if (prefs.getAll().size() >= SIZE_PREFS_MAX) {
                // 私信图片是流水式内容，旧尺寸没有保留价值，直接整体清空。
                prefs.edit().clear().apply();
                sSizeCache.clear();
                sSizeCache.put(url, new int[]{width, height});
            }
            prefs.edit().putString(url, width + "," + height).apply();
        } catch (Exception ignored) {
            // 落盘失败不影响本次显示。
        }
    }

    /**
     * 首次使用时把落盘的尺寸读进内存。
     *
     * <p>没有这一步，冷启动后第一次进会话所有图片都从 4:3 占位框开始，
     * 图片到达时因高度变化触发 {@code setText + requestLayout}，
     * 表现就是气泡"闪一下"。
     */
    private static void loadSizeCache(Context appContext) {
        if (sSizeCacheLoaded) return;
        synchronized (ChatImageLoader.class) {
            if (sSizeCacheLoaded) return;
            sSizeCacheLoaded = true;
            try {
                android.content.SharedPreferences prefs =
                        appContext.getSharedPreferences(SIZE_PREFS, Context.MODE_PRIVATE);
                for (java.util.Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
                    Object value = entry.getValue();
                    if (!(value instanceof String)) continue;
                    String[] parts = ((String) value).split(",");
                    if (parts.length != 2) continue;
                    int w = Integer.parseInt(parts[0].trim());
                    int h = Integer.parseInt(parts[1].trim());
                    if (w > 0 && h > 0) sSizeCache.put(entry.getKey(), new int[]{w, h});
                }
            } catch (Exception ignored) {
                // 缓存读不出来只是回到"首次加载"的表现，不影响功能。
            }
        }
    }

    /**
     * 图片就绪后刷新宿主 TextView。
     *
     * <p>延后一帧执行，既避开 Glide 同步回调（内存缓存命中）时 span 尚未 setText
     * 的时序问题，也保证此时再做"是否仍挂在宿主上"的判断是准确的。
     *
     * @param sizeChanged 尺寸是否变化；变了必须重新测量，否则 ImageSpan 占的行高
     *                    还是占位框的高度，图片会被裁掉或留下空白
     */
    private static void refreshHost(TextView host, Drawable wrapper, boolean sizeChanged) {
        host.post(() -> {
            boolean attached = isStillAttached(host, wrapper);
            android.util.Log.w("MT_FLASH", "refreshHost attached=" + attached
                    + " sizeChanged=" + sizeChanged);
            if (!attached) return;
            if (sizeChanged) {
                // 只调 requestLayout() 是不够的：TextView 会缓存 StaticLayout，
                // onMeasure 时若测量宽度与缓存 Layout 的宽度一致就直接复用，
                // 于是行高仍是占位框就绪前算出的旧值。图片比占位框高时，
                // DynamicDrawableSpan.draw 以"drawable 底边贴行底"的方式绘制，
                // 多出来的高度全部溢出到行顶之外被裁掉 —— 表现就是图片顶部缺一截。
                // 重新 setText 会走 checkForRelayout → makeNewLayout，
                // 强制按新 bounds 重算行高。文本对象不变，spans 全部保留。
                CharSequence text = host.getText();
                host.setText(text);
                host.requestLayout();
            }
            host.invalidate();
        });
    }

    /**
     * wrapper 是否仍挂在宿主的当前文本上。
     * RecyclerView 可能已把这个 TextView 复用给另一条消息，此时替换毫无意义。
     */
    private static boolean isStillAttached(TextView host, Drawable wrapper) {
        CharSequence text = host.getText();
        if (!(text instanceof Spanned)) return false;
        Spanned spanned = (Spanned) text;
        ImageSpan[] spans = spanned.getSpans(0, spanned.length(), ImageSpan.class);
        for (ImageSpan span : spans) {
            if (span.getDrawable() == wrapper) return true;
        }
        return false;
    }

    /**
     * 内容与尺寸都可替换的 Drawable。
     *
     * <p>{@link ImageSpan} 构造后不提供替换 Drawable 的入口，所以异步加载必须
     * 靠这一层间接。未就绪时画一个浅灰占位框，加载失败画一个带叉的框。
     */
    private static final class ResizableDrawable extends Drawable {
        @Nullable private Drawable content;
        private int width;
        private int height;
        private boolean failed;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        ResizableDrawable(int width, int height) {
            this.width = Math.max(1, width);
            this.height = Math.max(1, height);
            setBounds(0, 0, this.width, this.height);
        }

        void setContent(@NonNull Drawable next, int width, int height) {
            this.content = next;
            this.failed = false;
            this.width = Math.max(1, width);
            this.height = Math.max(1, height);
            next.setBounds(0, 0, this.width, this.height);
            setBounds(0, 0, this.width, this.height);
            invalidateSelf();
        }

        void markFailed() {
            this.failed = true;
            invalidateSelf();
        }

        @Override
        public void draw(@NonNull Canvas canvas) {
            if (content != null) {
                content.draw(canvas);
                return;
            }
            Rect b = getBounds();
            if (!failed) {
                // 刻意什么都不画。
                //
                // 这里原来画的是实心灰块 + 灰边框。尺寸缓存命中时布局已经一次到位
                // （不会跳动），所以占位框唯一的作用就是"先闪一块灰、再换成图片" ——
                // 冷启动首次进入会话时内存缓存为空，这块灰必然出现一次，
                // 就是用户看到的闪。留白反而不可见：气泡背景直接透出来，
                // 图片就绪后原地出现，没有任何颜色跳变。
                return;
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFFE8E8E8);
            canvas.drawRect(b, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setColor(0xFFCCCCCC);
            canvas.drawRect(b, paint);
            // 一个简单的叉，表示这张图取不回来了。
            float inset = Math.min(b.width(), b.height()) * 0.35f;
            canvas.drawLine(b.left + inset, b.top + inset,
                    b.right - inset, b.bottom - inset, paint);
            canvas.drawLine(b.right - inset, b.top + inset,
                    b.left + inset, b.bottom - inset, paint);
        }

        @Override
        public int getIntrinsicWidth() { return width; }

        @Override
        public int getIntrinsicHeight() { return height; }

        @Override
        public void setAlpha(int alpha) {
            if (content != null) content.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(@Nullable ColorFilter colorFilter) {
            if (content != null) content.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }
}
