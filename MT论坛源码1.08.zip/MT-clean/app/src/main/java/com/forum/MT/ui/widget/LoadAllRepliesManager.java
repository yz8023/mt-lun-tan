package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 管理"点进帖子加载全部评论"的设置
 * 开启后，进入帖子详情时自动加载所有页的回复
 */
public class LoadAllRepliesManager {
    private static final String PREF_NAME = "load_all_replies_pref";
    private static final String KEY_ENABLED = "enabled";

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
    }
}