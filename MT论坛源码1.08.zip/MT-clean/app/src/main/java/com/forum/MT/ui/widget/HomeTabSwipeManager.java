package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 首页内容栏（热门内容/最新内容/抢沙发/精华内容）左右滑动开关管理器。
 * 开启（默认）：ViewPager2 可左右滑动切换
 * 关闭：只能点击栏目文字切换，禁止滑动
 */
public class HomeTabSwipeManager {

    private static final String PREF_NAME = "app_settings";
    private static final String KEY_HOME_TAB_SWIPE = "home_tab_swipe_enabled";

    private static boolean swipeEnabled = true;

    public interface OnSwipeChangedListener {
        void onSwipeChanged();
    }

    private static volatile OnSwipeChangedListener listener;

    public static void setListener(OnSwipeChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnSwipeChangedListener l = listener;
        if (l != null) l.onSwipeChanged();
    }

    public static void initialize(Context context) {
        if (context == null) return;
        swipeEnabled = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_HOME_TAB_SWIPE, true);
    }

    public static boolean isSwipeEnabled() {
        return swipeEnabled;
    }

    public static void setSwipeEnabled(Context context, boolean value) {
        swipeEnabled = value;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_HOME_TAB_SWIPE, value).apply();
        }
        notifyChanged();
    }
}