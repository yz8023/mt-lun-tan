package com.forum.MT.ui.message;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.forum.MT.model.MessageTab;

/**
 * ViewPager2 页面适配器 - 对应官方APK的4个Tab
 */
public class NoticePagerAdapter extends FragmentStateAdapter {

    public NoticePagerAdapter(@NonNull Fragment fragment) {
        super(fragment);
    }

    public NoticePagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position == 3) {
            return new FragmentOtherMessages();
        }
        return FragmentNoticeList.newInstance(position);
    }

    @Override
    public int getItemCount() {
        return 4; // 私信/@我/帖子/系统通知
    }

    public CharSequence getPageTitle(int position) {
        return MessageTab.fromIndex(position).getDisplayName();
    }
}