package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理帖子正文加粗文字粗细程度的设置。
 * 与评论加粗（ReplyBoldWeightManager）相同的机制。
 */
public class ThreadBoldWeightManager {

    private static final String PREFS_NAME = "mt_forum_prefs";
    private static final String KEY_THREAD_BOLD_WEIGHT = "thread_bold_weight";
    private static final int DEFAULT_WEIGHT = 700;

    /**
     * 获取用户设置的帖子正文加粗值
     * @param context 上下文
     * @return 字体粗细值 (100-1000)，默认 700
     */
    public static int getWeight(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_THREAD_BOLD_WEIGHT, DEFAULT_WEIGHT);
    }

    /**
     * 保存帖子正文加粗值
     * @param context 上下文
     * @param weight 字体粗细值 (100-1000)
     */
    public static void setWeight(Context context, int weight) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_THREAD_BOLD_WEIGHT, weight).apply();
    }
}
