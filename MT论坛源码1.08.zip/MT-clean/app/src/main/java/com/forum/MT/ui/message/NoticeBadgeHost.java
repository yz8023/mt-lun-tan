package com.forum.MT.ui.message;

/**
 * 消息列表角标宿主。
 * 由实际承载 TabLayout 角标的容器实现（MessageFragment / NoticeActivity），
 * 供列表适配器在标记某条已读后回调刷新对应分类角标。
 */
public interface NoticeBadgeHost {

    /** 某分类下一条内容被标记已读后刷新对应 Tab 角标。 */
    void refreshTabBadge(String viewType);
}