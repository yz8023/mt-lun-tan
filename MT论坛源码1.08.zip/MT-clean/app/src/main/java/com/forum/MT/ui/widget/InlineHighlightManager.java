package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理行内高亮（发帖者用 [backcolor] 实现的代码/技术名词浅色背景）的显示样式：
 * 背景色、文字色、是否启用。
 * 颜色为 0 表示使用默认值。
 */
public class InlineHighlightManager {

    private static final String PREFS_NAME = "mt_forum_prefs";

    private static final String KEY_HL_ENABLED = "inline_hl_enabled";
    private static final String KEY_HL_BG      = "inline_hl_bg_color";
    private static final String KEY_HL_TEXT    = "inline_hl_text_color";

    /** 默认背景：网页 Discuz 原色 #F4F4F4 */
    public static final int DEFAULT_BG_COLOR = 0xFFF4F4F4;
    /** 默认文字色：网页原色 #333333 */
    public static final int DEFAULT_TEXT_COLOR = 0xFF333333;

    private InlineHighlightManager() {}

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_HL_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_HL_ENABLED, enabled).apply();
    }

    public static int getBgColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_HL_BG, 0);
    }

    public static int resolveBgColor(Context context) {
        int color = getBgColor(context);
        return color != 0 ? color : DEFAULT_BG_COLOR;
    }

    public static void setBgColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_HL_BG, color).apply();
    }

    public static int getTextColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_HL_TEXT, 0);
    }

    public static int resolveTextColor(Context context) {
        int color = getTextColor(context);
        return color != 0 ? color : DEFAULT_TEXT_COLOR;
    }

    public static void setTextColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_HL_TEXT, color).apply();
    }
}