package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 底部导航栏"+"按钮居中开关管理器。
 * 关闭（默认）：+ 按钮凸起上移（-14dp）
 * 开启：+ 按钮上下居中（topMargin=0），仅非官方导航栏样式下生效。
 */
public class NavPostCenterManager {

    private static final String PREF_NAME = "app_settings";
    private static final String KEY_POST_CENTER = "nav_post_center";

    private static boolean postCenter = false;

    public interface OnPostCenterChangedListener {
        void onPostCenterChanged();
    }

    private static volatile OnPostCenterChangedListener listener;

    public static void setListener(OnPostCenterChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnPostCenterChangedListener l = listener;
        if (l != null) l.onPostCenterChanged();
    }

    public static void initialize(Context context) {
        if (context == null) return;
        postCenter = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_POST_CENTER, false);
    }

    public static boolean isPostCenter() {
        return postCenter;
    }

    public static void setPostCenter(Context context, boolean value) {
        postCenter = value;
        if (context != null) {
            context.getApplicationContext()
                    .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_POST_CENTER, value).apply();
        }
        notifyChanged();
    }
}
