package com.forum.MT.ui.widget;

import android.content.Context;

/**
 * 管理"滑动切换评论区"设置。
 * 开启后，帖子正文和评论区分离为两个全屏页面，通过向右滑动无缝切换到评论区。
 * 与"回复区独立滚动"互斥：开启本设置时自动关闭"回复区独立滚动"。
 */
public class SwipeCommentManager {
    private static final String PREF_NAME = "swipe_comment_pref";
    private static final String KEY_ENABLED = "enabled";

    /**
     * 默认关闭。
     */
    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
    }
}
