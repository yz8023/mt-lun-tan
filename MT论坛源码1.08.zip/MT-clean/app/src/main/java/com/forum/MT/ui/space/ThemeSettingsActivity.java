package com.forum.MT.ui.space;
import com.forum.MT.ui.BaseActivity;

import android.view.View;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.forum.MT.R;
import com.forum.MT.databinding.ActivityThemeSettingsBinding;
import com.forum.MT.ui.widget.CommentBorderDrawable;
import com.forum.MT.ui.widget.ForumCardColorManager;
import com.forum.MT.ui.widget.RainbowBorderDrawable;
import com.forum.MT.ui.widget.RainbowBorderHelper;
import com.forum.MT.ui.widget.CardBorderManager;
import com.forum.MT.ui.widget.BackgroundColorManager;
import com.forum.MT.ui.widget.BottomNavBarColorManager;
import com.forum.MT.ui.widget.NavBarStyleManager;
import com.forum.MT.ui.widget.NavPostCenterManager;
import com.forum.MT.ui.widget.ForceDefaultTextColorManager;
import com.forum.MT.ui.widget.CardColorManager;
import com.forum.MT.ui.widget.AccentColorManager;
import com.forum.MT.ui.widget.ChatColorManager;
import com.forum.MT.ui.widget.TitleColorManager;
import com.forum.MT.ui.widget.StatusBarColorManager;
import com.forum.MT.ui.widget.ThreadTagColorManager;
import com.forum.MT.ui.widget.ReplyBlacklistManager;

/**
 * 主题子设置页 — 流水灯效果开关 + 自定义颜色
 */
public class ThemeSettingsActivity extends BaseActivity {

    private ActivityThemeSettingsBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityThemeSettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        RainbowBorderHelper.applyToCardViews(binding.getRoot(), this);

        // ===== 卡片边框效果（与流水灯互斥）=====
        boolean cardBorderEnabled = CardBorderManager.isEnabled();
        binding.switchCardBorder.setChecked(cardBorderEnabled);
        binding.switchCardBorder.setOnCheckedChangeListener((buttonView, isChecked) -> {
            CardBorderManager.setEnabled(this, isChecked);
            if (isChecked) {
                // 互斥：开启卡片边框时强制关闭流水灯
                binding.switchRainbowBorder.setChecked(false);
            }
        });

        // 流水灯效果开关
        boolean rainbowEnabled = RainbowBorderDrawable.isGloballyEnabled();
        binding.switchRainbowBorder.setChecked(rainbowEnabled);
        binding.switchRainbowBorder.setOnCheckedChangeListener((buttonView, isChecked) -> {
            RainbowBorderDrawable.setGlobalEnabled(this, isChecked);
            if (isChecked) {
                // 互斥：开启流水灯时强制关闭卡片边框
                binding.switchCardBorder.setChecked(false);
            }
        });

        // 自定义颜色（流水灯与帖子边框共用）
        updateColorPreview();
        binding.cardCustomColor.setOnClickListener(v -> showColorPickerDialog());

        // ===== 评论描边边框 =====
        boolean commentBorderEnabled = CommentBorderDrawable.isEnabled();
        binding.switchCommentBorder.setChecked(commentBorderEnabled);
        binding.switchCommentBorder.setOnCheckedChangeListener((buttonView, isChecked) ->
                CommentBorderDrawable.setEnabled(this, isChecked));

        updateCommentBorderColorPreview();
        binding.cardCommentBorderColor.setOnClickListener(v -> showCommentBorderColorPickerDialog());

        // 评论背景色
        updateCommentBgColorPreview();
        binding.cardCommentBgColor.setOnClickListener(v -> showCommentBgColorPickerDialog());

        // ===== 引用内容 =====
        updateQuoteBgColorPreview();
        binding.cardQuoteBgColor.setOnClickListener(v -> showQuoteBgColorPickerDialog());

        updateQuoteBorderColorPreview();
        binding.cardQuoteBorderColor.setOnClickListener(v -> showQuoteBorderColorPickerDialog());

        updateQuoteTitleColorPreview();
        binding.cardQuoteTitleColor.setOnClickListener(v -> showQuoteTitleColorPickerDialog());

        updateQuoteTextColorPreview();
        binding.cardQuoteTextColor.setOnClickListener(v -> showQuoteTextColorPickerDialog());

        // ===== 私信聊天配色 =====
        setupChatColorCards();

        // ===== 表格配色 =====
        updateTableHeaderBgPreview();
        binding.cardTableHeaderBg.setOnClickListener(v -> showTableHeaderBgPickerDialog());

        updateTableCellBgPreview();
        binding.cardTableCellBg.setOnClickListener(v -> showTableCellBgPickerDialog());

        updateTableBorderColorPreview();
        binding.cardTableBorderColor.setOnClickListener(v -> showTableBorderColorPickerDialog());

        updateTableTextColorPreview();
        binding.cardTableTextColor.setOnClickListener(v -> showTableTextColorPickerDialog());

        // ===== 行内代码配色 =====
        binding.switchInlineCodeEnabled.setChecked(com.forum.MT.ui.widget.InlineHighlightManager.isEnabled(this));
        binding.switchInlineCodeEnabled.setOnCheckedChangeListener((buttonView, isChecked) ->
                com.forum.MT.ui.widget.InlineHighlightManager.setEnabled(this, isChecked));
        updateInlineCodeBgPreview();
        binding.cardInlineCodeBg.setOnClickListener(v -> showInlineCodeBgPickerDialog());
        updateInlineCodeTextPreview();
        binding.cardInlineCodeText.setOnClickListener(v -> showInlineCodeTextPickerDialog());

        // ===== 代码块配色 =====
        updateCodeBlockBgPreview();
        binding.cardCodeBlockBg.setOnClickListener(v -> showCodeBlockBgPickerDialog());
        updateCodeBlockTextPreview();
        binding.cardCodeBlockText.setOnClickListener(v -> showCodeBlockTextPickerDialog());
        updateCodeBlockBorderPreview();
        binding.cardCodeBlockBorder.setOnClickListener(v -> showCodeBlockBorderPickerDialog());
        updateCodeBlockTitleBgPreview();
        binding.cardCodeBlockTitleBg.setOnClickListener(v -> showCodeBlockTitleBgPickerDialog());
        updateCodeBlockTitleTextPreview();
        binding.cardCodeBlockTitleText.setOnClickListener(v -> showCodeBlockTitleTextPickerDialog());

        // ===== 回复弹窗颜色 =====
        updateReplyDialogBgPreview();
        binding.cardReplyDialogBg.setOnClickListener(v -> showReplyDialogBgPickerDialog());
        updateReplyDialogTextPreview();
        binding.cardReplyDialogText.setOnClickListener(v -> showReplyDialogTextPickerDialog());
        updateReplyDialogBorderPreview();
        binding.cardReplyDialogBorder.setOnClickListener(v -> showReplyDialogBorderPickerDialog());
        updateReplyDialogBtnPreview();
        binding.cardReplyDialogBtn.setOnClickListener(v -> showReplyDialogBtnPickerDialog());

        // ===== 板块卡片颜色 =====
        updateForumColorPreview();
        binding.cardForumColor.setOnClickListener(v -> showForumColorPickerDialog());

        // ===== 全局背景色 =====
        updateGlobalBackgroundPreview();
        binding.cardGlobalBackground.setOnClickListener(v -> showGlobalBackgroundColorPickerDialog());
        BackgroundColorManager.apply(binding.getRoot());

        // ===== 内容卡片背景色 =====
        updateCardBgPreview();
        binding.cardCardBgColor.setOnClickListener(v -> showCardBgColorPickerDialog());

        // ===== 底部导航栏颜色 =====
        updateNavBgPreview();
        updateNavActivePreview();
        updateNavInactivePreview();
        binding.cardNavBarBg.setOnClickListener(v -> showNavBgColorPickerDialog());
        binding.cardNavBarActive.setOnClickListener(v -> showNavActiveColorPickerDialog());
        binding.cardNavBarInactive.setOnClickListener(v -> showNavInactiveColorPickerDialog());

        // ===== 凸起发帖按钮颜色 =====
        updatePostBgPreview();
        updatePostIconPreview();
        binding.cardPostBgColor.setOnClickListener(v -> showPostBgColorPickerDialog());
        binding.cardPostIconColor.setOnClickListener(v -> showPostIconColorPickerDialog());

        // ===== 官方导航栏样式开关 =====
        binding.switchNavOfficialStyle.setChecked(NavBarStyleManager.isOfficialStyle());
        binding.switchNavOfficialStyle.setOnCheckedChangeListener((buttonView, isChecked) ->
                NavBarStyleManager.setOfficialStyle(this, isChecked));

        // ===== 加号居中开关（非官方导航栏）=====
        binding.switchNavPostCenter.setChecked(NavPostCenterManager.isPostCenter());
        binding.switchNavPostCenter.setOnCheckedChangeListener((buttonView, isChecked) ->
                NavPostCenterManager.setPostCenter(this, isChecked));

        // ===== 帖子正文强制默认颜色开关 =====
        binding.switchForceDefaultTextColor.setChecked(ForceDefaultTextColorManager.isEnabled());
        binding.switchForceDefaultTextColor.setOnCheckedChangeListener((buttonView, isChecked) ->
                ForceDefaultTextColorManager.setEnabled(this, isChecked));

        // ===== 全局强调色（选中/高亮文字）=====
        updateAccentPreview();
        binding.cardAccentColor.setOnClickListener(v -> showAccentColorPickerDialog());

        // ===== 首页标题颜色 =====
        updateTitleColorPreview();
        binding.cardTitleColor.setOnClickListener(v -> showTitleColorPickerDialog());

        // ===== 状态栏颜色 =====
        updateStatusBarColorPreview();
        binding.cardStatusBarColor.setOnClickListener(v -> showStatusBarColorPickerDialog());

        // ===== 首页标题栏背景颜色 =====
        updateHomeTitleBarBgPreview();
        binding.cardHomeTitleBarBg.setOnClickListener(v -> showHomeTitleBarBgPickerDialog());

        // ===== 首页分类栏背景颜色 =====
        updateHomeTabBarBgPreview();
        binding.cardHomeTabBarBg.setOnClickListener(v -> showHomeTabBarBgPickerDialog());

        // ===== 首页搜索框背景颜色 =====
        updateHomeSearchBarBgPreview();
        binding.cardHomeSearchBarBg.setOnClickListener(v -> showHomeSearchBarBgPickerDialog());

        // ===== 搜索页标题栏背景 =====
        updateSearchPageToolbarBgPreview();
        binding.cardSearchPageToolbarBg.setOnClickListener(v -> showSearchPageToolbarBgPickerDialog());

        // ===== 搜索页输入区背景 =====
        updateSearchPageInputBgPreview();
        binding.cardSearchPageInputBg.setOnClickListener(v -> showSearchPageInputBgPickerDialog());

        // ===== 搜索页排序栏背景 =====
        updateSearchPageSortBgPreview();
        binding.cardSearchPageSortBg.setOnClickListener(v -> showSearchPageSortBgPickerDialog());

        // ===== 搜索页内容区背景 =====
        updateSearchPageContentBgPreview();
        binding.cardSearchPageContentBg.setOnClickListener(v -> showSearchPageContentBgPickerDialog());

        // ===== 搜索按钮颜色 =====
        updateSearchPageButtonBgPreview();
        binding.cardSearchPageButtonBg.setOnClickListener(v -> showSearchPageButtonBgPickerDialog());

        // ===== 帖子顶部背景 =====
        updateThreadTopBgPreview();
        binding.cardThreadTopBg.setOnClickListener(v -> showThreadTopBgPickerDialog());

        // ===== 帖子背景 =====
        updateThreadBgPreview();
        binding.cardThreadBg.setOnClickListener(v -> showThreadBgPickerDialog());

        // ===== 消息页标题栏背景 =====
        updateMessageTitleBgPreview();
        binding.cardMessageTitleBg.setOnClickListener(v -> showMessageTitleBgPickerDialog());

        // ===== 消息页Tab栏背景 =====
        updateMessageTabBgPreview();
        binding.cardMessageTabBg.setOnClickListener(v -> showMessageTabBgPickerDialog());

        // ===== 帖子操作按钮背景 =====
        updateThreadActionBtnBgPreview();
        binding.cardThreadActionBtnBg.setOnClickListener(v -> showThreadActionBtnBgPickerDialog());

        // ===== 底部输入栏背景 =====
        updateReplyBarBgPreview();
        binding.cardReplyBarBg.setOnClickListener(v -> showReplyBarBgPickerDialog());
        updateUnreadBarColorPreview();
        binding.cardUnreadBarColor.setOnClickListener(v -> showUnreadBarColorPickerDialog());

        // ===== 编辑时间文字颜色 =====
        updateEditTimeColorPreview();
        binding.cardEditTimeColor.setOnClickListener(v -> showEditTimeColorPickerDialog());

        // ===== 投票进度条颜色 =====
        updatePollBarColorPreview();
        binding.cardPollBarColor.setOnClickListener(v -> showPollBarColorPickerDialog());

        // ===== 帖子板块标签背景 =====
        updateThreadTagBgPreview();
        binding.cardThreadTagBg.setOnClickListener(v -> showThreadTagBgPickerDialog());

        // ===== 关注按钮背景 =====
        updateThreadFollowBgPreview();
        binding.cardThreadFollowBg.setOnClickListener(v -> showThreadFollowBgPickerDialog());

        // ===== 评论内容加粗文字 =====
        int savedReplyBoldWeight = com.forum.MT.ui.widget.ReplyBoldWeightManager.getWeight(this);
        binding.sbReplyBoldWeight.setProgress(savedReplyBoldWeight);
        binding.tvReplyBoldValue.setText(String.valueOf(savedReplyBoldWeight));
        binding.sbReplyBoldWeight.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                binding.tvReplyBoldValue.setText(String.valueOf(progress));
            }
            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {
                com.forum.MT.ui.widget.ReplyBoldWeightManager.setWeight(
                        ThemeSettingsActivity.this, seekBar.getProgress());
            }
        });

        // ===== 引用内容加粗文字 =====
        int savedWeight = com.forum.MT.ui.widget.QuoteBoldWeightManager.getWeight(this);
        binding.sbQuoteBoldWeight.setProgress(savedWeight);
        binding.tvQuoteBoldValue.setText(String.valueOf(savedWeight));
        binding.sbQuoteBoldWeight.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                binding.tvQuoteBoldValue.setText(String.valueOf(progress));
            }
            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {
                com.forum.MT.ui.widget.QuoteBoldWeightManager.setWeight(
                        ThemeSettingsActivity.this, seekBar.getProgress());
            }
        });

        // ===== 帖子正文加粗文字 =====
        int savedThreadBoldWeight = com.forum.MT.ui.widget.ThreadBoldWeightManager.getWeight(this);
        binding.sbThreadBoldWeight.setProgress(savedThreadBoldWeight);
        binding.tvThreadBoldValue.setText(String.valueOf(savedThreadBoldWeight));
        binding.sbThreadBoldWeight.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                binding.tvThreadBoldValue.setText(String.valueOf(progress));
            }
            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {
                com.forum.MT.ui.widget.ThreadBoldWeightManager.setWeight(
                        ThemeSettingsActivity.this, seekBar.getProgress());
            }
        });

        // ===== 显示大小（帖子正文 / 隐藏内容 / 评论文字 / 编辑时间） =====
        setupSizeSeekBar(
                binding.sbThreadTextSize, binding.tvThreadTextSizeValue,
                com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_THREAD);
        setupSizeSeekBar(
                binding.sbHiddenTextSize, binding.tvHiddenTextSizeValue,
                com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_HIDDEN);
        setupSizeSeekBar(
                binding.sbReplyTextSize, binding.tvReplyTextSizeValue,
                com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_REPLY);
        setupSizeSeekBar(
                binding.sbEditTimeTextSize, binding.tvEditTimeTextSizeValue,
                com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_EDIT_TIME);
        setupSizeSeekBar(
                binding.sbListTextSize, binding.tvListTextSizeValue,
                com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_LIST);
        setupCardScaleSeekBar(binding.sbCardTextSize, binding.tvCardTextSizeValue);

        // ★ 恢复默认大小：重置全部 6 项并刷新滑块
        binding.btnResetTextSize.setOnClickListener(v -> {
            com.forum.MT.ui.widget.ThreadTextSizeManager.resetAll(this);
            setupSizeSeekBar(
                    binding.sbThreadTextSize, binding.tvThreadTextSizeValue,
                    com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_THREAD);
            setupSizeSeekBar(
                    binding.sbHiddenTextSize, binding.tvHiddenTextSizeValue,
                    com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_HIDDEN);
            setupSizeSeekBar(
                    binding.sbReplyTextSize, binding.tvReplyTextSizeValue,
                    com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_REPLY);
            setupSizeSeekBar(
                    binding.sbEditTimeTextSize, binding.tvEditTimeTextSizeValue,
                    com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_EDIT_TIME);
            setupSizeSeekBar(
                    binding.sbListTextSize, binding.tvListTextSizeValue,
                    com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_LIST);
            setupCardScaleSeekBar(binding.sbCardTextSize, binding.tvCardTextSizeValue);
            android.widget.Toast.makeText(this, "已恢复默认大小", android.widget.Toast.LENGTH_SHORT).show();
        });

        // 返回
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        binding.toolbar.setNavigationIcon(null);
    }

    // ==================== 颜色选择 ====================

    private static final int[] PRESET_COLORS = {
            0,                              // 默认黄绿
            Color.parseColor("#FF707646"), // 黄绿（默认）
            Color.rgb(255, 82, 139),        // 粉红
            Color.rgb(255, 193, 79),        // 金橙
            Color.rgb(83, 210, 164),        // 翠绿
            Color.rgb(79, 164, 255),        // 天蓝
            Color.rgb(173, 104, 255),       // 紫色
            Color.rgb(255, 87, 87),         // 红色
            Color.rgb(0, 200, 83),          // 绿色
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(255, 255, 255),       // 白色
    };

    private static final String[] PRESET_COLOR_NAMES = {
            "默认黄绿", "黄绿", "粉红", "金橙", "翠绿", "天蓝", "紫色", "红色", "绿色", "深灰", "白色"
    };

    private void updateColorPreview() {
        int color = RainbowBorderDrawable.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? Color.parseColor("#FF707646") : color);
        }
        binding.tvCustomColorHint.setText(color == 0
                ? "点击选择流水灯颜色（当前：默认黄绿）"
                : "点击选择流水灯颜色（当前：" + getColorName(color) + "）");
    }

    private String getColorName(int color) {
        for (int i = 0; i < PRESET_COLORS.length; i++) {
            if (PRESET_COLORS[i] == color) return PRESET_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showColorPickerDialog() {
        int currentColor = RainbowBorderDrawable.getCustomColor();

        android.view.View dialogView = getLayoutInflater().inflate(R.layout.dialog_color_picker, null);
        android.widget.RadioGroup radioGroup = dialogView.findViewById(R.id.rg_preset_colors);
        android.widget.EditText etHex = dialogView.findViewById(R.id.et_custom_hex);

        // 判断当前颜色是否是预设颜色
        boolean isPreset = false;
        int checkedIndex = 0;
        for (int i = 0; i < PRESET_COLORS.length; i++) {
            if (PRESET_COLORS[i] == currentColor) {
                checkedIndex = i;
                isPreset = true;
                break;
            }
        }

        // 如果是自定义颜色，预填 hex 输入框
        if (!isPreset && currentColor != 0) {
            etHex.setText(String.format("%08X", currentColor));
        }

        for (int i = 0; i < PRESET_COLOR_NAMES.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setText(PRESET_COLOR_NAMES[i]);
            rb.setId(i);
            rb.setTextSize(14);
            rb.setTextColor(getResources().getColor(R.color.text_primary, null));
            if (isPreset && i == checkedIndex) rb.setChecked(true);
            radioGroup.addView(rb);
        }

        final int[] selectedIndex = {checkedIndex};

        // 预设颜色选中时清空 hex 输入框
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            selectedIndex[0] = checkedId;
            etHex.setText("");
        });

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("选择边框颜色")
                .setView(dialogView)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (dialog, which) -> {
                    // 优先使用 hex 输入框的内容
                    String hex = etHex.getText().toString().trim();
                    if (!hex.isEmpty()) {
                        int parsed = parseHexColor(hex);
                        if (parsed != -1) {
                            RainbowBorderDrawable.setCustomColor(this, parsed);
                            CardBorderManager.refreshAll();
                            updateColorPreview();
                            Toast.makeText(this,
                                    "颜色已应用：" + hex.toUpperCase(), Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            Toast.makeText(this,
                                    "色值无效，请检查格式（RRGGBB 或 AARRGGBB）",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    // 未输入 hex 则使用预设颜色
                    int selected = PRESET_COLORS[selectedIndex[0]];
                    RainbowBorderDrawable.setCustomColor(this, selected);
                    CardBorderManager.refreshAll();
                    updateColorPreview();
                    Toast.makeText(this,
                            "颜色已设为：" + PRESET_COLOR_NAMES[selectedIndex[0]],
                            Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    /** 解析 hex 色值，支持 RRGGBB 或 AARRGGBB，返回 int 颜色或 -1 */
    private int parseHexColor(String hex) {
        if (hex == null || hex.isEmpty()) return -1;
        // 去掉可能的 # 前缀
        if (hex.startsWith("#")) hex = hex.substring(1);
        if (hex.startsWith("0x") || hex.startsWith("0X")) hex = hex.substring(2);
        int len = hex.length();
        if (len != 6 && len != 8) return -1;
        try {
            long value = Long.parseLong(hex, 16);
            if (len == 6) {
                // RRGGBB → 不透明
                return (int) (0xFF000000L | value);
            } else {
                // AARRGGBB
                return (int) value;
            }
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ==================== 评论描边颜色 ====================

    private static final int[] COMMENT_BORDER_PRESET_COLORS = {
            0,                              // 默认浅灰
            Color.rgb(218, 220, 224),       // 浅灰（显式）
            Color.rgb(255, 82, 139),        // 粉红
            Color.rgb(255, 193, 79),        // 金橙
            Color.rgb(83, 210, 164),        // 翠绿
            Color.rgb(79, 164, 255),        // 天蓝
            Color.rgb(173, 104, 255),       // 紫色
            Color.rgb(255, 87, 87),         // 红色
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(255, 255, 255),       // 白色
    };

    private static final String[] COMMENT_BORDER_COLOR_NAMES = {
            "默认浅灰", "浅灰", "粉红", "金橙", "翠绿", "天蓝", "紫色", "红色", "深灰", "白色"
    };

    private void updateCommentBorderColorPreview() {
        int color = CommentBorderDrawable.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewCommentBorderColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0
                    ? CommentBorderDrawable.DEFAULT_BORDER_COLOR : color);
        }
        binding.tvCommentBorderColorHint.setText(color == 0
                ? "点击选择评论描边颜色（当前：默认浅灰）"
                : "点击选择评论描边颜色（当前：" + getCommentBorderColorName(color) + "）");
    }

    private String getCommentBorderColorName(int color) {
        for (int i = 0; i < COMMENT_BORDER_PRESET_COLORS.length; i++) {
            if (COMMENT_BORDER_PRESET_COLORS[i] == color) return COMMENT_BORDER_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showCommentBorderColorPickerDialog() {
        int currentColor = CommentBorderDrawable.getCustomColor();

        android.view.View dialogView = getLayoutInflater().inflate(R.layout.dialog_color_picker, null);
        android.widget.RadioGroup radioGroup = dialogView.findViewById(R.id.rg_preset_colors);
        android.widget.EditText etHex = dialogView.findViewById(R.id.et_custom_hex);

        boolean isPreset = false;
        int checkedIndex = 0;
        for (int i = 0; i < COMMENT_BORDER_PRESET_COLORS.length; i++) {
            if (COMMENT_BORDER_PRESET_COLORS[i] == currentColor) {
                checkedIndex = i;
                isPreset = true;
                break;
            }
        }

        if (!isPreset && currentColor != 0) {
            etHex.setText(String.format("%08X", currentColor));
        }

        for (int i = 0; i < COMMENT_BORDER_COLOR_NAMES.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setText(COMMENT_BORDER_COLOR_NAMES[i]);
            rb.setId(i);
            rb.setTextSize(14);
            rb.setTextColor(getResources().getColor(R.color.text_primary, null));
            if (isPreset && i == checkedIndex) rb.setChecked(true);
            radioGroup.addView(rb);
        }

        final int[] selectedIndex = {checkedIndex};

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            selectedIndex[0] = checkedId;
            etHex.setText("");
        });

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("选择评论描边颜色")
                .setView(dialogView)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (dialog, which) -> {
                    String hex = etHex.getText().toString().trim();
                    if (!hex.isEmpty()) {
                        int parsed = parseHexColor(hex);
                        if (parsed != -1) {
                            CommentBorderDrawable.setCustomColor(this, parsed);
                            updateCommentBorderColorPreview();
                            Toast.makeText(this,
                                    "颜色已应用：" + hex.toUpperCase(), Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            Toast.makeText(this,
                                    "色值无效，请检查格式（RRGGBB 或 AARRGGBB）",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    int selected = COMMENT_BORDER_PRESET_COLORS[selectedIndex[0]];
                    CommentBorderDrawable.setCustomColor(this, selected);
                    updateCommentBorderColorPreview();
                    Toast.makeText(this,
                            "颜色已设为：" + COMMENT_BORDER_COLOR_NAMES[selectedIndex[0]],
                            Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    // ==================== 评论背景颜色 ====================

    private static final int[] COMMENT_BG_PRESET_COLORS = {
            0,                              // 默认浅橙
            Color.rgb(250, 251, 252),       // 浅灰白
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(255, 240, 245),       // 浅粉
            Color.rgb(255, 249, 231),       // 浅橙
            Color.rgb(233, 248, 240),       // 浅绿
            Color.rgb(230, 243, 255),       // 浅蓝
            Color.rgb(246, 237, 255),       // 浅紫
            Color.rgb(255, 235, 235),       // 浅红
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(66, 66, 66),          // 中灰
    };

    private static final String[] COMMENT_BG_COLOR_NAMES = {
            "默认浅橙", "浅灰白", "白色", "浅粉", "浅橙", "浅绿", "浅蓝", "浅紫", "浅红", "深灰", "中灰"
    };

    private void updateCommentBgColorPreview() {
        int color = CommentBorderDrawable.getBgColor();
        android.graphics.drawable.Drawable bg = binding.viewCommentBgColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0
                    ? CommentBorderDrawable.DEFAULT_FILL_COLOR : color);
        }
        binding.tvCommentBgColorHint.setText(color == 0
                ? "点击选择评论背景色（当前：默认浅橙）"
                : "点击选择评论背景色（当前：" + getCommentBgColorName(color) + "）");
    }

    private String getCommentBgColorName(int color) {
        for (int i = 0; i < COMMENT_BG_PRESET_COLORS.length; i++) {
            if (COMMENT_BG_PRESET_COLORS[i] == color) return COMMENT_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showCommentBgColorPickerDialog() {
        showNavColorPickerDialog(CommentBorderDrawable.getBgColor(),
                COMMENT_BG_PRESET_COLORS, COMMENT_BG_COLOR_NAMES, "选择评论背景色",
                (color) -> {
                    CommentBorderDrawable.setBgColor(this, color);
                    updateCommentBgColorPreview();
                });
    }

    // ==================== 引用内容背景色 ====================

    private static final int[] QUOTE_BG_PRESET_COLORS = {
            0,                              // 默认浅绿色
            Color.rgb(240, 253, 250),       // 浅绿色（显式）
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(245, 247, 250),       // 浅灰白
            Color.rgb(255, 240, 245),       // 浅粉
            Color.rgb(255, 249, 231),       // 浅橙
            Color.rgb(233, 248, 240),       // 浅绿
            Color.rgb(230, 243, 255),       // 浅蓝
            Color.rgb(246, 237, 255),       // 浅紫
            Color.rgb(255, 235, 235),       // 浅红
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(66, 66, 66),          // 中灰
    };

    private static final String[] QUOTE_BG_COLOR_NAMES = {
            "默认浅绿色", "浅绿色", "白色", "浅灰白", "浅粉", "浅橙", "浅绿", "浅蓝", "浅紫", "浅红", "深灰", "中灰"
    };

    private void updateQuoteBgColorPreview() {
        int color = com.forum.MT.ui.widget.QuoteBgColorManager.getBgColor(this);
        android.graphics.drawable.Drawable bg = binding.viewQuoteBgColorPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.QuoteBgColorManager.DEFAULT_BG_COLOR : color);
        }
        binding.tvQuoteBgColorHint.setText(color == 0
                ? "点击选择引用内容卡片背景色（当前：默认浅绿色）"
                : "点击选择引用内容卡片背景色（当前：" + getQuoteBgColorName(color) + "）");
    }

    private String getQuoteBgColorName(int color) {
        for (int i = 0; i < QUOTE_BG_PRESET_COLORS.length; i++) {
            if (QUOTE_BG_PRESET_COLORS[i] == color) return QUOTE_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showQuoteBgColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.QuoteBgColorManager.getBgColor(this),
                QUOTE_BG_PRESET_COLORS, QUOTE_BG_COLOR_NAMES, "选择引用背景色",
                (color) -> {
                    com.forum.MT.ui.widget.QuoteBgColorManager.setBgColor(this, color);
                    updateQuoteBgColorPreview();
                });
    }

    // ==================== 引用边框色 ====================

    private static final int[] QUOTE_BORDER_PRESET_COLORS = {
            0,                              // 默认青绿色
            Color.rgb(45, 212, 191),        // 青绿色（显式）
            Color.rgb(218, 220, 224),       // 浅灰
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(66, 66, 66),          // 中灰
            Color.rgb(255, 125, 125),       // 亮红
            Color.rgb(255, 177, 57),        // 橙黄
            Color.rgb(126, 211, 33),        // 草绿
            Color.rgb(80, 144, 235),        // 亮蓝
            Color.rgb(168, 85, 247),        // 亮紫
    };

    private static final String[] QUOTE_BORDER_COLOR_NAMES = {
            "默认青绿色", "青绿色", "浅灰", "深灰", "中灰", "亮红", "橙黄", "草绿", "亮蓝", "亮紫"
    };

    private void updateQuoteBorderColorPreview() {
        int color = com.forum.MT.ui.widget.QuoteBgColorManager.getBorderColor(this);
        android.graphics.drawable.Drawable bg = binding.viewQuoteBorderColorPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.QuoteBgColorManager.DEFAULT_BORDER_COLOR : color);
        }
        binding.tvQuoteBorderColorHint.setText(color == 0
                ? "点击选择引用内容卡片边框颜色（当前：默认青绿色）"
                : "点击选择引用内容卡片边框颜色（当前：" + getQuoteBorderColorName(color) + "）");
    }

    private String getQuoteBorderColorName(int color) {
        for (int i = 0; i < QUOTE_BORDER_PRESET_COLORS.length; i++) {
            if (QUOTE_BORDER_PRESET_COLORS[i] == color) return QUOTE_BORDER_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showQuoteBorderColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.QuoteBgColorManager.getBorderColor(this),
                QUOTE_BORDER_PRESET_COLORS, QUOTE_BORDER_COLOR_NAMES, "选择引用边框色",
                (color) -> {
                    com.forum.MT.ui.widget.QuoteBgColorManager.setBorderColor(this, color);
                    updateQuoteBorderColorPreview();
                });
    }

    // ==================== 引用标题文字色 ====================

    private static final int[] QUOTE_TITLE_PRESET_COLORS = {
            0,                              // 默认深青色
            Color.rgb(15, 118, 110),        // 深青色（显式）
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(66, 66, 66),          // 中灰
            Color.rgb(211, 47, 47),         // 红色
            Color.rgb(249, 168, 37),        // 橙黄
            Color.rgb(67, 160, 71),         // 绿色
            Color.rgb(25, 118, 210),        // 蓝色
            Color.rgb(124, 58, 237),        // 紫色
    };

    private static final String[] QUOTE_TITLE_COLOR_NAMES = {
            "默认深青色", "深青色", "白色", "深灰", "中灰", "红色", "橙黄", "绿色", "蓝色", "紫色"
    };

    private void updateQuoteTitleColorPreview() {
        int color = com.forum.MT.ui.widget.QuoteBgColorManager.getTitleColor(this);
        android.graphics.drawable.Drawable bg = binding.viewQuoteTitleColorPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.QuoteBgColorManager.DEFAULT_TITLE_COLOR : color);
        }
        binding.tvQuoteTitleColorHint.setText(color == 0
                ? "点击选择引用卡片标题「引用内容」文字颜色（当前：默认深青色）"
                : "点击选择引用卡片标题「引用内容」文字颜色（当前：" + getQuoteTitleColorName(color) + "）");
    }

    private String getQuoteTitleColorName(int color) {
        for (int i = 0; i < QUOTE_TITLE_PRESET_COLORS.length; i++) {
            if (QUOTE_TITLE_PRESET_COLORS[i] == color) return QUOTE_TITLE_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showQuoteTitleColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.QuoteBgColorManager.getTitleColor(this),
                QUOTE_TITLE_PRESET_COLORS, QUOTE_TITLE_COLOR_NAMES, "选择引用标题文字色",
                (color) -> {
                    com.forum.MT.ui.widget.QuoteBgColorManager.setTitleColor(this, color);
                    updateQuoteTitleColorPreview();
                });
    }

    // ==================== 引用正文字色 ====================

    private static final int[] QUOTE_TEXT_PRESET_COLORS = {
            0,                              // 默认深蓝黑
            Color.rgb(26, 26, 46),          // 深蓝黑（显式）
            Color.rgb(0, 0, 0),             // 纯黑
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(66, 66, 66),          // 中灰
            Color.rgb(211, 47, 47),         // 红色
            Color.rgb(249, 168, 37),        // 橙黄
            Color.rgb(67, 160, 71),         // 绿色
            Color.rgb(25, 118, 210),        // 蓝色
            Color.rgb(124, 58, 237),        // 紫色
    };

    private static final String[] QUOTE_TEXT_COLOR_NAMES = {
            "默认深蓝黑", "深蓝黑", "纯黑", "白色", "深灰", "中灰", "红色", "橙黄", "绿色", "蓝色", "紫色"
    };

    private void updateQuoteTextColorPreview() {
        int color = com.forum.MT.ui.widget.QuoteBgColorManager.getTextColor(this);
        android.graphics.drawable.Drawable bg = binding.viewQuoteTextColorPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.QuoteBgColorManager.DEFAULT_TEXT_COLOR : color);
        }
        binding.tvQuoteTextColorHint.setText(color == 0
                ? "点击选择引用内容正文文字颜色（当前：默认深蓝黑）"
                : "点击选择引用内容正文文字颜色（当前：" + getQuoteTextColorName(color) + "）");
    }

    private String getQuoteTextColorName(int color) {
        for (int i = 0; i < QUOTE_TEXT_PRESET_COLORS.length; i++) {
            if (QUOTE_TEXT_PRESET_COLORS[i] == color) return QUOTE_TEXT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showQuoteTextColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.QuoteBgColorManager.getTextColor(this),
                QUOTE_TEXT_PRESET_COLORS, QUOTE_TEXT_COLOR_NAMES, "选择引用正文字色",
                (color) -> {
                    com.forum.MT.ui.widget.QuoteBgColorManager.setTextColor(this, color);
                    updateQuoteTextColorPreview();
                });
    }

    // ==================== 私信聊天配色 ====================

    /** 气泡底色可选项：偏浅的底色为主，保证深色文字可读。 */
    private static final int[] CHAT_BUBBLE_PRESET_COLORS = {
            0,                              // 默认
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(255, 64, 129),        // 粉色
            Color.rgb(33, 150, 243),        // 蓝色
            Color.rgb(76, 175, 80),         // 绿色
            Color.rgb(255, 152, 0),         // 橙色
            Color.rgb(156, 39, 176),        // 紫色
            Color.rgb(149, 236, 105),       // 微信绿
            Color.rgb(240, 240, 240),       // 浅灰
            Color.rgb(66, 66, 66),          // 深灰
            Color.rgb(33, 33, 33),          // 近黑
    };

    private static final String[] CHAT_BUBBLE_IN_COLOR_NAMES = {
            "默认白色", "白色", "粉色", "蓝色", "绿色", "橙色", "紫色", "微信绿", "浅灰", "深灰", "近黑"
    };

    private static final String[] CHAT_BUBBLE_OUT_COLOR_NAMES = {
            "默认粉色", "白色", "粉色", "蓝色", "绿色", "橙色", "紫色", "微信绿", "浅灰", "深灰", "近黑"
    };

    /** 文字与链接共用的色板。 */
    private static final int[] CHAT_TEXT_PRESET_COLORS = {
            0,                              // 默认
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(66, 66, 66),          // 中灰
            Color.rgb(21, 101, 192),        // 深蓝
            Color.rgb(33, 150, 243),        // 亮蓝
            Color.rgb(211, 47, 47),         // 红色
            Color.rgb(249, 168, 37),        // 橙黄
            Color.rgb(67, 160, 71),         // 绿色
            Color.rgb(124, 58, 237),        // 紫色
    };

    private static final String[] CHAT_TEXT_IN_COLOR_NAMES = {
            "默认深灰", "白色", "深灰", "中灰", "深蓝", "亮蓝", "红色", "橙黄", "绿色", "紫色"
    };

    private static final String[] CHAT_TEXT_OUT_COLOR_NAMES = {
            "默认白色", "白色", "深灰", "中灰", "深蓝", "亮蓝", "红色", "橙黄", "绿色", "紫色"
    };

    private static final String[] CHAT_LINK_IN_COLOR_NAMES = {
            "默认深蓝", "白色", "深灰", "中灰", "深蓝", "亮蓝", "红色", "橙黄", "绿色", "紫色"
    };

    private static final String[] CHAT_LINK_OUT_COLOR_NAMES = {
            "默认白色", "白色", "深灰", "中灰", "深蓝", "亮蓝", "红色", "橙黄", "绿色", "紫色"
    };

    private void setupChatColorCards() {
        updateChatBubbleInPreview();
        binding.cardChatBubbleInColor.setOnClickListener(v -> showNavColorPickerDialog(
                ChatColorManager.getBubbleInColor(this),
                CHAT_BUBBLE_PRESET_COLORS, CHAT_BUBBLE_IN_COLOR_NAMES, "选择对方气泡底色",
                (color) -> {
                    ChatColorManager.setBubbleInColor(this, color);
                    updateChatBubbleInPreview();
                }));

        updateChatBubbleOutPreview();
        binding.cardChatBubbleOutColor.setOnClickListener(v -> showNavColorPickerDialog(
                ChatColorManager.getBubbleOutColor(this),
                CHAT_BUBBLE_PRESET_COLORS, CHAT_BUBBLE_OUT_COLOR_NAMES, "选择我的气泡底色",
                (color) -> {
                    ChatColorManager.setBubbleOutColor(this, color);
                    updateChatBubbleOutPreview();
                }));

        updateChatTextInPreview();
        binding.cardChatTextInColor.setOnClickListener(v -> showNavColorPickerDialog(
                ChatColorManager.getTextInColor(this),
                CHAT_TEXT_PRESET_COLORS, CHAT_TEXT_IN_COLOR_NAMES, "选择对方气泡文字色",
                (color) -> {
                    ChatColorManager.setTextInColor(this, color);
                    updateChatTextInPreview();
                }));

        updateChatTextOutPreview();
        binding.cardChatTextOutColor.setOnClickListener(v -> showNavColorPickerDialog(
                ChatColorManager.getTextOutColor(this),
                CHAT_TEXT_PRESET_COLORS, CHAT_TEXT_OUT_COLOR_NAMES, "选择我的气泡文字色",
                (color) -> {
                    ChatColorManager.setTextOutColor(this, color);
                    updateChatTextOutPreview();
                }));

        updateChatLinkInPreview();
        binding.cardChatLinkInColor.setOnClickListener(v -> showNavColorPickerDialog(
                ChatColorManager.getLinkInColor(this),
                CHAT_TEXT_PRESET_COLORS, CHAT_LINK_IN_COLOR_NAMES, "选择对方气泡链接色",
                (color) -> {
                    ChatColorManager.setLinkInColor(this, color);
                    updateChatLinkInPreview();
                }));

        updateChatLinkOutPreview();
        binding.cardChatLinkOutColor.setOnClickListener(v -> showNavColorPickerDialog(
                ChatColorManager.getLinkOutColor(this),
                CHAT_TEXT_PRESET_COLORS, CHAT_LINK_OUT_COLOR_NAMES, "选择我的气泡链接色",
                (color) -> {
                    ChatColorManager.setLinkOutColor(this, color);
                    updateChatLinkOutPreview();
                }));
    }

    /**
     * 刷新单个聊天配色卡的色块与提示文案。
     *
     * @param saved     已保存值（0 表示默认）
     * @param fallback  默认颜色，用于色块显示
     * @param presets   预设色板，用于反查颜色名
     * @param names     颜色名
     * @param preview   色块 View
     * @param hint      提示文案 TextView
     * @param prefix    提示文案前缀
     */
    private void updateChatColorCard(int saved, int fallback, int[] presets, String[] names,
                                     android.view.View preview, TextView hint, String prefix) {
        android.graphics.drawable.Drawable bg = preview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(saved == 0 ? fallback : saved);
        }
        String name = "自定义颜色";
        for (int i = 0; i < presets.length; i++) {
            if (presets[i] == saved) {
                name = names[i];
                break;
            }
        }
        hint.setText(prefix + "（当前：" + name + "）");
    }

    private void updateChatBubbleInPreview() {
        updateChatColorCard(ChatColorManager.getBubbleInColor(this),
                ChatColorManager.DEFAULT_BUBBLE_IN,
                CHAT_BUBBLE_PRESET_COLORS, CHAT_BUBBLE_IN_COLOR_NAMES,
                binding.viewChatBubbleInColorPreview, binding.tvChatBubbleInColorHint,
                "点击选择对方消息气泡背景色");
    }

    private void updateChatBubbleOutPreview() {
        updateChatColorCard(ChatColorManager.getBubbleOutColor(this),
                ChatColorManager.DEFAULT_BUBBLE_OUT,
                CHAT_BUBBLE_PRESET_COLORS, CHAT_BUBBLE_OUT_COLOR_NAMES,
                binding.viewChatBubbleOutColorPreview, binding.tvChatBubbleOutColorHint,
                "点击选择自己消息气泡背景色");
    }

    private void updateChatTextInPreview() {
        updateChatColorCard(ChatColorManager.getTextInColor(this),
                ChatColorManager.DEFAULT_TEXT_IN,
                CHAT_TEXT_PRESET_COLORS, CHAT_TEXT_IN_COLOR_NAMES,
                binding.viewChatTextInColorPreview, binding.tvChatTextInColorHint,
                "点击选择对方消息文字颜色");
    }

    private void updateChatTextOutPreview() {
        updateChatColorCard(ChatColorManager.getTextOutColor(this),
                ChatColorManager.DEFAULT_TEXT_OUT,
                CHAT_TEXT_PRESET_COLORS, CHAT_TEXT_OUT_COLOR_NAMES,
                binding.viewChatTextOutColorPreview, binding.tvChatTextOutColorHint,
                "点击选择自己消息文字颜色");
    }

    private void updateChatLinkInPreview() {
        updateChatColorCard(ChatColorManager.getLinkInColor(this),
                ChatColorManager.DEFAULT_LINK_IN,
                CHAT_TEXT_PRESET_COLORS, CHAT_LINK_IN_COLOR_NAMES,
                binding.viewChatLinkInColorPreview, binding.tvChatLinkInColorHint,
                "点击选择对方消息中链接的颜色");
    }

    private void updateChatLinkOutPreview() {
        updateChatColorCard(ChatColorManager.getLinkOutColor(this),
                ChatColorManager.DEFAULT_LINK_OUT,
                CHAT_TEXT_PRESET_COLORS, CHAT_LINK_OUT_COLOR_NAMES,
                binding.viewChatLinkOutColorPreview, binding.tvChatLinkOutColorHint,
                "点击选择自己消息中链接的颜色");
    }

    // ==================== 表格配色 ====================

    private static final int[] TABLE_BG_PRESET_COLORS = {
            0,                              // 默认（浅灰 #F5F5F5）
            Color.rgb(245, 245, 245),       // 浅灰（显式）
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(232, 240, 254),       // 浅蓝
            Color.rgb(232, 245, 233),       // 浅绿
            Color.rgb(255, 243, 224),       // 浅橙
            Color.rgb(255, 235, 238),       // 浅红
            Color.rgb(238, 232, 255),       // 浅紫
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(13, 71, 161),         // 深蓝
    };

    private static final String[] TABLE_BG_COLOR_NAMES = {
            "默认浅灰", "浅灰", "白色", "浅蓝", "浅绿", "浅橙", "浅红", "浅紫", "深灰", "深蓝"
    };

    private void updateTableHeaderBgPreview() {
        int color = com.forum.MT.ui.widget.TableColorManager.getHeaderBg(this);
        android.graphics.drawable.Drawable bg = binding.viewTableHeaderBgPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.TableColorManager.resolveHeaderBg(this) : color);
        }
        binding.tvTableHeaderBgHint.setText(color == 0
                ? "点击选择表格表头背景色（当前：默认浅灰）"
                : "点击选择表格表头背景色（当前：" + getTableBgColorName(color) + "）");
    }

    private String getTableBgColorName(int color) {
        for (int i = 0; i < TABLE_BG_PRESET_COLORS.length; i++) {
            if (TABLE_BG_PRESET_COLORS[i] == color) return TABLE_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showTableHeaderBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.TableColorManager.getHeaderBg(this),
                TABLE_BG_PRESET_COLORS, TABLE_BG_COLOR_NAMES, "选择表格表头背景色",
                (color) -> {
                    com.forum.MT.ui.widget.TableColorManager.setHeaderBg(this, color);
                    updateTableHeaderBgPreview();
                });
    }

    private void updateTableCellBgPreview() {
        int color = com.forum.MT.ui.widget.TableColorManager.getCellBg(this);
        android.graphics.drawable.Drawable bg = binding.viewTableCellBgPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.TableColorManager.resolveCellBg(this) : color);
        }
        binding.tvTableCellBgHint.setText(color == 0
                ? "点击选择表格单元格背景色（当前：默认白色）"
                : "点击选择表格单元格背景色（当前：" + getTableBgColorName(color) + "）");
    }

    private void showTableCellBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.TableColorManager.getCellBg(this),
                TABLE_BG_PRESET_COLORS, TABLE_BG_COLOR_NAMES, "选择表格单元格背景色",
                (color) -> {
                    com.forum.MT.ui.widget.TableColorManager.setCellBg(this, color);
                    updateTableCellBgPreview();
                });
    }

    private static final int[] TABLE_BORDER_PRESET_COLORS = {
            0,                              // 默认浅灰
            Color.rgb(189, 189, 189),       // 浅灰（显式）
            Color.rgb(158, 158, 158),       // 中灰
            Color.rgb(97, 97, 97),          // 深灰
            Color.rgb(66, 66, 66),          // 更深灰
            Color.rgb(25, 118, 210),        // 蓝色
            Color.rgb(67, 160, 71),         // 绿色
            Color.rgb(255, 160, 0),         // 橙
            Color.rgb(211, 47, 47),         // 红色
            Color.rgb(124, 58, 237),        // 紫色
    };

    private static final String[] TABLE_BORDER_COLOR_NAMES = {
            "默认浅灰", "浅灰", "中灰", "深灰", "更深灰", "蓝色", "绿色", "橙色", "红色", "紫色"
    };

    private void updateTableBorderColorPreview() {
        int color = com.forum.MT.ui.widget.TableColorManager.getBorderColor(this);
        android.graphics.drawable.Drawable bg = binding.viewTableBorderColorPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.TableColorManager.resolveBorderColor(this) : color);
        }
        binding.tvTableBorderColorHint.setText(color == 0
                ? "点击选择表格边框颜色（当前：默认浅灰）"
                : "点击选择表格边框颜色（当前：" + getTableBorderColorName(color) + "）");
    }

    private String getTableBorderColorName(int color) {
        for (int i = 0; i < TABLE_BORDER_PRESET_COLORS.length; i++) {
            if (TABLE_BORDER_PRESET_COLORS[i] == color) return TABLE_BORDER_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showTableBorderColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.TableColorManager.getBorderColor(this),
                TABLE_BORDER_PRESET_COLORS, TABLE_BORDER_COLOR_NAMES, "选择表格边框色",
                (color) -> {
                    com.forum.MT.ui.widget.TableColorManager.setBorderColor(this, color);
                    updateTableBorderColorPreview();
                });
    }

    private static final int[] TABLE_TEXT_PRESET_COLORS = {
            0,                              // 默认黑色
            Color.rgb(0, 0, 0),             // 纯黑
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(66, 66, 66),          // 中灰
            Color.rgb(211, 47, 47),         // 红色
            Color.rgb(249, 168, 37),        // 橙黄
            Color.rgb(67, 160, 71),         // 绿色
            Color.rgb(25, 118, 210),        // 蓝色
            Color.rgb(124, 58, 237),        // 紫色
    };

    private static final String[] TABLE_TEXT_COLOR_NAMES = {
            "默认黑色", "纯黑", "深灰", "白色", "中灰", "红色", "橙黄", "绿色", "蓝色", "紫色"
    };

    private void updateTableTextColorPreview() {
        int color = com.forum.MT.ui.widget.TableColorManager.getTextColor(this);
        android.graphics.drawable.Drawable bg = binding.viewTableTextColorPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.TableColorManager.resolveTextColor(this) : color);
        }
        binding.tvTableTextColorHint.setText(color == 0
                ? "点击选择表格文字颜色（当前：默认黑色）"
                : "点击选择表格文字颜色（当前：" + getTableTextColorName(color) + "）");
    }

    private String getTableTextColorName(int color) {
        for (int i = 0; i < TABLE_TEXT_PRESET_COLORS.length; i++) {
            if (TABLE_TEXT_PRESET_COLORS[i] == color) return TABLE_TEXT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showTableTextColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.TableColorManager.getTextColor(this),
                TABLE_TEXT_PRESET_COLORS, TABLE_TEXT_COLOR_NAMES, "选择表格文字色",
                (color) -> {
                    com.forum.MT.ui.widget.TableColorManager.setTextColor(this, color);
                    updateTableTextColorPreview();
                });
    }

    // ==================== 行内代码配色 ====================

    private static final int[] INLINE_CODE_BG_PRESET_COLORS = {
            0,                              // 默认浅灰 #F4F4F4
            Color.rgb(244, 244, 244),       // 浅灰（显式）
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(255, 243, 224),       // 浅橙
            Color.rgb(232, 240, 254),       // 浅蓝
            Color.rgb(232, 245, 233),       // 浅绿
            Color.rgb(255, 235, 238),       // 浅红
            Color.rgb(238, 232, 255),       // 浅紫
            Color.rgb(255, 248, 220),       // 浅黄
            Color.rgb(33, 33, 33),          // 深灰
    };

    private static final String[] INLINE_CODE_BG_COLOR_NAMES = {
            "默认浅灰", "浅灰", "白色", "浅橙", "浅蓝", "浅绿", "浅红", "浅紫", "浅黄", "深灰"
    };

    private void updateInlineCodeBgPreview() {
        int color = com.forum.MT.ui.widget.InlineHighlightManager.getBgColor(this);
        android.graphics.drawable.Drawable bg = binding.viewInlineCodeBgPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.InlineHighlightManager.resolveBgColor(this) : color);
        }
        binding.tvInlineCodeBgHint.setText(color == 0
                ? "点击选择行内代码背景色（当前：默认浅灰 #F4F4F4）"
                : "点击选择行内代码背景色（当前：" + getInlineCodeBgColorName(color) + "）");
    }

    private String getInlineCodeBgColorName(int color) {
        for (int i = 0; i < INLINE_CODE_BG_PRESET_COLORS.length; i++) {
            if (INLINE_CODE_BG_PRESET_COLORS[i] == color) return INLINE_CODE_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showInlineCodeBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.InlineHighlightManager.getBgColor(this),
                INLINE_CODE_BG_PRESET_COLORS, INLINE_CODE_BG_COLOR_NAMES, "选择行内代码背景色",
                (color) -> {
                    com.forum.MT.ui.widget.InlineHighlightManager.setBgColor(this, color);
                    updateInlineCodeBgPreview();
                });
    }

    private static final int[] INLINE_CODE_TEXT_PRESET_COLORS = {
            0,                              // 默认深灰 #333333
            Color.rgb(51, 51, 51),          // 深灰（显式）
            Color.rgb(0, 0, 0),             // 纯黑
            Color.rgb(199, 37, 78),         // 玫红（Discuz 默认）
            Color.rgb(211, 47, 47),         // 红色
            Color.rgb(249, 168, 37),        // 橙黄
            Color.rgb(67, 160, 71),         // 绿色
            Color.rgb(25, 118, 210),        // 蓝色
            Color.rgb(124, 58, 237),        // 紫色
            Color.rgb(255, 255, 255),       // 白色
    };

    private static final String[] INLINE_CODE_TEXT_COLOR_NAMES = {
            "默认深灰", "深灰", "纯黑", "玫红", "红色", "橙黄", "绿色", "蓝色", "紫色", "白色"
    };

    private void updateInlineCodeTextPreview() {
        int color = com.forum.MT.ui.widget.InlineHighlightManager.getTextColor(this);
        android.graphics.drawable.Drawable bg = binding.viewInlineCodeTextPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.InlineHighlightManager.resolveTextColor(this) : color);
        }
        binding.tvInlineCodeTextHint.setText(color == 0
                ? "点击选择行内代码文字颜色（当前：默认深灰 #333333）"
                : "点击选择行内代码文字颜色（当前：" + getInlineCodeTextColorName(color) + "）");
    }

    private String getInlineCodeTextColorName(int color) {
        for (int i = 0; i < INLINE_CODE_TEXT_PRESET_COLORS.length; i++) {
            if (INLINE_CODE_TEXT_PRESET_COLORS[i] == color) return INLINE_CODE_TEXT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showInlineCodeTextPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.InlineHighlightManager.getTextColor(this),
                INLINE_CODE_TEXT_PRESET_COLORS, INLINE_CODE_TEXT_COLOR_NAMES, "选择行内代码文字色",
                (color) -> {
                    com.forum.MT.ui.widget.InlineHighlightManager.setTextColor(this, color);
                    updateInlineCodeTextPreview();
                });
    }

    // ==================== 代码块配色 ====================

    private static final int[] CODE_BLOCK_BG_PRESET_COLORS = {
            0,                              // 默认深蓝灰 #202B36
            Color.rgb(32, 43, 54),          // 深蓝灰（显式）
            Color.rgb(30, 30, 30),          // 纯黑灰
            Color.rgb(40, 44, 52),          // One Dark
            Color.rgb(39, 40, 34),          // Monokai
            Color.rgb(43, 43, 43),          // 深灰
            Color.rgb(21, 32, 43),          // 深蓝
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(244, 244, 244),       // 浅灰
            Color.rgb(252, 248, 227),       // 浅黄
    };

    private static final String[] CODE_BLOCK_BG_COLOR_NAMES = {
            "默认深蓝灰", "深蓝灰", "纯黑灰", "One Dark", "Monokai", "深灰", "深蓝", "白色", "浅灰", "浅黄"
    };

    private void updateCodeBlockBgPreview() {
        int color = com.forum.MT.ui.widget.CodeBlockColorManager.getBgColor(this);
        android.graphics.drawable.Drawable bg = binding.viewCodeBlockBgPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            bg.mutate();
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.CodeBlockColorManager.resolveBgColor(this) : color);
            binding.viewCodeBlockBgPreview.invalidate();
        }
        binding.tvCodeBlockBgHint.setText(color == 0
                ? "点击选择代码块背景色（当前：默认深蓝灰 #202B36）"
                : "点击选择代码块背景色（当前：" + getCodeBlockBgColorName(color) + "）");
    }

    private String getCodeBlockBgColorName(int color) {
        for (int i = 0; i < CODE_BLOCK_BG_PRESET_COLORS.length; i++) {
            if (CODE_BLOCK_BG_PRESET_COLORS[i] == color) return CODE_BLOCK_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showCodeBlockBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.CodeBlockColorManager.getBgColor(this),
                CODE_BLOCK_BG_PRESET_COLORS, CODE_BLOCK_BG_COLOR_NAMES, "选择代码块背景色",
                (color) -> {
                    com.forum.MT.ui.widget.CodeBlockColorManager.setBgColor(this, color);
                    updateCodeBlockBgPreview();
                });
    }

    private static final int[] CODE_BLOCK_TEXT_PRESET_COLORS = {
            0,                              // 默认浅灰 #E6EDF3
            Color.rgb(230, 237, 243),       // 浅灰（显式）
            Color.rgb(255, 255, 255),       // 纯白
            Color.rgb(0, 0, 0),             // 纯黑
            Color.rgb(51, 51, 51),          // 深灰
            Color.rgb(171, 178, 191),       // 亮灰
            Color.rgb(97, 175, 239),        // 亮蓝
            Color.rgb(152, 195, 121),       // 亮绿
            Color.rgb(229, 192, 123),       // 亮黄
            Color.rgb(206, 145, 120),       // 亮橙
    };

    private static final String[] CODE_BLOCK_TEXT_COLOR_NAMES = {
            "默认浅灰", "浅灰", "纯白", "纯黑", "深灰", "亮灰", "亮蓝", "亮绿", "亮黄", "亮橙"
    };

    private void updateCodeBlockTextPreview() {
        int color = com.forum.MT.ui.widget.CodeBlockColorManager.getTextColor(this);
        android.graphics.drawable.Drawable bg = binding.viewCodeBlockTextPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.CodeBlockColorManager.resolveTextColor(this) : color);
        }
        binding.tvCodeBlockTextHint.setText(color == 0
                ? "点击选择代码块文字颜色（当前：默认浅灰 #E6EDF3）"
                : "点击选择代码块文字颜色（当前：" + getCodeBlockTextColorName(color) + "）");
    }

    private String getCodeBlockTextColorName(int color) {
        for (int i = 0; i < CODE_BLOCK_TEXT_PRESET_COLORS.length; i++) {
            if (CODE_BLOCK_TEXT_PRESET_COLORS[i] == color) return CODE_BLOCK_TEXT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showCodeBlockTextPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.CodeBlockColorManager.getTextColor(this),
                CODE_BLOCK_TEXT_PRESET_COLORS, CODE_BLOCK_TEXT_COLOR_NAMES, "选择代码块文字色",
                (color) -> {
                    com.forum.MT.ui.widget.CodeBlockColorManager.setTextColor(this, color);
                    updateCodeBlockTextPreview();
                });
    }

    private static final int[] CODE_BLOCK_BORDER_PRESET_COLORS = {
            0,                              // 默认深蓝 #4B6475
            Color.rgb(75, 100, 117),        // 深蓝（显式）
            Color.rgb(60, 60, 60),          // 深灰
            Color.rgb(100, 100, 100),       // 中灰
            Color.rgb(200, 200, 200),       // 浅灰
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(33, 33, 33),          // 纯黑
            Color.rgb(55, 66, 77),          // 灰蓝
            Color.rgb(80, 80, 80),          // 暗灰
            Color.rgb(120, 120, 120),       // 中亮灰
    };

    private static final String[] CODE_BLOCK_BORDER_COLOR_NAMES = {
            "默认深蓝", "深蓝", "深灰", "中灰", "浅灰", "白色", "纯黑", "灰蓝", "暗灰", "中亮灰"
    };

    private void updateCodeBlockBorderPreview() {
        int color = com.forum.MT.ui.widget.CodeBlockColorManager.getBorderColor(this);
        android.graphics.drawable.Drawable bg = binding.viewCodeBlockBorderPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.CodeBlockColorManager.resolveBorderColor(this) : color);
        }
        binding.tvCodeBlockBorderHint.setText(color == 0
                ? "点击选择代码块边框颜色（默认深蓝 #4B6475）"
                : "点击选择代码块边框颜色（当前：" + getCodeBlockBorderColorName(color) + "）");
    }

    private String getCodeBlockBorderColorName(int color) {
        for (int i = 0; i < CODE_BLOCK_BORDER_PRESET_COLORS.length; i++) {
            if (CODE_BLOCK_BORDER_PRESET_COLORS[i] == color) return CODE_BLOCK_BORDER_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showCodeBlockBorderPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.CodeBlockColorManager.getBorderColor(this),
                CODE_BLOCK_BORDER_PRESET_COLORS, CODE_BLOCK_BORDER_COLOR_NAMES, "选择代码块边框色",
                (color) -> {
                    com.forum.MT.ui.widget.CodeBlockColorManager.setBorderColor(this, color);
                    updateCodeBlockBorderPreview();
                });
    }

    private static final int[] CODE_BLOCK_TITLE_TEXT_PRESET_COLORS = {
            0,                              // 默认浅蓝 #B8D8E8
            Color.rgb(184, 216, 232),       // 浅蓝（显式）
            Color.rgb(255, 255, 255),       // 纯白
            Color.rgb(230, 237, 243),       // 浅灰
            Color.rgb(171, 178, 191),       // 亮灰
            Color.rgb(97, 175, 239),        // 亮蓝
            Color.rgb(152, 195, 121),       // 亮绿
            Color.rgb(229, 192, 123),       // 亮黄
            Color.rgb(206, 145, 120),       // 亮橙
            Color.rgb(198, 120, 221),       // 亮紫
    };

    private static final String[] CODE_BLOCK_TITLE_TEXT_COLOR_NAMES = {
            "默认浅蓝", "浅蓝", "纯白", "浅灰", "亮灰", "亮蓝", "亮绿", "亮黄", "亮橙", "亮紫"
    };

    private static final int[] CODE_BLOCK_TITLE_BG_PRESET_COLORS = {
            0,                              // 默认深色 #1A1E28
            Color.rgb(26, 30, 40),          // 默认深色（显式）
            Color.rgb(32, 43, 54),          // 深蓝灰
            Color.rgb(30, 30, 30),          // 纯黑灰
            Color.rgb(21, 32, 43),          // 深蓝
            Color.rgb(40, 44, 52),          // One Dark
            Color.rgb(39, 40, 34),          // Monokai
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(244, 244, 244),       // 浅灰
            Color.rgb(252, 248, 227),       // 浅黄
    };

    private static final String[] CODE_BLOCK_TITLE_BG_COLOR_NAMES = {
            "默认深色", "深色", "深蓝灰", "纯黑灰", "深蓝", "One Dark", "Monokai", "白色", "浅灰", "浅黄"
    };

    private void updateCodeBlockTitleBgPreview() {
        int color = com.forum.MT.ui.widget.CodeBlockColorManager.getTitleBgColor(this);
        android.graphics.drawable.Drawable bg = binding.viewCodeBlockTitleBgPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            bg.mutate();
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.CodeBlockColorManager.resolveTitleBgColor(this) : color);
            binding.viewCodeBlockTitleBgPreview.invalidate();
        }
        binding.tvCodeBlockTitleBgHint.setText(color == 0
                ? "点击选择代码块标题背景颜色（默认深色 #1A1E28）"
                : "点击选择代码块标题背景颜色（当前：" + getCodeBlockTitleBgColorName(color) + "）");
    }

    private String getCodeBlockTitleBgColorName(int color) {
        for (int i = 0; i < CODE_BLOCK_TITLE_BG_PRESET_COLORS.length; i++) {
            if (CODE_BLOCK_TITLE_BG_PRESET_COLORS[i] == color) return CODE_BLOCK_TITLE_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showCodeBlockTitleBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.CodeBlockColorManager.getTitleBgColor(this),
                CODE_BLOCK_TITLE_BG_PRESET_COLORS, CODE_BLOCK_TITLE_BG_COLOR_NAMES, "选择代码块标题背景色",
                (color) -> {
                    com.forum.MT.ui.widget.CodeBlockColorManager.setTitleBgColor(this, color);
                    updateCodeBlockTitleBgPreview();
                });
    }

    private void updateCodeBlockTitleTextPreview() {
        int color = com.forum.MT.ui.widget.CodeBlockColorManager.getTitleTextColor(this);
        android.graphics.drawable.Drawable bg = binding.viewCodeBlockTitleTextPreview.getBackground();
        if (bg instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.CodeBlockColorManager.resolveTitleTextColor(this) : color);
        }
        binding.tvCodeBlockTitleTextHint.setText(color == 0
                ? "点击选择代码块标题文字颜色（默认浅蓝 #B8D8E8）"
                : "点击选择代码块标题文字颜色（当前：" + getCodeBlockTitleTextColorName(color) + "）");
    }

    private String getCodeBlockTitleTextColorName(int color) {
        for (int i = 0; i < CODE_BLOCK_TITLE_TEXT_PRESET_COLORS.length; i++) {
            if (CODE_BLOCK_TITLE_TEXT_PRESET_COLORS[i] == color) return CODE_BLOCK_TITLE_TEXT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showCodeBlockTitleTextPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.CodeBlockColorManager.getTitleTextColor(this),
                CODE_BLOCK_TITLE_TEXT_PRESET_COLORS, CODE_BLOCK_TITLE_TEXT_COLOR_NAMES, "选择代码块标题文字色",
                (color) -> {
                    com.forum.MT.ui.widget.CodeBlockColorManager.setTitleTextColor(this, color);
                    updateCodeBlockTitleTextPreview();
                });
    }

    // ==================== 板块卡片颜色 ====================

    private static final int[] FORUM_PRESET_COLORS = {
            0,                              // 默认蓝紫
            Color.rgb(255, 255, 255),       // 白色（显式）
            Color.rgb(255, 240, 245),       // 浅粉
            Color.rgb(255, 249, 231),       // 浅橙
            Color.rgb(233, 248, 240),       // 浅绿
            Color.rgb(230, 243, 255),       // 浅蓝
            Color.rgb(246, 237, 255),       // 浅紫
            Color.rgb(255, 235, 235),       // 浅红
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(66, 66, 66),          // 中灰
    };

    private static final String[] FORUM_COLOR_NAMES = {
            "默认淡黄", "白色", "浅粉", "浅橙", "浅绿", "浅蓝", "浅紫", "浅红", "深灰", "中灰"
    };

    private void updateForumColorPreview() {
        int color = ForumCardColorManager.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewForumColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0
                    ? ForumCardColorManager.DEFAULT_CARD_COLOR : color);
        }
        binding.tvForumColorHint.setText(color == 0
                ? "点击自定义「发现」板块卡片颜色（当前：默认淡黄）"
                : "点击自定义「发现」板块卡片颜色（当前：" + getForumColorName(color) + "）");
    }

    private String getForumColorName(int color) {
        for (int i = 0; i < FORUM_PRESET_COLORS.length; i++) {
            if (FORUM_PRESET_COLORS[i] == color) return FORUM_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showForumColorPickerDialog() {
        int currentColor = ForumCardColorManager.getCustomColor();

        android.view.View dialogView = getLayoutInflater().inflate(R.layout.dialog_color_picker, null);
        android.widget.RadioGroup radioGroup = dialogView.findViewById(R.id.rg_preset_colors);
        android.widget.EditText etHex = dialogView.findViewById(R.id.et_custom_hex);

        boolean isPreset = false;
        int checkedIndex = 0;
        for (int i = 0; i < FORUM_PRESET_COLORS.length; i++) {
            if (FORUM_PRESET_COLORS[i] == currentColor) {
                checkedIndex = i;
                isPreset = true;
                break;
            }
        }

        if (!isPreset && currentColor != 0) {
            etHex.setText(String.format("%08X", currentColor));
        }

        for (int i = 0; i < FORUM_COLOR_NAMES.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setText(FORUM_COLOR_NAMES[i]);
            rb.setId(i);
            rb.setTextSize(14);
            rb.setTextColor(getResources().getColor(R.color.text_primary, null));
            if (isPreset && i == checkedIndex) rb.setChecked(true);
            radioGroup.addView(rb);
        }

        final int[] selectedIndex = {checkedIndex};

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            selectedIndex[0] = checkedId;
            etHex.setText("");
        });

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("选择板块卡片颜色")
                .setView(dialogView)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (dialog, which) -> {
                    String hex = etHex.getText().toString().trim();
                    if (!hex.isEmpty()) {
                        int parsed = parseHexColor(hex);
                        if (parsed != -1) {
                            ForumCardColorManager.setCustomColor(this, parsed);
                            updateForumColorPreview();
                            Toast.makeText(this,
                                    "板块卡片颜色已应用：" + hex.toUpperCase(), Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            Toast.makeText(this,
                                    "色值无效，请检查格式（RRGGBB 或 AARRGGBB）",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    int selected = FORUM_PRESET_COLORS[selectedIndex[0]];
                    ForumCardColorManager.setCustomColor(this, selected);
                    updateForumColorPreview();
                    Toast.makeText(this,
                            "板块卡片颜色已设为：" + FORUM_COLOR_NAMES[selectedIndex[0]],
                            Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    // ==================== 全局背景色 ====================

    private static final int[] BACKGROUND_PRESET_COLORS = {
            0,                          // 默认淡黄
            Color.WHITE,                // 白色（显式）
            Color.rgb(245, 246, 247),   // 浅灰
            Color.rgb(250, 246, 255),   // 浅紫
            Color.rgb(245, 250, 255),   // 浅蓝
            Color.rgb(251, 248, 240),   // 浅米
            Color.rgb(33, 33, 33),      // 深灰
            Color.rgb(18, 18, 18),      // 纯黑
    };

    private static final String[] BACKGROUND_COLOR_NAMES = {
            "默认极浅蓝", "白色", "浅灰", "浅紫", "浅蓝", "浅米", "深灰", "纯黑"
    };

    private void updateGlobalBackgroundPreview() {
        int color = BackgroundColorManager.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewGlobalBackgroundPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFF5FAFF : color);
        }
        binding.tvGlobalBackgroundHint.setText(color == 0
                ? "点击自定义 App 全局背景颜色（当前：默认极浅蓝）"
                : "点击自定义 App 全局背景颜色（当前：" + getBackgroundColorName(color) + "）");
    }

    private String getBackgroundColorName(int color) {
        for (int i = 0; i < BACKGROUND_PRESET_COLORS.length; i++) {
            if (BACKGROUND_PRESET_COLORS[i] == color) return BACKGROUND_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showGlobalBackgroundColorPickerDialog() {
        int currentColor = BackgroundColorManager.getCustomColor();

        android.view.View dialogView = getLayoutInflater().inflate(R.layout.dialog_color_picker, null);
        android.widget.RadioGroup radioGroup = dialogView.findViewById(R.id.rg_preset_colors);
        android.widget.EditText etHex = dialogView.findViewById(R.id.et_custom_hex);

        boolean isPreset = false;
        int checkedIndex = 0;
        for (int i = 0; i < BACKGROUND_PRESET_COLORS.length; i++) {
            if (BACKGROUND_PRESET_COLORS[i] == currentColor) {
                checkedIndex = i;
                isPreset = true;
                break;
            }
        }

        if (!isPreset && currentColor != 0) {
            etHex.setText(String.format("%08X", currentColor));
        }

        for (int i = 0; i < BACKGROUND_COLOR_NAMES.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setText(BACKGROUND_COLOR_NAMES[i]);
            rb.setId(i);
            rb.setTextSize(14);
            rb.setTextColor(getResources().getColor(R.color.text_primary, null));
            if (isPreset && i == checkedIndex) rb.setChecked(true);
            radioGroup.addView(rb);
        }

        final int[] selectedIndex = {checkedIndex};

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            selectedIndex[0] = checkedId;
            etHex.setText("");
        });

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("选择全局背景颜色")
                .setView(dialogView)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (dialog, which) -> {
                    String hex = etHex.getText().toString().trim();
                    if (!hex.isEmpty()) {
                        int parsed = parseHexColor(hex);
                        if (parsed != -1) {
                            BackgroundColorManager.setCustomColor(this, parsed);
                            updateGlobalBackgroundPreview();
                            BackgroundColorManager.apply(binding.getRoot());
                            Toast.makeText(this,
                                    "背景颜色已应用：" + hex.toUpperCase(), Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            Toast.makeText(this,
                                    "色值无效，请检查格式（RRGGBB 或 AARRGGBB）",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    int selected = BACKGROUND_PRESET_COLORS[selectedIndex[0]];
                    BackgroundColorManager.setCustomColor(this, selected);
                    updateGlobalBackgroundPreview();
                    BackgroundColorManager.apply(binding.getRoot());
                    Toast.makeText(this,
                            "背景颜色已设为：" + BACKGROUND_COLOR_NAMES[selectedIndex[0]],
                            Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    // ==================== 内容卡片背景色 ====================

    private static final int[] CARD_BG_PRESET_COLORS = {
            0,                        // 默认淡黄
            Color.WHITE,              // 白色
            Color.rgb(250, 250, 250), // 极浅灰
            Color.rgb(240, 244, 255), // 浅蓝
            Color.rgb(255, 243, 248), // 浅粉
            Color.rgb(255, 248, 231), // 浅黄
            Color.rgb(36, 36, 36),    // 深灰卡片
    };

    private static final String[] CARD_BG_COLOR_NAMES = {
            "默认淡黄", "白色", "极浅灰", "浅蓝", "浅粉", "浅黄", "深灰卡片"
    };

    private void updateCardBgPreview() {
        int color = CardColorManager.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewCardBgColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? CardColorManager.DEFAULT_CARD_COLOR : color);
        }
        binding.tvCardBgColorHint.setText(color == 0
                ? "自定义帖子/消息/通知等卡片背景（当前：默认淡黄）"
                : "自定义帖子/消息/通知等卡片背景（当前：" + getCardBgColorName(color) + "）");
    }

    private String getCardBgColorName(int color) {
        for (int i = 0; i < CARD_BG_PRESET_COLORS.length; i++) {
            if (CARD_BG_PRESET_COLORS[i] == color) return CARD_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showCardBgColorPickerDialog() {
        android.view.View dialogView = getLayoutInflater().inflate(R.layout.dialog_color_picker, null);
        android.widget.RadioGroup radioGroup = dialogView.findViewById(R.id.rg_preset_colors);
        android.widget.EditText etHex = dialogView.findViewById(R.id.et_custom_hex);

        boolean isPreset = false;
        int checkedIndex = 0;
        int currentColor = CardColorManager.getCustomColor();
        for (int i = 0; i < CARD_BG_PRESET_COLORS.length; i++) {
            if (CARD_BG_PRESET_COLORS[i] == currentColor) {
                checkedIndex = i;
                isPreset = true;
                break;
            }
        }

        if (!isPreset && currentColor != 0) {
            etHex.setText(String.format("%08X", currentColor));
        }

        for (int i = 0; i < CARD_BG_COLOR_NAMES.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setText(CARD_BG_COLOR_NAMES[i]);
            rb.setId(i);
            rb.setTextSize(14);
            rb.setTextColor(getResources().getColor(R.color.text_primary, null));
            if (isPreset && i == checkedIndex) rb.setChecked(true);
            radioGroup.addView(rb);
        }

        final int[] selectedIndex = {checkedIndex};

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            selectedIndex[0] = checkedId;
            etHex.setText("");
        });

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("选择卡片背景颜色")
                .setView(dialogView)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (dialog, which) -> {
                    String hex = etHex.getText().toString().trim();
                    if (!hex.isEmpty()) {
                        int parsed = parseHexColor(hex);
                        if (parsed != -1) {
                            CardColorManager.setCustomColor(this, parsed);
                            updateCardBgPreview();
                            Toast.makeText(this,
                                    "卡片背景颜色已应用：" + hex.toUpperCase(), Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            Toast.makeText(this,
                                    "色值无效，请检查格式（RRGGBB 或 AARRGGBB）",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    int selected = CARD_BG_PRESET_COLORS[selectedIndex[0]];
                    CardColorManager.setCustomColor(this, selected);
                    updateCardBgPreview();
                    Toast.makeText(this,
                            "卡片背景颜色已设为：" + CARD_BG_COLOR_NAMES[selectedIndex[0]],
                            Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    // ==================== 底部导航栏颜色 ====================

    private static final int[] NAV_BG_PRESET_COLORS = {
            0,                       // 默认蓝紫
            Color.WHITE,             // 白色
            Color.rgb(255, 82, 82),  // 红色
            Color.rgb(33, 33, 33),   // 深灰
            Color.rgb(18, 18, 18),   // 纯黑
            Color.rgb(240, 244, 255),// 浅蓝
            Color.rgb(255, 243, 248),// 浅粉
    };

    private static final String[] NAV_BG_COLOR_NAMES = {
            "默认蓝紫", "白色", "红色", "深灰", "纯黑", "浅蓝", "浅粉"
    };

    private static final int[] NAV_ACTIVE_PRESET_COLORS = {
            0,                       // 默认橙色
            Color.rgb(255, 64, 129), // 默认粉色
            Color.WHITE,             // 白色
            Color.rgb(33, 150, 243), // 蓝色
            Color.rgb(76, 175, 80),  // 绿色
            Color.rgb(255, 152, 0),  // 橙色
            Color.BLACK,             // 黑色
    };

    private static final String[] NAV_ACTIVE_COLOR_NAMES = {
            "默认橙色", "粉色", "白色", "蓝色", "绿色", "橙色", "黑色"
    };

    private static final int[] NAV_INACTIVE_PRESET_COLORS = {
            0,                        // 默认灰色
            Color.rgb(117, 117, 117), // 灰色
            Color.WHITE,              // 白色
            Color.rgb(158, 158, 158), // 中灰
            Color.BLACK,              // 黑色
            Color.rgb(120, 144, 156), // 蓝灰
    };

    private static final String[] NAV_INACTIVE_COLOR_NAMES = {
            "默认灰色", "灰色", "白色", "中灰", "黑色", "蓝灰"
    };

    private void updateNavBgPreview() {
        int color = BottomNavBarColorManager.getBgColor();
        android.graphics.drawable.Drawable bg = binding.viewNavBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? BottomNavBarColorManager.DEFAULT_BG : color);
        }
        binding.tvNavBgHint.setText(color == 0
                ? "自定义底部导航栏背景颜色（当前：默认蓝紫）"
                : "自定义底部导航栏背景颜色（当前：" + getNavBgColorName(color) + "）");
    }

    private void updateNavActivePreview() {
        int color = BottomNavBarColorManager.getActiveColor();
        android.graphics.drawable.Drawable bg = binding.viewNavActivePreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? BottomNavBarColorManager.DEFAULT_ACTIVE : color);
        }
        binding.tvNavActiveHint.setText(color == 0
                ? "底部导航栏选中项文字/图标颜色（当前：默认橙色）"
                : "底部导航栏选中项文字/图标颜色（当前：" + getNavActiveColorName(color) + "）");
    }

    private void updateNavInactivePreview() {
        int color = BottomNavBarColorManager.getInactiveColor();
        android.graphics.drawable.Drawable bg = binding.viewNavInactivePreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? BottomNavBarColorManager.DEFAULT_INACTIVE : color);
        }
        binding.tvNavInactiveHint.setText(color == 0
                ? "底部导航栏未选中项文字/图标颜色（当前：默认灰色）"
                : "底部导航栏未选中项文字/图标颜色（当前：" + getNavInactiveColorName(color) + "）");
    }

    private String getNavBgColorName(int color) {
        for (int i = 0; i < NAV_BG_PRESET_COLORS.length; i++) {
            if (NAV_BG_PRESET_COLORS[i] == color) return NAV_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private String getNavActiveColorName(int color) {
        for (int i = 0; i < NAV_ACTIVE_PRESET_COLORS.length; i++) {
            if (NAV_ACTIVE_PRESET_COLORS[i] == color) return NAV_ACTIVE_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private String getNavInactiveColorName(int color) {
        for (int i = 0; i < NAV_INACTIVE_PRESET_COLORS.length; i++) {
            if (NAV_INACTIVE_PRESET_COLORS[i] == color) return NAV_INACTIVE_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showNavBgColorPickerDialog() {
        showNavColorPickerDialog(BottomNavBarColorManager.getBgColor(),
                NAV_BG_PRESET_COLORS, NAV_BG_COLOR_NAMES, "选择导航栏背景颜色",
                (color) -> {
                    BottomNavBarColorManager.setBgColor(this, color);
                    updateNavBgPreview();
                });
    }

    private void showNavActiveColorPickerDialog() {
        showNavColorPickerDialog(BottomNavBarColorManager.getActiveColor(),
                NAV_ACTIVE_PRESET_COLORS, NAV_ACTIVE_COLOR_NAMES, "选择导航栏选中颜色",
                (color) -> {
                    BottomNavBarColorManager.setActiveColor(this, color);
                    updateNavActivePreview();
                });
    }

    private void showNavInactiveColorPickerDialog() {
        showNavColorPickerDialog(BottomNavBarColorManager.getInactiveColor(),
                NAV_INACTIVE_PRESET_COLORS, NAV_INACTIVE_COLOR_NAMES, "选择导航栏未选中颜色",
                (color) -> {
                    BottomNavBarColorManager.setInactiveColor(this, color);
                    updateNavInactivePreview();
                });
    }

    private void showNavColorPickerDialog(int currentColor, int[] presetColors, String[] colorNames,
                                          String title, java.util.function.IntConsumer onApply) {
        android.view.View dialogView = getLayoutInflater().inflate(R.layout.dialog_color_picker, null);
        android.widget.RadioGroup radioGroup = dialogView.findViewById(R.id.rg_preset_colors);
        android.widget.EditText etHex = dialogView.findViewById(R.id.et_custom_hex);

        boolean isPreset = false;
        int checkedIndex = 0;
        for (int i = 0; i < presetColors.length; i++) {
            if (presetColors[i] == currentColor) {
                checkedIndex = i;
                isPreset = true;
                break;
            }
        }

        if (!isPreset && currentColor != 0) {
            etHex.setText(String.format("%08X", currentColor));
        }

        for (int i = 0; i < colorNames.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setText(colorNames[i]);
            rb.setId(i);
            rb.setTextSize(14);
            rb.setTextColor(getResources().getColor(R.color.text_primary, null));
            if (isPreset && i == checkedIndex) rb.setChecked(true);
            radioGroup.addView(rb);
        }

        final int[] selectedIndex = {checkedIndex};

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            selectedIndex[0] = checkedId;
            etHex.setText("");
        });

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setView(dialogView)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (dialog, which) -> {
                    String hex = etHex.getText().toString().trim();
                    if (!hex.isEmpty()) {
                        int parsed = parseHexColor(hex);
                        if (parsed != -1) {
                            onApply.accept(parsed);
                            Toast.makeText(this,
                                    "颜色已应用：" + hex.toUpperCase(), Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            Toast.makeText(this,
                                    "色值无效，请检查格式（RRGGBB 或 AARRGGBB）",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    int selected = presetColors[selectedIndex[0]];
                    onApply.accept(selected);
                    Toast.makeText(this,
                            "颜色已设为：" + colorNames[selectedIndex[0]],
                            Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    // ==================== 全局强调色（选中/高亮文字）====================

    private static final int[] ACCENT_PRESET_COLORS = {
            0,                       // 默认浅蓝
            Color.rgb(255, 64, 129), // 粉色
            Color.rgb(33, 150, 243), // 蓝色
            Color.rgb(76, 175, 80),  // 绿色
            Color.rgb(255, 152, 0),  // 橙色
            Color.rgb(156, 39, 176), // 紫色
            Color.rgb(83, 188, 245), // 天蓝（旧版消息页蓝）
    };

    private static final String[] ACCENT_COLOR_NAMES = {
            "默认浅蓝", "粉色", "蓝色", "绿色", "橙色", "紫色", "天蓝"
    };

    private void updateAccentPreview() {
        int color = AccentColorManager.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewAccentPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? AccentColorManager.DEFAULT_ACCENT : color);
        }
        binding.tvAccentHint.setText(color == 0
                ? "首页分类 tab、消息页 tab、全部已读、通知高亮等统一颜色（当前：默认浅蓝）"
                : "首页分类 tab、消息页 tab、全部已读、通知高亮等统一颜色（当前：" + getAccentColorName(color) + "）");
    }

    private String getAccentColorName(int color) {
        for (int i = 0; i < ACCENT_PRESET_COLORS.length; i++) {
            if (ACCENT_PRESET_COLORS[i] == color) return ACCENT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showAccentColorPickerDialog() {
        showNavColorPickerDialog(AccentColorManager.getCustomColor(),
                ACCENT_PRESET_COLORS, ACCENT_COLOR_NAMES, "选择文字高亮色",
                (color) -> {
                    AccentColorManager.setCustomColor(this, color);
                    updateAccentPreview();
                });
    }

    // ==================== 凸起发帖按钮颜色 ====================

    private static final int[] POST_BG_PRESET_COLORS = {
            0,                       // 默认橙色
            Color.rgb(255, 64, 129), // 粉色
            Color.rgb(33, 150, 243), // 蓝色
            Color.rgb(76, 175, 80),  // 绿色
            Color.rgb(255, 152, 0),  // 橙色
            Color.rgb(156, 39, 176), // 紫色
            Color.rgb(33, 33, 33),   // 深灰
            Color.rgb(18, 18, 18),   // 纯黑
    };

    private static final String[] POST_BG_COLOR_NAMES = {
            "默认橙色", "粉色", "蓝色", "绿色", "橙色", "紫色", "深灰", "纯黑"
    };

    private static final int[] POST_ICON_PRESET_COLORS = {
            0,                       // 默认白色
            Color.WHITE,             // 白色
            Color.BLACK,             // 黑色
            Color.rgb(255, 235, 59), // 黄色
            Color.rgb(33, 150, 243), // 蓝色
            Color.rgb(76, 175, 80),  // 绿色
    };

    private static final String[] POST_ICON_COLOR_NAMES = {
            "默认白色", "白色", "黑色", "黄色", "蓝色", "绿色"
    };

    private void updatePostBgPreview() {
        int color = BottomNavBarColorManager.getPostBgColor();
        android.graphics.drawable.Drawable bg = binding.viewPostBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? BottomNavBarColorManager.DEFAULT_POST_BG : color);
        }
        binding.tvPostBgHint.setText(color == 0
                ? "底部导航中间「+」圆形按钮的背景色（当前：默认橙色）"
                : "底部导航中间「+」圆形按钮的背景色（当前：" + getPostBgColorName(color) + "）");
    }

    private void updatePostIconPreview() {
        int color = BottomNavBarColorManager.getPostIconColor();
        android.graphics.drawable.Drawable bg = binding.viewPostIconPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? BottomNavBarColorManager.DEFAULT_POST_ICON : color);
        }
        binding.tvPostIconHint.setText(color == 0
                ? "「+」图标颜色（当前：默认白色）"
                : "「+」图标颜色（当前：" + getPostIconColorName(color) + "）");
    }

    private String getPostBgColorName(int color) {
        for (int i = 0; i < POST_BG_PRESET_COLORS.length; i++) {
            if (POST_BG_PRESET_COLORS[i] == color) return POST_BG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private String getPostIconColorName(int color) {
        for (int i = 0; i < POST_ICON_PRESET_COLORS.length; i++) {
            if (POST_ICON_PRESET_COLORS[i] == color) return POST_ICON_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showPostBgColorPickerDialog() {
        showNavColorPickerDialog(BottomNavBarColorManager.getPostBgColor(),
                POST_BG_PRESET_COLORS, POST_BG_COLOR_NAMES, "选择发帖按钮背景色",
                (color) -> {
                    BottomNavBarColorManager.setPostBgColor(this, color);
                    updatePostBgPreview();
                });
    }

    private void showPostIconColorPickerDialog() {
        showNavColorPickerDialog(BottomNavBarColorManager.getPostIconColor(),
                POST_ICON_PRESET_COLORS, POST_ICON_COLOR_NAMES, "选择发帖按钮图标色",
                (color) -> {
                    BottomNavBarColorManager.setPostIconColor(this, color);
                    updatePostIconPreview();
                });
    }

    // ==================== 首页标题颜色 ====================

    private static final int[] TITLE_PRESET_COLORS = {
            0,                       // 默认蓝色
            Color.rgb(255, 64, 129), // 粉色
            Color.rgb(33, 150, 243), // 蓝色
            Color.rgb(76, 175, 80),  // 绿色
            Color.rgb(255, 152, 0),  // 橙色
            Color.rgb(156, 39, 176), // 紫色
            Color.BLACK,             // 黑色
            Color.rgb(33, 33, 33),   // 深灰
            Color.WHITE,             // 白色
    };

    private static final String[] TITLE_COLOR_NAMES = {
            "默认蓝色", "粉色", "蓝色", "绿色", "橙色", "紫色", "黑色", "深灰", "白色"
    };

    private void updateTitleColorPreview() {
        int color = TitleColorManager.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewTitleColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? TitleColorManager.DEFAULT_TITLE_COLOR : color);
        }
        binding.tvTitleColorHint.setText(color == 0
                ? "自定义首页「MT论坛」标题文字颜色（当前：默认蓝色）"
                : "自定义首页「MT论坛」标题文字颜色（当前：" + getTitleColorName(color) + "）");
    }

    private String getTitleColorName(int color) {
        for (int i = 0; i < TITLE_PRESET_COLORS.length; i++) {
            if (TITLE_PRESET_COLORS[i] == color) return TITLE_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showTitleColorPickerDialog() {
        showNavColorPickerDialog(TitleColorManager.getCustomColor(),
                TITLE_PRESET_COLORS, TITLE_COLOR_NAMES, "选择首页标题颜色",
                (color) -> {
                    TitleColorManager.setCustomColor(this, color);
                    updateTitleColorPreview();
                });
    }

    // ==================== 状态栏颜色 ====================

    private static final int[] STATUS_BAR_PRESET_COLORS = {
            0,                       // 默认蓝色
            Color.WHITE,             // 白色
            Color.rgb(255, 64, 129), // 粉色
            Color.rgb(33, 150, 243), // 蓝色
            Color.rgb(76, 175, 80),  // 绿色
            Color.rgb(255, 152, 0),  // 橙色
            Color.rgb(156, 39, 176), // 紫色
            Color.BLACK,             // 黑色
            Color.rgb(33, 33, 33),   // 深灰
            Color.rgb(255, 255, 255),// 纯白
            Color.rgb(240, 248, 255),// 极浅蓝
    };

    private static final String[] STATUS_BAR_COLOR_NAMES = {
            "默认蓝色", "白色", "粉色", "蓝色", "绿色", "橙色", "紫色", "黑色", "深灰", "纯白", "极浅蓝"
    };

    private void updateStatusBarColorPreview() {
        int color = StatusBarColorManager.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewStatusBarColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? StatusBarColorManager.DEFAULT_STATUS_BAR_COLOR : color);
        }
        binding.tvStatusBarColorHint.setText(color == 0
                ? "自定义状态栏背景颜色（当前：默认蓝色）"
                : "自定义状态栏背景颜色（当前：" + getStatusBarColorName(color) + "）");
    }

    private String getStatusBarColorName(int color) {
        for (int i = 0; i < STATUS_BAR_PRESET_COLORS.length; i++) {
            if (STATUS_BAR_PRESET_COLORS[i] == color) return STATUS_BAR_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showStatusBarColorPickerDialog() {
        showNavColorPickerDialog(StatusBarColorManager.getCustomColor(),
                STATUS_BAR_PRESET_COLORS, STATUS_BAR_COLOR_NAMES, "选择状态栏颜色",
                (color) -> {
                    StatusBarColorManager.setCustomColor(this, color);
                    updateStatusBarColorPreview();
                });
    }

    // ==================== 首页标题栏背景颜色 ====================

    private static final int[] HOME_TITLE_BAR_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFCE4EC,             // 极浅粉
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] HOME_TITLE_BAR_COLOR_NAMES = {
            "默认极浅蓝", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙", "极浅粉",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateHomeTitleBarBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getTitleBarCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewHomeTitleBarBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvHomeTitleBarBgHint.setText(color == 0
                ? "自定义「MT论坛」标题与搜索框栏背景颜色（当前：默认极浅蓝）"
                : "自定义「MT论坛」标题与搜索框栏背景颜色（当前：" + getHomeTitleBarColorName(color) + "）");
    }

    private String getHomeTitleBarColorName(int color) {
        for (int i = 0; i < HOME_TITLE_BAR_PRESET_COLORS.length; i++) {
            if (HOME_TITLE_BAR_PRESET_COLORS[i] == color) return HOME_TITLE_BAR_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showHomeTitleBarBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getTitleBarCustomColor(),
                HOME_TITLE_BAR_PRESET_COLORS, HOME_TITLE_BAR_COLOR_NAMES, "选择首页标题栏背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setTitleBarColor(this, color);
                    updateHomeTitleBarBgPreview();
                });
    }

    // ==================== 首页分类栏背景颜色 ====================

    private static final int[] HOME_TAB_BAR_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFCE4EC,             // 极浅粉
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] HOME_TAB_BAR_COLOR_NAMES = {
            "默认极浅蓝", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙", "极浅粉",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateHomeTabBarBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getTabBarCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewHomeTabBarBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvHomeTabBarBgHint.setText(color == 0
                ? "自定义「热门内容」分类栏背景颜色（当前：默认极浅蓝）"
                : "自定义「热门内容」分类栏背景颜色（当前：" + getHomeTabBarColorName(color) + "）");
    }

    private String getHomeTabBarColorName(int color) {
        for (int i = 0; i < HOME_TAB_BAR_PRESET_COLORS.length; i++) {
            if (HOME_TAB_BAR_PRESET_COLORS[i] == color) return HOME_TAB_BAR_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showHomeTabBarBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getTabBarCustomColor(),
                HOME_TAB_BAR_PRESET_COLORS, HOME_TAB_BAR_COLOR_NAMES, "选择首页分类栏背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setTabBarColor(this, color);
                    updateHomeTabBarBgPreview();
                });
    }

    // ==================== 首页搜索框背景颜色 ====================

    private static final int[] HOME_SEARCH_BAR_PRESET_COLORS = {
            0,                      // 默认浅灰
            0xFFF5F5F5,             // 浅灰
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFCE4EC,             // 极浅粉
            0xFFEEEEEE,             // 灰
            0xFFE0E0E0,             // 中灰
            0xFF212121,             // 深灰
            0xFF1A237E,             // 深蓝
    };

    private static final String[] HOME_SEARCH_BAR_COLOR_NAMES = {
            "默认极浅蓝", "浅灰", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙", "极浅粉",
            "灰", "中灰", "深灰", "深蓝"
    };

    private void updateHomeSearchBarBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getSearchBarCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewHomeSearchBarBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvHomeSearchBarBgHint.setText(color == 0
                ? "自定义首页搜索框背景颜色（当前：默认极浅蓝）"
                : "自定义首页搜索框背景颜色（当前：" + getHomeSearchBarColorName(color) + "）");
    }

    private String getHomeSearchBarColorName(int color) {
        for (int i = 0; i < HOME_SEARCH_BAR_PRESET_COLORS.length; i++) {
            if (HOME_SEARCH_BAR_PRESET_COLORS[i] == color) return HOME_SEARCH_BAR_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showHomeSearchBarBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getSearchBarCustomColor(),
                HOME_SEARCH_BAR_PRESET_COLORS, HOME_SEARCH_BAR_COLOR_NAMES, "选择搜索框背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setSearchBarColor(this, color);
                    updateHomeSearchBarBgPreview();
                });
    }

    // ==================== 搜索页标题栏背景 ====================

    private static final int[] SEARCH_PAGE_TOOLBAR_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFCE4EC,             // 极浅粉
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] SEARCH_PAGE_TOOLBAR_COLOR_NAMES = {
            "默认极浅蓝", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙", "极浅粉",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateSearchPageToolbarBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getSearchToolbarBg();
        android.graphics.drawable.Drawable bg = binding.viewSearchPageToolbarBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvSearchPageToolbarBgHint.setText(color == 0
                ? "自定义搜索页面顶部标题栏背景颜色（当前：默认极浅蓝）"
                : "自定义搜索页面顶部标题栏背景颜色（当前：" + getSearchPageToolbarColorName(color) + "）");
    }

    private String getSearchPageToolbarColorName(int color) {
        for (int i = 0; i < SEARCH_PAGE_TOOLBAR_PRESET_COLORS.length; i++) {
            if (SEARCH_PAGE_TOOLBAR_PRESET_COLORS[i] == color) return SEARCH_PAGE_TOOLBAR_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showSearchPageToolbarBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getSearchToolbarBg(),
                SEARCH_PAGE_TOOLBAR_PRESET_COLORS, SEARCH_PAGE_TOOLBAR_COLOR_NAMES, "选择搜索页标题栏背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setSearchToolbarBg(this, color);
                    updateSearchPageToolbarBgPreview();
                });
    }

    // ==================== 搜索页输入区背景 ====================

    private static final int[] SEARCH_PAGE_INPUT_PRESET_COLORS = {
            0,                      // 默认浅灰
            0xFFF5F5F5,             // 浅灰
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFCE4EC,             // 极浅粉
            0xFFEEEEEE,             // 灰
            0xFFE0E0E0,             // 中灰
            0xFF212121,             // 深灰
            0xFF1A237E,             // 深蓝
    };

    private static final String[] SEARCH_PAGE_INPUT_COLOR_NAMES = {
            "默认极浅蓝", "浅灰", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙", "极浅粉",
            "灰", "中灰", "深灰", "深蓝"
    };

    private void updateSearchPageInputBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getSearchInputBg();
        android.graphics.drawable.Drawable bg = binding.viewSearchPageInputBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvSearchPageInputBgHint.setText(color == 0
                ? "自定义搜索页面搜索框所在区域背景颜色（当前：默认极浅蓝）"
                : "自定义搜索页面搜索框所在区域背景颜色（当前：" + getSearchPageInputColorName(color) + "）");
    }

    private String getSearchPageInputColorName(int color) {
        for (int i = 0; i < SEARCH_PAGE_INPUT_PRESET_COLORS.length; i++) {
            if (SEARCH_PAGE_INPUT_PRESET_COLORS[i] == color) return SEARCH_PAGE_INPUT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showSearchPageInputBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getSearchInputBg(),
                SEARCH_PAGE_INPUT_PRESET_COLORS, SEARCH_PAGE_INPUT_COLOR_NAMES, "选择搜索页输入区背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setSearchInputBg(this, color);
                    updateSearchPageInputBgPreview();
                });
    }

    // ==================== 搜索页排序栏背景 ====================

    private static final int[] SEARCH_PAGE_SORT_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFCE4EC,             // 极浅粉
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] SEARCH_PAGE_SORT_COLOR_NAMES = {
            "默认极浅蓝", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙", "极浅粉",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateSearchPageSortBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getSearchSortBg();
        android.graphics.drawable.Drawable bg = binding.viewSearchPageSortBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvSearchPageSortBgHint.setText(color == 0
                ? "自定义搜索页面排序切换栏背景颜色（当前：默认极浅蓝）"
                : "自定义搜索页面排序切换栏背景颜色（当前：" + getSearchPageSortColorName(color) + "）");
    }

    private String getSearchPageSortColorName(int color) {
        for (int i = 0; i < SEARCH_PAGE_SORT_PRESET_COLORS.length; i++) {
            if (SEARCH_PAGE_SORT_PRESET_COLORS[i] == color) return SEARCH_PAGE_SORT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showSearchPageSortBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getSearchSortBg(),
                SEARCH_PAGE_SORT_PRESET_COLORS, SEARCH_PAGE_SORT_COLOR_NAMES, "选择搜索页排序栏背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setSearchSortBg(this, color);
                    updateSearchPageSortBgPreview();
                });
    }

    // ==================== 搜索页内容区背景 ====================

    private static final int[] SEARCH_PAGE_CONTENT_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFCE4EC,             // 极浅粉
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] SEARCH_PAGE_CONTENT_COLOR_NAMES = {
            "默认极浅蓝", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙", "极浅粉",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateSearchPageContentBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getSearchContentBg();
        android.graphics.drawable.Drawable bg = binding.viewSearchPageContentBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvSearchPageContentBgHint.setText(color == 0
                ? "自定义搜索页面内容区背景颜色（当前：默认极浅蓝）"
                : "自定义搜索页面内容区背景颜色（当前：" + getSearchPageContentColorName(color) + "）");
    }

    private String getSearchPageContentColorName(int color) {
        for (int i = 0; i < SEARCH_PAGE_CONTENT_PRESET_COLORS.length; i++) {
            if (SEARCH_PAGE_CONTENT_PRESET_COLORS[i] == color) return SEARCH_PAGE_CONTENT_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showSearchPageContentBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getSearchContentBg(),
                SEARCH_PAGE_CONTENT_PRESET_COLORS, SEARCH_PAGE_CONTENT_COLOR_NAMES, "选择搜索页内容区背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setSearchContentBg(this, color);
                    updateSearchPageContentBgPreview();
                });
    }

    // ==================== 搜索按钮颜色 ====================

    private static final int[] SEARCH_PAGE_BUTTON_PRESET_COLORS = {
            0,                      // 默认蓝灰
            0xFFFF4081,             // 粉红
            0xFF2196F3,             // 蓝
            0xFF4CAF50,             // 绿
            0xFFFF9800,             // 橙
            0xFF9C27B0,             // 紫
            0xFF00BCD4,             // 青
            0xFFF44336,             // 红
            0xFFFFFFFF,             // 白
            0xFF000000,             // 黑
            0xFF607D8B,             // 蓝灰
    };

    private static final String[] SEARCH_PAGE_BUTTON_COLOR_NAMES = {
            "默认蓝灰", "粉红", "蓝", "绿", "橙", "紫", "青", "红", "白", "黑", "蓝灰"
    };

    private void updateSearchPageButtonBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getSearchButtonBg();
        android.graphics.drawable.Drawable bg = binding.viewSearchPageButtonBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFF607D8B : color);
        }
        binding.tvSearchPageButtonBgHint.setText(color == 0
                ? "自定义搜索页面「搜索」按钮背景颜色（当前：默认蓝灰）"
                : "自定义搜索页面「搜索」按钮背景颜色（当前：" + getSearchPageButtonColorName(color) + "）");
    }

    private String getSearchPageButtonColorName(int color) {
        for (int i = 0; i < SEARCH_PAGE_BUTTON_PRESET_COLORS.length; i++) {
            if (SEARCH_PAGE_BUTTON_PRESET_COLORS[i] == color) return SEARCH_PAGE_BUTTON_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showSearchPageButtonBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getSearchButtonBg(),
                SEARCH_PAGE_BUTTON_PRESET_COLORS, SEARCH_PAGE_BUTTON_COLOR_NAMES, "选择搜索按钮颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setSearchButtonBg(this, color);
                    updateSearchPageButtonBgPreview();
                });
    }


    // ==================== 帖子顶部背景 ====================

    private static final int[] THREAD_TOP_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFF5F5F5,             // 浅灰白
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] THREAD_TOP_COLOR_NAMES = {
            "默认极浅蓝", "白色", "浅灰白", "极浅蓝", "极浅紫", "极浅绿", "极浅橙",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateThreadTopBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getThreadTopBg();
        android.graphics.drawable.Drawable bg = binding.viewThreadTopBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvThreadTopBgHint.setText(color == 0
                ? "自定义帖子详情页顶部「帖子详情」栏背景颜色（当前：默认极浅蓝）"
                : "自定义帖子详情页顶部「帖子详情」栏背景颜色（当前：" + getThreadTopColorName(color) + "）");
    }

    private String getThreadTopColorName(int color) {
        for (int i = 0; i < THREAD_TOP_PRESET_COLORS.length; i++) {
            if (THREAD_TOP_PRESET_COLORS[i] == color) return THREAD_TOP_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showThreadTopBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getThreadTopBg(),
                THREAD_TOP_PRESET_COLORS, THREAD_TOP_COLOR_NAMES, "选择帖子顶部背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setThreadTopBg(this, color);
                    updateThreadTopBgPreview();
                });
    }

    // ==================== 帖子背景 ====================

    private static final int[] THREAD_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFF5F5F5,             // 浅灰白
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] THREAD_COLOR_NAMES = {
            "默认极浅蓝", "白色", "浅灰白", "极浅蓝", "极浅紫", "极浅绿", "极浅橙",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateThreadBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getThreadBg();
        android.graphics.drawable.Drawable bg = binding.viewThreadBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvThreadBgHint.setText(color == 0
                ? "自定义帖子详情页内容区域背景颜色（当前：默认极浅蓝）"
                : "自定义帖子详情页内容区域背景颜色（当前：" + getThreadColorName(color) + "）");
    }

    private String getThreadColorName(int color) {
        for (int i = 0; i < THREAD_PRESET_COLORS.length; i++) {
            if (THREAD_PRESET_COLORS[i] == color) return THREAD_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showThreadBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getThreadBg(),
                THREAD_PRESET_COLORS, THREAD_COLOR_NAMES, "选择帖子背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setThreadBg(this, color);
                    updateThreadBgPreview();
                });
    }

    // ==================== 消息页标题栏背景 ====================

    private static final int[] MESSAGE_TITLE_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFF5F5F5,             // 浅灰白
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] MESSAGE_TITLE_COLOR_NAMES = {
            "默认极浅蓝", "白色", "浅灰白", "极浅蓝", "极浅紫", "极浅绿", "极浅橙",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateMessageTitleBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getMessageTitleBg();
        android.graphics.drawable.Drawable bg = binding.viewMessageTitleBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvMessageTitleBgHint.setText(color == 0
                ? "自定义消息页面顶部标题栏背景颜色（当前：默认极浅蓝）"
                : "自定义消息页面顶部标题栏背景颜色（当前：" + getMessageTitleColorName(color) + "）");
    }

    private String getMessageTitleColorName(int color) {
        for (int i = 0; i < MESSAGE_TITLE_PRESET_COLORS.length; i++) {
            if (MESSAGE_TITLE_PRESET_COLORS[i] == color) return MESSAGE_TITLE_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showMessageTitleBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getMessageTitleBg(),
                MESSAGE_TITLE_PRESET_COLORS, MESSAGE_TITLE_COLOR_NAMES, "选择消息页标题栏背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setMessageTitleBg(this, color);
                    updateMessageTitleBgPreview();
                });
    }

    // ==================== 消息页Tab栏背景 ====================

    private static final int[] MESSAGE_TAB_PRESET_COLORS = {
            0,                      // 默认极浅蓝
            0xFFFFFFFF,             // 白色
            0xFFF5F5F5,             // 浅灰白
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] MESSAGE_TAB_COLOR_NAMES = {
            "默认极浅蓝", "白色", "浅灰白", "极浅蓝", "极浅紫", "极浅绿", "极浅橙",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateMessageTabBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getMessageTabBg();
        android.graphics.drawable.Drawable bg = binding.viewMessageTabBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE3F2FD : color);
        }
        binding.tvMessageTabBgHint.setText(color == 0
                ? "自定义消息页面Tab分类栏背景颜色（当前：默认极浅蓝）"
                : "自定义消息页面Tab分类栏背景颜色（当前：" + getMessageTabColorName(color) + "）");
    }

    private String getMessageTabColorName(int color) {
        for (int i = 0; i < MESSAGE_TAB_PRESET_COLORS.length; i++) {
            if (MESSAGE_TAB_PRESET_COLORS[i] == color) return MESSAGE_TAB_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showMessageTabBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getMessageTabBg(),
                MESSAGE_TAB_PRESET_COLORS, MESSAGE_TAB_COLOR_NAMES, "选择消息页Tab栏背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setMessageTabBg(this, color);
                    updateMessageTabBgPreview();
                });
    }

    // ==================== 帖子操作按钮背景 ====================

    private static final int[] THREAD_ACTION_BTN_PRESET_COLORS = {
            0,                      // 默认蓝灰
            0xFF4CAF50,             // 绿色
            0xFF2196F3,             // 蓝色
            0xFF009688,             // 青色
            0xFFFF9800,             // 橙色
            0xFFF44336,             // 红色
            0xFF9C27B0,             // 紫色
            0xFF607D8B,             // 蓝灰
            0xFF795548,             // 棕色
            0xFF000000,             // 黑色
            0xFFFFFFFF,             // 白色
            0xFFE91E63,             // 粉色
    };

    private static final String[] THREAD_ACTION_BTN_COLOR_NAMES = {
            "默认蓝灰", "绿色", "蓝色", "青色", "橙色", "红色", "紫色", "蓝灰", "棕色", "黑色", "白色", "粉色"
    };

    private void updateThreadActionBtnBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getThreadActionBtnBg();
        android.graphics.drawable.Drawable bg = binding.viewThreadActionBtnBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFF607D8B : color);
        }
        binding.tvThreadActionBtnBgHint.setText(color == 0
                ? "自定义「打赏」「踢帖」按钮背景颜色（当前：默认蓝灰）"
                : "自定义「打赏」「踢帖」按钮背景颜色（当前：" + getThreadActionBtnColorName(color) + "）");
    }

    private String getThreadActionBtnColorName(int color) {
        for (int i = 0; i < THREAD_ACTION_BTN_PRESET_COLORS.length; i++) {
            if (THREAD_ACTION_BTN_PRESET_COLORS[i] == color) return THREAD_ACTION_BTN_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showThreadActionBtnBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getThreadActionBtnBg(),
                THREAD_ACTION_BTN_PRESET_COLORS, THREAD_ACTION_BTN_COLOR_NAMES, "选择帖子操作按钮背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setThreadActionBtnBg(this, color);
                    updateThreadActionBtnBgPreview();
                });
    }

    // ==================== 底部输入栏背景 ====================

    private static final int[] REPLY_BAR_PRESET_COLORS = {
            0,                      // 默认蓝紫
            0xFFFFFFFF,             // 白色
            0xFFF5F5F5,             // 浅灰白
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFAFAFA,             // 浅灰
            0xFF212121,             // 深灰
            0xFF000000,             // 黑色
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] REPLY_BAR_COLOR_NAMES = {
            "默认蓝紫", "白色", "浅灰白", "极浅蓝", "极浅紫", "极浅绿", "极浅橙",
            "浅灰", "深灰", "黑色", "深蓝", "深红"
    };

    private void updateReplyBarBgPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getReplyBarBg();
        android.graphics.drawable.Drawable bg = binding.viewReplyBarBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFF575996 : color);
        }
        binding.tvReplyBarBgHint.setText(color == 0
                ? "自定义帖子详情页底部输入框所在栏背景颜色（当前：默认蓝紫）"
                : "自定义帖子详情页底部输入框所在栏背景颜色（当前：" + getReplyBarColorName(color) + "）");
    }

    private String getReplyBarColorName(int color) {
        for (int i = 0; i < REPLY_BAR_PRESET_COLORS.length; i++) {
            if (REPLY_BAR_PRESET_COLORS[i] == color) return REPLY_BAR_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showReplyBarBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getReplyBarBg(),
                REPLY_BAR_PRESET_COLORS, REPLY_BAR_COLOR_NAMES, "选择底部输入栏背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setReplyBarBg(this, color);
                    updateReplyBarBgPreview();
                });
    }

    // ==================== 未读高亮色条颜色 ====================

    private static final int[] UNREAD_BAR_PRESET_COLORS = {
            0,                      // 默认黄绿
            0xFF707646,             // 黄绿（默认）
            0xFFFF1744,             // 亮红
            0xFFFF5722,             // 深橙
            0xFFFF9800,             // 橙色
            0xFFFFC107,             // 琥珀
            0xFF4CAF50,             // 绿色
            0xFF00BCD4,             // 青色
            0xFF2196F3,             // 蓝色
            0xFF3F51B5,             // 靛蓝
            0xFF9C27B0,             // 紫色
            0xFFE91E63,             // 玫红
            0xFF000000,             // 黑色
    };

    private static final String[] UNREAD_BAR_COLOR_NAMES = {
            "默认黄绿", "黄绿", "亮红", "深橙", "橙色", "琥珀",
            "绿色", "青色", "蓝色", "靛蓝", "紫色", "玫红", "黑色"
    };

    private void updateUnreadBarColorPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getUnreadBarColor();
        android.graphics.drawable.Drawable bg = binding.viewUnreadBarColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFF707646 : color);
        }
        binding.tvUnreadBarColorHint.setText(color == 0
                ? "自定义消息列表未读高亮色条颜色（当前：默认黄绿）"
                : "自定义消息列表未读高亮色条颜色（当前：" + getUnreadBarColorName(color) + "）");
    }

    private String getUnreadBarColorName(int color) {
        for (int i = 0; i < UNREAD_BAR_PRESET_COLORS.length; i++) {
            if (UNREAD_BAR_PRESET_COLORS[i] == color) return UNREAD_BAR_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showUnreadBarColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getUnreadBarColor(),
                UNREAD_BAR_PRESET_COLORS, UNREAD_BAR_COLOR_NAMES, "选择未读高亮色条颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setUnreadBarColor(this, color);
                    updateUnreadBarColorPreview();
                });
    }

    // ==================== 编辑时间文字颜色 ====================

    private static final int[] EDIT_TIME_PRESET_COLORS = {
            0,                      // 默认浅灰
            0xFF9E9E9E,             // 灰色（默认）
            0xFF757575,             // 中灰
            0xFF616161,             // 深灰
            0xFF424242,             // 更深深灰
            0xFF212121,             // 铁灰
            0xFF000000,             // 黑色
            0xFF888888,             // 浅灰
            0xFF1565C0,             // 蓝色
            0xFF2E7D32,             // 绿色
            0xFFC62828,             // 红色
            0xFF6A1B9A,             // 紫色
            0xFFE65100,             // 橙色
    };

    private static final String[] EDIT_TIME_COLOR_NAMES = {
            "默认浅灰", "灰色", "中灰", "深灰", "更深深灰", "铁灰",
            "黑色", "浅灰", "蓝色", "绿色", "红色", "紫色", "橙色"
    };

    private void updateEditTimeColorPreview() {
        int color = com.forum.MT.ui.widget.HomeBarColorManager.getEditTimeColor();
        android.graphics.drawable.Drawable bg = binding.viewEditTimeColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFF888888 : color);
        }
        binding.tvEditTimeColorHint.setText(color == 0
                ? "自定义帖子/评论「本帖最后由…编辑」文字颜色（当前：默认浅灰）"
                : "自定义帖子/评论「本帖最后由…编辑」文字颜色（当前：" + getEditTimeColorName(color) + "）");
    }

    private String getEditTimeColorName(int color) {
        for (int i = 0; i < EDIT_TIME_PRESET_COLORS.length; i++) {
            if (EDIT_TIME_PRESET_COLORS[i] == color) return EDIT_TIME_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showEditTimeColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.HomeBarColorManager.getEditTimeColor(),
                EDIT_TIME_PRESET_COLORS, EDIT_TIME_COLOR_NAMES, "选择编辑时间文字颜色",
                (color) -> {
                    com.forum.MT.ui.widget.HomeBarColorManager.setEditTimeColor(this, color);
                    updateEditTimeColorPreview();
                });
    }

    // ==================== 投票进度条颜色 ====================

    private static final int[] POLL_BAR_PRESET_COLORS = {
            0,                       // 默认粉色
            Color.rgb(255, 64, 129), // 粉色（默认）
            Color.rgb(33, 150, 243), // 蓝色
            Color.rgb(76, 175, 80),  // 绿色
            Color.rgb(255, 152, 0),  // 橙色
            Color.rgb(156, 39, 176), // 紫色
            Color.rgb(244, 67, 54),  // 红色
            Color.rgb(0, 150, 136),  // 青色
            Color.rgb(121, 85, 72),  // 棕色
            Color.rgb(96, 125, 139), // 蓝灰
            Color.rgb(33, 33, 33),   // 深灰
    };

    private static final String[] POLL_BAR_COLOR_NAMES = {
            "默认粉色", "粉色", "蓝色", "绿色", "橙色", "紫色",
            "红色", "青色", "棕色", "蓝灰", "深灰"
    };

    private void updatePollBarColorPreview() {
        int color = com.forum.MT.ui.widget.PollBarColorManager.getCustomColor();
        android.graphics.drawable.Drawable bg = binding.viewPollBarColorPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? com.forum.MT.ui.widget.PollBarColorManager.DEFAULT_COLOR : color);
        }
        binding.tvPollBarColorHint.setText(color == 0
                ? "帖子投票选项进度条的填充颜色（当前：默认粉色）"
                : "帖子投票选项进度条的填充颜色（当前：" + getPollBarColorName(color) + "）");
    }

    private String getPollBarColorName(int color) {
        for (int i = 0; i < POLL_BAR_PRESET_COLORS.length; i++) {
            if (POLL_BAR_PRESET_COLORS[i] == color) return POLL_BAR_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showPollBarColorPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.PollBarColorManager.getCustomColor(),
                POLL_BAR_PRESET_COLORS, POLL_BAR_COLOR_NAMES, "选择投票进度条颜色",
                (color) -> {
                    com.forum.MT.ui.widget.PollBarColorManager.setCustomColor(this, color);
                    updatePollBarColorPreview();
                });
    }

    // ==================== 帖子板块标签背景 ====================

    private static final int[] THREAD_TAG_PRESET_COLORS = {
            0,                      // 默认浅青
            0xFFF3F3F3,             // 浅灰（默认）
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFFEBEE,             // 极浅红
            0xFFE0F7FA,             // 极浅青
            0xFF212121,             // 深灰
            0xFF1A237E,             // 深蓝
            0xFFB71C1C,             // 深红
    };

    private static final String[] THREAD_TAG_COLOR_NAMES = {
            "默认浅青", "浅灰", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙",
            "极浅红", "极浅青", "深灰", "深蓝", "深红"
    };

    private void updateThreadTagBgPreview() {
        int color = ThreadTagColorManager.getTagBg();
        android.graphics.drawable.Drawable bg = binding.viewThreadTagBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFE0F7FA : color);
        }
        binding.tvThreadTagBgHint.setText(color == 0
                ? "自定义帖子列表中板块标签（如「逆向交流」）背景颜色（当前：默认浅青）"
                : "自定义帖子列表中板块标签（如「逆向交流」）背景颜色（当前：" + getThreadTagColorName(color) + "）");
    }

    private String getThreadTagColorName(int color) {
        for (int i = 0; i < THREAD_TAG_PRESET_COLORS.length; i++) {
            if (THREAD_TAG_PRESET_COLORS[i] == color) return THREAD_TAG_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showThreadTagBgPickerDialog() {
        showNavColorPickerDialog(ThreadTagColorManager.getTagBg(),
                THREAD_TAG_PRESET_COLORS, THREAD_TAG_COLOR_NAMES, "选择板块标签背景颜色",
                (color) -> {
                    ThreadTagColorManager.setTagBg(this, color);
                    updateThreadTagBgPreview();
                });
    }

    // ==================== 关注按钮背景 ====================

    private static final int[] THREAD_FOLLOW_PRESET_COLORS = {
            0,                      // 默认浅紫
            0xFFF2F2F2,             // 浅灰（默认）
            0xFFFFFFFF,             // 白色
            0xFFE3F2FD,             // 极浅蓝
            0xFFF3E5F5,             // 极浅紫
            0xFFE8F5E9,             // 极浅绿
            0xFFFFF3E0,             // 极浅橙
            0xFFFFEBEE,             // 极浅红
            0xFFE0F7FA,             // 极浅青
            0xFF212121,             // 深灰
            0xFF1976D2,             // 蓝色
            0xFFD32F2F,             // 红色
            0xFF388E3C,             // 绿色
    };

    private static final String[] THREAD_FOLLOW_COLOR_NAMES = {
            "默认浅紫", "浅灰", "白色", "极浅蓝", "极浅紫", "极浅绿", "极浅橙",
            "极浅红", "极浅青", "深灰", "蓝色", "红色", "绿色"
    };

    private void updateThreadFollowBgPreview() {
        int color = ThreadTagColorManager.getFollowBg();
        android.graphics.drawable.Drawable bg = binding.viewThreadFollowBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0 ? 0xFFF3E5F5 : color);
        }
        binding.tvThreadFollowBgHint.setText(color == 0
                ? "自定义帖子列表中「关注」按钮背景颜色（当前：默认浅紫）"
                : "自定义帖子列表中「关注」按钮背景颜色（当前：" + getThreadFollowColorName(color) + "）");
    }

    private String getThreadFollowColorName(int color) {
        for (int i = 0; i < THREAD_FOLLOW_PRESET_COLORS.length; i++) {
            if (THREAD_FOLLOW_PRESET_COLORS[i] == color) return THREAD_FOLLOW_COLOR_NAMES[i];
        }
        return "自定义颜色";
    }

    private void showThreadFollowBgPickerDialog() {
        showNavColorPickerDialog(ThreadTagColorManager.getFollowBg(),
                THREAD_FOLLOW_PRESET_COLORS, THREAD_FOLLOW_COLOR_NAMES, "选择关注按钮背景颜色",
                (color) -> {
                    ThreadTagColorManager.setFollowBg(this, color);
                    updateThreadFollowBgPreview();
                });
    }

    // ==================== 回复弹窗颜色 ====================

    private static final int[] REPLY_DIALOG_PRESET_COLORS = {
            0,                              // 默认
            Color.rgb(255, 255, 255),       // 白色
            Color.rgb(245, 245, 245),       // 极浅灰
            Color.rgb(33, 33, 33),          // 深灰
            Color.rgb(255, 87, 87),         // 红色
            Color.rgb(76, 175, 80),         // 绿色
            Color.rgb(33, 150, 243),         // 蓝色
            Color.rgb(255, 152, 0),         // 橙色
            Color.rgb(156, 39, 176),        // 紫色
            Color.rgb(0, 0, 0),             // 黑色
    };

    private static final String[] REPLY_DIALOG_COLOR_NAMES = {
            "默认", "白色", "极浅灰", "深灰", "红色", "绿色", "蓝色", "橙色", "紫色", "黑色"
    };

    private void updateReplyDialogBgPreview() {
        int color = com.forum.MT.ui.widget.ReplyDialogColorManager.getBgColor(this);
        android.graphics.drawable.Drawable bg = binding.viewReplyDialogBgPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBgColor(this) : color);
            binding.viewReplyDialogBgPreview.invalidate();
        }
        binding.tvReplyDialogBgHint.setText(color == 0
                ? "点击选择弹窗背景颜色（默认白色 #FFFFFF）"
                : "点击选择弹窗背景颜色（当前：" + getColorName(color) + "）");
    }

    private void showReplyDialogBgPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.ReplyDialogColorManager.getBgColor(this),
                REPLY_DIALOG_PRESET_COLORS, REPLY_DIALOG_COLOR_NAMES, "选择弹窗背景颜色",
                (color) -> {
                    com.forum.MT.ui.widget.ReplyDialogColorManager.setBgColor(this, color);
                    updateReplyDialogBgPreview();
                });
    }

    private void updateReplyDialogTextPreview() {
        int color = com.forum.MT.ui.widget.ReplyDialogColorManager.getTextColor(this);
        android.graphics.drawable.Drawable bg = binding.viewReplyDialogTextPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.ReplyDialogColorManager.resolveTextColor(this) : color);
            binding.viewReplyDialogTextPreview.invalidate();
        }
        binding.tvReplyDialogTextHint.setText(color == 0
                ? "点击选择弹窗文字颜色（默认深灰 #333333）"
                : "点击选择弹窗文字颜色（当前：" + getColorName(color) + "）");
    }

    private void showReplyDialogTextPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.ReplyDialogColorManager.getTextColor(this),
                REPLY_DIALOG_PRESET_COLORS, REPLY_DIALOG_COLOR_NAMES, "选择弹窗文字颜色",
                (color) -> {
                    com.forum.MT.ui.widget.ReplyDialogColorManager.setTextColor(this, color);
                    updateReplyDialogTextPreview();
                });
    }

    private void updateReplyDialogBorderPreview() {
        int color = com.forum.MT.ui.widget.ReplyDialogColorManager.getBorderColor(this);
        android.graphics.drawable.Drawable bg = binding.viewReplyDialogBorderPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBorderColor(this) : color);
            binding.viewReplyDialogBorderPreview.invalidate();
        }
        binding.tvReplyDialogBorderHint.setText(color == 0
                ? "点击选择弹窗边框颜色（默认浅灰 #E0E0E0）"
                : "点击选择弹窗边框颜色（当前：" + getColorName(color) + "）");
    }

    private void showReplyDialogBorderPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.ReplyDialogColorManager.getBorderColor(this),
                REPLY_DIALOG_PRESET_COLORS, REPLY_DIALOG_COLOR_NAMES, "选择弹窗边框颜色",
                (color) -> {
                    com.forum.MT.ui.widget.ReplyDialogColorManager.setBorderColor(this, color);
                    updateReplyDialogBorderPreview();
                });
    }

    private void updateReplyDialogBtnPreview() {
        int color = com.forum.MT.ui.widget.ReplyDialogColorManager.getBtnColor(this);
        android.graphics.drawable.Drawable bg = binding.viewReplyDialogBtnPreview.getBackground();
        if (bg instanceof GradientDrawable) {
            ((GradientDrawable) bg).setColor(color == 0
                    ? com.forum.MT.ui.widget.ReplyDialogColorManager.resolveBtnColor(this) : color);
            binding.viewReplyDialogBtnPreview.invalidate();
        }
        binding.tvReplyDialogBtnHint.setText(color == 0
                ? "点击选择弹窗按钮背景颜色（默认绿色 #4CAF50，发送和取消共用）"
                : "点击选择弹窗按钮背景颜色（当前：" + getColorName(color) + "）");
    }

    private void showReplyDialogBtnPickerDialog() {
        showNavColorPickerDialog(com.forum.MT.ui.widget.ReplyDialogColorManager.getBtnColor(this),
                REPLY_DIALOG_PRESET_COLORS, REPLY_DIALOG_COLOR_NAMES, "选择弹窗按钮颜色",
                (color) -> {
                    com.forum.MT.ui.widget.ReplyDialogColorManager.setBtnColor(this, color);
                    updateReplyDialogBtnPreview();
                });
    }
    /**
     * 帖子卡片缩放百分比滑块：50%~250%，默认 170%
     */
    private void setupCardScaleSeekBar(android.widget.SeekBar sb, android.widget.TextView tvValue) {
        int percent = com.forum.MT.ui.widget.ThreadTextSizeManager.getCardScalePercent(this);
        sb.setMax(200); // 50 + 200 = 250
        sb.setProgress(percent - 50);
        tvValue.setText(percent + "%");
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                tvValue.setText((progress + 50) + "%");
            }
            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {
                com.forum.MT.ui.widget.ThreadTextSizeManager.setCardScalePercent(
                        ThemeSettingsActivity.this, seekBar.getProgress() + 50);
            }
        });
    }

    private void setupSizeSeekBar(android.widget.SeekBar sb,
                                  android.widget.TextView tvValue, int mode) {
        float saved = com.forum.MT.ui.widget.ThreadTextSizeManager.getTextSizeSp(this, mode);
        // 编辑时间：0 = 跟随正文（默认）。UI 上显示在 15.0 位置并标注"跟随正文"
        boolean followText = (mode == com.forum.MT.ui.widget.ThreadTextSizeManager.MODE_EDIT_TIME && saved <= 0);
        int savedTenth = followText
                ? com.forum.MT.ui.widget.ThreadTextSizeManager.DEFAULT_TEXT_SIZE_TENTH
                : Math.round(saved * 10f);
        sb.setProgress(savedTenth - com.forum.MT.ui.widget.ThreadTextSizeManager.MIN_TEXT_SIZE_TENTH);
        tvValue.setText(followText ? "跟随正文" : String.format(java.util.Locale.ROOT, "%.1f", saved));
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                int tenth = progress + com.forum.MT.ui.widget.ThreadTextSizeManager.MIN_TEXT_SIZE_TENTH;
                tvValue.setText(String.format(java.util.Locale.ROOT, "%.1f", tenth / 10f));
            }
            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {
                int tenth = seekBar.getProgress() + com.forum.MT.ui.widget.ThreadTextSizeManager.MIN_TEXT_SIZE_TENTH;
                com.forum.MT.ui.widget.ThreadTextSizeManager.setTextSizeTenth(
                        ThemeSettingsActivity.this, mode, tenth);
            }
        });
    }

}
