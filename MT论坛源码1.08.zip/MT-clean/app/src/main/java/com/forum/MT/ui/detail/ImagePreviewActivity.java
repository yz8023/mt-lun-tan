package com.forum.MT.ui.detail;
import com.forum.MT.ui.BaseActivity;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.forum.MT.R;

/**
 * 全屏图片预览 Activity
 * 支持 ZoomableImageView 双指缩放、单指拖动
 */
public class ImagePreviewActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_preview);

        ZoomableImageView ivPreview = findViewById(R.id.iv_preview);
        ImageButton btnClose = findViewById(R.id.btn_close);

        // 关闭按钮
        btnClose.setOnClickListener(v -> finish());

        // 获取图片URL
        String imageUrl = getIntent().getStringExtra("image_url");
        if (imageUrl == null || imageUrl.isEmpty()) {
            Toast.makeText(this, "图片加载失败", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 用 Glide 加载原图到 ZoomableImageView
        // ZoomableImageView.onLayout() 会自动计算适应屏幕的初始矩阵
        // ★ 使用与正文一致的带防盗链 headers 的请求，避免裸 URL 缓存状态与正文不一致
        Glide.with(this)
                .load(com.forum.MT.ui.detail.ReplyAdapter.buildForumImageRequest(imageUrl))
                .placeholder(new android.graphics.drawable.ColorDrawable(0xFF333333))
                .error(new android.graphics.drawable.ColorDrawable(0xFF111111))
                .into(ivPreview);
    }
}