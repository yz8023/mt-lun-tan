package com.forum.MT.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Discuz! 编辑帖子/评论表单数据。
 *
 * <p>对应 {@code forum.php?mod=post&action=edit&fid=..&tid=..&pid=..&page=..} 返回的
 * {@code form#postform}。编辑提交时必须原样回传 formhash / posttime / delete，
 * 否则 Discuz 会判定为非法请求；已有附件也必须通过 {@code attachnew[aid][description]}
 * 重新绑定，否则保存后原帖附件会被清空。
 */
public class PostEditForm {

    private String formhash = "";
    private String posttime = "";
    private String fid = "";
    private String tid = "";
    private String pid = "";
    private int page = 1;

    /** 原标题。只有主题第一楼才有值，评论楼层为空。 */
    private String subject = "";
    /** 原正文（BBCode 源码，textarea 内容）。 */
    private String message = "";

    private String deleteValue = "0";
    /**
     * 编辑页是否输出了删除复选框（{@code input[name=delete][type=checkbox]}）。
     *
     * <p>Discuz 只在当前用户确实可删该帖时才渲染这个 checkbox，因此它是判断
     * "有无删除权限"最可靠的页面信号。移动模板有时会精简掉它，所以这只作为
     * 提示依据，最终仍由服务端响应决定成败。
     */
    private boolean deleteSupported;
    private String allowNoticeAuthor = "1";
    private String useSig = "1";
    /** 编辑页是否输出"回帖仅作者可见"开关（仅主题第一楼、且论坛允许时才有）。 */
    private boolean hiddenRepliesSupported;
    private boolean hiddenReplies;
    /** 编辑页是否输出"回帖倒序排列"开关。 */
    private boolean orderTypeSupported;
    private boolean orderReverse;

    /** 是否为主题第一楼（可编辑标题）。 */
    private boolean firstPost;

    /** 附件上传凭证（与发帖页同源，来自 uploadformdata）。 */
    private String uploadUid = "";
    private String uploadHash = "";

    /** 原帖已关联的附件 aid，提交时必须重新绑定。 */
    private List<String> attachmentAids = new ArrayList<>();

    public String getFormhash() { return formhash; }
    public void setFormhash(String formhash) { this.formhash = formhash; }

    public String getPosttime() { return posttime; }
    public void setPosttime(String posttime) { this.posttime = posttime; }

    public String getFid() { return fid; }
    public void setFid(String fid) { this.fid = fid; }

    public String getTid() { return tid; }
    public void setTid(String tid) { this.tid = tid; }

    public String getPid() { return pid; }
    public void setPid(String pid) { this.pid = pid; }

    public int getPage() { return page; }
    public void setPage(int page) { this.page = page; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getDeleteValue() { return deleteValue; }
    public void setDeleteValue(String deleteValue) { this.deleteValue = deleteValue; }

    public boolean isDeleteSupported() { return deleteSupported; }
    public void setDeleteSupported(boolean deleteSupported) {
        this.deleteSupported = deleteSupported;
    }

    public String getAllowNoticeAuthor() { return allowNoticeAuthor; }
    public void setAllowNoticeAuthor(String allowNoticeAuthor) {
        this.allowNoticeAuthor = allowNoticeAuthor;
    }

    public String getUseSig() { return useSig; }
    public void setUseSig(String useSig) { this.useSig = useSig; }

    public boolean isHiddenRepliesSupported() { return hiddenRepliesSupported; }
    public void setHiddenRepliesSupported(boolean supported) {
        this.hiddenRepliesSupported = supported;
    }

    public boolean isHiddenReplies() { return hiddenReplies; }
    public void setHiddenReplies(boolean hiddenReplies) { this.hiddenReplies = hiddenReplies; }

    public boolean isOrderTypeSupported() { return orderTypeSupported; }
    public void setOrderTypeSupported(boolean supported) { this.orderTypeSupported = supported; }

    public boolean isOrderReverse() { return orderReverse; }
    public void setOrderReverse(boolean orderReverse) { this.orderReverse = orderReverse; }

    public boolean isFirstPost() { return firstPost; }
    public void setFirstPost(boolean firstPost) { this.firstPost = firstPost; }

    public String getUploadUid() { return uploadUid; }
    public void setUploadUid(String uploadUid) { this.uploadUid = uploadUid; }

    public String getUploadHash() { return uploadHash; }
    public void setUploadHash(String uploadHash) { this.uploadHash = uploadHash; }

    public List<String> getAttachmentAids() { return attachmentAids; }
    public void setAttachmentAids(List<String> attachmentAids) {
        this.attachmentAids = attachmentAids == null ? new ArrayList<>() : attachmentAids;
    }

    /** 编辑器是否可用：缺 formhash/posttime 时提交必定被拒。 */
    public boolean isUsable() {
        return !formhash.isEmpty() && !posttime.isEmpty();
    }

    public boolean canUploadImages() {
        return !uploadUid.isEmpty() && !uploadHash.isEmpty();
    }
}
