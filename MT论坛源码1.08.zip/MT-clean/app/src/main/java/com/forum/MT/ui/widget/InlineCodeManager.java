package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理行内代码（<code>）的显示样式：
 * 背景色、文字色、是否启用。
 * 颜色为 0 表示使用默认值。
 */
public class InlineCodeManager {

    private static final String PREFS_NAME = "mt_forum_prefs";

    private static final String KEY_CODE_ENABLED    = "code_style_enabled";
    private static final String KEY_CODE_BG         = "code_bg_color";
    private static final String KEY_CODE_TEXT       = "code_text_color";

    /** 默认背景：浅灰（网页 Discuz 风格） */
    public static final int DEFAULT_BG_COLOR = 0xFFF2F2F2;
    /** 默认文字色：深灰蓝 */
    public static final int DEFAULT_TEXT_COLOR = 0xFFC7254E; // 近似网页行内代码的玫红，可后续让用户调

    private InlineCodeManager() {}

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_CODE_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_CODE_ENABLED, enabled).apply();
    }

    public static int getBgColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_CODE_BG, 0);
    }

    public static int resolveBgColor(Context context) {
        int color = getBgColor(context);
        return color != 0 ? color : DEFAULT_BG_COLOR;
    }

    public static void setBgColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_CODE_BG, color).apply();
    }

    public static int getTextColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_CODE_TEXT, 0);
    }

    public static int resolveTextColor(Context context) {
        int color = getTextColor(context);
        return color != 0 ? color : DEFAULT_TEXT_COLOR;
    }

    public static void setTextColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_CODE_TEXT, color).apply();
    }
}