package com.forum.MT.util;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.forum.MT.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 「导入 Markdown」底部面板。
 *
 * 用户在面板里粘贴/输入 Markdown → 实时转换为 BBCode → 预览 →
 * 插入到光标处或替换正文。转换由 {@link MarkdownBbcodeConverter} 完成。
 *
 * 若提供了 titleEditText，首行 # 标题会自动提取到标题栏，只转换剩余内容。
 *
 * 调用方式：
 *   MarkdownImportHelper.show(activity, contentEditText, titleEditText);
 *   MarkdownImportHelper.show(activity, contentEditText, null);
 */
public final class MarkdownImportHelper {

    private static final Pattern HEADING_FIRST = Pattern.compile("^#{1,6}\\s+(.+?)\\s*#*\\s*$");

    private MarkdownImportHelper() {}

    public static void show(Activity activity, EditText targetEditText, EditText titleEditText) {
        if (activity == null || activity.isFinishing()) return;
        final BottomSheetDialog sheet = new BottomSheetDialog(activity);
        final View content = activity.getLayoutInflater().inflate(R.layout.bottom_sheet_markdown_import, null);
        sheet.setContentView(content);

        final EditText mdInput = content.findViewById(R.id.md_input);
        final ScrollView scrollInput = content.findViewById(R.id.md_scroll_input);
        final ScrollView scrollPreview = content.findViewById(R.id.md_scroll_preview);
        final TextView tvPreview = content.findViewById(R.id.md_preview);
        final TextView tvCharCount = content.findViewById(R.id.md_char_count);
        final TextView tabInput = content.findViewById(R.id.md_tab_input);
        final TextView tabPreview = content.findViewById(R.id.md_tab_preview);
        final View btnClose = content.findViewById(R.id.md_btn_close);
        final TextView btnCopy = content.findViewById(R.id.md_btn_copy);
        final TextView btnInsert = content.findViewById(R.id.md_btn_insert);
        final TextView btnReplace = content.findViewById(R.id.md_btn_replace);

        final int[] currentTab = {0}; // 0=MD, 1=BBCode
        final String[] bbcodeResult = {""};
        final String[] extractedTitle = {""};

        final boolean hasTitleField = titleEditText != null;

        // Tab 切换
        final Runnable updateTabs = () -> {
            boolean isInput = currentTab[0] == 0;
            tabInput.setBackgroundColor(isInput ? activity.getColor(R.color.primary) : 0);
            tabInput.setTextColor(isInput ? activity.getColor(R.color.white) : activity.getColor(R.color.text_secondary));
            tabPreview.setBackgroundColor(!isInput ? activity.getColor(R.color.primary) : 0);
            tabPreview.setTextColor(!isInput ? activity.getColor(R.color.white) : activity.getColor(R.color.text_secondary));
            scrollInput.setVisibility(isInput ? View.VISIBLE : View.GONE);
            scrollPreview.setVisibility(isInput ? View.GONE : View.VISIBLE);
        };
        updateTabs.run();

        tabInput.setOnClickListener(v -> { currentTab[0] = 0; updateTabs.run(); });
        tabPreview.setOnClickListener(v -> {
            currentTab[0] = 1;
            doConvert(mdInput, tvPreview, tvCharCount, bbcodeResult, extractedTitle, hasTitleField);
            updateTabs.run();
        });

        btnClose.setOnClickListener(v -> sheet.dismiss());

        // 实时转换
        mdInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                doConvert(mdInput, tvPreview, tvCharCount, bbcodeResult, extractedTitle, hasTitleField);
            }
        });

        // 复制 BBCode
        btnCopy.setOnClickListener(v -> {
            if (bbcodeResult[0].isEmpty()) {
                Toast.makeText(activity, "没有可复制的内容", Toast.LENGTH_SHORT).show();
                return;
            }
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("BBCode", bbcodeResult[0]));
            Toast.makeText(activity, "已复制 BBCode", Toast.LENGTH_SHORT).show();
        });

        // 插入到光标
        btnInsert.setOnClickListener(v -> {
            if (bbcodeResult[0].isEmpty()) {
                Toast.makeText(activity, "没有可用的转换结果", Toast.LENGTH_SHORT).show();
                return;
            }
            // 有标题字段时，先把提取的标题填入
            if (hasTitleField && !extractedTitle[0].isEmpty()) {
                titleEditText.setText(extractedTitle[0]);
            }
            insertAtCursor(targetEditText, bbcodeResult[0]);
            sheet.dismiss();
            Toast.makeText(activity, hasTitleField && !extractedTitle[0].isEmpty()
                    ? "标题已填入，正文已插入" : "已插入到光标处", Toast.LENGTH_SHORT).show();
        });

        // 替换正文
        btnReplace.setOnClickListener(v -> {
            if (bbcodeResult[0].isEmpty()) {
                Toast.makeText(activity, "没有可用的转换结果", Toast.LENGTH_SHORT).show();
                return;
            }
            Editable existing = targetEditText.getText();
            boolean hasContent = existing != null && existing.toString().trim().length() > 0;
            Runnable doReplace = () -> {
                if (hasTitleField && !extractedTitle[0].isEmpty()) {
                    titleEditText.setText(extractedTitle[0]);
                }
                targetEditText.setText(bbcodeResult[0]);
                targetEditText.setSelection(bbcodeResult[0].length());
                sheet.dismiss();
                Toast.makeText(activity, hasTitleField && !extractedTitle[0].isEmpty()
                        ? "标题已填入，正文已替换" : "已替换正文", Toast.LENGTH_SHORT).show();
            };
            if (hasContent) {
                new AlertDialog.Builder(activity)
                        .setTitle("替换正文")
                        .setMessage("将用转换结果替换编辑器中的全部内容。")
                        .setPositiveButton("替换", (d, w) -> doReplace.run())
                        .setNegativeButton("取消", null)
                        .show();
            } else {
                doReplace.run();
            }
        });

        sheet.show();
    }

    /** 兼容旧调用 */
    public static void show(Activity activity, EditText targetEditText) {
        show(activity, targetEditText, null);
    }

    /**
     * 执行 Markdown → BBCode 转换并更新预览和字符统计。
     * 若 hasTitleField=true 且首行是 # 标题，提取标题文字并只转换剩余部分。
     */
    private static void doConvert(EditText mdInput, TextView tvPreview,
                                  TextView tvCharCount, String[] bbcodeResult,
                                  String[] extractedTitle, boolean hasTitleField) {
        String md = mdInput.getText() == null ? "" : mdInput.getText().toString();
        String bodyMd = md;
        extractedTitle[0] = "";

        if (hasTitleField && !md.isEmpty()) {
            // 找第一个 # 标题行
            String[] lines = md.split("\\n", 2);
            if (lines.length > 0) {
                Matcher m = HEADING_FIRST.matcher(lines[0].trim());
                if (m.matches()) {
                    extractedTitle[0] = m.group(1).trim();
                    bodyMd = lines.length > 1 ? lines[1] : "";
                }
            }
        }

        String bbcode = MarkdownBbcodeConverter.convert(bodyMd);
        bbcodeResult[0] = bbcode;
        if (bbcode.isEmpty()) {
            tvPreview.setText("输入 Markdown 后可预览");
        } else {
            tvPreview.setText(bbcode);
        }
        String titleInfo = !extractedTitle[0].isEmpty() ? "标题: " + extractedTitle[0] + " | " : "";
        tvCharCount.setText(titleInfo + md.length() + " 字符 → " + bbcode.length() + " 字符");
    }

    /** 在 EditText 光标处插入文本 */
    private static void insertAtCursor(EditText et, String text) {
        Editable editable = et.getText();
        if (editable == null) {
            et.setText(text);
            return;
        }
        int start = et.getSelectionStart();
        int end = et.getSelectionEnd();
        if (start < 0) start = editable.length();
        if (end < start) end = start;
        if (end > start) {
            editable.replace(start, end, text);
        } else {
            editable.insert(start, text);
        }
        et.setSelection(start + text.length());
    }
}
