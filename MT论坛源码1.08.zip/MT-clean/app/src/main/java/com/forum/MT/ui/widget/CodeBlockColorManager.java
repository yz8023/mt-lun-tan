package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 管理代码块卡片（CodeCard）的自定义配色：
 * 背景色、文字颜色、边框颜色、标题颜色、标题文字颜色。
 * 颜色为 0 表示使用默认值。
 */
public class CodeBlockColorManager {

    private static final String PREFS_NAME = "mt_forum_prefs";

    private static final String KEY_BG     = "code_block_bg";
    private static final String KEY_TEXT   = "code_block_text";
    private static final String KEY_BORDER = "code_block_border";
    private static final String KEY_TITLE_BG    = "code_block_title_bg";
    private static final String KEY_TITLE_TEXT  = "code_block_title_text";

    private CodeBlockColorManager() {}

    // ==================== 背景色 ====================

    public static int getBgColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_BG, 0);
    }

    public static int resolveBgColor(Context context) {
        int color = getBgColor(context);
        return color != 0 ? color : 0xFF202B36;
    }

    public static void setBgColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_BG, color).apply();
    }

    // ==================== 文字颜色 ====================

    public static int getTextColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_TEXT, 0);
    }

    public static int resolveTextColor(Context context) {
        int color = getTextColor(context);
        return color != 0 ? color : 0xFFE6EDF3;
    }

    public static void setTextColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_TEXT, color).apply();
    }

    // ==================== 边框颜色 ====================

    public static int getBorderColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_BORDER, 0);
    }

    public static int resolveBorderColor(Context context) {
        int color = getBorderColor(context);
        return color != 0 ? color : 0xFF4B6475;
    }

    public static void setBorderColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_BORDER, color).apply();
    }

    // ==================== 标题栏背景色 ====================

    public static int getTitleBgColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_TITLE_BG, 0);
    }

    public static int resolveTitleBgColor(Context context) {
        int color = getTitleBgColor(context);
        return color != 0 ? color : 0xFF1A1E28;
    }

    public static void setTitleBgColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_TITLE_BG, color).apply();
    }

    // ==================== 标题文字颜色 ====================

    public static int getTitleTextColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_TITLE_TEXT, 0);
    }

    public static int resolveTitleTextColor(Context context) {
        int color = getTitleTextColor(context);
        return color != 0 ? color : 0xFFB8D8E8;
    }

    public static void setTitleTextColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_TITLE_TEXT, color).apply();
    }
}