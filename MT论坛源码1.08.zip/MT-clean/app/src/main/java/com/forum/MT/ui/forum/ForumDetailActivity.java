package com.forum.MT.ui.forum;
import com.forum.MT.ui.BaseActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.core.widget.NestedScrollView;

import com.bumptech.glide.Glide;
import com.forum.MT.R;
import com.forum.MT.adapter.StickyThreadAdapter;
import com.forum.MT.adapter.ThreadAdapter;
import com.forum.MT.databinding.ActivityForumDetailBinding;
import com.forum.MT.model.ForumCategory;
import com.forum.MT.model.Thread;
import com.forum.MT.network.ForumParser;
import com.forum.MT.ui.widget.RainbowBorderHelper;
import com.forum.MT.network.HttpClient;
import com.forum.MT.ui.detail.ThreadDetailActivity;
import com.forum.MT.ui.space.UserProfileActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * 板块详情页 — 展示指定板块的帖子列表
 * 支持4种排序：最新发表、热门动态、最近回复、精华
 */
public class ForumDetailActivity extends BaseActivity {

    private ActivityForumDetailBinding binding;
    private HttpClient httpClient;
    private ThreadAdapter threadAdapter;
    private StickyThreadAdapter stickyThreadAdapter;
    private View stickyThreadsContainer;
    private NestedScrollView nestedScrollView;
    private final List<Thread> allThreads = new ArrayList<>();

    // 从Intent获取的板块信息
    private String fid;
    private String forumName;
    private String description;
    private String iconUrl;
    private int totalPosts;
    private int totalThreads;

    private int currentPage = 1;
    private boolean isLoading = false;
    private boolean hasMore = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityForumDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        RainbowBorderHelper.applyToCardViews(binding.getRoot(), this);

        stickyThreadsContainer = findViewById(R.id.sticky_threads_container);
        nestedScrollView = findViewById(R.id.nested_scroll_view);
        RecyclerView stickyRecycler = findViewById(R.id.rv_sticky_threads);
        stickyRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        stickyThreadAdapter = new StickyThreadAdapter(this);
        ThreadAdapter.registerColorChangeListener(stickyThreadAdapter);
        stickyThreadAdapter.setOnItemClickListener(thread -> openThread(thread));
        stickyRecycler.setAdapter(stickyThreadAdapter);

        httpClient = HttpClient.getInstance();

        // 从Intent读取数据
        fid = getIntent().getStringExtra("fid");
        forumName = getIntent().getStringExtra("forumName");
        description = getIntent().getStringExtra("description");
        iconUrl = getIntent().getStringExtra("iconUrl");
        totalPosts = getIntent().getIntExtra("totalPosts", 0);
        totalThreads = getIntent().getIntExtra("totalThreads", 0);

        // Toolbar
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            if (forumName != null && !forumName.isEmpty()) {
                getSupportActionBar().setTitle(forumName);
            }
        }

        // 板块头部信息
        binding.tvForumName.setText(forumName != null ? forumName : "");
        binding.tvForumDesc.setText(description != null && !description.isEmpty() ? description : "暂无描述");

        // 加载图标
        if (iconUrl != null && !iconUrl.isEmpty()) {
            Glide.with(this)
                    .load(iconUrl)
                    .placeholder(R.drawable.ic_circle)
                    .circleCrop()
                    .into(binding.ivForumIcon);
        } else {
            binding.ivForumIcon.setImageResource(R.drawable.ic_circle);
        }

        // 加入按钮切换
        binding.btnJoin.setOnClickListener(v -> {
            MaterialButton btn = binding.btnJoin;
            if (btn.getText().toString().equals(getString(R.string.forum_join))) {
                btn.setText(R.string.forum_joined);
            } else {
                btn.setText(R.string.forum_join);
            }
        });

        // 设置帖子列表
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.recyclerView.setLayoutManager(layoutManager);

        threadAdapter = new ThreadAdapter(this);
        ThreadAdapter.registerColorChangeListener(threadAdapter);
        threadAdapter.setOnItemClickListener((thread, position) -> openThread(thread));
        threadAdapter.setOnUserClickListener(thread -> {
            if (thread == null || TextUtils.isEmpty(thread.getAuthorUid())) return;
            Intent intent = new Intent(this, UserProfileActivity.class);
            intent.putExtra("uid", thread.getAuthorUid());
            intent.putExtra("username", thread.getAuthor());
            startActivity(intent);
        });

        binding.recyclerView.setAdapter(threadAdapter);
        // 置顶帖子和帖子列表不再单独处理下拉刷新，整页由 NestedScrollView 滚动。

        // 外层 NestedScrollView 负责整页滚动，头部、置顶模块和帖子列表会同步移动。
        nestedScrollView.setOnScrollChangeListener((NestedScrollView.OnScrollChangeListener) (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            if (scrollY <= oldScrollY || isLoading || !hasMore) return;
            View child = nestedScrollView.getChildAt(0);
            if (child != null && scrollY + nestedScrollView.getHeight() >= child.getHeight() - 240) {
                currentPage++;
                loadThreads(currentPage);
            }
        });

        // TabLayout 切换
        int accent = com.forum.MT.ui.widget.AccentColorManager.resolveAccentColor();
        binding.tabLayout.setTabTextColors(
                getResources().getColor(R.color.text_secondary, null), accent);
        binding.tabLayout.setSelectedTabIndicatorColor(accent);
        com.forum.MT.ui.widget.AccentColorManager.setListener(() -> {
            int a = com.forum.MT.ui.widget.AccentColorManager.resolveAccentColor();
            binding.tabLayout.setTabTextColors(
                    getResources().getColor(R.color.text_secondary, null), a);
            binding.tabLayout.setSelectedTabIndicatorColor(a);
        });
        binding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                currentPage = 1;
                hasMore = true;
                loadThreads(currentPage);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) { }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                currentPage = 1;
                hasMore = true;
                loadThreads(currentPage);
            }
        });

        // 初始加载
        loadThreads(currentPage);
    }

    /**
     * 根据当前选中的Tab加载帖子
     * Tab 0: 最新发表 (newthread)
     * Tab 1: 热门动态 (hot)
     * Tab 2: 最近回复 (replies)
     * Tab 3: 精华 (digest, 客户端过滤)
     */
    private void loadThreads(int page) {
        if (isLoading) return;
        isLoading = true;
        binding.tvEmpty.setVisibility(View.GONE);

        int tabPosition = binding.tabLayout.getSelectedTabPosition();

        new java.lang.Thread(() -> {
            try {
                String url;
                List<Thread> threads;

                if (tabPosition == 3) {
                    // 精华 — 使用全局精华帖，客户端过滤
                    url = ForumParser.getGuideUrl("digest", page);
                    String html = httpClient.get(url);
                    List<Thread> allGuideThreads = ForumParser.parseForumThreadList(html);
                    // 过滤：保留forumName包含当前板块名称的帖子
                    threads = new ArrayList<>();
                    for (Thread t : allGuideThreads) {
                        if (t.getForumName() != null && forumName != null
                                && t.getForumName().contains(forumName)) {
                            threads.add(t);
                        }
                    }
                } else {
                    // 根据Tab位置拼接排序参数
                    String sortParam = "";
                    if (tabPosition == 1) {
                        sortParam = "&order=hot";
                    } else if (tabPosition == 2) {
                        sortParam = "&order=replies";
                    }
                    url = ForumParser.getThreadListUrl(fid + sortParam, page);
                    String html = httpClient.get(url);
                    threads = ForumParser.parseForumThreadList(html);
                }

                runOnUiThread(() -> {
                    isLoading = false;

                    if (threads.isEmpty()) {
                        hasMore = false;
                        if (page == 1) {
                            allThreads.clear();
                            threadAdapter.setThreadList(new ArrayList<>());
                            binding.tvEmpty.setVisibility(View.VISIBLE);
                        }
                        return;
                    }

                    if (page == 1) {
                        allThreads.clear();
                        threadAdapter.setThreadList(threads);
                    } else {
                        threadAdapter.addThreads(threads);
                    }
                    allThreads.addAll(threads);
                    updateStickyThreads();
                    binding.tvEmpty.setVisibility(View.GONE);
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    isLoading = false;
                    if (page == 1 && allThreads.isEmpty()) {
                        binding.tvEmpty.setVisibility(View.VISIBLE);
                    }
                });
            }
        }).start();
    }

    private void updateStickyThreads() {
        if (stickyThreadsContainer == null || stickyThreadAdapter == null) return;
        boolean hideRecycled = com.forum.MT.ui.widget.RecycleFilterManager.isEnabled(this);
        boolean hideClosed = com.forum.MT.ui.widget.ClosedFilterManager.isEnabled(this);
        List<Thread> stickyThreads = new ArrayList<>();
        for (Thread thread : allThreads) {
            if (thread == null || !thread.isSticky()) continue;
            // 置顶区同样遵守「隐藏带回收站的帖子」设置
            if (hideRecycled && thread.isRecycled()) continue;
            if (hideClosed && thread.isClosed()) continue;
            stickyThreads.add(thread);
        }
        stickyThreadAdapter.setItems(stickyThreads);
        stickyThreadsContainer.setVisibility(stickyThreads.isEmpty() ? View.GONE : View.VISIBLE);
        TextView countView = stickyThreadsContainer.findViewById(R.id.tv_sticky_count);
        if (countView != null) countView.setText(stickyThreads.size() + "条");
    }

    private void openThread(Thread thread) {
        if (thread == null || TextUtils.isEmpty(thread.getTid())) return;
        Intent intent = new Intent(this, ThreadDetailActivity.class);
        intent.putExtra("tid", thread.getTid());
        startActivity(intent);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        com.forum.MT.ui.widget.AccentColorManager.setListener(null);
    }
}