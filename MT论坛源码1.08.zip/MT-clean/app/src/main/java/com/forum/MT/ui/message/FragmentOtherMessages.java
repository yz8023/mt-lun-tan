package com.forum.MT.ui.message;
import com.forum.MT.ui.BaseFragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.forum.MT.R;
import com.forum.MT.network.HttpClient;
import com.forum.MT.network.NoticeBadgeManager;
import com.forum.MT.session.UserSessionManager;
import com.forum.MT.ui.space.FriendListActivity;
import com.forum.MT.ui.widget.RainbowBorderHelper;

/**
 * "其它消息" Tab — 子分类列表页
 *
 * 包含 4 个子分类：我的粉丝、坛友互动、系统通知、应用通知。
 * 每个子分类显示角标（相对新增数），点击进入对应详情页。
 *
 * 角标规则与其它 Tab 一致：进入不自动清零，逐条已读减少，"全部已读"一键清零。
 */
public class FragmentOtherMessages extends BaseFragment {

    private TextView badgeFans, badgeInteractive, badgeSystem, badgeApp;
    private MessageViewModel viewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_other_messages, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        badgeFans = view.findViewById(R.id.badge_fans);
        badgeInteractive = view.findViewById(R.id.badge_interactive);
        badgeSystem = view.findViewById(R.id.badge_system);
        badgeApp = view.findViewById(R.id.badge_app);

        // 我的粉丝 → FriendListActivity
        view.findViewById(R.id.card_fans).setOnClickListener(v -> {
            NoticeBadgeManager.markViewed(requireContext(), "follower");
            Intent intent = new Intent(requireContext(), FriendListActivity.class);
            intent.putExtra("mode", "followers");
            startActivity(intent);
        });

        // 坛友互动 → NoticeDetailActivity
        view.findViewById(R.id.card_interactive).setOnClickListener(v ->
                openNativeDetail("interactive", "坛友互动"));

        // 系统通知 → NoticeDetailActivity
        view.findViewById(R.id.card_system).setOnClickListener(v ->
                openNativeDetail("system", "系统通知"));

        // 应用通知 → NoticeDetailActivity
        view.findViewById(R.id.card_app).setOnClickListener(v ->
                openNativeDetail("app", "应用通知"));

        // 应用统一卡片边框（与通知列表、私信列表一致）
        RainbowBorderHelper.applyToCardViews(view, requireContext());

        // 获取 ViewModel（从父 Fragment 或 Activity）
        if (getParentFragment() instanceof MessageFragment) {
            viewModel = ((MessageFragment) getParentFragment()).getViewModel();
        } else if (getActivity() != null) {
            viewModel = new ViewModelProvider(requireActivity()).get(MessageViewModel.class);
        }

        // 刷新角标
        refreshBadges();

        // 后台加载各分类角标数据
        if (viewModel != null) {
            viewModel.getOtherMessagesBadgesUpdated().observe(getViewLifecycleOwner(), value -> {
                refreshBadges();
                if (getParentFragment() instanceof MessageFragment) {
                    ((MessageFragment) getParentFragment()).updateTabBadges();
                }
            });
            viewModel.loadOtherMessagesBadges();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // 从详情页返回时刷新角标
        refreshBadges();
        if (viewModel != null) {
            viewModel.loadOtherMessagesBadges();
        }
    }

    private void openNativeDetail(String viewType, String title) {
        String url = HttpClient.BASE_URL + "home.php?mod=space&do=notice&view=" + viewType;
        Intent intent = new Intent(requireContext(), NoticeDetailActivity.class);
        intent.putExtra("url", url);
        intent.putExtra(NoticeDetailActivity.EXTRA_VIEW_TYPE, viewType);
        intent.putExtra(NoticeDetailActivity.EXTRA_TITLE, title);
        startActivity(intent);
    }

    /** 从 NoticeBadgeManager 读取各子分类新增数，更新角标。 */
    public void refreshBadges() {
        if (getActivity() == null) return;
        updateBadge(badgeFans, NoticeBadgeManager.getNewCount(requireContext(), "follower"));
        String[] interactiveTypes = {"poke", "friend", "click", "wall", "comment", "share"};
        int interactiveTotal = NoticeBadgeManager.getInteractiveAggregate(
                requireContext(), interactiveTypes);
        NoticeBadgeManager.setNewCount(requireContext(), "interactive", interactiveTotal);
        updateBadge(badgeInteractive, interactiveTotal);
        updateBadge(badgeSystem, NoticeBadgeManager.getNewCount(requireContext(), "system"));
        updateBadge(badgeApp, NoticeBadgeManager.getNewCount(requireContext(), "app"));
    }

    private void updateBadge(TextView badgeView, int count) {
        if (badgeView == null) return;
        if (count > 0) {
            badgeView.setText(count > 99 ? "99+" : String.valueOf(count));
            badgeView.setVisibility(View.VISIBLE);
        } else {
            badgeView.setVisibility(View.GONE);
        }
    }

    private String getUid() {
        String uid = UserSessionManager.getInstance().getUid(requireContext());
        return TextUtils.isEmpty(uid) ? "0" : uid;
    }
}
