package com.forum.MT.model;

/**
 * 消息Tab枚举 - 对应官方APK的4个Tab
 */
public enum MessageTab {
    PRIVATE_MESSAGE("私信", 0),
    AT_ME("@我的", 1),
    MY_POST("我的帖子", 2),
    OTHER_MESSAGES("其它消息", 3);

    private final String displayName;
    private final int index;

    MessageTab(String displayName, int index) {
        this.displayName = displayName;
        this.index = index;
    }

    public String getDisplayName() { return displayName; }
    public int getIndex() { return index; }

    public static MessageTab fromIndex(int index) {
        for (MessageTab tab : values()) {
            if (tab.index == index) return tab;
        }
        return PRIVATE_MESSAGE;
    }
}