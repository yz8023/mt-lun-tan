package com.forum.MT.session;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 未读消息高亮显示开关管理器。
 * 开启后，消息列表中未读条目会以更醒目的方式高亮显示。
 */
public final class UnreadHighlightManager {

    private static final String PREF_NAME = "unread_highlight_pref";
    private static final String KEY_ENABLED = "unread_highlight_enabled";
    private static final boolean DEFAULT_ENABLED = true;

    private UnreadHighlightManager() {}

    public static boolean isEnabled(Context context) {
        if (context == null) return DEFAULT_ENABLED;
        return context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, DEFAULT_ENABLED);
    }

    public static void setEnabled(Context context, boolean enabled) {
        if (context == null) return;
        context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ENABLED, enabled)
                .apply();
    }
}