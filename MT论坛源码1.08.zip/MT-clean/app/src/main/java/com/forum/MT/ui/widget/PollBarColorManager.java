package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 投票进度条颜色管理。
 *
 * 控制帖子详情页投票选项进度条的填充颜色。
 * 颜色为 0 时表示使用默认色（网页端颜色或默认粉色 #FF4081）。
 *
 * 偏好键：
 *   poll_bar_color (int, 0 表示默认)
 */
public final class PollBarColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_POLL_BAR_COLOR = "poll_bar_color";

    /** 默认投票进度条颜色（与 R.color.primary 一致） */
    public static final int DEFAULT_COLOR = 0xFFFF4081;

    private static volatile int customColor = 0;

    private PollBarColorManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        customColor = prefs.getInt(KEY_POLL_BAR_COLOR, 0);
    }

    public static int getCustomColor() { return customColor; }

    /** 设置自定义颜色，0 表示恢复默认。持久化 + 回调刷新。 */
    public static void setCustomColor(Context context, int color) {
        customColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_POLL_BAR_COLOR, color).apply();
        }
        notifyChanged();
    }

    /** 当前应使用的投票进度条颜色。 */
    public static int resolveColor() {
        return customColor != 0 ? customColor : DEFAULT_COLOR;
    }

    /** 变更回调。 */
    public interface OnPollBarColorChangedListener {
        void onPollBarColorChanged();
    }

    private static volatile OnPollBarColorChangedListener listener;

    public static void setListener(OnPollBarColorChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnPollBarColorChangedListener l = listener;
        if (l != null) l.onPollBarColorChanged();
    }
}
