package com.forum.MT.ui;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.forum.MT.ui.widget.BackgroundColorManager;

/**
 * 全局 Fragment 基类。
 * 在 view 创建后统一应用自定义背景颜色。
 */
public abstract class BaseFragment extends Fragment {

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        BackgroundColorManager.apply(view);
    }
}