package com.forum.MT.ui.space;
import com.forum.MT.ui.BaseActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.forum.MT.BuildConfig;
import com.forum.MT.R;
import com.forum.MT.databinding.ActivityAboutSettingsBinding;
import com.forum.MT.network.UpdateChecker;
import com.forum.MT.ui.widget.RainbowBorderHelper;

/**
 * 关于子设置页 — 应用信息、检测更新、开发者
 */
public class AboutSettingsActivity extends BaseActivity {

    private ActivityAboutSettingsBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAboutSettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        RainbowBorderHelper.applyToCardViews(binding.getRoot(), this);

        binding.tvVersion.setText(BuildConfig.VERSION_NAME);

        binding.toolbar.setNavigationOnClickListener(v -> finish());
        binding.toolbar.setNavigationIcon(null);

        // 自动检测更新开关
        boolean autoCheckEnabled = getSharedPreferences("app_settings", MODE_PRIVATE)
                .getBoolean("auto_check_update", true);
        binding.switchAutoCheckUpdate.setChecked(autoCheckEnabled);
        binding.switchAutoCheckUpdate.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences("app_settings", MODE_PRIVATE)
                        .edit().putBoolean("auto_check_update", isChecked).apply());

        // 检测更新：自动模式下进入即检查，手动模式下需点击
        binding.layoutCheckUpdate.setOnClickListener(v -> checkForUpdate());
        if (autoCheckEnabled) {
            checkForUpdate();
        } else {
            binding.tvUpdateStatus.setText("点击检查");
        }

        // 开发者：点击头像唤起QQ
        binding.authorAvatar.setOnClickListener(v -> openAuthorQq());
        Glide.with(this)
                .load("https://q1.qlogo.cn/g?b=qq&nk=466656897&s=640")
                .placeholder(R.drawable.ic_account)
                .error(R.drawable.ic_account)
                .circleCrop()
                .into(binding.authorAvatar);

        // 二次开发者：固定为 UID 139562（尘缘梦），不随登录账号变化
        binding.cardSecondaryDev.setOnClickListener(v -> {
            Intent intent = new Intent(this, UserProfileActivity.class);
            intent.putExtra("uid", "139562");
            startActivity(intent);
        });
        // 加载二次开发者头像（固定 UID）
        Glide.with(this)
                .load("https://bbs.binmt.cc/uc_server/avatar.php?uid=139562&size=middle")
                .placeholder(R.drawable.ic_account)
                .error(R.drawable.ic_account)
                .circleCrop()
                .into(binding.secondaryDevAvatar);
        // 用户名固定显示"尘缘梦"（UID 139562），不随登录账号变化
        binding.secondaryDevName.setText("尘缘梦");
        // 方案B：异步获取该UID当前最新用户名（7天缓存），失败时保持上面的回退值
        loadSecondaryDevName();
    }

    /** 二次开发者 UID */
    private static final String SECONDARY_DEV_UID = "139562";
    private static final String SECONDARY_DEV_FALLBACK = "尘缘梦";
    private static final String PREFS_SECONDARY_DEV = "secondary_dev_name";
    private static final String PREFS_SECONDARY_DEV_TS = "secondary_dev_name_ts";
    private static final long CACHE_MS = 7L * 24 * 3600 * 1000; // 7天

    /**
     * 方案B：动态获取 UID 139562 的最新用户名。
     * 优先读7天缓存；过期则异步请求个人空间页解析 <meta name="keywords"> 或
     * <title> 中的用户名，成功则更新缓存并刷新UI，失败保持回退值"尘缘梦"。
     */
    private void loadSecondaryDevName() {
        try {
            // 1) 读缓存
            android.content.SharedPreferences prefs = getSharedPreferences("app_settings", MODE_PRIVATE);
            String cached = prefs.getString(PREFS_SECONDARY_DEV, null);
            long ts = prefs.getLong(PREFS_SECONDARY_DEV_TS, 0L);
            if (cached != null && !cached.isEmpty() && System.currentTimeMillis() - ts < CACHE_MS) {
                binding.secondaryDevName.setText(cached);
                return;
            }
            // 2) 异步请求解析
            final String url = com.forum.MT.network.HttpClient.BASE_URL
                    + "home.php?mod=space&uid=" + SECONDARY_DEV_UID + "&do=profile";
            java.util.concurrent.Executors.newSingleThreadExecutor().execute(() -> {
                final String name = fetchSecondaryDevName(url);
                runOnUiThread(() -> {
                    if (isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                    if (name != null && !name.isEmpty()) {
                        binding.secondaryDevName.setText(name);
                        getSharedPreferences("app_settings", MODE_PRIVATE)
                                .edit().putString(PREFS_SECONDARY_DEV, name)
                                .putLong(PREFS_SECONDARY_DEV_TS, System.currentTimeMillis()).apply();
                    }
                    // 失败则保持回退值"尘缘梦"
                });
            });
        } catch (Exception ignored) {}
    }

    private String fetchSecondaryDevName(String url) {
        try {
            String html = com.forum.MT.network.HttpClient.getInstance().get(url);
            if (html == null || html.isEmpty()) return null;
            // <meta name="keywords" content="尘缘梦的个人资料" />
            java.util.regex.Matcher km = java.util.regex.Pattern.compile(
                    "<meta name=[\"']keywords[\"'][^>]*content=[\"']([^\"']*?)的个人资料[\"']",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
            if (km.find()) {
                String n = km.group(1).trim();
                if (!n.isEmpty()) return n;
            }
            // 兜底：页面中 <h2 class="fyy">用户名</h2>
            java.util.regex.Matcher hm = java.util.regex.Pattern.compile(
                    "<h2\\s+class=[\"']fyy[\"'][^>]*>([^<]+)</h2>",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
            if (hm.find()) {
                String n = hm.group(1).trim();
                if (!n.isEmpty()) return n;
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void checkForUpdate() {
        binding.tvUpdateStatus.setText("检查中…");
        binding.layoutCheckUpdate.setEnabled(false);
        UpdateChecker.check(this, result -> {
            if (isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
            binding.layoutCheckUpdate.setEnabled(true);
            if (!result.success) {
                binding.tvUpdateStatus.setText("检查失败");
                return;
            }
            if (result.hasUpdate) {
                binding.tvUpdateStatus.setText("有新版本");
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("发现新版本")
                        .setMessage("更新文件夹检测到新内容，是否打开下载页面？")
                        .setNegativeButton("稍后", null)
                        .setPositiveButton("立即更新", (dialog, which) -> openUpdatePage())
                        .show();
            } else {
                binding.tvUpdateStatus.setText(result.firstCheck ? "已记录" : "已是最新");
            }
        });
    }

    private void openUpdatePage() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(UpdateChecker.UPDATE_URL)));
        } catch (Exception e) {
            Toast.makeText(this, "没有可用的浏览器", Toast.LENGTH_SHORT).show();
        }
    }

    private void openAuthorQq() {
        final String qq = "466656897";
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin="
                            + qq + "&card_type=person&source=qrcode"));
            startActivity(intent);
        } catch (Exception ignored) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://qm.qq.com/cgi-bin/qm/qr?k=" + qq)));
            } catch (Exception e) {
                Toast.makeText(this, "未找到可用的QQ客户端", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
