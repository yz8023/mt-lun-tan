package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/**
 * 全局强调色管理。
 *
 * 控制所有「选中/高亮状态文字」的颜色（首页分类 tab、TabLayout 选中项与指示条、
 * 「全部已读」链接、通知未读高亮等）。底部导航栏选中色由 {@link BottomNavBarColorManager}
 * 单独管理。
 *
 * 颜色为 0 时表示使用默认强调色（与主题主色 #FF4081 一致）。
 *
 * 偏好键：
 *   accent_color (int, 0 表示默认强调色 #FF4081)
 */
public final class AccentColorManager {

    public static final String PREF_NAME = "app_settings";
    public static final String KEY_ACCENT = "accent_color";

    /** 默认强调色（与 R.color.primary 一致） */
    public static final int DEFAULT_ACCENT = 0xFF53BCF5;

    private static volatile int accentColor = 0;

    private AccentColorManager() {}

    /** 应用启动时调用，从磁盘恢复设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        accentColor = prefs.getInt(KEY_ACCENT, 0);
    }

    public static int getCustomColor() { return accentColor; }

    /** 设置自定义强调色，0 表示恢复默认。持久化 + 回调刷新。 */
    public static void setCustomColor(Context context, int color) {
        accentColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_ACCENT, color).apply();
        }
        notifyChanged();
    }

    /** 当前应使用的强调色。 */
    public static int resolveAccentColor() {
        return accentColor != 0 ? accentColor : DEFAULT_ACCENT;
    }

    /** 变更回调（各页面注册用于实时刷新高亮文字）。 */
    public interface OnAccentColorChangedListener {
        void onAccentColorChanged();
    }

    private static volatile OnAccentColorChangedListener listener;

    /** 注册强调色变更回调。 */
    public static void setListener(OnAccentColorChangedListener l) {
        listener = l;
    }

    private static void notifyChanged() {
        OnAccentColorChangedListener l = listener;
        if (l != null) l.onAccentColorChanged();
    }
}