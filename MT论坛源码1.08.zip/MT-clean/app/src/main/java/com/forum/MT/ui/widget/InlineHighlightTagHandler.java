package com.forum.MT.ui.widget;

import android.text.Editable;
import android.text.Html;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;

import org.xml.sax.XMLReader;

/**
 * 自定义 TagHandler：渲染两种行内样式
 * <ul>
 *   <li><b>&lt;hl&gt;</b> 行内高亮（发帖者用 background-color 实现的代码/名词底色）——背景色 + 文字色可自定义</li>
 *   <li><b>&lt;code&gt;</b> 行内代码（Discuz [code] 内联）——背景色 + 文字色 + 等宽字体可自定义</li>
 * </ul>
 * 颜色通过构造传入（由调用方从 InlineHighlightManager / InlineCodeManager 读取当前配置），
 * 随用户设置即时生效。
 */
public class InlineHighlightTagHandler implements Html.TagHandler {

    private final int mBgColor;
    private final int mTextColor;
    private final boolean mEnabled;

    /** 行内代码样式（<code> 专用） */
    private final int mCodeBgColor;
    private final int mCodeTextColor;
    private final boolean mCodeEnabled;

    /** 高亮起始偏移栈（支持嵌套 <hl>） */
    private final java.util.ArrayList<Integer> mStartStack = new java.util.ArrayList<>();
    /** code 起始偏移栈（支持嵌套 <code>） */
    private final java.util.ArrayList<Integer> mCodeStartStack = new java.util.ArrayList<>();

    public InlineHighlightTagHandler(int bgColor, int textColor, boolean enabled) {
        this(bgColor, textColor, enabled,
                InlineCodeManager.DEFAULT_BG_COLOR, InlineCodeManager.DEFAULT_TEXT_COLOR, true);
    }

    public InlineHighlightTagHandler(int bgColor, int textColor, boolean enabled,
                                     int codeBgColor, int codeTextColor, boolean codeEnabled) {
        mBgColor = bgColor;
        mTextColor = textColor;
        mEnabled = enabled;
        mCodeBgColor = codeBgColor;
        mCodeTextColor = codeTextColor;
        mCodeEnabled = codeEnabled;
    }

    @Override
    public void handleTag(boolean opening, String tag, Editable output, XMLReader xmlReader) {
        if ("hl".equalsIgnoreCase(tag)) {
            handleHl(opening, output);
        } else if ("code".equalsIgnoreCase(tag)) {
            handleCode(opening, output);
        }
    }

    private void handleHl(boolean opening, Editable output) {
        if (opening) {
            mStartStack.add(output.length());
            return;
        }

        // 闭合 </hl>
        if (mStartStack.isEmpty()) return;
        int start = mStartStack.remove(mStartStack.size() - 1);
        int end = output.length();

        // 修剪首尾空白
        CharSequence text = output.subSequence(start, end);
        int trimStart = 0;
        int trimEnd = text.length();
        while (trimStart < trimEnd && Character.isWhitespace(text.charAt(trimStart))) trimStart++;
        while (trimEnd > trimStart && Character.isWhitespace(text.charAt(trimEnd - 1))) trimEnd--;
        start += trimStart;
        end = start + (trimEnd - trimStart);

        if (start >= end) return;
        if (!mEnabled) return;

        output.setSpan(new BackgroundColorSpan(mBgColor), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        output.setSpan(new ForegroundColorSpan(mTextColor), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void handleCode(boolean opening, Editable output) {
        if (opening) {
            mCodeStartStack.add(output.length());
            return;
        }

        // 闭合 </code>
        if (mCodeStartStack.isEmpty()) return;
        int start = mCodeStartStack.remove(mCodeStartStack.size() - 1);
        int end = output.length();

        CharSequence text = output.subSequence(start, end);
        int trimStart = 0;
        int trimEnd = text.length();
        while (trimStart < trimEnd && Character.isWhitespace(text.charAt(trimStart))) trimStart++;
        while (trimEnd > trimStart && Character.isWhitespace(text.charAt(trimEnd - 1))) trimEnd--;
        start += trimStart;
        end = start + (trimEnd - trimStart);

        if (start >= end) return;
        if (!mCodeEnabled) return;

        output.setSpan(new BackgroundColorSpan(mCodeBgColor), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        output.setSpan(new ForegroundColorSpan(mCodeTextColor), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        output.setSpan(new android.text.style.TypefaceSpan("monospace"), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
}