package com.forum.MT.ui.widget;

import android.content.Context;
import android.content.SharedPreferences;

import com.forum.MT.ui.detail.TableBitmapRenderer;

/**
 * 管理表格（正文表格与引用卡片内嵌表格）的自定义配色：
 * 边框色、表头背景色、单元格背景色、文字颜色。
 * 颜色为 0 表示使用默认值。
 */
public class TableColorManager {

    private static final String PREFS_NAME = "mt_forum_prefs";

    private static final String KEY_TABLE_BORDER_COLOR = "table_border_color";
    private static final String KEY_TABLE_HEADER_BG    = "table_header_bg";
    private static final String KEY_TABLE_CELL_BG      = "table_cell_bg";
    private static final String KEY_TABLE_TEXT_COLOR   = "table_text_color";

    private TableColorManager() {}

    /** 当前应使用的表格配色（已解析默认值） */
    public static TableBitmapRenderer.TableColors resolveColors(Context context) {
        return new TableBitmapRenderer.TableColors(
                resolveBorderColor(context),
                resolveHeaderBg(context),
                resolveCellBg(context),
                resolveTextColor(context));
    }

    // ==================== 边框色 ====================

    public static int getBorderColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_TABLE_BORDER_COLOR, 0);
    }

    public static int resolveBorderColor(Context context) {
        int color = getBorderColor(context);
        return color != 0 ? color : 0xFFBDBDBD;
    }

    public static void setBorderColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_TABLE_BORDER_COLOR, color).apply();
    }

    // ==================== 表头背景 ====================

    public static int getHeaderBg(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_TABLE_HEADER_BG, 0);
    }

    public static int resolveHeaderBg(Context context) {
        int color = getHeaderBg(context);
        return color != 0 ? color : 0xFFF5F5F5;
    }

    public static void setHeaderBg(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_TABLE_HEADER_BG, color).apply();
    }

    // ==================== 单元格背景 ====================

    public static int getCellBg(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_TABLE_CELL_BG, 0);
    }

    public static int resolveCellBg(Context context) {
        int color = getCellBg(context);
        return color != 0 ? color : 0xFFFFFFFF;
    }

    public static void setCellBg(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_TABLE_CELL_BG, color).apply();
    }

    // ==================== 文字颜色 ====================

    public static int getTextColor(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getInt(KEY_TABLE_TEXT_COLOR, 0);
    }

    public static int resolveTextColor(Context context) {
        int color = getTextColor(context);
        return color != 0 ? color : 0xFF000000;
    }

    public static void setTextColor(Context context, int color) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_TABLE_TEXT_COLOR, color).apply();
    }
}