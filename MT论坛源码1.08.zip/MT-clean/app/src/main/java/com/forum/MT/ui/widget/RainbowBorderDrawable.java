package com.forum.MT.ui.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.animation.LinearInterpolator;

import android.content.SharedPreferences;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 彩色流水灯边框：渐变色沿边框流动，同时进行轻微呼吸变化。
 * 通过全局开关统一控制所有已创建和后续创建的实例。
 */
public class RainbowBorderDrawable extends Drawable {
    public static final String PREF_NAME = "app_settings";
    public static final String KEY_GLOBAL_ENABLED = "rainbow_border_enabled";
    public static final String KEY_CUSTOM_COLOR = "rainbow_custom_color";
    public static final int CUSTOM_COLOR_NONE = 0; // 0 表示使用默认彩虹色

    private static volatile boolean globalEnabled = false;
    private static volatile int customColor = 0xFF707646;
    private static final Set<RainbowBorderDrawable> INSTANCES =
            Collections.newSetFromMap(new WeakHashMap<>());

    /** 呼吸动画监听器，用于同步外部视图（如未读高亮色条）的缩放。 */
    public interface BreathListener {
        void onBreath(float breath);
    }
    private static final List<BreathListener> BREATH_LISTENERS = new CopyOnWriteArrayList<>();

    public static void addBreathListener(BreathListener l) {
        if (l != null) BREATH_LISTENERS.add(l);
    }

    public static void removeBreathListener(BreathListener l) {
        BREATH_LISTENERS.remove(l);
    }

    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Matrix shaderMatrix = new Matrix();
    private int fillColor;
    private final float radius;
    private final float density;
    private float phase;
    private float breath = 0.5f;
    private ValueAnimator animator;
    private boolean borderOnly = false;

    private static final int[] COLORS = {
            Color.rgb(255, 82, 139), Color.rgb(255, 193, 79),
            Color.rgb(83, 210, 164), Color.rgb(79, 164, 255),
            Color.rgb(173, 104, 255), Color.rgb(255, 82, 139)
    };

    public RainbowBorderDrawable(int fillColor, float radius, float density) {
        this(fillColor, radius, density, false);
    }

    public RainbowBorderDrawable(int fillColor, float radius, float density, boolean borderOnly) {
        this.fillColor = fillColor;
        this.radius = radius;
        this.density = density;
        this.borderOnly = borderOnly;
        fillPaint.setColor(fillColor);
        fillPaint.setStyle(Paint.Style.FILL);
        strokePaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStyle(Paint.Style.STROKE);
        synchronized (INSTANCES) {
            INSTANCES.add(this);
        }
        startAnimation();
    }

    /** 应用启动时调用，默认开启，且从磁盘恢复用户设置。 */
    public static void initialize(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        globalEnabled = prefs.getBoolean(KEY_GLOBAL_ENABLED, false);
        customColor = prefs.getInt(KEY_CUSTOM_COLOR, 0xFF707646);
    }

    /** 获取当前自定义颜色，0 表示使用默认彩虹色。 */
    public static int getCustomColor() {
        return customColor;
    }

    /** 设置自定义颜色，0 表示恢复默认彩虹色。持久化并刷新所有实例。 */
    public static void setCustomColor(Context context, int color) {
        customColor = color;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_CUSTOM_COLOR, color).apply();
        }
        synchronized (INSTANCES) {
            for (RainbowBorderDrawable drawable : INSTANCES) {
                if (drawable == null) continue;
                drawable.updateShader();
                drawable.invalidateSelf();
            }
        }
    }

    public static boolean isGloballyEnabled() {
        return globalEnabled;
    }

    public static void setGlobalEnabled(Context context, boolean enabled) {
        globalEnabled = enabled;
        if (context != null) {
            context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_GLOBAL_ENABLED, enabled).apply();
        }
        synchronized (INSTANCES) {
            for (RainbowBorderDrawable drawable : INSTANCES) {
                if (drawable == null || drawable.animator == null) continue;
                if (enabled) {
                    if (drawable.isVisible()) {
                        if (!drawable.animator.isStarted()) drawable.animator.start();
                        else if (drawable.animator.isPaused()) drawable.animator.resume();
                    }
                } else {
                    if (drawable.animator.isStarted()) drawable.animator.pause();
                    drawable.invalidateSelf();
                }
            }
        }
    }

    private void startAnimation() {
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(2600L);
        animator.setInterpolator(new LinearInterpolator());
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.addUpdateListener(animation -> {
            phase = animation.getAnimatedFraction();
            breath = 0.5f + 0.5f * (float) Math.sin(phase * Math.PI * 2.0);
            for (BreathListener l : BREATH_LISTENERS) {
                l.onBreath(breath);
            }
            invalidateSelf();
        });
        if (globalEnabled) animator.start();
    }

    @Override
    protected void onBoundsChange(android.graphics.Rect bounds) {
        super.onBoundsChange(bounds);
        rect.set(bounds.left + 2.5f * density, bounds.top + 2.5f * density,
                bounds.right - 2.5f * density, bounds.bottom - 2.5f * density);
        updateShader();
    }

    private void updateShader() {
        if (rect.width() <= 0 || rect.height() <= 0) return;
        float length = Math.max(rect.width(), rect.height()) * 2f;
        int[] colors = COLORS;
        if (customColor != CUSTOM_COLOR_NONE) {
            // 根据自定义颜色生成亮/暗变体，形成单色渐变流动效果
            int lighter = lightenColor(customColor, 0.3f);
            int darker = darkenColor(customColor, 0.3f);
            colors = new int[]{customColor, lighter, customColor, darker, customColor};
        }
        strokePaint.setShader(new LinearGradient(0, 0, length, length, colors, null, Shader.TileMode.MIRROR));
        glowPaint.setShader(strokePaint.getShader());
    }

    private static int lightenColor(int color, float factor) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        r = Math.min(255, (int) (r + (255 - r) * factor));
        g = Math.min(255, (int) (g + (255 - g) * factor));
        b = Math.min(255, (int) (b + (255 - b) * factor));
        return Color.rgb(r, g, b);
    }

    private static int darkenColor(int color, float factor) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        r = Math.max(0, (int) (r * (1 - factor)));
        g = Math.max(0, (int) (g * (1 - factor)));
        b = Math.max(0, (int) (b * (1 - factor)));
        return Color.rgb(r, g, b);
    }

    @Override
    public void draw(Canvas canvas) {
        if (rect.width() <= 0 || rect.height() <= 0) return;
        if (!borderOnly) {
            fillPaint.setColor(fillColor);
            canvas.drawRoundRect(rect, radius, radius, fillPaint);
        }
        if (!globalEnabled) return;

        float angle = phase * 360f;
        shaderMatrix.setRotate(angle, rect.centerX(), rect.centerY());
        Shader shader = strokePaint.getShader();
        if (shader != null) shader.setLocalMatrix(shaderMatrix);

        glowPaint.setAlpha((int) (35f + 75f * breath));
        glowPaint.setStrokeWidth((2.8f + 2.2f * breath) * density);
        canvas.drawRoundRect(rect, radius, radius, glowPaint);

        strokePaint.setAlpha(210 + (int) (45f * breath));
        strokePaint.setStrokeWidth((1.2f + 0.9f * breath) * density);
        canvas.drawRoundRect(rect, radius, radius, strokePaint);
    }

    @Override public void setAlpha(int alpha) {
        fillPaint.setAlpha(alpha);
        strokePaint.setAlpha(alpha);
        glowPaint.setAlpha(alpha);
    }

    @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) {
        fillPaint.setColorFilter(colorFilter);
        strokePaint.setColorFilter(colorFilter);
        glowPaint.setColorFilter(colorFilter);
    }

    /** 动态修改填充色（导航栏背景色变化时使用）。 */
    public void setFillColor(int color) {
        this.fillColor = color;
        fillPaint.setColor(color);
        invalidateSelf();
    }

    @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    @Override protected boolean onLevelChange(int level) { invalidateSelf(); return true; }

    @Override public boolean setVisible(boolean visible, boolean restart) {
        boolean changed = super.setVisible(visible, restart);
        if (animator == null || !globalEnabled) return changed;
        if (visible) {
            if (restart) animator.start();
            else if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                if (animator.isPaused()) animator.resume();
                else if (!animator.isStarted()) animator.start();
            } else animator.start();
        } else if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            animator.pause();
        }
        return changed;
    }
}