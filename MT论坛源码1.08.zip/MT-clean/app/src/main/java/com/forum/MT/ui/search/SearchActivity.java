package com.forum.MT.ui.search;
import com.forum.MT.ui.BaseActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.forum.MT.R;
import com.forum.MT.adapter.ThreadAdapter;
import com.forum.MT.model.Thread;
import com.forum.MT.network.ForumParser;
import com.forum.MT.network.HttpClient;
import com.forum.MT.ui.detail.ThreadDetailActivity;
import com.forum.MT.ui.space.UserProfileActivity;

import java.util.ArrayList;
import java.util.List;


/**
 * 搜索结果页面（首页即显示，剩余页后台增量追加，支持排序切换）
 */
public class SearchActivity extends BaseActivity {

    private Toolbar toolbar;
    private EditText etSearch;
    private ProgressBar progressBar;
    private ProgressBar progressLoadMore;
    private RecyclerView recyclerView;
    private TextView tvEmpty;
    private TextView tvError;
    private com.google.android.material.button.MaterialButton btnSearch;
    private ThreadAdapter threadAdapter;

    // 排序相关
    private LinearLayout layoutSortBar;
    private TextView btnSortLastpost, btnSortDateline, btnSortReplies;
    private String currentSortBy = "lastpost"; // lastpost / dateline / replies
    private String pendingKeyword = null;
    private final Handler searchHandler = new Handler(Looper.getMainLooper());
    private int searchGeneration = 0;
    private static final long SEARCH_TIMEOUT_MS = 15000L;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        toolbar = findViewById(R.id.toolbar);
        etSearch = findViewById(R.id.et_search);
        progressBar = findViewById(R.id.progress_bar);
        progressLoadMore = findViewById(R.id.progress_load_more);
        recyclerView = findViewById(R.id.recycler_view);
        tvEmpty = findViewById(R.id.tv_empty);
        tvError = findViewById(R.id.tv_error);
        layoutSortBar = findViewById(R.id.layout_sort_bar);
        btnSortLastpost = findViewById(R.id.btn_sort_lastpost);
        btnSortDateline = findViewById(R.id.btn_sort_dateline);
        btnSortReplies = findViewById(R.id.btn_sort_replies);

        // === Toolbar ===
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
        toolbar.setNavigationIcon(null);

        // === RecyclerView ===
        threadAdapter = new ThreadAdapter(this);
        ThreadAdapter.registerColorChangeListener(threadAdapter);
        threadAdapter.setOnItemClickListener((thread, position) -> {
            Intent intent = new Intent(this, ThreadDetailActivity.class);
            intent.putExtra("tid", thread.getTid());
            startActivity(intent);
        });
        threadAdapter.setOnUserClickListener(thread -> {
            if (thread == null || TextUtils.isEmpty(thread.getAuthorUid())) return;
            Intent intent = new Intent(this, UserProfileActivity.class);
            intent.putExtra("uid", thread.getAuthorUid());
            intent.putExtra("username", thread.getAuthor());
            startActivity(intent);
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(threadAdapter);

        // === 搜索按钮 ===
        btnSearch = findViewById(R.id.btn_search);
        btnSearch.setOnClickListener(v -> performSearch());

        // === 键盘搜索动作 ===
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch();
                return true;
            }
            return false;
        });

        // === 排序切换 ===
        btnSortLastpost.setOnClickListener(v -> switchSort("lastpost"));
        btnSortDateline.setOnClickListener(v -> switchSort("dateline"));
        btnSortReplies.setOnClickListener(v -> switchSort("replies"));

        // === Intent 携带关键词自动搜索 ===
        String keyword = getIntent().getStringExtra("keyword");
        if (!TextUtils.isEmpty(keyword)) {
            etSearch.setText(keyword);
            performSearch();
        }

        // === 应用搜索页自定义颜色 ===
        applySearchPageColors();
    }

    /**
     * 切换排序方式
     */
    private void switchSort(String orderby) {
        if (orderby.equals(currentSortBy)) return;
        currentSortBy = orderby;
        updateSortChips();
        if (!TextUtils.isEmpty(pendingKeyword)) {
            fetchAllResults(pendingKeyword, currentSortBy);
        }
    }

    /**
     * 更新排序按钮的激活/非激活样式
     */
    private void updateSortChips() {
        int accent = com.forum.MT.ui.widget.AccentColorManager.resolveAccentColor();
        android.content.res.ColorStateList accentTint =
                android.content.res.ColorStateList.valueOf(accent);

        btnSortLastpost.setBackgroundResource(
                "lastpost".equals(currentSortBy) ? R.drawable.chip_active_bg : R.drawable.chip_inactive_bg);
        btnSortLastpost.setBackgroundTintList(
                "lastpost".equals(currentSortBy) ? accentTint : null);
        btnSortLastpost.setTextColor(ContextCompat.getColor(this,
                "lastpost".equals(currentSortBy) ? R.color.text_white : R.color.text_hint));

        btnSortDateline.setBackgroundResource(
                "dateline".equals(currentSortBy) ? R.drawable.chip_active_bg : R.drawable.chip_inactive_bg);
        btnSortDateline.setBackgroundTintList(
                "dateline".equals(currentSortBy) ? accentTint : null);
        btnSortDateline.setTextColor(ContextCompat.getColor(this,
                "dateline".equals(currentSortBy) ? R.color.text_white : R.color.text_hint));

        btnSortReplies.setBackgroundResource(
                "replies".equals(currentSortBy) ? R.drawable.chip_active_bg : R.drawable.chip_inactive_bg);
        btnSortReplies.setBackgroundTintList(
                "replies".equals(currentSortBy) ? accentTint : null);
        btnSortReplies.setTextColor(ContextCompat.getColor(this,
                "replies".equals(currentSortBy) ? R.color.text_white : R.color.text_hint));
    }

    private void performSearch() {
        String keyword = etSearch.getText().toString().trim();
        if (TextUtils.isEmpty(keyword)) {
            etSearch.setError(getString(R.string.search_hint));
            return;
        }
        threadAdapter.setThreadList(null);
        currentSortBy = "lastpost";
        updateSortChips();
        layoutSortBar.setVisibility(View.VISIBLE);
        fetchAllResults(keyword, currentSortBy);
    }

    /**
     * 搜索并增量显示结果：第1页立即显示，剩余页后台追加。
     * @param keyword 搜索关键词
     * @param orderby 排序方式：lastpost/dateline/replies
     */
    private void fetchAllResults(String keyword, String orderby) {
        pendingKeyword = keyword;
        final int requestGeneration = ++searchGeneration;

        // 15秒超时：仅作用于第1页加载；第1页显示后超时自动取消。
        final Runnable timeoutAction = () -> {
            if (requestGeneration != searchGeneration || isFinishing()
                    || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
            searchGeneration++;
            progressBar.setVisibility(View.GONE);
            progressLoadMore.setVisibility(View.GONE);
            tvError.setText(R.string.search_failed);
            tvError.setVisibility(View.VISIBLE);
        };

        if (!HttpClient.getInstance().isLoggedIn()) {
            progressBar.setVisibility(View.GONE);
            tvError.setText(R.string.search_login_required);
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        progressLoadMore.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        tvEmpty.setVisibility(View.GONE);
        tvError.setVisibility(View.GONE);
        searchHandler.postDelayed(timeoutAction, SEARCH_TIMEOUT_MS);

        new java.lang.Thread(() -> {
            try {
                // === 1. 抓第1页，提取 searchid & totalPages ===
                String htmlP1 = HttpClient.getInstance().get(ForumParser.getSearchUrl(keyword, 1, orderby));
                List<Thread> allResults = ForumParser.parseSearchResults(htmlP1);
                if (allResults == null) allResults = new ArrayList<>();

                String searchId = ForumParser.extractSearchId(htmlP1);
                int totalPages = ForumParser.parseSearchTotalPages(htmlP1);

                // === 2. 立即显示第1页结果，隐藏主进度条 ===
                final List<Thread> firstPageResults = new ArrayList<>(allResults);
                runOnUiThread(() -> {
                    if (requestGeneration != searchGeneration || isFinishing()
                            || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                    searchHandler.removeCallbacks(timeoutAction);
                    progressBar.setVisibility(View.GONE);
                    if (!firstPageResults.isEmpty()) {
                        threadAdapter.setThreadList(firstPageResults);
                        recyclerView.setVisibility(View.VISIBLE);
                    } else {
                        tvEmpty.setText(R.string.search_no_results);
                        tvEmpty.setVisibility(View.VISIBLE);
                    }
                });

                // 第1页为空或只有1页时，不需要继续加载
                if (searchId == null || totalPages <= 1 || allResults.isEmpty()) return;

                // === 3. 后台逐页抓取剩余结果，增量追加到列表 ===
                runOnUiThread(() -> {
                    if (requestGeneration != searchGeneration) return;
                    progressLoadMore.setVisibility(View.VISIBLE);
                });

                for (int page = 2; page <= totalPages; page++) {
                    // 新搜索发起或活动销毁时，停止后台翻页
                    if (requestGeneration != searchGeneration) break;
                    try {
                        String html = HttpClient.getInstance().get(
                                ForumParser.getSearchPageUrl(searchId, page, orderby));
                        List<Thread> pageResults = ForumParser.parseSearchResults(html);
                        if (pageResults != null && !pageResults.isEmpty()) {
                            List<Thread> newItems = new ArrayList<>();
                            for (Thread t : pageResults) {
                                boolean dup = false;
                                for (Thread existing : allResults) {
                                    if (existing.getTid() != null && existing.getTid().equals(t.getTid())) {
                                        dup = true;
                                        break;
                                    }
                                }
                                if (!dup) {
                                    allResults.add(t);
                                    newItems.add(t);
                                }
                            }
                            if (!newItems.isEmpty()) {
                                runOnUiThread(() -> {
                                    if (requestGeneration != searchGeneration || isFinishing()
                                            || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                                    threadAdapter.addThreads(newItems);
                                });
                            }
                        }
                    } catch (Exception ignored) {
                        // 单页失败不重试，保留已成功解析的结果
                    }
                }

                // 后台翻页结束，隐藏底部加载指示器
                runOnUiThread(() -> {
                    if (requestGeneration != searchGeneration) return;
                    progressLoadMore.setVisibility(View.GONE);
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (requestGeneration != searchGeneration || isFinishing()
                            || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                    searchHandler.removeCallbacks(timeoutAction);
                    progressBar.setVisibility(View.GONE);
                    progressLoadMore.setVisibility(View.GONE);
                    tvError.setText(R.string.search_failed);
                    tvError.setVisibility(View.VISIBLE);
                });
            }
        }, "search-fetch-" + requestGeneration).start();
    }

    // ==================== 搜索页自定义颜色 ====================

    private void applySearchPageColors() {
        int toolbarBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveSearchToolbarBg();
        int inputBg   = com.forum.MT.ui.widget.HomeBarColorManager.resolveSearchInputBg();
        int sortBg    = com.forum.MT.ui.widget.HomeBarColorManager.resolveSearchSortBg();
        int contentBg = com.forum.MT.ui.widget.HomeBarColorManager.resolveSearchContentBg();
        int buttonBg  = com.forum.MT.ui.widget.HomeBarColorManager.resolveSearchButtonBg();

        toolbar.setBackgroundColor(toolbarBg);
        findViewById(R.id.layout_search_input_area).setBackgroundColor(inputBg);
        layoutSortBar.setBackgroundColor(sortBg);
        // 整页内容区背景，排除 toolbar / 输入区 / 排序栏
        View contentRoot = findViewById(R.id.search_content_root);
        if (contentRoot != null) {
            contentRoot.setBackgroundColor(contentBg);
        } else {
            // fallback：直接给根布局设置
            View root = findViewById(android.R.id.content);
            if (root != null) root.setBackgroundColor(contentBg);
        }
        // 搜索按钮背景
        if (btnSearch != null) {
            btnSearch.setBackgroundTintList(android.content.res.ColorStateList.valueOf(buttonBg));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        com.forum.MT.ui.widget.HomeBarColorManager.setListener(() -> {
            if (!isFinishing()) applySearchPageColors();
        });
    }

    @Override
    protected void onDestroy() {
        searchGeneration++;
        searchHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
        com.forum.MT.ui.widget.HomeBarColorManager.setListener(null);
    }
}
